// Đặt Android tối thiểu 7.0 (API 24) và target API 36 cho thư mục android/ vừa tạo.
const fs=require('fs');const f='android/variables.gradle';if(!fs.existsSync(f)){console.error('Chưa có android/. Chạy: npx cap add android');process.exit(1)}
let s=fs.readFileSync(f,'utf8');s=s.replace(/minSdkVersion\s*=\s*\d+/,'minSdkVersion = 24').replace(/compileSdkVersion\s*=\s*\d+/,'compileSdkVersion = 36').replace(/targetSdkVersion\s*=\s*\d+/,'targetSdkVersion = 36');fs.writeFileSync(f,s);console.log('OK: minSdk 24 (Android 7.0), target 36');
