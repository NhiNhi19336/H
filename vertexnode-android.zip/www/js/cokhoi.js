/* Cờ Lăn Khối (Rolling-Cube Chess) — an original board game for VertexNode.
   Each piece is a die-cube (opposite faces sum to 7). A move tips a cube one square, so its top face changes
   exactly as a real cube would; or spins it a quarter-turn in place. A cube may capture by rolling onto an enemy
   whose top is LOWER than its own new top — except a 1 can topple a 6. Reach an enemy gate square to win.
   VN.COKHOI.open(opts) opens the game in a modal. Pure logic lives in VN.COKHOI.L (tested headless). */
(function(){
'use strict';
const VN=window.VN||{};const T=VN.T||((a)=>a);
const N=6;                    /* board size */
/* ---------- die orientation: {t:top, n:north, e:east}; north = toward row+1 ---------- */
const roll={
 n:d=>({t:7-d.n,n:d.t,e:d.e}),
 s:d=>({t:d.n,n:7-d.t,e:d.e}),
 e:d=>({t:7-d.e,n:d.n,e:d.t}),
 w:d=>({t:d.e,n:d.n,e:7-d.t}),
 cw:d=>({t:d.t,n:7-d.e,e:d.n}),   /* spin clockwise seen from above */
 ccw:d=>({t:d.t,n:d.e,e:7-d.n})};
const DIR={n:[0,1],s:[0,-1],e:[1,0],w:[-1,0]};
/* all 24 orientations reachable from a real die (keeps one handedness) */
function orient(top,north){const seen=new Set(),q=[{t:1,n:2,e:3}];while(q.length){const d=q.shift(),k=d.t*100+d.n*10+d.e;if(seen.has(k))continue;seen.add(k);if(d.t===top&&(north==null||d.n===north))return d;for(const f of Object.values(roll))q.push(f(d))}return null}
/* ---------- state ---------- */
function newGame(){const P=[];const tops=[3,5,4,2,6,1].sort(()=>Math.random()-.5).slice(0,4);if(!tops.includes(5)&&!tops.includes(6))tops[0]=5;[0,1,4,5].forEach((c,i)=>{P.push({id:i,o:0,c,r:0,d:orient(tops[i])});P.push({id:i+4,o:1,c:N-1-c,r:N-1,d:orient(tops[i])})});return{p:P,turn:0,ply:0,win:-1,last:null,spun:[-1,-1],quiet:0}}
const GATES=o=>[[2,o?0:N-1],[3,o?0:N-1]];          /* the squares player o must reach */
const isGate=(o,c,r)=>r===(o?0:N-1)&&(c===2||c===3);
const at=(G,c,r)=>G.p.find(x=>x.c===c&&x.r===r);
const beats=(a,b)=>a>b||(a===1&&b===6);
function moves(G,o){const out=[];G.p.forEach((pc,i)=>{if(pc.o!==o)return;for(const k of ['n','s','e','w']){const c=pc.c+DIR[k][0],r=pc.r+DIR[k][1];if(c<0||r<0||c>=N||r>=N)continue;if(isGate(1-o,c,r))continue;const nd=roll[k](pc.d),oc=at(G,c,r);if(oc){if(oc.o===o)continue;if(!beats(nd.t,oc.d.t))continue}out.push({i,k,c,r,cap:!!oc})}if(G.spun[o]!==pc.id)out.push({i,k:'cw',c:pc.c,r:pc.r,spin:1},{i,k:'ccw',c:pc.c,r:pc.r,spin:1})});return out}
function apply(G,m){const H={p:G.p.map(x=>({id:x.id,o:x.o,c:x.c,r:x.r,d:x.d})),turn:G.turn,ply:G.ply+1,win:G.win,last:m,spun:G.spun.slice(),quiet:G.quiet+1};const pc=H.p[m.i];const o=pc.o;
 if(!m.spin){const vi=H.p.findIndex(x=>x.c===m.c&&x.r===m.r);if(vi>=0){H.p.splice(vi,1);H.quiet=0}H.spun[o]=-1;pc.c=m.c;pc.r=m.r;pc.d=roll[m.k](pc.d);if(isGate(o,pc.c,pc.r))H.win=o;if(!H.p.some(x=>x.o!==o))H.win=o}else{pc.d=roll[m.k](pc.d);H.spun[o]=pc.id}
 H.turn=1-o;if(H.win<0&&!moves(H,H.turn).some(x=>!x.spin)&&H.ply>0){/* only spins left: blocked = loss */H.win=o}if((H.ply>=240||H.quiet>=60)&&H.win<0)H.win=2;return H}
/* ---------- AI ---------- */
let NOISE=0;function evalG(G,o){if(G.win===o)return 1e6;if(G.win===1-o)return-1e6;if(G.win===2)return 0;let s=0;
 for(const pc of G.p){const me=pc.o===o?1:-1;const goal=pc.o?0:N-1,dist=Math.abs(goal-pc.r)+Math.max(0,Math.min(Math.abs(pc.c-2),Math.abs(pc.c-3)));s+=me*(100+pc.d.t*5+(7-dist)*(7-dist)*4+(pc.d.t===1?8:0))+(NOISE?(Math.random()-.5)*NOISE:0);
  /* threat: enemy cube adjacent that could capture me next */
  for(const k of ['n','s','e','w']){const q=at(G,pc.c+DIR[k][0],pc.r+DIR[k][1]);if(q&&q.o!==pc.o){const back={n:'s',s:'n',e:'w',w:'e'}[k];if(beats(roll[back](q.d).t,pc.d.t))s-=me*(G.turn===pc.o?8:45)}}}
 return s}
function search(G,o,depth,a,b){if(depth===0||G.win>=0)return[evalG(G,o)];const ms=moves(G,G.turn);ms.sort((x,y)=>(y.cap|0)-(x.cap|0)||(x.spin|0)-(y.spin|0));let best=null;
 if(G.turn===o){let v=-Infinity;for(const m of ms){const r=search(apply(G,m),o,depth-1,a,b)[0];if(r>v){v=r;best=m}a=Math.max(a,v);if(a>=b)break}return[v,best]}
 let v=Infinity;for(const m of ms){const r=search(apply(G,m),o,depth-1,a,b)[0];if(r<v){v=r;best=m}b=Math.min(b,v);if(a>=b)break}return[v,best]}
function aiMove(G,level){const o=G.turn,ms=moves(G,o);if(!ms.length)return null;
 /* always take an immediate win */
 for(const m of ms){if(apply(G,m).win===o)return m}
 if(level===0&&Math.random()<.45){const nm=ms.filter(m=>!m.spin);return(nm.length?nm:ms)[Math.floor(Math.random()*(nm.length||ms.length))]}
 const d=level===0?1:level===1?2:4;NOISE=level===2?3:8;const r=search(G,o,d,-Infinity,Infinity);NOISE=0;return r[1]||ms[0]}
const L={N,roll,orient,newGame,moves,apply,aiMove,beats,isGate,evalG};
/* ---------- view (canvas, isometric) ---------- */
let st=null;
function open(opts){opts=opts||{};if(!VN.modal)return;const m=VN.modal('<div class="ckw"><div class="ckhd"><h3>🎲 '+T('Cờ Lăn Khối','Rolling-Cube Chess')+'</h3><select id="ckMode" class="chip"><option value="1">'+T('Đấu máy · vừa','vs CPU · medium')+'</option><option value="0">'+T('Đấu máy · dễ','vs CPU · easy')+'</option><option value="2">'+T('Đấu máy · khó','vs CPU · hard')+'</option><option value="pvp">'+T('2 người, 1 máy','2 players, 1 device')+'</option></select></div>'+
 '<div class="ckst" id="ckSt"></div><canvas id="ckCv"></canvas><div class="row ckbar"><button class="btn g" id="ckL" disabled>⟲ '+T('Xoay trái','Spin left')+'</button><button class="btn g" id="ckR" disabled>⟳ '+T('Xoay phải','Spin right')+'</button><label class="mu"><input type="checkbox" id="ckHint" checked> '+T('Hiện mặt trên dự đoán','Show predicted top')+'</label><span class="sp"></span><button class="btn g" id="ckNew">↺ '+T('Ván mới','New game')+'</button></div>'+
 '<details class="ckrules"><summary>'+T('Luật chơi','Rules')+'</summary><ol>'+
 [T('Mỗi quân là một khối lập phương như xúc xắc: hai mặt đối nhau cộng lại bằng 7. Sức mạnh của quân = số chấm mặt trên.','Each piece is a die-cube: opposite faces add up to 7. Its strength = the top face.'),
  T('Đến lượt, chọn một khối rồi LĂN nó sang ô kề (lên, xuống, trái, phải). Khối lật đúng như ngoài đời nên mặt trên đổi theo.','On your turn, pick a cube and ROLL it to a neighbouring square. It tips like a real cube, so the top face changes.'),
  T('Hoặc XOAY khối tại chỗ 1/4 vòng: mặt trên giữ nguyên nhưng lần lăn sau sẽ ra mặt khác. Không xoay cùng một khối hai lượt liền.','Or SPIN it a quarter turn in place: the top stays, but the next roll will show a different face. You cannot spin the same cube two turns in a row.'),
  T('Ăn quân: lăn vào ô có quân địch khi mặt trên MỚI của bạn lớn hơn mặt trên của nó. Ngoại lệ: 1 chấm hạ được 6 chấm.','Capture: roll onto an enemy if your NEW top is bigger than its top. Exception: a 1 topples a 6.'),
  T('Thắng khi đưa một khối vào ô Cổng ✦ ở hàng cuối bên địch, hoặc ăn hết quân địch. Không được đứng chặn trên Cổng của chính mình. Bên chỉ còn nước xoay mà không lăn được thì thua.','Win by rolling a cube onto an enemy Gate ✦ on their back row, or by capturing every enemy cube. You may not park on your own Gate. A side that can only spin, never roll, loses.')].map(x=>'<li>'+x+'</li>').join('')+'</ol><p class="mu">'+T('Mẹo: trước khi lăn, hãy tưởng tượng khối lật — mặt phía sau (đối diện mặt trước) sẽ lên trên. Đây là bài tập trí tưởng tượng không gian.','Tip: before rolling, picture the tip-over — the face on the far side comes up top. It is spatial-imagination practice.')+'</p></details></div>');
 m.firstChild.classList.add('ckcard');
 st={G:newGame(),sel:-1,mode:'1',hint:true,busy:false,cv:m.querySelector('#ckCv'),m,anim:null,onWin:opts.onWin};
 m.querySelector('#ckMode').onchange=e=>{st.mode=e.target.value;reset()};m.querySelector('#ckNew').onclick=reset;m.querySelector('#ckHint').onchange=e=>{st.hint=e.target.checked;draw()};
 m.querySelector('#ckL').onclick=()=>spin('ccw');m.querySelector('#ckR').onclick=()=>spin('cw');
 st.cv.addEventListener('pointerup',tap);const ro=new ResizeObserver(()=>{if(!st||!st.cv.isConnected){ro.disconnect();return}size();draw()});ro.observe(st.cv);size();draw()}
function reset(){st.G=newGame();st.sel=-1;st.busy=false;draw()}
function size(){const cv=st.cv,w=Math.min(cv.parentElement.clientWidth||340,560),h=Math.round(w*.66),d=Math.min(2,devicePixelRatio||1);cv.style.width=w+'px';cv.style.height=h+'px';cv.width=w*d;cv.height=h*d;st.W=w;st.H=h;st.dpr=d;st.S=w/(N*2+1.2);st.ox=w/2;st.oy=(h-N*st.S)/2+st.S*.45}
/* grid -> screen; gx = column, gy = N-1-row (row 0 = your back row, nearest you) */
function P(c,r,z){const gx=c,gy=N-r;return[st.ox+(gx-gy)*st.S,st.oy+(gx+gy)*st.S*.5-(z||0)]}
function cellAt(x,y){/* try raised top faces first (front-most first) */const h=st.S*.95;const order=st.G.p.slice().sort((a,b)=>(b.c+(N-1-b.r))-(a.c+(N-1-a.r)));for(const pc of order){const [cx,cy]=P(pc.c+.5,pc.r-.5+1,h);/* centre of the top diamond */const q=diamond(pc.c,pc.r,h);if(inPoly(x,y,q))return[pc.c,pc.r]}
 for(let c=0;c<N;c++)for(let r=0;r<N;r++)if(inPoly(x,y,diamond(c,r,0)))return[c,r];return null}
function diamond(c,r,z){/* square cell c..c+1, r..r+1 (rows grow away from you) */return[P(c,r,z),P(c+1,r,z),P(c+1,r+1,z),P(c,r+1,z)]}
function inPoly(x,y,q){let s=false;for(let i=0,j=q.length-1;i<q.length;j=i++){const [xi,yi]=q[i],[xj,yj]=q[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)s=!s}return s}
const COL=[{top:'#e9fbff',l:'#9fd9ea',rr:'#c9eef7',pip:'#0b3b4a',edge:'#3f8fa6'},{top:'#ffe6ec',l:'#f0a2b6',rr:'#f7c6d2',pip:'#5a1023',edge:'#c0566f'}];
function pips(x,n,q){/* q = 4 corners of a face (screen), draw n pips by bilinear map */const L={1:[[.5,.5]],2:[[.27,.27],[.73,.73]],3:[[.25,.25],[.5,.5],[.75,.75]],4:[[.27,.27],[.73,.27],[.27,.73],[.73,.73]],5:[[.27,.27],[.73,.27],[.5,.5],[.27,.73],[.73,.73]],6:[[.27,.24],[.73,.24],[.27,.5],[.73,.5],[.27,.76],[.73,.76]]}[n]||[];
 const mp=(u,v)=>{const a=q[0],b=q[1],c=q[2],d=q[3];return[a[0]*(1-u)*(1-v)+b[0]*u*(1-v)+c[0]*u*v+d[0]*(1-u)*v,a[1]*(1-u)*(1-v)+b[1]*u*(1-v)+c[1]*u*v+d[1]*(1-u)*v]};
 const sz=Math.hypot(q[1][0]-q[0][0],q[1][1]-q[0][1])*.085;L.forEach(([u,v])=>{const [px,py]=mp(u,v);x.beginPath();x.ellipse(px,py,sz,sz*.72,0,0,7);x.fill()})}
function cube(x,pc,sel,dx,dy){const h=st.S*.95,c=pc.c,r=pc.r;const t=diamond(c,r,h).map(p=>[p[0]+(dx||0),p[1]+(dy||0)]),b=diamond(c,r,0).map(p=>[p[0]+(dx||0),p[1]+(dy||0)]);const K=COL[pc.o];
 /* visible side faces: south (toward you, row r) and east (column c+1) */
 const south=[t[0],t[1],b[1],b[0]],east=[t[1],t[2],b[2],b[1]];
 const face=(q,f)=>{x.fillStyle=f;x.beginPath();q.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.closePath();x.fill();x.strokeStyle=K.edge;x.lineWidth=1.2;x.stroke()};
 face(south,K.l);face(east,K.rr);face(t,K.top);x.fillStyle=K.pip;
 pips(x,pc.d.t,[t[3],t[2],t[1],t[0]]);x.globalAlpha=.75;pips(x,7-pc.d.n,south);pips(x,pc.d.e,[t[1],t[2],b[2],b[1]]);x.globalAlpha=1;
 if(sel){x.strokeStyle='#ffd23f';x.lineWidth=3;x.beginPath();t.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.closePath();x.stroke()}}
function draw(){if(!st)return;const cv=st.cv,x=cv.getContext('2d');x.setTransform(st.dpr,0,0,st.dpr,0,0);x.clearRect(0,0,st.W,st.H);const G=st.G;const dark=document.documentElement.classList.contains('dark')||matchMedia('(prefers-color-scheme: dark)').matches&&!document.documentElement.classList.contains('light');
 for(let c=0;c<N;c++)for(let r=0;r<N;r++){const q=diamond(c,r,0);x.fillStyle=(c+r)%2?(dark?'#2b2550':'#e7defa'):(dark?'#3a3170':'#f6f1ff');for(const o of [0,1])if(isGate(o,c,r))x.fillStyle=o?'rgba(255,170,190,.55)':'rgba(140,220,240,.55)';x.beginPath();q.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.closePath();x.fill();x.strokeStyle=dark?'rgba(255,255,255,.12)':'rgba(60,30,110,.15)';x.stroke();
  for(const o of [0,1])if(isGate(o,c,r)){const [gx,gy]=P(c+.5,r+.5,0);x.fillStyle=o?'#c0566f':'#3f8fa6';x.font='700 '+Math.round(st.S*.5)+'px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText('✦',gx,gy)}}
 /* legal targets */
 const ms=st.sel>=0?moves(G,G.turn).filter(m=>m.i===st.sel&&!m.spin):[];
 ms.forEach(m=>{const q=diamond(m.c,m.r,0);x.fillStyle=m.cap?'rgba(255,90,90,.35)':'rgba(255,210,63,.35)';x.beginPath();q.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.closePath();x.fill();
  if(st.hint&&!at(G,m.c,m.r)){const nt=roll[m.k](G.p[m.i].d).t;const [hx,hy]=P(m.c+.5,m.r+.5,0);x.fillStyle='#5b3fa0';x.font='800 '+Math.round(st.S*.55)+'px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText(String(nt),hx,hy)}});
 /* pieces back-to-front */
 const order=G.p.map((p,i)=>[p,i]).sort((a,b)=>(a[0].c+(N-1-a[0].r))-(b[0].c+(N-1-b[0].r)));order.forEach(([p,i])=>{if(st.anim&&st.anim.i===i)return;cube(x,p,i===st.sel)});
 if(st.anim){const A=st.anim,k=Math.min(1,(performance.now()-A.t0)/220),p=G.p[A.i];const [x0,y0]=P(A.from[0],A.from[1],0),[x1,y1]=P(p.c,p.r,0);cube(x,p,false,(x0-x1)*(1-k),(y0-y1)*(1-k)-Math.sin(k*Math.PI)*st.S*.35);if(k<1)requestAnimationFrame(draw);else{st.anim=null;requestAnimationFrame(draw)}}
 /* status */
 const s=st.m.querySelector('#ckSt'),pvp=st.mode==='pvp';const who=o=>pvp?(o?T('Hồng','Pink'):T('Xanh','Blue')):(o?T('Máy','CPU'):T('Bạn','You'));
 s.innerHTML=G.win>=0?(G.win===2?T('Hòa (60 nước liền không ai ăn quân).','Draw (60 moves without a capture).'):'🏆 <b>'+who(G.win)+'</b> '+T('thắng!','win!')):T('Lượt: ','Turn: ')+'<b style="color:'+(G.turn?'#c0566f':'#3f8fa6')+'">'+who(G.turn)+'</b>'+(st.sel>=0?' · '+T('chọn ô sáng để lăn, hoặc xoay','tap a lit square to roll, or spin'):' · '+T('chạm một khối của mình','tap one of your cubes'))+(G.last?'<small class="mu"> · '+T('nước trước: ','last: ')+({n:'↑',s:'↓',e:'→',w:'←',cw:'⟳',ccw:'⟲'}[G.last.k])+'</small>':'');
 const can=st.sel>=0&&G.win<0&&!st.busy;st.m.querySelector('#ckL').disabled=!can;st.m.querySelector('#ckR').disabled=!can}
function human(){return st.mode==='pvp'||st.G.turn===0}
function tap(e){if(!st||st.busy||st.G.win>=0||!human())return;const b=st.cv.getBoundingClientRect();const cell=cellAt(e.clientX-b.left,e.clientY-b.top);if(!cell)return;const G=st.G,pc=at(G,cell[0],cell[1]);
 if(st.sel>=0){const m=moves(G,G.turn).find(m=>m.i===st.sel&&!m.spin&&m.c===cell[0]&&m.r===cell[1]);if(m)return play(m)}
 if(pc&&pc.o===G.turn){st.sel=G.p.indexOf(pc)}else st.sel=-1;draw()}
function spin(k){if(st.sel<0)return;const m=moves(st.G,st.G.turn).find(m=>m.i===st.sel&&m.k===k);if(m)play(m)}
function play(m){const G=st.G,from=[G.p[m.i].c,G.p[m.i].r];const mover=G.p[m.i];st.G=apply(G,m);const ni=st.G.p.findIndex(p=>p.o===mover.o&&p.c===(m.spin?from[0]:m.c)&&p.r===(m.spin?from[1]:m.r));st.sel=m.spin&&human()?ni:-1;if(!m.spin)st.anim={i:ni,from,t0:performance.now()};
 VN.sfx&&VN.sfx(m.cap?'hit':'tap');draw();
 if(st.G.win>=0)return done();
 if(st.mode!=='pvp'&&st.G.turn===1){st.busy=true;st.sel=-1;draw();setTimeout(()=>{if(!st||!st.cv.isConnected)return;const am=aiMove(st.G,+st.mode);st.busy=false;if(am)play(am);else draw()},380)}}
function done(){draw();const G=st.G;if(st.mode!=='pvp'&&G.win===0){const lv=+st.mode;const coins=[10,20,40][lv],xp=[4,8,15][lv];VN.WORLD&&VN.WORLD.coin&&VN.WORLD.coin(coins,T('Cờ Lăn Khối','Rolling-Cube Chess'));VN.xp&&VN.xp(xp,'cokhoi');st.onWin&&st.onWin(lv)}}
VN.COKHOI={open,L};
})();
