/* Solve: one offline-first solver for geometry, physics and cross problems; calculator store; log of methods; optional Gemini (user key). */
(function(){
'use strict';
const {T,esc,fmt,$,$$,S}=VN,PI=Math.PI,X=VN.XLAB;
/* ================= parsing ================= */
const norm=s=>String(s).normalize('NFC').replace(/³/g,'3').replace(/²/g,'2').replace(/\^3/g,'3').replace(/\^2/g,'2').replace(/(\d),(\d)/g,'$1.$2').replace(/(\d)\s+(\d{3})(?!\d)/g,'$1$2');
const F=s=>VN.fold(norm(s));
const toM=(v,u)=>+v*({mm:.001,cm:.01,dm:.1,m:1,km:1000}[u||'cm']);
const NUMR='(-?\\d+(?:\\.\\d+)?)',UN='(mm|cm|dm|km|m)?(?![a-z0-9\\/])';
function lenAfter(t,kw,span){const m=kw.exec(t);if(!m)return null;const seg=t.slice(m.index+m[0].length,m.index+m[0].length+(span||34)),r=new RegExp('(?:la|bang|=|:|\\s)\\s*'+NUMR+'\\s*'+UN).exec(seg);return r?{v:toM(r[1],r[2]),assumed:!r[2],raw:+r[1],u:r[2]||'cm'}:null}
function lensAll(t){const o=[],re=new RegExp(NUMR+'\\s*(mm|cm|dm|km|m)(?![a-z0-9\\/])','g');let m;while((m=re.exec(t)))o.push({v:toM(m[1],m[2]),pos:m.index,u:m[2],raw:+m[1]});return o}
function dens(t){const o=[],re=/(\d+(?:\.\d+)?)\s*(kg\/m3|g\/cm3|kg\/l|g\/ml|kg\/lit)/g;let m;while((m=re.exec(t))){const v=+m[1]*(m[2]==='kg/m3'?1:1000),pre=t.slice(Math.max(0,m.index-34),m.index);o.push({v,pos:m.index,fluid:/(nuoc|chat long|long|dau|xang|thuy ngan|glycerin|ruou|dich)\s*[a-z ]{0,14}(?:co|la|bang|=|:)?\s*(?:khoi luong rieng|ty trong)?[^0-9]*$/.test(pre)&&!/(vat|khoi|qua|vien|go|nhua|sat|thep|nhom|dong|da)\s*[a-z ]{0,10}[^0-9]*$/.test(pre.slice(-18))})}return o}
const FLUIDS=[[/nuoc bien/,1025,['nước biển','seawater']],[/thuy ngan/,13600,['thủy ngân','mercury']],[/xang/,750,['xăng','petrol']],[/dau an/,920,['dầu ăn','cooking oil']],[/dau hoa/,800,['dầu hỏa','kerosene']],[/glycerin|glixerin/,1260,['glycerin','glycerine']],[/\bnuoc\b|water/,1000,['nước','water']],[/\bdau\b|\boil\b/,800,['dầu','oil']]];
const gVal=t=>{const m=/\bg\s*=\s*(\d+(?:\.\d+)?)/.exec(t);return m?+m[1]:9.81};
const mass=t=>{const m=/(\d+(?:\.\d+)?)\s*(kg|g)(?![a-z0-9\/])/.exec(t);return m?(m[2]==='g'?+m[1]/1000:+m[1]):null};
const angle=t=>{const m=/(\d+(?:\.\d+)?)\s*(?:do\b|°|deg)/.exec(t);return m?+m[1]:null};
const G=v=>fmt(v,4);
function shapeOf(t){if(/lap phuong|khoi vuong|\bcube\b/.test(t))return'cube';if(/\bcau\b|sphere|\bball\b/.test(t))return'sph';if(/\btru\b|cylinder/.test(t))return'cyl';if(/\bnon\b|\bcone\b/.test(t))return'cone';if(/khoi chu nhat|hop chu nhat|\bhop\b|cuboid|\bbox\b|khoi go|\bblock\b|tam van|vien gach|\bgach\b/.test(t))return'box';return null}
const R=(ttl,data,ask,steps,ans,tip,methods,extra)=>Object.assign({ttl,data,ask,steps,ans,tip:tip||'',alt:[],methods:methods||[],cross:true},extra||{});
const need=(m)=>({err:T('Thiếu dữ kiện: ','Missing data: ')+m,cross:true,miss:true});
/* ================= cross solvers ================= */
function dimsOf(t,shape){const L=lensAll(t),o={};
 if(shape==='cube'){const a=lenAfter(t,/canh/)||(L[0]&&{v:L[0].v});if(a)o.a=a.v}
 else if(shape==='sph'){const r=lenAfter(t,/ban kinh|\br\b/),d=lenAfter(t,/duong kinh|\bd\b/);if(r)o.r=r.v;else if(d)o.r=d.v/2;else if(L[0])o.r=L[0].v}
 else if(shape==='cyl'||shape==='cone'){const r=lenAfter(t,/ban kinh|\br\b/),d=lenAfter(t,/duong kinh|\bd\b/),h=lenAfter(t,/chieu cao|\bcao\b|\bh\b/);if(r)o.r=r.v;else if(d)o.r=d.v/2;if(h)o.h=h.v;const nums=L.map(x=>x.v);if(o.r==null&&nums.length)o.r=nums[0];if(o.h==null&&nums.length>1)o.h=nums[1]}
 else if(shape==='box'){const a=lenAfter(t,/\bdai\b|chieu dai/),b=lenAfter(t,/\brong\b|chieu rong/),c=lenAfter(t,/chieu cao|\bcao\b|day\b|do day/);if(a)o.a=a.v;if(b)o.b=b.v;if(c)o.c=c.v;const nums=L.map(x=>x.v);let i=0;['a','b','c'].forEach(k=>{if(o[k]==null){while(i<nums.length&&Object.values(o).includes(nums[i]))i++;if(i<nums.length)o[k]=nums[i++]}})}
 return o}
function floatSolve(raw){const t=F(raw);if(!/noi|chim|tha vao|tha xuong|luc day|archimedes|float|sink|buoyan|submerg|immers|ngap/.test(t))return null;const sh=shapeOf(t);if(!sh)return null;
 const dm=dimsOf(t,sh),g=gVal(t),ds=dens(t);let rf=null,fname=T('nước','water');
 const dfl=ds.find(d=>d.fluid);if(dfl){rf=dfl.v;fname=T('chất lỏng','the liquid')}else{for(const f of FLUIDS){if(f[0].test(t)){rf=f[1];fname=T(f[2][0],f[2][1]);break}}}
 if(rf==null&&ds.length>1)rf=ds[ds.length-1].v;if(rf==null)rf=1000;
 let V,desc,dimTxt,vert;
 const dtxt=[];let Vm;
 switch(sh){
  case'cube':if(dm.a==null)return need(T('cạnh a của khối lập phương','edge a of the cube'));V=dm.a**3;vert=dm.a;dimTxt=T('V = a³ = ','V = a³ = ')+G(dm.a)+'³';desc=T('Khối lập phương cạnh ','Cube with edge ')+G(dm.a*100)+' cm';break;
  case'box':if(dm.a==null||dm.b==null||dm.c==null)return need(T('ba kích thước dài, rộng, cao của khối hộp','the length, width and height of the box'));V=dm.a*dm.b*dm.c;vert=dm.c;dimTxt='V = abc';desc=T('Khối hộp ','Box ')+G(dm.a*100)+'×'+G(dm.b*100)+'×'+G(dm.c*100)+' cm';break;
  case'cyl':if(dm.r==null||dm.h==null)return need(T('bán kính và chiều cao hình trụ','radius and height of the cylinder'));V=PI*dm.r*dm.r*dm.h;vert=dm.h;dimTxt='V = πr²h';desc=T('Hình trụ đứng r = ','Upright cylinder r = ')+G(dm.r*100)+' cm, h = '+G(dm.h*100)+' cm';break;
  case'sph':if(dm.r==null)return need(T('bán kính hình cầu','radius of the sphere'));V=4*PI*dm.r**3/3;vert=2*dm.r;dimTxt='V = 4πr³/3';desc=T('Hình cầu r = ','Sphere r = ')+G(dm.r*100)+' cm';break;
  case'cone':if(dm.r==null||dm.h==null)return need(T('bán kính đáy và chiều cao hình nón','base radius and height of the cone'));V=PI*dm.r*dm.r*dm.h/3;vert=dm.h;dimTxt='V = πr²h/3';desc=T('Hình nón r = ','Cone r = ')+G(dm.r*100)+' cm, h = '+G(dm.h*100)+' cm';break}
 const apexDown=!/day xuong|base down|day huong xuong|dat day/.test(t);
 /* object density */
 let rho=null,rhoFrom='';const dob=ds.find(d=>!d.fluid);const m=mass(t.replace(/(\d+(?:\.\d+)?)\s*(kg\/m3|g\/cm3|kg\/l|g\/ml)/g,' '));
 if(dob){rho=dob.v;rhoFrom=T('Khối lượng riêng của vật ρ = ','Body density ρ = ')+G(rho)+' kg/m³'}
 else if(m!=null){rho=m/V;rhoFrom=T('ρ = m/V = ','ρ = m/V = ')+G(m)+' / '+G(V)+' = '+G(rho)+' kg/m³'}
 else{const dr=/(ty trong|ty khoi|do ca)\s*(?:la|bang|=)?\s*(\d+(?:\.\d+)?)/.exec(t);if(dr){rho=+dr[2]*1000;rhoFrom=T('Tỉ trọng ','Relative density ')+dr[2]+' ⇒ ρ = '+G(rho)+' kg/m³'}}
 if(rho==null)return need(T('khối lượng riêng (kg/m³ hay g/cm³) hoặc khối lượng của vật','the body density (kg/m³ or g/cm³) or its mass'));
 const q=rho/rf,steps=[];
 steps.push([T('Thể tích vật','Body volume'),dimTxt+' = '+G(V)+' m³ ('+G(V*1000)+' L)']);steps.push([T('Khối lượng riêng','Densities'),rhoFrom+'; '+T('của ','of ')+fname+': ρ_l = '+G(rf)+' kg/m³']);
 const qq=q;let h,fr,FB,Wt=rho*V*g,verdict;
 const solveSph=()=>{const r=dm.r;let lo=0,hi=2*r;const tgt=qq*4*PI*r**3/3;for(let i=0;i<100;i++){const mid=(lo+hi)/2;(PI*mid*mid*(3*r-mid)/3<tgt)?lo=mid:hi=mid}return(lo+hi)/2};
 if(qq>1+1e-12){verdict='sink';FB=rf*g*V;steps.push([T('So sánh','Compare'),'ρ = '+G(rho)+' > ρ_l = '+G(rf)+' ⇒ '+T('vật chìm hẳn','the body sinks')]);steps.push([T('Lực đẩy Archimedes','Buoyant force'),'F_A = ρ_l·g·V = '+G(rf)+'·'+G(g)+'·'+G(V)+' = '+G(FB)+' N']);steps.push([T('Trọng lượng biểu kiến','Apparent weight'),'P − F_A = '+G(Wt)+' − '+G(FB)+' = '+G(Wt-FB)+' N']);
  return R(T('Vật thả vào chất lỏng: nổi hay chìm','Body in a liquid: float or sink'),[desc,rhoFrom],T('Nổi hay chìm, lực đẩy','Float or sink, buoyant force'),steps,T('Chìm. F_A = ','Sinks. F_A = ')+G(FB)+' N',T('Chìm khi ρ_vật > ρ_lỏng.','It sinks when ρ_body > ρ_fluid.'),['archimedes','density','volume'])}
 if(Math.abs(qq-1)<1e-9){steps.push([T('So sánh','Compare'),'ρ = ρ_l ⇒ '+T('lơ lửng','neutrally buoyant')]);return R(T('Vật thả vào chất lỏng','Body in a liquid'),[desc,rhoFrom],T('Nổi hay chìm','Float or sink'),steps,T('Lơ lửng; F_A = P = ','Neutral; F_A = P = ')+G(Wt)+' N','',['archimedes'])}
 steps.push([T('So sánh','Compare'),'ρ = '+G(rho)+' < ρ_l = '+G(rf)+' ⇒ '+T('vật nổi','the body floats')]);steps.push([T('Điều kiện cân bằng','Equilibrium'),'F_A = P ⇒ ρ_l·V_chìm = ρ·V ⇒ V_chìm/V = ρ/ρ_l = '+G(qq)]);
 let depthTxt;
 if(sh==='cube'||sh==='box'||sh==='cyl'){h=vert*qq;depthTxt=T('Ngập sâu h = c·(ρ/ρ_l) = ','Draft h = c·(ρ/ρ_f) = ')+G(vert)+'·'+G(qq)+' = '+G(h)+' m'}
 else if(sh==='sph'){h=solveSph();depthTxt=T('Giải V_chìm = πh²(3r − h)/3 = (ρ/ρ_l)·4πr³/3 cho h: h = ','Solve V_sub = πh²(3r − h)/3 = (ρ/ρ_f)·4πr³/3 for h: h = ')+G(h)+' m'}
 else if(apexDown){h=vert*Math.cbrt(qq);depthTxt=T('Nón đỉnh xuống: (h/H)³ = ρ/ρ_l ⇒ h = H·∛(ρ/ρ_l) = ','Apex down: (h/H)³ = ρ/ρ_f ⇒ h = H·∛(ρ/ρ_f) = ')+G(h)+' m'}
 else{h=vert*(1-Math.cbrt(1-qq));depthTxt=T('Nón đáy xuống: 1 − (1 − h/H)³ = ρ/ρ_l ⇒ h = H(1 − ∛(1 − ρ/ρ_l)) = ','Base down: 1 − (1 − h/H)³ = ρ/ρ_f ⇒ h = H(1 − ∛(1 − ρ/ρ_f)) = ')+G(h)+' m'}
 steps.push([T('Độ ngập sâu','Depth submerged'),depthTxt]);FB=rf*g*qq*V;steps.push([T('Lực đẩy Archimedes','Buoyant force'),'F_A = ρ_l·g·V_chìm = P = ρ·V·g = '+G(FB)+' N']);
 if(sh==='cone')steps.push([T('Giả thiết','Assumption'),apexDown?T('Nón đặt đỉnh hướng xuống (ghi "đáy xuống" để đổi).','Cone floats apex down (write "base down" to change).'):T('Nón đặt đáy hướng xuống.','Cone floats base down.')]);
 steps.push([T('Lấy g','Using g'),'g = '+G(g)+' m/s²'+(/\bg\s*=/.test(t)?'':T(' (ghi "g = 10" trong đề để đổi)',' (write "g = 10" in the problem to change)'))]);
 return R(T('Vật thả vào chất lỏng: nổi hay chìm','Body in a liquid: float or sink'),[desc,rhoFrom],T('Phần chìm, độ ngập, lực đẩy','Submerged part, draft, buoyant force'),steps,T('Nổi: chìm ','Floats: ')+G(qq*100)+T(' % thể tích, ngập ',' % submerged, draft ')+G(h*100)+' cm, F_A = '+G(FB)+' N',T('Phần chìm của vật nổi luôn bằng ρ_vật/ρ_lỏng (theo thể tích).','The submerged fraction of a floating body is always ρ_body/ρ_fluid (by volume).'),['archimedes','density','volume'],{lab:'float'})}
function pressSolve(raw){const t=F(raw);if(!/ap suat|luc len mat|pressure|do sau/.test(t))return null;if(/\d\s*n\s*\/\s*m(3|³)/.test(t))return null;
 const g=gVal(t);let rf=1000,fname=T('nước','water');const ds=dens(t);if(ds.length)rf=ds[0].v;else for(const f of FLUIDS){if(f[0].test(t)){rf=f[1];fname=T(f[2][0],f[2][1]);break}}
 const sh=shapeOf(t),dep=lenAfter(t,/do sau|cach mat nuoc|mat tren cach|depth|duoi mat nuoc|o do sau/),atm=/khi quyen|atm|atmosph/.test(t)?101325:0;
 if(!dep)return null;
 if(sh!=='cube'&&sh!=='box'){/* plain hydrostatic pressure */const p=rf*g*dep.v;return R(T('Áp suất chất lỏng','Hydrostatic pressure'),[T('Độ sâu h = ','Depth h = ')+G(dep.v)+' m',T('ρ = ','ρ = ')+G(rf)+' kg/m³'],T('Áp suất tại độ sâu h','Pressure at depth h'),[[T('Công thức','Formula'),'p = ρ·g·h'],[T('Thay số','Substitute'),'p = '+G(rf)+'·'+G(g)+'·'+G(dep.v)+' = '+G(p)+' Pa'],...(atm?[[T('Cộng khí quyển','Add atmosphere'),'p_tổng = '+G(p)+' + 101325 = '+G(p+atm)+' Pa']]:[])],'p = '+G(p+atm)+' Pa',T('Áp suất chỉ phụ thuộc độ sâu, không phụ thuộc hình dạng bình.','Pressure depends only on depth, not on the vessel’s shape.'),['pressure'])}
 const dm=dimsOf(t.replace(/(do sau|cach mat nuoc)[^.;]*?(\d+(?:\.\d+)?)\s*(mm|cm|dm|m)\b/,' '),sh);const a=dm.a!=null&&sh==='cube'?dm.a:dm.a,b=sh==='cube'?dm.a:dm.b,c=sh==='cube'?dm.a:dm.c;
 if(a==null||b==null||c==null)return need(T('kích thước khối (cạnh, hoặc dài–rộng–cao)','the solid’s dimensions (edge, or length–width–height)'));
 const A=a*b,V=A*c,pt=atm+rf*g*dep.v,pb=atm+rf*g*(dep.v+c),Ft=pt*A,Fb=pb*A,FA=Fb-Ft,zc=dep.v===0?2*c/3:(2/3)*(((dep.v+c)**3-dep.v**3)/((dep.v+c)**2-dep.v**2));
 return R(T('Áp suất và lực lên các mặt của khối chìm','Pressure and forces on the faces of a submerged solid'),[T('Khối ','Solid ')+G(a*100)+'×'+G(b*100)+'×'+G(c*100)+' cm',T('Mặt trên cách mặt thoáng ','Top face at depth ')+G(dep.v*100)+' cm',T('ρ = ','ρ = ')+G(rf)+' kg/m³ ('+fname+')'],T('p và F lên mặt trên, dưới; lực đẩy','p and F on top and bottom; buoyancy'),
  [[T('Áp suất mặt trên','Top pressure'),'p₁ = ρgd = '+G(rf)+'·'+G(g)+'·'+G(dep.v)+' = '+G(rf*g*dep.v)+' Pa'+(atm?' (+101325)':'')],[T('Áp suất mặt dưới','Bottom pressure'),'p₂ = ρg(d + H) = '+G(pb-atm)+' Pa'+(atm?' (+101325)':'')],[T('Lực lên mặt trên (xuống)','Force on top (down)'),'F₁ = p₁·S = '+G(pt)+'·'+G(A)+' = '+G(Ft)+' N'],[T('Lực lên mặt dưới (lên)','Force on bottom (up)'),'F₂ = p₂·S = '+G(pb)+'·'+G(A)+' = '+G(Fb)+' N'],[T('Hợp lực thẳng đứng','Net vertical force'),'F₂ − F₁ = '+G(FA)+' N = ρ·g·V = '+G(rf*g*V)+' N  (Archimedes)'],[T('Lực lên một mặt bên đứng','Force on a vertical side'),'F = ρg(d + H/2)·(mặt bên)',],[T('Điểm đặt áp lực mặt bên (độ sâu)','Centre of pressure of a side'),'z = (2/3)·((d+H)³ − d³)/((d+H)² − d²) = '+G(zc)+' m'],[T('Hợp lực ngang','Net horizontal force'),'0 N '+T('(hai mặt bên đối nhau triệt tiêu)','(opposite sides cancel)')]],
  T('Lực đẩy Archimedes = ','Buoyant force = ')+G(FA)+' N; p₁ = '+G(pt)+' Pa, p₂ = '+G(pb)+' Pa',T('Áp suất khí quyển cộng như nhau mọi mặt nên không đổi lực đẩy.','Atmospheric pressure adds equally on all faces and does not change the buoyancy.'),['pressure','archimedes','volume'],{lab:'press'})}
function tipSolve(raw){const t=F(raw);if(!/\blat\b|topple|\btip\b|tip over/.test(t)||!/nghieng|incline|slope/.test(t))return null;
 const sh=shapeOf(t);if(sh!=='box'&&sh!=='cube')return null;const dm=dimsOf(t,sh);let w=sh==='cube'?dm.a:(dm.b!=null?Math.min(dm.a||1e9,dm.b):dm.a),h=sh==='cube'?dm.a:dm.c;
 const wr=lenAfter(t,/\brong\b|chieu rong|\bday\b|do rong/),hh=lenAfter(t,/\bcao\b|chieu cao/);if(wr)w=wr.v;if(hh)h=hh.v;if(!w||!h)return need(T('chiều rộng đáy và chiều cao của khối','the base width and height of the block'));
 const mu=/(he so ma sat|\bmu\b|μ)\s*(?:la|bang|=|:)?\s*(\d+(?:\.\d+)?)/.exec(t),th=Math.atan(w/h)*180/PI,steps=[[T('Trọng tâm','Centre of mass'),T('Khối đồng chất hình chữ nhật: G ở chính giữa, cách mặt dốc h/2 = ','Uniform rectangle: G is at the centre, h/2 = ')+G(h/2*100)+' cm']],data=[T('Rộng đáy ','Base width ')+G(w*100)+' cm',T('Cao ','Height ')+G(h*100)+' cm'];
 steps.push([T('Điều kiện lật','Tipping condition'),T('Khối bắt đầu lật quanh mép dưới khi đường thẳng đứng qua G đi qua mép đó: tanθ = (w/2)/(h/2) = w/h','The block starts to tip about its lower edge when the vertical through G passes that edge: tanθ = (w/2)/(h/2) = w/h')]);steps.push([T('Góc lật','Tipping angle'),'θ_lật = arctan(' +G(w)+'/'+G(h)+') = '+G(th)+'°']);
 let ans=T('Lật ở θ = ','Tips at θ = ')+G(th)+'°';
 if(mu){const ts=Math.atan(+mu[2])*180/PI;data.push('μ = '+mu[2]);steps.push([T('Điều kiện trượt','Sliding condition'),'tanθ = μ ⇒ θ_trượt = arctan('+mu[2]+') = '+G(ts)+'°']);steps.push([T('So sánh','Compare'),th<ts?T('Góc lật nhỏ hơn ⇒ khối lật trước khi kịp trượt.','Tipping angle is smaller ⇒ it tips before it can slide.'):T('Góc trượt nhỏ hơn ⇒ khối trượt trước khi lật.','Sliding angle is smaller ⇒ it slides before it tips.')]);ans+=T('; trượt ở ','; slides at ')+G(ts)+'° ⇒ '+(th<ts?T('lật trước','tips first'):T('trượt trước','slides first'))}
 return R(T('Khối trên mặt phẳng nghiêng: lật hay trượt','Block on an incline: tip or slide'),data,T('Góc lật / trượt','Tipping / sliding angle'),steps,ans,T('Khối cao và hẹp lật dễ hơn; ma sát lớn thì lật trước khi trượt.','Tall and narrow blocks tip more easily; with high friction it tips before it slides.'),['centroid','incline'],{lab:'cm'})}
function centroidSolve(raw){const t=F(raw);if(!/trong tam|khoi tam|centroid|centre of mass|center of mass/.test(t))return null;
 const pts=[...String(raw).replace(/(\d),(\d)/g,'$1.$2').matchAll(/([A-Za-z])\s*\(\s*(-?\d+(?:\.\d+)?)\s*[;,]\s*(-?\d+(?:\.\d+)?)\s*\)/g)].map(m=>[+m[2],+m[3]]);
 if(pts.length<4)return null;const c=X.centroid(pts);if(!isFinite(c.x))return null;
 let s='';const n=pts.length;for(let i=0;i<n;i++){const[a,b]=pts[i],[d,e]=pts[(i+1)%n];s+=(i?' + ':'')+'('+G(a)+'·'+G(e)+' − '+G(d)+'·'+G(b)+')'}
 return R(T('Trọng tâm đa giác (hình đồng chất)','Centroid of a polygon (uniform plate)'),[T('Đỉnh: ','Vertices: ')+pts.map(p=>'('+G(p[0])+'; '+G(p[1])+')').join(', ')],'G',[[T('Diện tích (shoelace)','Area (shoelace)'),'A = ½|Σ(xᵢyᵢ₊₁ − xᵢ₊₁yᵢ)| = '+G(c.A)],[T('Tọa độ trọng tâm','Centroid'),'x_G = Σ(xᵢ+xᵢ₊₁)(xᵢyᵢ₊₁−xᵢ₊₁yᵢ)/(6A) = '+G(c.x)],['','y_G = Σ(yᵢ+yᵢ₊₁)(xᵢyᵢ₊₁−xᵢ₊₁yᵢ)/(6A) = '+G(c.y)]],'G('+G(c.x)+'; '+G(c.y)+')',T('Trọng tâm hình học = khối tâm khi bản đồng chất.','The geometric centroid is the centre of mass for a uniform plate.'),['centroid','area'],{lab:'cm'})}
const BODY=[[/cau dac|solid sphere/,2/5,['Quả cầu đặc','Solid sphere'],'2/5'],[/cau rong|vo cau|hollow sphere|thin.walled sphere/,2/3,['Cầu rỗng','Hollow sphere'],'2/3'],[/tru dac|dia\b|disc|disk|solid cylinder|hinh tru dac/,1/2,['Trụ đặc / đĩa','Solid cylinder / disc'],'1/2'],[/vanh|vong|\bong\b|ring|hoop|hollow cylinder|tru rong/,1,['Vành / ống','Ring / hoop'],'1']];
function rollSolve(raw){const t=F(raw);if(!/\blan\b|roll/.test(t)||!/nghieng|incline|slope|doc\b/.test(t))return null;
 let b=BODY.find(x=>x[0].test(t));if(!b&&/\bcau\b|sphere/.test(t))b=BODY[0];if(!b&&/\btru\b|cylinder/.test(t))b=BODY[2];if(!b)return need(T('loại vật (cầu đặc, cầu rỗng, trụ đặc, vành)','the body (solid sphere, hollow sphere, solid cylinder, ring)'));
 const g=gVal(t);let th=angle(t);const Ln=lenAfter(t,/\bdai\b|chieu dai|length|quang duong/),H=lenAfter(t,/do cao|cao\b|height/);let L=Ln?Ln.v:null;
 if(th==null&&H&&Ln)th=Math.asin(Math.min(1,H.v/Ln.v))*180/PI;if(th==null)return need(T('góc nghiêng (hoặc độ cao và chiều dài dốc)','the slope angle (or height and slope length)'));
 if(L==null&&H)L=H.v/Math.sin(th*PI/180);
 const k=b[1],s=Math.sin(th*PI/180),a=g*s/(1+k),mumin=k*Math.tan(th*PI/180)/(1+k),steps=[[T('Mô hình','Model'),T('Lăn không trượt: m·a = mg·sinθ − f; I·α = f·R; a = αR; I = k·mR²','Rolling without slipping: m·a = mg·sinθ − f; I·α = f·R; a = αR; I = k·mR²')],[T('Hệ số quán tính','Inertia factor'),'k = I/(mR²) = '+b[3]+' ('+T(b[2][0],b[2][1])+')'],[T('Gia tốc','Acceleration'),'a = g·sinθ/(1+k) = '+G(g)+'·sin'+G(th)+'°/(1+'+G(k)+') = '+G(a)+' m/s²']];
 let ans='a = '+G(a)+' m/s²';
 if(L!=null){const tt=Math.sqrt(2*L/a),v=Math.sqrt(2*a*L);steps.push([T('Thời gian xuống','Time down'),'t = √(2L/a) = √(2·'+G(L)+'/'+G(a)+') = '+G(tt)+' s']);steps.push([T('Vận tốc ở chân dốc','Speed at the bottom'),'v = √(2aL) = '+G(v)+' m/s']);ans+='; t = '+G(tt)+' s; v = '+G(v)+' m/s'}
 steps.push([T('Điều kiện không trượt','No-slip condition'),'μ ≥ k·tanθ/(1+k) = '+G(mumin)]);steps.push([T('Lưu ý','Note'),T('a không phụ thuộc khối lượng hay bán kính, chỉ phụ thuộc hình dạng (k).','a does not depend on mass or radius, only on the shape (k).')]);
 return R(T('Vật lăn không trượt xuống mặt phẳng nghiêng','Body rolling down an incline'),[T(b[2][0],b[2][1]),T('Góc dốc ','Slope ')+G(th)+'°',...(L!=null?[T('Chiều dài dốc ','Slope length ')+G(L)+' m']:[]),'g = '+G(g)+' m/s²'],T('Gia tốc, thời gian, vận tốc','Acceleration, time, speed'),steps,ans,T('Thứ tự về đích: khối trượt > cầu đặc > trụ đặc > cầu rỗng > vành.','Finishing order: block > solid sphere > solid cylinder > hollow sphere > ring.'),['rolling','incline','energy'],{lab:'roll'})}
function forceSolve(raw){const t=F(raw);if(!/hop luc|luc tong hop|resultant|net force/.test(t)||!/\d\s*n\b/.test(t))return null;const fs=[...t.matchAll(/(\d+(?:\.\d+)?)\s*n\b/g)].map(m=>+m[1]);if(fs.length<2)return need(T('hai lực (N)','two forces (N)'));
 const F1=fs[0],F2=fs[1];let al=angle(t);if(al==null&&/vuong goc|perpendicular|right angle/.test(t))al=90;if(al==null&&/cung huong|same direction/.test(t))al=0;if(al==null&&/nguoc huong|opposite/.test(t))al=180;if(al==null)return need(T('góc giữa hai lực (hoặc "vuông góc", "cùng hướng", "ngược hướng")','the angle between the forces (or "perpendicular", "same direction", "opposite")'));
 const a=al*PI/180,Fr=Math.sqrt(F1*F1+F2*F2+2*F1*F2*Math.cos(a)),b=Math.atan2(F2*Math.sin(a),F1+F2*Math.cos(a))*180/PI;
 return R(T('Tổng hợp hai lực (cộng vectơ)','Resultant of two forces (vector sum)'),['F₁ = '+G(F1)+' N','F₂ = '+G(F2)+' N',T('Góc giữa hai lực α = ','Angle α = ')+G(al)+'°'],T('Hợp lực F','Resultant F'),[[T('Quy tắc hình bình hành','Parallelogram rule'),'F² = F₁² + F₂² + 2F₁F₂cosα'],[T('Thay số','Substitute'),'F = √('+G(F1)+'² + '+G(F2)+'² + 2·'+G(F1)+'·'+G(F2)+'·cos'+G(al)+'°) = '+G(Fr)+' N'],[T('Hướng của F so với F₁','Direction of F from F₁'),'tanβ = F₂sinα/(F₁ + F₂cosα) ⇒ β = '+G(b)+'°']],'F = '+G(Fr)+' N',T('Vuông góc: Pytago; cùng hướng: cộng; ngược hướng: trừ.','Perpendicular: Pythagoras; same direction: add; opposite: subtract.'),['vector','pythagoras'],{lab:''})}
function orbitSolve(raw){const t=F(raw);if(!/quy dao|orbit|elip|ellipse/.test(t)||!/tam sai|eccentric|\be\s*=/.test(t))return null;const em=/(?:tam sai|eccentricity|\be)\s*(?:la|bang|=|:)?\s*(\d+(?:\.\d+)?)/.exec(t);if(!em)return null;const e=+em[1];if(e<0)return null;
 const type=e<1e-9?T('đường tròn','circle'):e<1?T('elip','ellipse'):e===1?T('parabol','parabola'):T('hypebol','hyperbola');const steps=[[T('Phân loại','Classify'),'e = '+G(e)+' ⇒ '+type+T(e<1?' (quỹ đạo kín, vật bị buộc)':' (vật thoát khỏi thiên thể)',e<1?' (closed orbit, bound)':' (escapes the body)')],[T('Phương trình quỹ đạo','Orbit equation'),'r = p/(1 + e·cosφ)']];
 const am=/(?:ban truc lon|semi.major)[^0-9]{0,14}(\d+(?:\.\d+)?)\s*(mm|cm|m|km)?/.exec(t);let ans=T('Quỹ đạo ','Orbit: ')+type;
 if(am&&e<1){const a=+am[1],u=am[2]||'',rp=a*(1-e),ra=a*(1+e),b=a*Math.sqrt(1-e*e);steps.push([T('Cận điểm','Periapsis'),'r_p = a(1 − e) = '+G(rp)+' '+u]);steps.push([T('Viễn điểm','Apoapsis'),'r_a = a(1 + e) = '+G(ra)+' '+u]);steps.push([T('Bán trục nhỏ','Semi-minor axis'),'b = a√(1 − e²) = '+G(b)+' '+u]);steps.push([T('Tỉ số vận tốc','Speed ratio'),'v_p/v_a = r_a/r_p = (1 + e)/(1 − e) = '+G((1+e)/(1-e))+T(' (bảo toàn mô men động lượng)',' (angular momentum conservation)')]);ans+='; r_p = '+G(rp)+' '+u+', r_a = '+G(ra)+' '+u}
 else if(am&&e>1){const a=+am[1],u=am[2]||'';steps.push([T('Cận điểm','Periapsis'),'r_p = a(e − 1) = '+G(a*(e-1))+' '+u]);ans+='; r_p = '+G(a*(e-1))+' '+u}
 steps.push([T('Liên hệ mặt cắt nón','Cone-section link'),T('e = cosβ/cosα: β là góc mặt phẳng cắt hợp với trục nón, α là nửa góc ở đỉnh.','e = cosβ/cosα: β is the angle between the cutting plane and the cone axis, α the half-angle of the cone.')]);
 return R(T('Quỹ đạo conic','Conic orbit'),['e = '+G(e)],T('Dạng quỹ đạo và các điểm đặc biệt','Orbit type and key points'),steps,ans,T('e = 0 tròn, 0 < e < 1 elip, e = 1 parabol, e > 1 hypebol.','e = 0 circle, 0 < e < 1 ellipse, e = 1 parabola, e > 1 hyperbola.'),['conic','kepler'],{lab:'orbit'})}
const CROSS=[pressSolve,floatSolve,tipSolve,rollSolve,centroidSolve,forceSolve,orbitSolve];
VN.crossSolve=function(raw){for(const f of CROSS){let r;try{r=f(raw)}catch(e){console.error(e);r=null}if(r)return r}return null};
/* hint when the text looks cross-disciplinary but data is missing, so geo's partial answer is not shown as if it solved the question */
const PHYWORDS=/noi|chim|tha vao|luc|ap suat|khoi luong rieng|archimedes|lan\b|quy dao|van toc|gia toc|nang luong|cong suat|dien|nhiet|song|anh sang|\bn\b|\bj\b|m\/s|kg\b/;
const GEOWORDS=/hinh|canh|the tich|dien tich|duong cheo|goc|ban kinh|chop|lang tru|mat cau|tam giac|vecto|toa do|mat phang|duong thang|khoi|cube|sphere|volume|area|edge|radius|triangle|vector|plane|diagonal/;
/* ================= method tags ================= */
const METHODS={volume:['Công thức thể tích','Volume formulas'],area:['Công thức diện tích','Area formulas'],pythagoras:['Định lý Pytago','Pythagoras'],heron:['Công thức Heron','Heron’s formula'],vector:['Vectơ','Vectors'],archimedes:['Lực đẩy Archimedes','Buoyancy'],density:['Khối lượng riêng','Density'],pressure:['Áp suất','Pressure'],centroid:['Trọng tâm','Centroids'],incline:['Mặt phẳng nghiêng','Inclined plane'],rolling:['Chuyển động lăn','Rolling motion'],energy:['Bảo toàn năng lượng','Energy conservation'],conic:['Đường conic','Conics'],kepler:['Quỹ đạo / Kepler','Orbits / Kepler'],coords:['Tọa độ trong không gian','Coordinates in space'],trig:['Lượng giác','Trigonometry'],kinematics:['Động học','Kinematics'],dynamics:['Động lực học','Dynamics'],circuit:['Điện','Electricity'],other:['Tổng hợp','General'],sumdiff:['Tổng – hiệu, tổng – tỉ','Sum–difference'],calculus:['Tích phân','Integrals'],inertia:['Mômen quán tính','Moment of inertia'],oscillation:['Dao động','Oscillations'],optics:['Quang hình','Geometric optics'],lever:['Đòn bẩy, mômen','Levers, moments'],hyper:['Hình học nhiều chiều','Higher dimensions']};
const MAPK=[[/the tich|volume|v = /,'volume'],[/dien tich|stp|sxq|area/,'area'],[/pytago|pythag|√\(.*².*²/,'pythagoras'],[/heron/,'heron'],[/vecto|vector|tich vo huong|dot product/,'vector'],[/archimedes|luc day/,'archimedes'],[/khoi luong rieng|density/,'density'],[/ap suat|pressure/,'pressure'],[/trong tam|centroid|centre of mass/,'centroid'],[/nghieng|incline/,'incline'],[/\blan\b|roll/,'rolling'],[/nang luong|dong nang|the nang|cong\b|energy/,'energy'],[/conic|elip|ellipse|hypebol|parabol/,'conic'],[/kepler|quy dao|orbit/,'kepler'],[/toa do|khoang cach|coordinate|distance/,'coords'],[/sin|cos|tan|luong giac/,'trig'],[/van toc|gia toc|quang duong|velocity|accelerat/,'kinematics'],[/luc\b|newton|force/,'dynamics'],[/dien|dong dien|cuong do|circuit|ohm/,'circuit']];
function tagMethods(txt,given){const set=new Set(given||[]);const f=F(txt);MAPK.forEach(m=>{if(m[0].test(f))set.add(m[1])});if(!set.size)set.add('other');return[...set].slice(0,4)}
/* ================= rendering ================= */
const sanitize=h=>{const d=new DOMParser().parseFromString('<body>'+h+'</body>','text/html');d.querySelectorAll('script,iframe,object,embed,link,meta,style').forEach(n=>n.remove());d.querySelectorAll('*').forEach(n=>[...n.attributes].forEach(a=>{if(/^on/i.test(a.name)||/^javascript:/i.test(a.value))n.removeAttribute(a.name)}));return d.body.innerHTML};
function stepsHtml(r){return(r.data&&r.data.length?'<div class="step"><b>'+T('Dữ kiện','Given')+'</b>'+r.data.map(esc).join('<br>')+'</div>':'')+(r.ask?'<div class="step"><b>'+T('Cần tìm','Find')+'</b>'+esc(r.ask)+'</div>':'')+r.steps.map((s,i)=>'<div class="step"><b>'+(i+1)+'. '+esc(s[0])+'</b>'+(/<[a-z]/.test(String(s[1]))&&!r.cross?String(s[1]):esc(s[1]))+'</div>').join('')+'<div class="ans">'+T('Đáp số','Answer')+': '+esc(r.ans)+'</div>'+(r.tip?'<div class="mu" style="margin-top:6px">💡 '+esc(r.tip)+'</div>':'')+((r.alt||[]).length?'<div class="mu" style="margin-top:4px">'+r.alt.map(a=>'↪ '+esc(a)).join('<br>')+'</div>':'')}
const dec=x=>S.lg==='en'||x==null?x:String(x).replace(/(\d)\.(\d)/g,'$1,$2');
function geoToRes(g){return{ttl:g.ttl,data:(g.data||[]).map(dec),ask:g.ask,steps:(g.steps||[]).map(s=>[s[0],dec(s[1])]),ans:dec(g.ans),tip:g.tip,alt:g.alt||[],g:g.g,cross:false,geo:true,txt:g.txt}}
/* ================= routing ================= */
const last={raw:'',eng:'',res:null};
const FUK={r:'ban kinh',d:'duong kinh',a:'canh|chieu dai|day lon|\\bdai',b:'chieu rong|day be|\\brong',c:'chieu cao',h:'chieu cao|do cao|\\bcao',l:'chieu dai|\\bdai',m:'khoi luong',v:'van toc|toc do',f:'tieu cu',k:'do cung',p:'chu vi',s:'dien tich'};
const FU=/^\s*(?:doi|thay|neu|cho|gia su|change|set|what if|if)?\s*([a-zA-Zα-ω][a-zA-Z0-9_]{0,3})\s*(?:=|bang|la)\s*(-?\d+(?:[.,]\d+)?)\s*(?:cm|mm|dm|m|kg|g|n|s|°)?\s*(?:thi|then)?[\s.!?]*$/;
async function route(raw){raw=String(raw).replace(/−/g,'-').replace(/(\w)\s*–\s*(\w)/g,'$1-$2').replace(/[ \u00a0]+/g,' ');const t=F(raw);
 if(/^\s*(ve|draw|ve hinh|hay ve)\b/.test(t)&&VN.FIG){const f=VN.FIG.html(raw.replace(/^\s*(vẽ hình|vẽ|hãy vẽ|draw)\s*/i,''));if(f)return{kind:'fig',fig:f};return{kind:'none',text:T('Mình chưa vẽ được hình này. Thử: "vẽ hình chóp S.ABCD đáy hình vuông, SA vuông góc đáy".','I cannot draw that yet. Try: "draw pyramid S.ABCD with a square base, SA perpendicular to the base".')}}
 /* 1) follow-up: change one number of the previous problem */
 if(last.raw&&FU.test(t)){const m=FU.exec(t),sym=m[1],val=m[2].replace(',','.');
  if(last.eng==='geo'){try{const s=await VN.eng.geo.call('tutor',raw);if(s&&!/chua|not recogn|không|unable/i.test(s.slice(0,40))){last.raw=raw;return{kind:'geo',text:s,ttl:T('Đổi số','Changed number'),ans:s.split('\n').filter(x=>/Đáp số|Answer|✅/.test(x)).join(' ').replace(/^✅\s*/,'')||'',methods:tagMethods(last.raw)}}}catch(e){}}
  const re=new RegExp('(\\b'+sym+'\\s*=\\s*)(-?\\d+(?:[.,]\\d+)?)','i');if(re.test(last.raw)){const nr=last.raw.replace(re,'$1'+val);return await route2(nr,true)}
  const kw=FUK[sym.toLowerCase()];if(kw){const rw=last.raw.normalize('NFC'),fo=VN.fold(rw),km=new RegExp('(?:'+kw+')[^0-9]{0,24}?(\\d+(?:[.,]\\d+)?)').exec(fo);if(km){const at=km.index+km[0].length-km[1].length;const nr=rw.slice(0,at)+val.replace('.',',')+rw.slice(at+km[1].length);const o=await route2(nr,true);if(o&&o.kind!=='none'){o.fu=nr}return o}}
  return{kind:'none',text:T('Mình chưa biết đổi số nào trong đề trước. Hãy gõ lại đề với số mới.','I do not know which number of the previous problem to change. Please retype the problem with the new number.')}}
 return route2(raw)}
async function route2(raw,fromFU){raw=String(raw).replace(/−/g,'-').replace(/(\w)\s*–\s*(\w)/g,'$1-$2').replace(/[ \u00a0]+/g,' ');const t=F(raw);
 const cr=VN.crossSolve(raw);
 if(cr&&!cr.err){last.raw=raw;last.eng='cross';return{kind:'cross',res:cr,methods:tagMethods(cr.ttl+' '+cr.steps.map(s=>s[0]).join(' '),cr.methods)}}
 const xs=VN.xsolve?VN.xsolve(raw):null;
 if(xs&&xs.err&&!(cr&&cr.err))return{kind:'none',text:xs.err};
 if(xs&&!xs.err){last.raw=raw;last.eng='xs';return{kind:'xs',res:xs,methods:xs.methods&&xs.methods.length?xs.methods:tagMethods(xs.ttl)}}
 let [g,p]=await Promise.all([VN.eng.geo.call('solve',raw).catch(()=>({err:'x'})),VN.eng.phy.call('solve',raw).catch(()=>'')]);
 const gOk=g&&!g.err,pOk=!!p;
 const pw=PHYWORDS.test(t),gw=GEOWORDS.test(t);
 /* cross-looking text with missing data: do not present a partial geometry answer as the solution */
 if(cr&&cr.err&&!pOk){return{kind:'none',text:cr.err+'\n'+T('Hãy bổ sung rồi gửi lại. Mở "Lab" để thử bằng thanh trượt.','Add it and send again. Open "Lab" to try it with sliders.')}}
 if(gOk&&pOk){const gs=(GEOWORDS.test(t)?1:0)+(t.match(/hinh|canh|the tich|dien tich|ban kinh/g)||[]).length,ps=(t.match(/luc|van toc|gia toc|khoi luong|nang luong|cong|\bn\b|\bj\b|m\/s|kg/g)||[]).length;
  if(ps>gs)return mkPhy(raw,p,{g})}
 if(gOk){last.raw=raw;last.eng='geo';try{VN.eng.geo.call('tutor',raw).catch(()=>0)}catch(e){}const r=VN.fitLevel(raw,geoToRes(g));return{kind:'geo',res:r,methods:tagMethods(g.ttl+' '+(g.steps||[]).map(s=>s[0]+' '+s[1]).join(' ')),alt:pOk?{p}:null}}
 if(pOk)return mkPhy(raw,p);
 /* 2) offline tutor knowledge base (hints, formulas) */
 let tut='';try{tut=await VN.eng.geo.call('tutor',raw)}catch(e){}
 const nrm=x=>String(x).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
 if(tut&&/\d/.test(raw)&&/(tinh|tim|hoi|bao nhieu|may gio|find|compute)/.test(nrm(raw))){const q=nrm(raw),head=nrm(tut.split('\n').slice(0,2).join(' ')).replace(/\([^)]*\)/g,' ').replace(/[^a-z ]/g,' ').split(/\s+/).filter(w=>w.length>1&&!/^(hinh|khoi|cua|va|cac|la|mot|the|of|and)$/.test(w));let hit=0;for(let i=0;i+1<head.length;i++)if(q.includes(head[i]+' '+head[i+1]))hit++;if(!hit)tut=''}
 if(tut&&!/^(Chào|Hi!)/.test(tut)&&tut.length>20){last.raw=raw;last.eng='geo';return{kind:'tutor',text:tut,methods:tagMethods(tut)}}
 if(/^(Chào|Hi!)/.test(tut||''))return{kind:'none',text:tut}
 /* 3) library search */
 const hits=VN.libSearch(raw,5);
 /* 4) Gemini with the user's own key */
 if(aiOn()){try{const a=await gem(raw);return{kind:'ai',text:a,methods:tagMethods(raw+' '+a),hits}}catch(e){return{kind:'none',text:T('Không nhờ được AI: ','AI request failed: ')+e.message,hits}}}
 return{kind:'none',text:T('Mình chưa nhận ra dạng bài này bằng quy tắc offline. Hãy thử viết rõ số liệu và đơn vị, hoặc xem gợi ý bên dưới. (Có thể thêm khóa Gemini của bạn trong ⚙ để hỏi tự do.)','I could not recognise this problem with the offline rules. Try stating the numbers and units clearly, or see the suggestions below. (You can add your own Gemini key in ⚙ for free-form questions.)'),hits}}
VN.route=route;
function mkPhy(raw,p,extra){last.raw=raw;last.eng='phy';const d=document.createElement('div');d.innerHTML=sanitize(p);const txt=d.textContent.replace(/\s+/g,' ').trim(),grp=/(?:Nhóm kiến thức|Topic):\s*([^\n]{3,60}?)(?=\s*1\.|$)/.exec(txt);
 return Object.assign({kind:'phy',html:sanitize(p),text:txt,methods:tagMethods(txt.slice(0,400)),topic:grp?grp[1]:''},extra||{})}
/* ================= library search (832 items, offline) ================= */
let LIDX=null;
VN.libSearch=function(q,k){if(!LIDX)LIDX=(window.LIBDATA?LIBDATA.items:[]).map(it=>({it,n:VN.fold(it.vi[0]+' '+it.en[0]),b:VN.fold(it.vi[0]+' '+it.vi[1]+' '+it.en[0]+' '+it.en[1]+' '+(it.q||''))}));
 const tk=[...new Set(VN.fold(q).split(/[^a-z0-9]+/).filter(w=>w.length>2))];if(!tk.length)return[];
 return LIDX.map(o=>({it:o.it,s:tk.reduce((a,w)=>a+(o.n.includes(w)?3:0)+(o.b.includes(w)?1:0),0)})).filter(o=>o.s>=2).sort((a,b)=>b.s-a.s).slice(0,k||8).map(o=>o.it)};
/* ================= Gemini (optional, user key) ================= */
const hist=[];
let aiLeft=null;const PROXY=()=>((window.VN_CFG&&VN_CFG.proxy)||'').trim();
function aiOn(){return navigator.onLine!==false&&!!(S.gk||PROXY())}
async function gemProxy(q,H){if(!S.did){S.did=Math.random().toString(36).slice(2,12)+Date.now().toString(36);VN.save()}const lv=VN.level?VN.level(q):null;const ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),35000);
 try{const r=await fetch(PROXY(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({q:q.slice(0,1200),hist:(H||hist).slice(-4),lg:S.lg,grade:lv&&lv.lbl||'',did:S.did}),signal:ctl.signal});const d=await r.json().catch(()=>({}));
  if(r.status===429)throw new Error(T('Hết lượt AI tài trợ hôm nay. Bộ giải offline vẫn dùng được; mai quay lại nhé.','Sponsored AI is used up for today. The offline solver still works; come back tomorrow.'));
  if(!r.ok||!d.text)throw new Error(T('AI tài trợ đang bận, thử lại sau.','Sponsored AI is busy, try later.'));aiLeft=d.left;if(!H)hist.push({role:'user',parts:[{text:q.slice(0,1500)}]},{role:'model',parts:[{text:d.text.slice(0,3000)}]});return d.text}finally{clearTimeout(tm)}}
VN.aiAsk=async(q,H)=>{if(S.gk)return gem(q);if(!PROXY())throw new Error(T('Chưa bật AI tài trợ.','Sponsored AI is not set up.'));return gemProxy(q,H)};VN.aiOn=()=>!!(S.gk||PROXY());
async function gem(q){if(!S.gk&&PROXY())return gemProxy(q);const sys=T('Bạn là gia sư hình học và vật lý trong ứng dụng VertexNode. Giải từng bước, chính xác, đúng chương trình; kiểm tra lại phép tính và nói rõ nếu chưa chắc. Trả lời cùng ngôn ngữ với người hỏi. Chỉ trả lời về toán hình học, vật lý và các liên hệ giữa chúng.','You are the geometry and physics tutor inside VertexNode. Solve step by step, accurately and at the right level; double-check arithmetic and say so when unsure. Answer in the asker’s language. Only answer about geometry, physics and their connections.');
 const msgs=[...hist.slice(-6),{role:'user',parts:[{text:q.slice(0,6000)}]}];const ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),35000);
 try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':S.gk},body:JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents:msgs,generationConfig:{temperature:.3,maxOutputTokens:1800}}),signal:ctl.signal});
  const d=await r.json().catch(()=>({}));if(d.error)throw new Error(d.error.message||'Gemini error');const c=((d.candidates||[])[0]||{}).content,tx=c&&c.parts?c.parts.map(p=>p.text||'').join(''):'';if(!tx)throw new Error(T('Phản hồi trống','Empty response'));
  hist.push({role:'user',parts:[{text:q.slice(0,2000)}]},{role:'model',parts:[{text:tx.slice(0,3000)}]});return tx}finally{clearTimeout(tm)}}
/* ================= UI ================= */
let root,msgs,tab='chat',busy=false;
const EX=[['Khối lập phương cạnh 10 cm khối lượng riêng 600 kg/m³ thả vào nước. Tính phần chìm và lực đẩy','A cube with edge 10 cm and density 600 kg/m³ is placed in water. Find the submerged part and the buoyant force'],
 ['Khối chữ nhật rộng 6 cm cao 15 cm đặt trên mặt phẳng nghiêng, μ = 0,5. Lật hay trượt trước?','A block 6 cm wide and 15 cm tall sits on an incline, μ = 0.5. Does it tip or slide first?'],
 ['Quả cầu đặc lăn không trượt xuống dốc 30° dài 2 m. Tính gia tốc và thời gian','A solid sphere rolls without slipping down a 30° slope 2 m long. Find the acceleration and the time'],
 ['Hình chóp tứ giác đều cạnh đáy 6 cm chiều cao 4 cm. Tính thể tích và diện tích toàn phần','A regular square pyramid, base 6 cm, height 4 cm. Find the volume and total surface area'],
 ['Vật 2 kg rơi tự do từ độ cao 20 m. Tính vận tốc chạm đất','A 2 kg body falls freely from 20 m. Find the impact speed'],
 ['Tính khoảng cách từ M(1;2;3) đến mặt phẳng 2x+y−2z+1=0','Find the distance from M(1;2;3) to the plane 2x+y−2z+1=0'],
 ['Hai lực 30 N và 40 N hợp nhau góc 90°. Tính hợp lực','Two forces of 30 N and 40 N make an angle of 90°. Find the resultant'],
 ['Quỹ đạo có tâm sai e = 0,6, bán trục lớn 10000 km. Tính cận điểm và viễn điểm','An orbit has eccentricity e = 0.6 and semi-major axis 10000 km. Find periapsis and apoapsis']];
function init(el){root=el;el.innerHTML='<div class="wrap" style="display:flex;flex-direction:column;flex:1;min-height:0;width:100%"><div class="row" style="justify-content:space-between;margin-bottom:6px"><span class="seg" id="sgT"></span><span class="tag" id="sgS"></span></div><div id="sgB" style="flex:1;min-height:0;overflow:auto"></div><div id="sbox" style="padding-top:8px"><textarea id="sgI" rows="2" maxlength="900"></textarea><div class="row" style="flex-direction:column"><button class="btn" id="sgGo">➤</button><button class="btn g" id="sgMic" title="">🔊</button></div></div></div>';
 $('#sgT').onclick=e=>{const b=e.target.closest('button');if(b){tab=b.dataset.t;render()}};
 $('#sgGo').onclick=()=>send();$('#sgI').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send()}});
 $('#sgMic').onclick=async()=>{try{const v=await VN.eng.geo.call('vstat');VN.toast(v.ok?T('Giọng offline sẵn sàng: ','Offline voice ready: ')+v.name:T('Chưa có giọng offline; dùng giọng mạng nếu có.','No offline voice installed; using a network voice if available.'))}catch(e){}};
 msgs=[]}
function render(){if(!root)return;$('#sgT').innerHTML=[['chat',T('Trò chuyện','Chat')],['calc',T('Kho tính','Calculators')],['log',T('Nhật ký','Log')]].map(x=>'<button data-t="'+x[0]+'" class="'+(tab===x[0]?'on':'')+'">'+x[1]+'</button>').join('');
 $('#sgS').textContent=aiOn()?(S.gk?T('Offline + AI của bạn','Offline + your AI'):T('Offline + AI tài trợ','Offline + sponsored AI')+(aiLeft!=null?' · '+aiLeft+T(' lượt',' left'):'')):T('Offline 100%','100% offline');
 $('#sbox').style.display=tab==='chat'?'':'none';$('#sgI').placeholder=T('Dán đề hoặc hỏi (hình học, vật lý, liên ngành)…','Paste a problem or ask (geometry, physics, cross)…');
 if(tab==='chat')chat();else if(tab==='calc')calcTab();else logTab()}
function chat(){const b=$('#sgB');if(!msgs.length){b.innerHTML='<div class="card"><h3>'+T('Gia sư hình học × vật lý (offline)','Geometry × physics tutor (offline)')+'</h3><p class="mu">'+T('Dán đề bài: mình giải từng bước ngay trên máy, không cần mạng. Nói "r = 5" để đổi số của đề trước. Chạm một ví dụ để thử:','Paste a problem: I solve it step by step on your device, no network needed. Say "r = 5" to change a number of the previous problem. Tap an example:')+'</p><div class="links">'+EX.map((e,i)=>'<button class="chip" data-ex="'+i+'" style="white-space:normal;text-align:left">'+esc(T(e[0],e[1]))+'</button>').join('')+'</div></div>';b.onclick=e=>{const x=e.target.closest('[data-ex]');if(x)send(T(EX[+x.dataset.ex][0],EX[+x.dataset.ex][1]))};return}
 b.onclick=chatClick;b.innerHTML=msgs.map((m,i)=>'<div class="msg'+(m.u?' u':'')+'" data-i="'+i+'">'+m.h+'</div>').join('');b.scrollTop=b.scrollHeight}
function chatClick(e){const bt=e.target.closest('[data-a]');if(!bt)return;const i=+bt.closest('.msg').dataset.i,m=msgs[i],a=bt.dataset.a;
 if(a==='say'){VN.eng.geo.call(m.geo?'speakSolve':'speakText',m.geo?m.raw:m.speak).then(ok=>{if(!ok)VN.toast(T('Thiết bị chưa có giọng đọc','No voice available'))}).catch(()=>{})}
 else if(a==='stop')VN.eng.geo.call('stopSpeak').catch(()=>{});
 else if(a==='draw')VN.go('learn',{eng:'geo',tab:'mJ',q:m.raw});
 else if(a==='lab')VN.go('lab',{lab:m.lab});
 else if(a==='ai'){bt.disabled=true;gem(m.raw).then(t=>push(botBox(S.gk?T('🤖 AI của bạn (kiểm tra lại kết quả)','🤖 Your AI (double-check the result)'):T('🤖 AI tài trợ (kiểm tra lại kết quả)','🤖 Sponsored AI (double-check the result)'),'<pre>'+esc(t)+'</pre>'))).catch(er=>VN.toast(er.message))}
 else if(a==='fav'){S.fav=S.fav||[];if(!S.fav.includes(m.raw)){S.fav.unshift(m.raw);S.fav=S.fav.slice(0,30);VN.save();VN.toast('★ '+T('Đã lưu','Saved'))}}
 else if(a==='hit'){const it=(window.LIBDATA?LIBDATA.items:[]).find(x=>x.id===bt.dataset.id);if(it)push(botBox(T(it.vi[0],it.en[0]),'<div>'+esc(T(it.vi[1],it.en[1]))+'</div>'))}}
const botBox=(title,html)=>'<b>'+esc(title)+'</b>'+html;
function push(h,o){msgs.push(Object.assign({h},o||{}));if(tab==='chat')chat()}
function actions(o){return '<div class="links" style="margin-top:8px"><button class="chip" data-a="say">🔊 '+T('Đọc','Read')+'</button><button class="chip" data-a="stop">⏹</button>'+(o.draw?'<button class="chip" data-a="draw">✏️ '+T('Vẽ hình','Draw it')+'</button>':'')+(o.lab?'<button class="chip" data-a="lab">🧪 '+T('Thử trong Lab','Try in the Lab')+'</button>':'')+(aiOn()?'<button class="chip" data-a="ai">🤖 '+T('Hỏi thêm AI','Ask the AI')+'</button>':'')+'<button class="chip" data-a="fav">★</button></div>'}
async function send(text){if(busy)return;const raw=(text||$('#sgI').value).trim();if(!raw)return;if(tab!=='chat'){tab='chat';render()}$('#sgI').value='';busy=true;
 push(esc(raw),{u:1});const waitIdx=msgs.length;push('<span class="mu">'+T('Đang giải…','Solving…')+'</span>');
 let r;try{r=await route(raw)}catch(e){console.error(e);r={kind:'none',text:T('Có lỗi khi giải: ','Error while solving: ')+e.message}}
 let h='',o={raw};
 if(r.kind==='cross'||r.kind==='xs'||r.kind==='geo'&&r.res){const rs=r.res;h=(r.fu?'<div class="mu" style="margin-bottom:4px">↻ '+esc(r.fu)+'</div>':'')+'<div class="steps"><b>'+esc(rs.ttl)+'</b>'+(rs.lv?' <span class="tag lv lv-'+rs.band+'">'+esc(rs.lv)+'</span>':rs.g?' <span class="tag">'+T('Lớp ','Grade ')+rs.g+'</span>':'')+(rs.note?'<div class="mu">⚠ '+esc(rs.note)+'</div>':'')+(rs.cross?' <span class="tag">'+T('Liên ngành','Cross')+'</span>':'')+stepsHtml(rs)+(VN.FIG?VN.FIG.html(r.fu||raw,rs):'')+'</div>'+actions({draw:!rs.cross&&!rs.xs,lab:!!rs.lab});o.geo=!!rs.geo;o.lab=rs.lab;o.speak=rs.ttl+'. '+rs.steps.map((s,i)=>T('Bước ','Step ')+(i+1)+'. '+s[0]+'. '+s[1]).join('. ')+'. '+T('Đáp số: ','Answer: ')+rs.ans;
  if(rs.cross){VN.bump('cross',1)}
  if(r.alt&&r.alt.p){/* also physics reading */}}
 else if(r.kind==='phy'){h='<div class="steps"><span class="tag">'+T('Vật lý','Physics')+'</span>'+r.html+'</div>'+actions({});o.speak=r.text;if(r.kind==='phy'&&r.g&&!r.g.err)h+='<div class="mu" style="margin-top:6px">'+T('Đề cũng có thể hiểu theo hình học: ','The text can also be read as geometry: ')+esc(r.g.ttl)+' → '+esc(r.g.ans)+'</div>'}
 else if(r.kind==='geo'||r.kind==='tutor'){h='<pre>'+esc(r.text)+'</pre>'+(r.kind==='geo'&&VN.FIG?VN.FIG.html(raw):'')+actions({draw:true});o.speak=r.text}
 else if(r.kind==='ai'){h='<b>🤖 '+T('AI của bạn (kiểm tra lại kết quả)','Your AI (double-check)')+'</b><pre>'+esc(r.text)+'</pre>'+actions({});o.speak=r.text}
 else if(r.kind==='fig'){h='<b>✏️ '+T('Hình vẽ theo đề','Figure from the problem')+'</b>'+r.fig+'<div class="mu" style="margin-top:6px">'+T('Kéo để xoay hình không gian. Gửi kèm số liệu và câu hỏi để mình giải.','Drag to rotate solids. Add numbers and a question and I will solve it.')+'</div>'}
 else{h='<pre>'+esc(r.text||'')+'</pre>'+(VN.FIG&&VN.FIG.has(raw)?VN.FIG.html(raw):'')}
 if(r.hits&&r.hits.length)h+='<div class="mu" style="margin-top:8px">'+T('Có thể bạn đang tìm:','You might be looking for:')+'</div><div class="links">'+r.hits.map(x=>'<button class="chip" data-a="hit" data-id="'+x.id+'">'+esc(T(x.vi[0]||x.vi[1].slice(0,30),x.en[0]||x.en[1].slice(0,30)))+'</button>').join('')+'</div>';
 msgs[waitIdx]=Object.assign({h},o);
 /* record in the log */
 if(r.kind!=='none'){const rs=r.res||{};S.hist=S.hist||[];S.hist.unshift({ts:Date.now(),q:raw.slice(0,240),k:r.kind,ttl:rs.ttl||r.topic||'',ans:(rs.ans||r.ans||'').toString().slice(0,100),m:r.methods||[]});S.hist=S.hist.slice(0,200);S.methods=S.methods||{};(r.methods||[]).forEach(k=>S.methods[k]=(S.methods[k]||0)+1);
  S.stat.solved=(S.stat.solved||0)+1;if(S.stat.solved%1===0){VN.xp(r.kind==='cross'?6:4,'solve')}VN.bump('solve',1);VN.save()}
 busy=false;if(tab==='chat')chat()}
function calcTab(){const b=$('#sgB');b.onclick=null;b.innerHTML='<div class="card"><h3>🧮 '+T('Kho tính hình học (không cần mạng)','Geometry calculators (no network)')+'</h3><div id="cgBody" class="mu">'+T('Đang tải…','Loading…')+'</div></div><div class="card"><h3>⚛ '+T('Kho công thức vật lý','Physics formula vault')+'</h3><p class="mu">'+T('Chọn công thức, đổi số, tìm ẩn bất kỳ: có sẵn trong mục Học → Vật lý → Kho công thức.','Pick a formula, change numbers, solve for any unknown: Learn → Physics → Formula vault.')+'</p><button class="btn g" id="cgPhy">'+T('Mở kho công thức','Open the formula vault')+'</button> <button class="btn g" id="cgLib">'+T('Tìm trong thư viện','Search the library')+'</button></div><div id="cgLibB"></div>';
 $('#cgPhy').onclick=()=>VN.go('learn',{eng:'phy',tab:'fx'});$('#cgLib').onclick=()=>libUI();
 VN.eng.geo.call('calcList').then(list=>{let cur=0;const draw=()=>{const e=list[cur];$('#cgBody').innerHTML='<div class="row"><select id="cgS">'+list.map((x,i)=>'<option value="'+i+'"'+(i===cur?' selected':'')+'>'+esc(T(x.vi,x.en))+'</option>').join('')+'</select>'+(e.nu?'':'<select id="cgU"><option>mm</option><option selected>cm</option><option>dm</option><option>m</option></select>')+'</div><div class="row" style="margin-top:8px" id="cgF">'+e.p.map(f=>'<label>'+esc(T(f[1],f[2]))+'<br><input data-k="'+f[0]+'" inputmode="decimal" value="'+f[3]+'" style="width:96px"></label>').join('')+'</div><div class="row" style="margin-top:8px"><button class="btn" id="cgGo">'+T('Tính & giải thích','Compute & explain')+'</button></div>';
   $('#cgS').onchange=()=>{cur=+$('#cgS').value;draw()};$('#cgGo').onclick=async()=>{const v={};$$('#cgF input').forEach(i=>v[i.dataset.k]=parseFloat(String(i.value).replace(',','.')));const u=$('#cgU')?$('#cgU').value:'cm';try{const txt=await VN.eng.geo.call('calcText',e.id,v,u);tab='chat';render();send(txt)}catch(er){VN.toast(er.message)}}};draw()}).catch(()=>{$('#cgBody').textContent=T('Không tải được kho tính.','Could not load the calculators.')})}
function libUI(){const b=$('#cgLibB');b.innerHTML='<div class="card"><div class="row"><input id="lq" placeholder="'+T('Tìm: thể tích, áp suất, Euler, lực đẩy…','Search: volume, pressure, Euler, buoyancy…')+'" style="flex:1"></div><div id="lr" style="margin-top:8px"></div></div>';
 const run=()=>{const q=$('#lq').value;const hs=q.trim().length>1?VN.libSearch(q,14):[];$('#lr').innerHTML=hs.length?hs.map(h=>'<div class="step"><b>'+esc(T(h.vi[0]||h.c,h.en[0]||h.c))+' <span class="tag">'+(h.k==='g'?T('Hình','Geo'):T('Lý','Phy'))+'</span></b>'+esc(T(h.vi[1],h.en[1]))+'</div>').join(''):'<span class="mu">'+(q.trim().length>1?T('Không thấy mục nào.','Nothing found.'):T('Gõ từ khóa (832 mục, hình + lý).','Type a keyword (832 entries, geometry + physics).'))+'</span>'};
 $('#lq').oninput=run;run();$('#lq').focus()}
function logTab(){const b=$('#sgB');b.onclick=e=>{const r=e.target.closest('[data-re]');if(r){tab='chat';render();send(S.hist[+r.dataset.re].q)}const f=e.target.closest('[data-fv]');if(f){tab='chat';render();send(S.fav[+f.dataset.fv])}};
 const H=S.hist||[],M=Object.entries(S.methods||{}).sort((a,b)=>b[1]-a[1]),mx=M.length?M[0][1]:1;
 b.innerHTML='<div class="card"><h3>📊 '+T('Cách giải bạn hay dùng','Methods you use most')+'</h3>'+(M.length?M.slice(0,8).map(m=>'<div style="margin:6px 0"><div class="row" style="justify-content:space-between"><span>'+esc(T((METHODS[m[0]]||METHODS.other)[0],(METHODS[m[0]]||METHODS.other)[1]))+'</span><b class="mono">'+m[1]+'</b></div><div class="bar"><i style="width:'+Math.round(100*m[1]/mx)+'%"></i></div></div>').join(''):'<span class="mu">'+T('Chưa có bài nào. Giải vài bài để thấy thống kê.','No problems yet. Solve a few to see your stats.')+'</span>')+'<div class="mu" style="margin-top:8px">'+T('Tổng số bài đã giải: ','Problems solved: ')+(S.stat.solved||0)+'</div></div>'+
  ((S.fav||[]).length?'<div class="card"><h3>★ '+T('Đã lưu','Saved')+'</h3>'+S.fav.map((q,i)=>'<div class="q"><span class="p">'+esc(q.slice(0,120))+'</span><button class="chip" data-fv="'+i+'">↻</button></div>').join('')+'</div>':'')+
  '<div class="card"><h3>🕘 '+T('Nhật ký lời giải','Solution log')+'</h3>'+(H.length?H.slice(0,30).map((h,i)=>'<div class="q"><span class="p"><b>'+esc(h.ttl||h.k)+'</b><br><small>'+esc(h.q.slice(0,90))+(h.ans?' → '+esc(h.ans):'')+'</small></span><button class="chip" data-re="'+i+'">↻</button></div>').join(''):'<span class="mu">—</span>')+'</div>'}
function show(p){render();if(p&&p.q){tab='chat';render();if(p.run)send(p.q);else{$('#sgI').value=p.q}}}
VN.views.solve={init,show,render};
})();
