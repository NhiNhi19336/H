/* App config. proxy: your Cloudflare Worker URL (the Gemini key stays inside the Worker, never here). Leave '' for offline only. */
window.VN_CFG={proxy:'https://broken-firefly-178b.bentobeto19.workers.dev'};
