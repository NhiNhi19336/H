/* Oasis life-sim layer on top of the 3D realm (realm3d.js):
   - Portal: pick a space (server), a polyhedron character, colour and name, then cross over.
   - Your oasis: a house, a build/decorate mode (place, rotate, move, store items on a grid), working objects
     (well waters every crop, beehive gives honey, statue teaches Euler's formula, board table opens Cờ Lăn Khối,
     mailbox = guestbook), a pet that follows you, passing rain that waters your crops, photo mode.
   - Friends (online): their oasis is built from their real saved layout; leave a note, help water their crops.
   Everything saves locally; online it is mirrored into your public doc (dc, ch, nk, hw). */
(function(){
'use strict';
const {T,esc,$,S}=VN,N=VN.NET,TAU=Math.PI*2;
const lib=()=>VN.REALM.lib;
const now=()=>Date.now();
/* ---------- character ---------- */
const SHP=[['crystal','💎','Pha lê','Crystal'],['tetra','🔺','Tứ diện','Tetrahedron'],['cube','🧊','Lập phương','Cube'],['octa','🔷','Bát diện','Octahedron'],['dodeca','⬟','Thập nhị diện','Dodecahedron'],['icosa','💠','Nhị thập diện','Icosahedron'],['prism','⬢','Lăng trụ lục giác','Hex prism']];
const COLS=['#bff3ff','#9ff7c4','#ffd6a8','#ffb3e6','#d9c7ff','#fff1a6','#ff9a8a','#8ec5ff'];
const FACTS={crystal:[6,12,8],tetra:[4,6,4],cube:[8,12,6],octa:[6,12,8],dodeca:[20,30,12],icosa:[12,30,20],prism:[12,18,8]};
function ch(){if(!S.w)return{sh:'crystal',col:'#bff3ff',nk:''};if(!S.w.ch)S.w.ch={sh:'crystal',col:'#bff3ff',nk:''};return S.w.ch}
const O={portalDone:false};
function syncMe(){N.save({ch:{sh:ch().sh,col:ch().col},nk:ch().nk||'',dc:S.w.dec||[]})}
/* ---------- portal panel ---------- */
function portal(R0){const host=R0.host;const SV=(VN.WORLD&&VN.WORLD.SERVERS)||[];const c=ch();let srv=S.w.srv||(SV[0]&&SV[0].id)||'tess',sh=c.sh,col=c.col;
 const el=document.createElement('div');el.className='r3portal';
 el.innerHTML='<div class="r3pp"><div class="r3ph"><b>🌀 '+T('Cổng xuyên không','Crossing gate')+'</b><small>'+T('Chọn không gian, nhân vật khối và tên của bạn','Pick a space, your polyhedron self and a name')+'</small></div>'+
  '<div class="r3ps"><span class="r3pn">1</span>'+T('Không gian','Space')+'</div><div class="r3row" id="ppSrv">'+SV.map(s=>'<button class="r3opt'+(s.id===srv?' on':'')+'" data-psrv="'+s.id+'"><b>'+esc(s.name)+'</b><small>'+esc(T(s.vi,s.en))+'</small></button>').join('')+'</div>'+
  '<div class="r3ps"><span class="r3pn">2</span>'+T('Nhân vật khối','Your polyhedron')+'</div><div class="r3row" id="ppSh">'+SHP.map(x=>'<button class="r3opt sm'+(x[0]===sh?' on':'')+'" data-psh="'+x[0]+'"><i>'+x[1]+'</i><small>'+T(x[2],x[3])+'</small></button>').join('')+'</div>'+
  '<div class="r3row r3cols" id="ppCol">'+COLS.map(k=>'<button class="r3sw'+(k===col?' on':'')+'" data-pcol="'+k+'" style="--c:'+k+'" aria-label="'+k+'"></button>').join('')+'</div>'+
  '<div class="r3ps"><span class="r3pn">3</span>'+T('Tên nhân vật','Character name')+'</div><div class="row r3pname"><input id="ppNk" maxlength="16" placeholder="'+T('Ví dụ: Tí Tứ Diện','e.g. Tiny Tetra')+'" value="'+esc(c.nk||'')+'"><button class="chip" id="ppRnd" title="'+T('Tên ngẫu nhiên','Random name')+'">🎲</button></div>'+
  '<div class="r3pfact" id="ppFact"></div><button class="btn r3go" id="ppGo">✦ '+T('Xuyên không','Cross over')+'</button></div>';
 host.appendChild(el);
 const home0=R0.P.p.clone();R0.P.p.set(0,5,17);R0.P.v.set(0,0,0);const pr=new THREE.Group();pr.position.set(0,5,17);const ring=new THREE.Mesh(new THREE.TorusGeometry(1.25,.06,8,64),new THREE.MeshBasicMaterial({color:'#ffffff'}));ring.rotation.x=Math.PI/2;pr.add(ring);const ring2=new THREE.Mesh(new THREE.TorusGeometry(1.6,.03,8,64),new THREE.MeshBasicMaterial({color:'#ffd6f5',transparent:true,opacity:.7}));ring2.rotation.x=Math.PI/2;pr.add(ring2);const gl=lib().glow('#e8d0ff',2.4);gl.position.y=.3;pr.add(gl);R0.scene.add(pr);R0.moving.push(t=>{ring.rotation.z=t*.6;ring2.rotation.z=-t*.4;ring2.position.y=Math.sin(t*1.5)*.1});R0.meAv.position.copy(R0.P.p);
 const leave=()=>{R0.scene.remove(pr);R0.P.p.copy(home0);R0.P.v.set(0,0,0)};
 const fact=()=>{const f=FACTS[sh];el.querySelector('#ppFact').innerHTML=f?'<b>'+T(SHP.find(x=>x[0]===sh)[2],SHP.find(x=>x[0]===sh)[3])+'</b>: '+f[0]+T(' đỉnh, ',' vertices, ')+f[1]+T(' cạnh, ',' edges, ')+f[2]+T(' mặt',' faces')+' · Euler: '+f[0]+' − '+f[1]+' + '+f[2]+' = 2':''};fact();
 const live=()=>R0.setMe({sh,col,nk:c.nk});
 el.onclick=e=>{const b=e.target.closest('[data-psrv],[data-psh],[data-pcol],#ppRnd,#ppGo');if(!b)return;const d=b.dataset;
  if(d.psrv){srv=d.psrv;el.querySelectorAll('[data-psrv]').forEach(x=>x.classList.toggle('on',x===b))}
  if(d.psh){sh=d.psh;el.querySelectorAll('[data-psh]').forEach(x=>x.classList.toggle('on',x===b));live();fact()}
  if(d.pcol){col=d.pcol;el.querySelectorAll('[data-pcol]').forEach(x=>x.classList.toggle('on',x===b));live()}
  if(b.id==='ppRnd'){const A=T(['Tí','Bé','Bạn','Mây','Gió','Sao','Bông'],['Tiny','Little','Brave','Cloudy','Windy','Starry','Fluffy']),B=T(['Tứ Diện','Lập Phương','Bát Diện','Pi','Vector','Pytago','Đỉnh'],['Tetra','Cube','Octa','Pi','Vector','Pythag','Vertex']);el.querySelector('#ppNk').value=A[Math.floor(Math.random()*A.length)]+' '+B[Math.floor(Math.random()*B.length)]}
  if(b.id==='ppGo'){const nk=el.querySelector('#ppNk').value.replace(/[<>]/g,'').trim().slice(0,16);Object.assign(c,{sh,col,nk});S.w.ch=c;O.portalDone=true;VN.save();syncMe();leave();el.classList.add('out');setTimeout(()=>el.remove(),350);flash(R0.host);
   if(srv!==S.w.srv){S.w.srv=srv;VN.save();N.save({srv});const h=R0.host;setTimeout(()=>{VN.REALM.unmount();VN.REALM.mount(h)},380);VN.toast('🌀 '+T('Đang tới ','Travelling to ')+((SV.find(x=>x.id===srv)||{}).name||srv))}
   else{R0.setMe(c);R0.startIntro()}}};
 setTimeout(()=>{const i=el.querySelector('#ppNk');if(i&&!c.nk&&matchMedia('(pointer:fine)').matches)i.focus()},300)}
function flash(host){const f=document.createElement('div');f.className='r3flash';host.appendChild(f);setTimeout(()=>f.remove(),900)}
/* ---------- decor catalogue ---------- */
const DEC={
 house:{i:'🏠',vi:'Nhà',en:'House',cost:0,max:1,fp:1.55,col:1.5},
 mailbox:{i:'📮',vi:'Hộp thư',en:'Mailbox',cost:0,max:1,fp:.45},
 lamp:{i:'🏮',vi:'Đèn pha lê',en:'Crystal lamp',cost:12,fp:.4},
 fence:{i:'🚧',vi:'Hàng rào',en:'Fence',cost:4,fp:.85},
 flowers:{i:'🌷',vi:'Luống hoa',en:'Flowerbed',cost:8,fp:.7},
 tree:{i:'🌳',vi:'Cây cầu',en:'Round tree',cost:14,fp:.7,col:.45},
 bench:{i:'🪑',vi:'Ghế đá',en:'Bench',cost:10,fp:.75},
 board:{i:'🎲',vi:'Bàn cờ khối',en:'Cube-chess table',cost:20,max:2,fp:.85,col:.7},
 well:{i:'🪣',vi:'Giếng tưới',en:'Watering well',cost:30,max:1,fp:.85,col:.8},
 bee:{i:'🐝',vi:'Tổ ong lục giác',en:'Hexagon hive',cost:60,max:1,fp:.6,col:.5},
 statue:{i:'🗿',vi:'Tượng đa diện',en:'Polyhedron statue',cost:45,max:3,fp:.65,col:.55},
 windmill:{i:'🌬',vi:'Cối xay gió',en:'Windmill',cost:40,fp:.9,col:.7},
 campfire:{i:'🔥',vi:'Lửa trại',en:'Campfire',cost:15,fp:.6},
 arch:{i:'⛩',vi:'Cổng vòm',en:'Arch',cost:25,fp:1.1}};
const DEFAULT=()=>[['house',2.4,-5.0,0],['mailbox',-.6,-4.9,0],['lamp',-1.9,-4.7,0],['flowers',4.6,-2.6,0]];
function dec(){if(!Array.isArray(S.w.dec))S.w.dec=DEFAULT();if(!S.w.inv)S.w.inv={};return S.w.dec}
function clean(list){return(Array.isArray(list)?list:[]).filter(d=>Array.isArray(d)&&DEC[d[0]]&&isFinite(d[1])&&isFinite(d[2])&&Math.hypot(d[1],d[2])<7.2).slice(0,60).map(d=>[d[0],+(+d[1]).toFixed(2),+(+d[2]).toFixed(2),(+d[3]||0)%8])}
/* ---------- meshes ---------- */
function M(c,o){return lib().mat(c,o)}
function box(w,h,d,c,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),M(c));m.position.set(x||0,(y||0)+h/2,z||0);return m}
function cyl(r1,r2,h,n,c,x,y,z){const m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,n),M(c));m.position.set(x||0,(y||0)+h/2,z||0);return m}
function mesh(type,col,night){const g=new THREE.Group();g.userData.type=type;const L=lib();
 if(type==='house'){g.add(box(2.5,1.55,2.0,'#f4e7d7',0,0,0));g.add(box(2.62,.16,2.12,'#d9c4ad',0,0,0));const sh=new THREE.Shape();sh.moveTo(-1.5,0);sh.lineTo(1.5,0);sh.lineTo(0,1.15);sh.lineTo(-1.5,0);const rg=new THREE.ExtrudeGeometry(sh,{depth:2.3,bevelEnabled:false});rg.translate(0,0,-1.15);const roof=new THREE.Mesh(rg,M(col||'#9b7ee0'));roof.position.y=1.55;g.add(roof);
  g.add(box(.62,1.0,.06,'#7a5235',0,0,1.02));const wm=new THREE.MeshStandardMaterial({color:'#ffe9a8',emissive:'#ffcf6b',emissiveIntensity:night?1.2:.25});[-.8,.8].forEach(x=>{const w=new THREE.Mesh(new THREE.BoxGeometry(.46,.46,.05),wm);w.position.set(x,.95,1.02);g.add(w)});g.add(box(.3,.75,.3,'#c9a7a7',.75,2.0,-.3));
  const step=box(.9,.12,.4,'#d9c4ad',0,0,1.2);g.add(step)}
 else if(type==='mailbox'){g.add(cyl(.05,.05,.9,6,'#7a5235'));const b=box(.42,.32,.6,'#ff7a7a',0,.9,0);g.add(b);const fl=box(.04,.28,.14,'#ffd23f',.24,1.0,.1);fl.userData.flag=1;g.add(fl)}
 else if(type==='lamp'){g.add(cyl(.05,.07,1.55,6,'#5b4a6a'));const cr=L.crystal(col||'#ffe9a8',.16);cr.position.y=1.75;g.add(cr);const gl=L.glow('#ffe2a8',night?2.6:1.3);gl.position.y=1.75;g.add(gl);g.userData.glow=gl}
 else if(type==='fence'){[-.75,0,.75].forEach(x=>g.add(box(.1,.7,.1,'#e9d6bf',x,0,0)));[.25,.52].forEach(y=>g.add(box(1.6,.08,.06,'#d9c0a3',0,y,0)))}
 else if(type==='flowers'){g.add(box(1.2,.16,.8,'#7a5235'));const P=['#ff8fc8','#ffe066','#ffffff','#9fd8ff','#c9a7f5','#ff9a8a'];for(let i=0;i<9;i++){const f=new THREE.Mesh(new THREE.OctahedronGeometry(.1,0),M(P[i%P.length],{emissive:'#220011'}));f.position.set(-.45+(i%3)*.45,.32+(i%2)*.06,-.25+Math.floor(i/3)*.25);g.add(f);const st=box(.03,.16,.03,'#5fae5a',f.position.x,.14,f.position.z);g.add(st)}}
 else if(type==='tree'){g.add(cyl(.12,.17,1.1,6,'#8a5a3c'));const fg=new THREE.IcosahedronGeometry(.75,0).toNonIndexed();L.faceColors(fg,'#7fcf6a',.25,L.rng(7));const f=new THREE.Mesh(fg,L.vmat());f.position.y=1.55;g.add(f)}
 else if(type==='bench'){g.add(box(1.3,.1,.45,'#d9c0a3',0,.42,0));g.add(box(1.3,.4,.08,'#d9c0a3',0,.5,-.2));[-.55,.55].forEach(x=>g.add(box(.1,.42,.4,'#9e8fb0',x,0,0)))}
 else if(type==='board'){g.add(cyl(.1,.16,.72,6,'#9e8fb0'));const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');for(let i=0;i<6;i++)for(let j=0;j<6;j++){x.fillStyle=(i+j)%2?'#c9b6ef':'#f6f1ff';x.fillRect(i*128/6,j*128/6,128/6+1,128/6+1)}const tx=new THREE.CanvasTexture(c);tx.encoding=THREE.sRGBEncoding;const top=new THREE.Mesh(new THREE.BoxGeometry(1.25,.1,1.25),[M('#b79ad8'),M('#b79ad8'),new THREE.MeshLambertMaterial({map:tx}),M('#b79ad8'),M('#b79ad8'),M('#b79ad8')]);top.position.y=.77;g.add(top);
  [[-.3,-.3,'#e9fbff'],[.3,.3,'#ffe6ec'],[.1,-.3,'#e9fbff']].forEach(([a,b,c2])=>g.add(box(.18,.18,.18,c2,a,.82,b)))}
 else if(type==='well'){const r=new THREE.Mesh(new THREE.CylinderGeometry(.62,.66,.6,10,1,true),M('#b8a7c9',{side:THREE.DoubleSide}));r.position.y=.3;g.add(r);const w=new THREE.Mesh(new THREE.CircleGeometry(.58,10),new THREE.MeshStandardMaterial({color:'#7fd3ff',emissive:'#2a7fd0',emissiveIntensity:.35}));w.rotation.x=-Math.PI/2;w.position.y=.45;g.add(w);[-.55,.55].forEach(x=>g.add(box(.08,1.3,.08,'#7a5235',x,.3,0)));const rf=new THREE.Mesh(new THREE.ConeGeometry(.9,.55,4),M(col||'#9b7ee0'));rf.position.y=1.85;rf.rotation.y=Math.PI/4;g.add(rf)}
 else if(type==='bee'){for(let i=0;i<3;i++){const h=cyl(.42-i*.08,.42-i*.08,.3,6,i%2?'#ffd23f':'#f2b33d',0,.12+i*.3,0);g.add(h)}g.add(cyl(.04,.04,.15,6,'#7a5235',0,0,0));const bees=[];for(let i=0;i<3;i++){const b=new THREE.Mesh(new THREE.SphereGeometry(.06,6,4),M('#3a2a10'));g.add(b);bees.push(b)}g.userData.bees=bees}
 else if(type==='statue'){g.add(box(.7,.5,.7,'#e2d8ef'));g.add(box(.8,.08,.8,'#cfc2e2',0,.5,0));const sh=new THREE.Group();sh.position.y=1.2;g.add(sh);g.userData.statue=sh;setStatue(g,0)}
 else if(type==='windmill'){g.add(cyl(.32,.55,2.4,6,'#f0e4d4'));const rf=new THREE.Mesh(new THREE.ConeGeometry(.45,.5,6),M(col||'#9b7ee0'));rf.position.y=2.65;g.add(rf);const hub=new THREE.Group();hub.position.set(0,2.2,.42);g.add(hub);for(let i=0;i<4;i++){const b=box(.16,1.05,.03,'#ffffff',0,.12,0);const a=new THREE.Group();a.add(b);a.rotation.z=i*Math.PI/2;hub.add(a)}g.userData.spin=hub}
 else if(type==='campfire'){for(let i=0;i<4;i++){const l=cyl(.06,.06,.7,5,'#7a4a2c');l.rotation.z=Math.PI/2;l.rotation.y=i*Math.PI/4;l.position.y=.08;g.add(l)}const fl=new THREE.Mesh(new THREE.ConeGeometry(.22,.6,5),new THREE.MeshBasicMaterial({color:'#ffb347'}));fl.position.y=.4;g.add(fl);const f2=new THREE.Mesh(new THREE.ConeGeometry(.12,.4,5),new THREE.MeshBasicMaterial({color:'#fff2a8'}));f2.position.y=.36;g.add(f2);const gl=L.glow('#ff9a3c',2.2);gl.position.y=.5;g.add(gl);g.userData.fire=[fl,f2]}
 else if(type==='arch'){[-.85,.85].forEach(x=>g.add(box(.22,1.5,.22,'#e2d8ef',x,0,0)));const t=new THREE.Mesh(new THREE.TorusGeometry(.85,.11,6,18,Math.PI),M(col||'#c9a7f5'));t.position.y=1.5;g.add(t);const cr=L.crystal('#bff3ff',.14);cr.position.y=2.45;g.add(cr)}
 return g}
const STAT=['tetra','cube','octa','dodeca','icosa'];
function setStatue(g,k){const sh=g.userData.statue;while(sh.children.length)sh.remove(sh.children[0]);const t=STAT[k%STAT.length];const geo=lib().AVG[t]();const m=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:'#e9e2ff',emissive:'#7c5cff',emissiveIntensity:.25,flatShading:true,roughness:.35}));m.scale.setScalar(1.05);sh.add(m);sh.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo),new THREE.LineBasicMaterial({color:'#5b3fa0'})));g.userData.stIdx=k%STAT.length}
function shadeAll(o){o.traverse(x=>{if(x.isMesh&&!x.material.transparent&&!(x.material.isMeshBasicMaterial)){x.castShadow=true;x.receiveShadow=true}})}
function group(list,col,night){const G=new THREE.Group();list.forEach((d,i)=>{const m=mesh(d[0],col,night);m.position.set(d[1],.5,d[2]);m.rotation.y=(d[3]||0)*Math.PI/4;m.userData.idx=i;G.add(m)});shadeAll(G);return G}
/* ---------- build into the realm ---------- */
const isNight=()=>{const h=new Date().getHours();return h<6||h>=19};
function onBuild(R0){dec();R0.oasis={pet:null,rain:null,nextRain:now()+(90+Math.random()*150)*1000};placeMine(R0);
 /* public chess table in Vertex City */
 const tb=mesh('board');tb.position.set(-4.4,.5,-3.0);tb.rotation.y=.6;R0.hub.add(tb);shadeAll(tb);R0.inter.push({oasis:1,kind:'decor',t:'board',x:-4.4,y:0,z:-3.0,r:1.7,pub:1});
 /* pet */
 const pc=ch().col;const pet=new THREE.Group();const pm=new THREE.Mesh(new THREE.TetrahedronGeometry(.22,0),new THREE.MeshStandardMaterial({color:'#ffffff',emissive:pc,emissiveIntensity:.8,flatShading:true}));pet.add(pm);const pg=lib().glow(pc,1.1);pet.add(pg);pet.position.copy(R0.P.p).add(new THREE.Vector3(1,1.4,0));R0.scene.add(pet);R0.oasis.pet=pet;
 helpIncoming();}
function placeMine(R0){const O2=R0.oasis;if(O2.g){R0.home.remove(O2.g)}R0.inter.splice(0,R0.inter.length,...R0.inter.filter(x=>!x.mine));R0.cols.length=0;
 const list=dec();O2.g=group(list,ch().col,isNight());R0.home.add(O2.g);const H=R0.L.home;
 list.forEach((d,i)=>{const D=DEC[d[0]];const wx=H.x+d[1],wz=H.z+d[2];if(D.col)R0.cols.push({x:wx,z:wz,r:D.col+.35,y:H.y+.5,h:3});if(['house','mailbox','board','well','bee','statue','bench'].includes(d[0]))R0.inter.push({oasis:1,mine:1,kind:'decor',t:d[0],i,x:wx,y:H.y,z:wz,r:D.fp+1.3})});
}
function friend(R0,m,o,id,d){const list=clean(d.dc);const fc=d.ch&&/^#[0-9a-f]{6}$/i.test(d.ch.col)?d.ch.col:'#9b7ee0';const use=list.length?list:[['house',2.4,-3.2,0],['mailbox',-.6,-3.6,0],['tree',-3,1,0],['tree',3,1.4,0]];
 /* friend islands are smaller (r = 6): scale positions a little */const k=o.r/7.6;const g=group(use.map(x=>[x[0],x[1]*k,x[2]*k,x[3]]),fc,isNight());m.add(g);
 const mb=use.find(x=>x[0]==='mailbox')||use[0];R0.inter.push({oasis:1,kind:'fmail',uid:id,x:o.x+mb[1]*k,y:o.y,z:o.z+mb[2]*k,r:2});R0.inter.push({oasis:1,kind:'fhelp',uid:id,x:o.x,y:o.y,z:o.z,r:2.6})}
/* ---------- interactions ---------- */
function label(n){const t=n.t;if(n.kind==='fmail')return'✉ '+T('Để lại lời nhắn','Leave a note');if(n.kind==='fhelp')return'💧 '+T('Tưới giúp','Help water');
 return({house:'🏠 '+T('Vào nhà','Enter'),mailbox:'📮 '+T('Hộp thư','Mailbox')+(unread()?' ('+unread()+')':''),board:'🎲 '+T('Chơi Cờ Lăn Khối','Play cube chess'),well:'🪣 '+T('Múc nước tưới','Draw water'),bee:'🍯 '+T('Lấy mật','Collect honey'),statue:'🗿 '+T('Đọc bia đá','Read plaque'),bench:'🪑 '+T('Ngồi ngắm','Sit & watch')})[t]||'✋'}
const gb=uid=>N.msgs('gb:'+uid);
function unread(){const seen=S.w.gbSeen||0;return gb(N.uid).filter(m=>m.ts>seen&&m.uid!==N.uid).length}
function waterAll(){const W=VN.WORLD,C=W.CROPS;let n=0;(S.w.plots||[]).forEach(p=>{if(p.c&&!p.w&&W.grow(p)<1){const el=now()-p.t0;p.w=1;p.t0=now()-el*.5;n++}});if(n){VN.save();N.save({f:W.farmSummary()})}return n}
function use(R0,n){const t=n.t;
 if(n.kind==='fmail')return noteModal(n.uid);
 if(n.kind==='fhelp'){const day=VN.dkey();const hw=Object.assign({},N.mine.hw||{});if(hw[n.uid]===day)return VN.toast(T('Hôm nay bạn đã tưới giúp ốc đảo này rồi.','You already helped this oasis today.'));hw[n.uid]=day;Object.keys(hw).forEach(k=>{if(hw[k]!==day)delete hw[k]});N.save({hw});VN.WORLD.coin(3,T('giúp bạn','helping'));VN.xp(2,'help');rainBurst(R0,n,1.8);return VN.toast('💧 '+T('Đã tưới giúp! Cây của bạn ấy sẽ lớn nhanh gấp đôi khi họ vào game.','Watered! Their crops grow twice as fast when they log in.'))}
 if(t==='board')return VN.COKHOI&&VN.COKHOI.open({onWin:lv=>{N.post('khoe','🎲 '+T('Vừa thắng Cờ Lăn Khối mức ','Just won Rolling-Cube Chess on ')+T(['dễ','vừa','khó'][lv],['easy','medium','hard'][lv])+'!',true)}});
 if(t==='house')return houseModal(R0);
 if(t==='mailbox'){S.w.gbSeen=now();VN.save();return noteModal(N.uid)}
 if(t==='well'){const left=(S.w.wellT||0)+20*60000-now();if(left>0)return VN.toast('🪣 '+T('Giếng đang đầy lại: ','Refilling: ')+Math.ceil(left/60000)+T(' phút',' min'));const k=waterAll();S.w.wellT=now();VN.save();rainBurst(R0,{x:R0.L.home.x,y:R0.L.home.y,z:R0.L.home.z},6);return VN.toast(k?'💧 '+T('Đã tưới ','Watered ')+k+T(' ô đất! Cây lớn nhanh gấp đôi.',' plots! Crops grow twice as fast.'):T('Chưa có ô nào cần tưới.','Nothing needs water right now.'))}
 if(t==='bee'){const left=(S.w.beeT||0)+15*60000-now();if(left>0)return VN.toast('🐝 '+T('Ong đang làm mật: ','Bees at work: ')+Math.ceil(left/60000)+T(' phút',' min'));S.w.beeT=now();VN.save();return VN.WORLD.coin(10,T('mật ong lục giác','hexagon honey'))}
 if(t==='statue'){const g=R0.oasis.g.children.find(x=>x.userData.idx===n.i);const k=g?g.userData.stIdx||0:0;const nm=STAT[k],f=FACTS[nm],sh=SHP.find(x=>x[0]===nm);VN.modal('<h3>🗿 '+T(sh[2],sh[3])+'</h3><p>'+T('Số đỉnh','Vertices')+' V = <b>'+f[0]+'</b> · '+T('số cạnh','edges')+' E = <b>'+f[1]+'</b> · '+T('số mặt','faces')+' F = <b>'+f[2]+'</b></p><p class="big">V − E + F = '+f[0]+' − '+f[1]+' + '+f[2]+' = <b>2</b></p><p class="mu">'+T('Công thức Euler đúng cho mọi khối đa diện lồi. Bấm “Đổi khối” để tượng hiện khối khác.','Euler’s formula holds for every convex polyhedron. Tap “Next shape” to change the statue.')+'</p><button class="btn" id="stNext">↻ '+T('Đổi khối','Next shape')+'</button>');$('#stNext').onclick=()=>{if(g)setStatue(g,k+1);VN.closeModal();VN.xp(1,'euler')};return}
 if(t==='bench'){R0.sit=!R0.sit;VN.toast(R0.sit?T('🪑 Ngồi ngắm cảnh… chạm Nhảy để đứng dậy','🪑 Enjoying the view… tap Jump to stand'):'');return}}
function houseModal(R0){const c=ch(),W=VN.WORLD;const placed=dec().length,inv=Object.values(S.w.inv||{}).reduce((a,b)=>a+b,0);const sh=SHP.find(x=>x[0]===c.sh)||SHP[0];
 const m=VN.modal('<h3>🏠 '+T('Nhà của ','Home of ')+esc(c.nk||T('bạn','you'))+'</h3><div class="hsgrid"><div class="hsc"><span>'+sh[1]+'</span><b>'+T(sh[2],sh[3])+'</b><small>'+T('Nhân vật','Character')+'</small></div><div class="hsc"><span>✦</span><b>'+(S.w.coins||0)+'</b><small>'+T('Tinh thể','Crystals')+'</small></div><div class="hsc"><span>⭐</span><b>'+VN.lvOf(S.xp||0)+'</b><small>'+T('Cấp','Level')+'</small></div><div class="hsc"><span>🪴</span><b>'+placed+'</b><small>'+T('Đồ đã đặt','Items placed')+(inv?' · '+inv+T(' trong kho',' stored'):'')+'</small></div></div>'+
  '<div class="grid g2"><button class="btn" id="hsBuild">🛠 '+T('Xây & trang trí','Build & decorate')+'</button><button class="btn g" id="hsChar">🌀 '+T('Đổi nhân vật','Change character')+'</button><button class="btn g" id="hsFarm">📦 '+T('Đơn hàng & sưu tập','Orders & collection')+'</button><button class="btn g" id="hsPhoto">📷 '+T('Chụp ảnh ốc đảo','Photo of your oasis')+'</button></div>');
 m.onclick=e=>{const b=e.target.closest('button');if(!b)return;VN.closeModal();if(b.id==='hsBuild')build(R0);if(b.id==='hsChar'){O.portalDone=false;const h=R0.host;VN.REALM.unmount();VN.REALM.mount(h)}if(b.id==='hsFarm')setTimeout(ordersModal,10);if(b.id==='hsPhoto')photo(R0)}}
async function noteModal(uid){const mine=uid===N.uid;const nm=await N.names([uid]);const owner=mine?T('bạn','you'):((N.users[uid]&&N.users[uid].nk)||nm[uid]||'?');const list=gb(uid).slice(-30).reverse();const ids=[...new Set(list.map(x=>x.uid))];const nn=await N.names(ids);
 const m=VN.modal('<h3>📮 '+T('Sổ lưu bút của ','Guestbook of ')+esc(owner)+'</h3>'+(list.length?'<div class="gbl">'+list.map(x=>'<div class="gbi"><b>'+esc((N.users[x.uid]&&N.users[x.uid].nk)||nn[x.uid]||'?')+'</b><small class="mu"> · '+new Date(x.ts).toLocaleDateString()+'</small><p></p></div>').join('')+'</div>':'<p class="mu">'+(mine?T('Chưa có ai để lại lời nhắn. Khi online, bạn bè ghé ốc đảo có thể viết vào đây.','No notes yet. When online, friends who visit can write here.'):T('Hãy là người đầu tiên để lại lời nhắn!','Be the first to leave a note!'))+'</p>')+
  (mine?'':'<div class="row" style="margin-top:8px"><input id="gbIn" maxlength="160" placeholder="'+T('Viết lời nhắn dễ thương…','Write something kind…')+'" style="flex:1"><button class="btn" id="gbGo">'+T('Gửi','Send')+'</button></div>'));
 m.querySelectorAll('.gbi p').forEach((p,i)=>p.textContent=list[i].t);
 const go=m.querySelector('#gbGo');if(go)go.onclick=async()=>{const v=m.querySelector('#gbIn').value.trim();if(!v)return;if(N.mode!=='online'){VN.toast(T('Cần online để gửi lời nhắn cho bạn bè.','You need to be online to leave notes.'));return}await N.post('gb:'+uid,v);VN.xp(1,'note');VN.closeModal();VN.toast('📮 '+T('Đã gửi lời nhắn!','Note sent!'))}}
/* friends who watered my oasis today */
function helpIncoming(){if(!S.w)return;const day=VN.dkey();S.w.hwSeen=S.w.hwSeen||{};const who=Object.entries(N.users).filter(([u,d])=>u!==N.uid&&d&&d.hw&&d.hw[N.uid]===day&&!S.w.hwSeen[u+day]).map(x=>x[0]);if(!who.length)return;who.forEach(u=>S.w.hwSeen[u+day]=1);Object.keys(S.w.hwSeen).forEach(k=>{if(!k.endsWith(day))delete S.w.hwSeen[k]});const n=waterAll();VN.save();
 N.names(who).then(nm=>VN.toast('💧 '+who.map(u=>(N.users[u]&&N.users[u].nk)||nm[u]).join(', ')+T(' đã tưới giúp ốc đảo của bạn',' watered your oasis')+(n?' ('+n+T(' ô)',' plots)'):'')))}
VN.on&&VN.on('net',()=>{try{helpIncoming()}catch(e){}});
/* ---------- build mode ---------- */
function build(R0){if(R0.bm)return;const H=R0.L.home,P=R0.P;if(P.last!=='home'||Math.hypot(P.p.x-H.x,P.p.z-H.z)>9){P.p.set(H.x,H.y+1.2,H.z+5.6);P.v.set(0,0,0)}
 const keep={cp:P.cp,dist:P.dist};P.cp=1.0;P.dist=15.5;P.cy=Math.PI;
 const B={sel:null,pick:-1,rot:0,ghost:null,ring:null,x:0,z:2,keep};R0.bm=B;R0.host.classList.add('r3building');
 const el=document.createElement('div');el.className='r3bm';R0.host.appendChild(el);B.el=el;
 const ring=new THREE.Mesh(new THREE.RingGeometry(.9,1.05,32),new THREE.MeshBasicMaterial({color:'#7dffb0',transparent:true,opacity:.9,side:THREE.DoubleSide,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.visible=false;R0.home.add(ring);B.ring=ring;
 const ray=new THREE.Raycaster(),plane=new THREE.Plane(new THREE.Vector3(0,1,0),-(H.y+.5)),hit=new THREE.Vector3();
 R0.onTap=(nx,ny)=>{ray.setFromCamera({x:nx,y:ny},R0.cam);if(!ray.ray.intersectPlane(plane,hit))return;const lx=Math.round((hit.x-H.x)*2)/2,lz=Math.round((hit.z-H.z)*2)/2;
  if(B.sel){B.x=lx;B.z=lz;show();return}
  /* pick an existing item */const list=dec();let best=-1,bd=1e9;list.forEach((d,i)=>{const dd=Math.hypot(d[1]-(hit.x-H.x),d[2]-(hit.z-H.z));if(dd<Math.max(.8,DEC[d[0]].fp+.2)&&dd<bd){bd=dd;best=i}});B.pick=best;show()};
 function free(type,x,z,skip){const D=DEC[type];const a=Math.atan2(x,z),sec=TAU/6;let aa=((a-Math.PI/6)%sec+sec)%sec-sec/2;if(Math.hypot(x,z)*Math.cos(aa)+D.fp>H.r*Math.cos(Math.PI/6)*.97)return T('Sát mép đảo quá','Too close to the edge');
  const n=(S.w.plots||[]).length,rows=Math.ceil(n/4);if(n&&Math.abs(x)<3.65+D.fp&&z>(-.6-(rows-1)/2*1.85-.8-D.fp)&&z<(-.6+(rows-1)/2*1.85+.8+D.fp))return T('Đè lên ô đất trồng','Overlaps the farm plots');
  if(Math.hypot(x-4.3,z-2.3)<1.5+D.fp)return T('Đè lên ao cá','Overlaps the pond');
  for(const [i,d] of dec().entries()){if(i===skip)continue;if(Math.hypot(d[1]-x,d[2]-z)<DEC[d[0]].fp+D.fp-.1)return T('Đè lên ','Overlaps ')+T(DEC[d[0]].vi,DEC[d[0]].en).toLowerCase()}return''}
 function count(t){return dec().filter(d=>d[0]===t).length}
 function show(){const list=dec();if(B.ghost){R0.home.remove(B.ghost);B.ghost=null}ring.visible=false;
  let why='';if(B.sel){B.ghost=mesh(B.sel,ch().col,isNight());B.ghost.traverse(o=>{if(o.isMesh){o.material=o.material.clone?(Array.isArray(o.material)?o.material.map(x=>x.clone()):o.material.clone()):o.material;(Array.isArray(o.material)?o.material:[o.material]).forEach(mm=>{mm.transparent=true;mm.opacity=.62})}});B.ghost.position.set(B.x,.5,B.z);B.ghost.rotation.y=B.rot*Math.PI/4;R0.home.add(B.ghost);why=free(B.sel,B.x,B.z,B.moving);ring.visible=true;ring.position.set(B.x,.53,B.z);ring.scale.setScalar(DEC[B.sel].fp+.05);ring.material.color.set(why?'#ff6b6b':'#7dffb0')}
  else if(B.pick>=0){const d=list[B.pick];ring.visible=true;ring.position.set(d[1],.53,d[2]);ring.scale.setScalar(DEC[d[0]].fp+.05);ring.material.color.set('#ffd23f')}
  const inv=S.w.inv||{};
  el.innerHTML='<div class="r3bh"><b>🛠 '+T('Xây ốc đảo','Build your oasis')+'</b><span class="tag">✦ '+(S.w.coins||0)+'</span><span class="sp"></span><button class="chip" data-b="done">✓ '+T('Xong','Done')+'</button></div>'+
   '<div class="r3bmsg">'+(B.sel?(why?'⚠ '+why:T('Chạm lên đảo để dời chỗ, rồi bấm Đặt','Tap the island to move it, then Place')):B.pick>=0?esc(T(DEC[list[B.pick][0]].vi,DEC[list[B.pick][0]].en))+' · '+T('xoay, dời hoặc cất vào kho','rotate, move or store'):T('Chọn món bên dưới, hoặc chạm một món trên đảo để chỉnh','Pick an item below, or tap one on the island to edit'))+'</div>'+
   (B.sel?'<div class="r3bact"><button class="btn g" data-b="rot">⟳ '+T('Xoay','Rotate')+'</button><button class="btn g" data-b="cancel">✕ '+T('Hủy','Cancel')+'</button><button class="btn" data-b="place"'+(why?' disabled':'')+'>✓ '+T('Đặt','Place')+'</button></div>':
    B.pick>=0?'<div class="r3bact"><button class="btn g" data-b="prot">⟳ '+T('Xoay','Rotate')+'</button><button class="btn g" data-b="move">✥ '+T('Dời','Move')+'</button>'+(list[B.pick][0]==='house'?'':'<button class="btn g" data-b="store">📦 '+T('Cất kho','Store')+'</button>')+'<button class="btn g" data-b="unpick">✕</button></div>':
    '<div class="r3tray">'+Object.entries(DEC).map(([k,D])=>{const have=inv[k]||0,full=D.max&&count(k)>=D.max;return'<button class="r3it'+(full?' off':'')+'" data-add="'+k+'"'+(full?' disabled':'')+'><i>'+D.i+'</i><small>'+T(D.vi,D.en)+'</small><em>'+(full?T('đã có','placed'):have?T('kho ','stored ')+have:D.cost?'✦'+D.cost:T('miễn phí','free'))+'</em></button>'}).join('')+'</div>')}
 el.onclick=e=>{const b=e.target.closest('[data-b],[data-add]');if(!b)return;const k=b.dataset.b,list=dec();
  if(b.dataset.add){B.sel=b.dataset.add;B.rot=0;B.moving=undefined;const f=P.p.clone().sub(new THREE.Vector3(H.x,0,H.z));B.x=Math.round(Math.max(-5,Math.min(5,f.x))*2)/2;B.z=Math.round(Math.max(-5,Math.min(5,f.z-2))*2)/2;show();return}
  if(k==='rot'){B.rot=(B.rot+1)%8;show()}
  if(k==='cancel'){if(B.moving!=null&&B.moved){list.splice(B.moving,0,B.moved);placeMine(R0)}B.sel=null;B.moving=undefined;B.moved=null;show()}
  if(k==='place'){const t=B.sel,D=DEC[t];if(free(t,B.x,B.z,B.moving))return;const inv=S.w.inv||(S.w.inv={});
   if(B.moved){list.push([t,B.x,B.z,B.rot])}else if(inv[t]>0){inv[t]--;list.push([t,B.x,B.z,B.rot])}else{if((S.w.coins||0)<D.cost)return VN.toast(T('Chưa đủ tinh thể ✦','Not enough crystals ✦'));if(D.cost)VN.WORLD.coin(-D.cost);list.push([t,B.x,B.z,B.rot])}
   B.sel=null;B.moving=undefined;B.moved=null;VN.save();syncMe();placeMine(R0);VN.sfx&&VN.sfx('ok');show();VN.bump&&VN.bump('decor',1)}
  if(k==='prot'){list[B.pick][3]=((list[B.pick][3]||0)+1)%8;VN.save();syncMe();placeMine(R0);show()}
  if(k==='move'){const d=list.splice(B.pick,1)[0];B.moved=d;B.moving=undefined;B.sel=d[0];B.rot=d[3]||0;B.x=d[1];B.z=d[2];B.pick=-1;placeMine(R0);show()}
  if(k==='store'){const d=list.splice(B.pick,1)[0];const inv=S.w.inv||(S.w.inv={});inv[d[0]]=(inv[d[0]]||0)+1;B.pick=-1;VN.save();syncMe();placeMine(R0);show();VN.toast('📦 '+T('Đã cất vào kho (đặt lại miễn phí)','Stored (place again for free)'))}
  if(k==='unpick'){B.pick=-1;show()}
  if(k==='done')exitBuild(R0)};
 show()}
function exitBuild(R0){const B=R0.bm;if(!B)return;if(B.moved){dec().push(B.moved);VN.save();syncMe();placeMine(R0)}if(B.ghost)R0.home.remove(B.ghost);R0.home.remove(B.ring);B.el.remove();R0.P.cp=B.keep.cp;R0.P.dist=B.keep.dist;R0.onTap=null;R0.bm=null;R0.host.classList.remove('r3building')}
/* ---------- weather, pet, animated decor ---------- */
function rainBurst(R0,at,rad){const n=60,pos=new Float32Array(n*3),v=[];for(let i=0;i<n;i++){const a=Math.random()*TAU,r=Math.random()*rad;pos[i*3]=at.x+Math.cos(a)*r;pos[i*3+1]=at.y+3+Math.random()*3;pos[i*3+2]=at.z+Math.sin(a)*r;v.push(4+Math.random()*3)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));const p=new THREE.Points(g,new THREE.PointsMaterial({color:'#bfe9ff',size:.14,transparent:true,opacity:.9}));R0.scene.add(p);const t0=performance.now();
 (R0.oasis.bursts=R0.oasis.bursts||[]).push({p,v,t0,base:at.y})}
function startRain(R0){const n=Math.round(1100*Math.max(.4,(VN.gfx?VN.gfx().k:1))),pos=new Float32Array(n*6);const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));const ls=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:'#cfe8ff',transparent:true,opacity:.55}));ls.frustumCulled=false;R0.scene.add(ls);
 const seed=[];for(let i=0;i<n;i++)seed.push([Math.random()*44-22,Math.random()*22,Math.random()*44-22,9+Math.random()*5]);R0.oasis.rain={ls,seed,t0:performance.now(),dur:38000};const k=waterAll();R0.sun&&(R0.sun.userData.base=R0.sun.userData.base||R0.sun.intensity);
 VN.toast('🌧 '+T('Mưa rào đi qua!','A rain shower!')+(k?' '+T('Đã tưới ','Watered ')+k+T(' ô trên ốc đảo',' plots on your oasis'):''))}
const lowEnd=()=>Math.min(innerWidth,innerHeight)<700;
function tick(R0,t,dt){const O2=R0.oasis;if(!O2)return;const P=R0.P;
 /* pet: trails behind your shoulder */if(O2.pet){const tgt=new THREE.Vector3(P.p.x-Math.sin(P.yaw)*1.1+Math.cos(P.yaw)*.8,P.p.y+1.6+Math.sin(t*2.4)*.15,P.p.z-Math.cos(P.yaw)*1.1-Math.sin(P.yaw)*.8);O2.pet.position.lerp(tgt,Math.min(1,dt*3.2));O2.pet.children[0].rotation.y+=dt*2;O2.pet.children[0].rotation.x+=dt*1.1}
 /* sit on a bench: slow orbit */if(R0.sit){P.cy+=dt*.12;if(R0.inp.jump||Math.hypot(R0.inp.x,R0.inp.z)>.1)R0.sit=false}
 /* animated decor */if(O2.g)O2.g.children.forEach(g=>{const u=g.userData;if(u.spin)u.spin.rotation.z+=dt*1.6;if(u.statue)u.statue.rotation.y+=dt*.6;if(u.fire)u.fire.forEach((f,i)=>{f.scale.set(1,1+Math.sin(t*12+i*2)*.18,1)});if(u.bees)u.bees.forEach((b,i)=>{const a=t*2.2+i*2.1;b.position.set(Math.cos(a)*.7,.6+Math.sin(t*5+i)*.2,Math.sin(a)*.7)});if(u.type==='mailbox'){const f=g.children.find(x=>x.userData.flag);if(f)f.rotation.z=unreadCached>0?-.0:-1.4}});
 if(!O2.ut||t-O2.ut>3){O2.ut=t;unreadCached=unread()}
 /* rain */if(!O2.rain&&now()>O2.nextRain&&!R0.portal&&!R0.intro){startRain(R0);O2.nextRain=now()+(240+Math.random()*300)*1000}
 if(O2.rain){const r=O2.rain,el=performance.now()-r.t0,k=el/r.dur,fade=Math.min(1,el/2500,(r.dur-el)/2500);const a=r.ls.geometry.attributes.position.array;r.seed.forEach((q,i)=>{let y=q[1]-((el/1000)*q[3])%22;if(y<-4)y+=22;const x=P.p.x+q[0],z=P.p.z+q[2],yy=P.p.y+y;a.set([x,yy,z,x+.05,yy-.55,z],i*6)});r.ls.geometry.attributes.position.needsUpdate=true;r.ls.material.opacity=.5*Math.max(0,fade);if(R0.sun&&R0.sun.userData.base)R0.sun.intensity=R0.sun.userData.base*(1-.45*Math.max(0,fade));
  if(k>=1){R0.scene.remove(r.ls);r.ls.geometry.dispose();O2.rain=null;if(R0.sun&&R0.sun.userData.base)R0.sun.intensity=R0.sun.userData.base}}
 if(O2.pops)O2.pops=O2.pops.filter(p=>{const k=(performance.now()-p.t0)/1400;p.l.position.y=p.y+k*1.6;p.l.material.opacity=Math.max(0,1-k*k);if(k>=1){R0.scene.remove(p.l);return false}return true});
 if(O2.bursts)O2.bursts=O2.bursts.filter(b=>{const el=(performance.now()-b.t0)/1000,a=b.p.geometry.attributes.position.array;for(let i=0;i<b.v.length;i++){a[i*3+1]-=b.v[i]*dt;if(a[i*3+1]<b.base+.5)a[i*3+1]=b.base+3+Math.random()*2}b.p.geometry.attributes.position.needsUpdate=true;b.p.material.opacity=Math.max(0,.9-el/2.2);if(el>2.2){R0.scene.remove(b.p);return false}return true})}
let unreadCached=0;
/* ---------- harvest FX + orders modal ---------- */
function ordersModal(){const W=VN.WORLD;const m=VN.modal('<div id="ordM">'+W.ordersCard()+'</div><p class="mu" style="margin-top:6px">'+T('Thu hoạch đúng loại để giao đơn. Mỗi ngày có đơn mới.','Harvest the right crops to fill orders. New orders every day.')+'</p>');
 m.onclick=e=>{const x=e.target.closest('[data-hall],[data-pall],[data-book]');if(!x)return;if(x.dataset.book){W.bookModal();return}if(x.dataset.hall)W.harvestAll();if(x.dataset.pall)W.plantAll(x.dataset.pall);const o=m.querySelector('#ordM');if(o)o.innerHTML=W.ordersCard();const R=VN.REALM._R;if(R)R.lastPlots=''}}
VN.on&&VN.on('harvest',d=>{const R=VN.REALM&&VN.REALM._R;if(!R||!R.oasis)return;const pm=R.plotMeshes.find(x=>x.i===d.i);if(!pm)return;const H=R.L.home,x=H.x+pm.x,z=H.z+pm.z,y=H.y+1.4;
 const l=lib().label((d.gold?'✨ ':'')+'+✦'+d.coins,{h:.6,bg:d.gold?'rgba(255,210,63,.95)':'rgba(255,255,255,.92)',col:'#2a1840',fs:40});l.position.set(x,y,z);R.scene.add(l);const t0=performance.now();(R.oasis.pops=R.oasis.pops||[]).push({l,t0,y});rainBurst(R,{x,y:H.y-1.5,z},.8)});
/* ---------- photo mode ---------- */
function photo(R0){const h=R0.host;h.classList.add('r3snap');requestAnimationFrame(()=>{try{R0.ren.render(R0.scene,R0.cam);const url=R0.ren.domElement.toDataURL('image/jpeg',.92);h.classList.remove('r3snap');flash(h);
  const c=ch();const m=VN.modal('<h3>📷 '+T('Ảnh ốc đảo','Oasis snapshot')+'</h3><img class="snap" alt="" src="'+url+'"><p class="mu">'+T('Nhấn giữ ảnh để lưu hoặc chia sẻ.','Long-press the image to save or share.')+'</p><div class="row"><a class="btn" download="vertexnode-oasis.jpg" href="'+url+'">⬇ '+T('Tải ảnh','Download')+'</a><button class="btn g" id="snShare">📣 '+T('Khoe ở kênh','Brag in channel')+'</button></div>');
  const sh=m.querySelector('a[download]');if(navigator.canShare){fetch(url).then(r=>r.blob()).then(bl=>{const f=new File([bl],'vertexnode-oasis.jpg',{type:'image/jpeg'});if(navigator.canShare({files:[f]})){const bt=document.createElement('button');bt.className='btn g';bt.textContent='↗ '+T('Chia sẻ','Share');sh.after(bt);bt.onclick=()=>navigator.share({files:[f],title:'VertexNode',text:T('Ốc đảo hình học của mình ở VertexNode ✦','My geometry oasis in VertexNode ✦')}).catch(()=>{})}}).catch(()=>{})}
  $('#snShare').onclick=()=>{N.post('khoe','📷 '+(c.nk||T('Mình','I'))+T(' vừa chụp ốc đảo của mình ở VertexNode!',' just snapped their oasis in VertexNode!'),true);VN.closeModal();VN.toast(T('Đã khoe!','Shared!'))}}catch(e){h.classList.remove('r3snap');VN.toast(T('Không chụp được ảnh trên thiết bị này.','Could not take a photo here.'))}})}
Object.assign(O,{ordersModal,ch,portal,onBuild,friend,label,use,tick,build,photo,exitBuild,DEC,clean,_dec:dec});
VN.OASIS=O;
})();
