/* Living space background: nebula, 3-layer starfield with parallax, glowing perspective grid,
   drifting 4D wireframes (tesseract, 16-cell, 24-cell…), shooting stars. Toggle: S.fx (1 on, 0 off).
   Cheap: nebula pre-rendered at low resolution, DPR capped, paused when hidden, static frame for reduced motion. */
(function(){
'use strict';
const S=VN.S,R4=VN.R4,TAU=Math.PI*2;
let cv,ctx,neb,W=0,H=0,D=1,on=false,raf=0,t0=0,last=0,px=0,py=0,tx=0,ty=0,stars=[],objs=[],shoot=null,dark=true;
const RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function rnd(a,b){return a+Math.random()*(b-a)}
function build(){stars=[];const n=Math.round(Math.min(340,W*H/4200));for(let i=0;i<n;i++){const z=Math.random();stars.push({x:Math.random(),y:Math.random(),z,r:.4+z*1.5,tw:rnd(0,TAU),sp:rnd(.6,2.2),hue:Math.random()})}
 const G=R4.gen,mk=[['tesseract',4],['cell16',4],['cell24',4],['icosa',3],['octa',3],['cell5',4]];objs=[];
 const k=W<700?3:5;for(let i=0;i<k;i++){const [g]=mk[i%mk.length];let m;try{m=G[g]()}catch(e){m=G.tesseract()}
  let r=0;m.V.forEach(p=>r=Math.max(r,Math.hypot(p[0],p[1],p[2],p[3]||0)));objs.push({m,r:r||1,x:rnd(.06,.94),y:rnd(.08,.62),s:rnd(.05,.1)*(i===0?1.5:1),z:rnd(.3,1),a:{xy:rnd(0,6),xz:rnd(0,6),yz:rnd(0,6),xw:rnd(0,6),yw:rnd(0,6),zw:rnd(0,6)},w:[rnd(-.2,.2),rnd(.08,.22),rnd(-.12,.12),rnd(.1,.3),rnd(-.2,.2),rnd(.05,.2)],vx:rnd(-.004,.004),vy:rnd(-.002,.002)})}
 renderNebula()}
function renderNebula(){neb=document.createElement('canvas');const w=neb.width=Math.max(160,Math.round(W/6)),h=neb.height=Math.max(120,Math.round(H/6)),c=neb.getContext('2d');
 const bg=c.createLinearGradient(0,0,0,h);if(dark){bg.addColorStop(0,'#03050b');bg.addColorStop(.55,'#070c1a');bg.addColorStop(1,'#0b0a14')}else{bg.addColorStop(0,'#fff7ec');bg.addColorStop(.6,'#f1f6ff');bg.addColorStop(1,'#eaf7ef')}c.fillStyle=bg;c.fillRect(0,0,w,h);
 const blob=(x,y,r,col,a)=>{const g=c.createRadialGradient(x*w,y*h,0,x*w,y*h,r*Math.max(w,h));g.addColorStop(0,col.replace('A',a));g.addColorStop(.45,col.replace('A',a*.45));g.addColorStop(1,col.replace('A',0));c.fillStyle=g;c.fillRect(0,0,w,h)};
 if(R4.classic()){prismBg(c,w,h);return}
 const k=dark?1:.55;blob(.12,.1,.55,'rgba(255,122,26,A)',.30*k);blob(.92,.18,.5,'rgba(61,220,132,A)',.22*k);blob(.55,.95,.6,'rgba(255,210,63,A)',.16*k);blob(.7,.45,.35,'rgba(120,90,255,A)',dark?.10:.05);blob(.25,.6,.3,'rgba(0,190,255,A)',dark?.07:.04)}

/* ===== "Prism" style (classic, default): purple→teal sky, translucent faceted polyhedra, light streaks, tilt parallax ===== */
let prisms=[],streaks=[];
const PCOL={dark:[[78,124,222],[206,92,82],[128,96,226],[86,176,232]],light:[[255,255,255],[255,255,255],[120,170,255],[255,255,255]]};
function buildPrism(){prisms=[];const G=R4.gen,kinds=['icosa','octa','cube','tetra','pyramid','octa','tetra','cube','icosa'];const n=W<700?6:9;
 for(let i=0;i<n;i++){let m;try{m=G[kinds[i%kinds.length]]()}catch(e){m=G.cube()}if(!m.F||!m.F.length)continue;let r=0;m.V.forEach(p=>r=Math.max(r,Math.hypot(p[0],p[1],p[2])));
  const z=rnd(.35,1.4),big=i<2;prisms.push({m,r:r||1,x:rnd(-.05,1.05),y:rnd(.05,.95),z,s:(big?rnd(.32,.48):rnd(.1,.24)),st:kinds[i%kinds.length]==='octa'&&i>3?2.1:1,a:{xy:rnd(0,6),xz:rnd(0,6),yz:rnd(0,6),xw:0,yw:0,zw:0},w:[rnd(-.05,.05),rnd(.04,.12)*(Math.random()<.5?-1:1),rnd(-.06,.06)],col:i%4})}
 prisms.sort((a,b)=>a.z-b.z);streaks=[];const k=W<700?26:42;for(let i=0;i<k;i++)streaks.push({x:Math.random(),y:Math.random(),l:rnd(14,46),z:rnd(.3,1.2),a:rnd(.25,.7)})}
function prismBg(c,w,h){const g=c.createLinearGradient(0,0,0,h);if(dark){g.addColorStop(0,'#1a0f3f');g.addColorStop(.45,'#3a1c72');g.addColorStop(.75,'#2c2f7a');g.addColorStop(1,'#1d6c86')}else{g.addColorStop(0,'#86b6ff');g.addColorStop(.55,'#9fd0ff');g.addColorStop(1,'#64e2d2')}c.fillStyle=g;c.fillRect(0,0,w,h);
 const b=(x,y,r,col)=>{const q=c.createRadialGradient(x*w,y*h,0,x*w,y*h,r*Math.max(w,h));q.addColorStop(0,col);q.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=q;c.fillRect(0,0,w,h)};
 if(dark){b(.15,.05,.6,'rgba(150,80,255,.28)');b(.9,.95,.6,'rgba(40,200,210,.22)');b(.6,.45,.4,'rgba(255,90,140,.08)')}else{b(.1,.1,.6,'rgba(255,255,255,.35)');b(.9,.9,.5,'rgba(40,220,200,.25)')}}
function drawPrism(ts,dt){const c=ctx,pk=dark?PCOL.dark:PCOL.light;
 /* streaks */
 c.lineCap='round';streaks.forEach(s=>{if(!RM){s.y+=dt*.012*s.z;s.x-=dt*.004*s.z;if(s.y>1.05){s.y=-.05;s.x=Math.random()*1.1}if(s.x<-.05)s.x=1.05}const x=s.x*W+px*30*s.z,y=s.y*H+py*30*s.z;c.strokeStyle=dark?'rgba(120,190,255,'+s.a*.7+')':'rgba(255,255,255,'+s.a+')';c.lineWidth=1+s.z*1.4;c.beginPath();c.moveTo(x,y);c.lineTo(x+s.l*.34,y-s.l);c.stroke()});
 /* grid floor */
 const hz=H*.64;c.lineWidth=1;const vx=W/2+px*50;for(let i=-22;i<=22;i++){const x0=vx+i*(W/22)*2.4;c.strokeStyle=dark?'rgba(150,190,255,.14)':'rgba(255,255,255,.4)';c.beginPath();c.moveTo(vx+(x0-vx)*.03,hz);c.lineTo(x0,H);c.stroke()}
 for(let k=0;k<12;k++){const f=(k+((ts/1000*.08)%1))/12,y=hz+(H-hz)*f*f;c.strokeStyle=dark?'rgba(150,190,255,'+(.2*f)+')':'rgba(255,255,255,'+(.5*f)+')';c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke()}
 const hl=c.createLinearGradient(0,hz-30,0,hz+30);hl.addColorStop(0,'rgba(255,255,255,0)');hl.addColorStop(.5,dark?'rgba(170,140,255,.16)':'rgba(255,255,255,.35)');hl.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=hl;c.fillRect(0,hz-30,W,60);
 /* translucent polyhedra, far first */
 prisms.forEach(o=>{if(!RM){o.a.xy+=o.w[0]*dt;o.a.xz+=o.w[1]*dt;o.a.yz+=o.w[2]*dt}const a=Object.assign({},o.a);a.xz+=px*.5*o.z;a.yz+=py*.4*o.z;const R=R4.rot(a);
  const sc=Math.min(W,H)*o.s/o.r,cx=o.x*W+px*70*o.z,cy=o.y*H+py*50*o.z;
  const Q=o.m.V.map(p=>{const q=[R[0]*p[0]+R[1]*p[1]+R[2]*p[2],R[4]*p[0]+R[5]*p[1]+R[6]*p[2],R[8]*p[0]+R[9]*p[1]+R[10]*p[2]];q[1]*=o.st;const k=4/(4-q[2]*.8);return[cx+q[0]*k*sc,cy-q[1]*k*sc,q[2],q]});
  const col=pk[o.col],fz=o.m.F.map(f=>{const A=Q[f[0]][3],B=Q[f[1]][3],C=Q[f[2]][3];let n=[(B[1]-A[1])*(C[2]-A[2])-(B[2]-A[2])*(C[1]-A[1]),(B[2]-A[2])*(C[0]-A[0])-(B[0]-A[0])*(C[2]-A[2]),(B[0]-A[0])*(C[1]-A[1])-(B[1]-A[1])*(C[0]-A[0])];const ce=[0,1,2].map(k=>f.reduce((s,i)=>s+Q[i][3][k],0)/f.length);if(n[0]*ce[0]+n[1]*ce[1]+n[2]*ce[2]<0)n=n.map(v=>-v);const L=Math.hypot(...n)||1;return{f,z:ce[2],lit:Math.max(0,(n[0]*-.4+n[1]*.6+n[2]*.7)/L),front:n[2]>0}}).sort((p,q)=>p.z-q.z);
  const al=dark?(.1+.12*Math.min(1,o.z)):(.16+.1*Math.min(1,o.z));
  fz.forEach(F=>{c.beginPath();F.f.forEach((i,k)=>k?c.lineTo(Q[i][0],Q[i][1]):c.moveTo(Q[i][0],Q[i][1]));c.closePath();const l=F.lit;c.fillStyle='rgba('+col.map(v=>Math.round(Math.min(255,v*(.75+.45*l)))).join(',')+','+(al*(F.front?1:.55)).toFixed(3)+')';c.fill();c.strokeStyle='rgba('+col.map(v=>Math.round(Math.min(255,v+60))).join(',')+','+(dark?(F.front?.55:.18):(F.front?.75:.3))+')';c.lineWidth=F.front?1.1:.7;c.stroke()})})}
function size(){D=Math.min(1.5,window.devicePixelRatio||1);W=innerWidth;H=innerHeight;cv.width=Math.round(W*D);cv.height=Math.round(H*D);cv.style.width=W+'px';cv.style.height=H+'px';dark=VN.dark();build();buildPrism();draw(performance.now())}
const ramp=(t,a)=>R4.ramp(t,dark,a);
function grid(ts){const hz=H*.64,c=ctx;const g=c.createLinearGradient(0,hz,0,H);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,dark?'rgba(255,138,43,.10)':'rgba(226,88,12,.06)');c.fillStyle=g;c.fillRect(0,hz,W,H-hz);
 c.lineWidth=1;const vx=W/2+px*40;const n=26;for(let i=-n;i<=n;i++){const x0=vx+i*(W/n)*2.2;c.strokeStyle=ramp(.5+i/(2*n)*.9,dark?.16:.12);c.beginPath();c.moveTo(vx+(x0-vx)*.02,hz);c.lineTo(x0,H);c.stroke()}
 const sp=(ts/1000*.12)%1;for(let k=0;k<14;k++){const f=(k+sp)/14,y=hz+(H-hz)*f*f;c.strokeStyle=ramp(.2+f*.6,(dark?.22:.16)*f);c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke()}
 const hl=c.createLinearGradient(0,0,W,0);hl.addColorStop(0,'rgba(255,122,26,0)');hl.addColorStop(.3,dark?'rgba(255,122,26,.5)':'rgba(226,88,12,.35)');hl.addColorStop(.5,dark?'rgba(255,210,63,.6)':'rgba(217,154,0,.4)');hl.addColorStop(.7,dark?'rgba(61,220,132,.5)':'rgba(19,154,84,.35)');hl.addColorStop(1,'rgba(61,220,132,0)');c.strokeStyle=hl;c.lineWidth=1.2;c.beginPath();c.moveTo(0,hz);c.lineTo(W,hz);c.stroke()}
function poly(o,ts,dt){const c=ctx,m=o.m;for(let i=0;i<6;i++){const k=['xy','xz','yz','xw','yw','zw'][i];o.a[k]+=o.w[i]*dt}o.x+=o.vx*dt;o.y+=o.vy*dt;if(o.x<-.15)o.x=1.15;if(o.x>1.15)o.x=-.15;if(o.y<-.1||o.y>.75)o.vy*=-1;
 const R=R4.rot(o.a),sc=Math.min(W,H)*o.s/o.r,cx=(o.x+px*.03*o.z)*W,cy=(o.y+py*.03*o.z)*H;
 const P=m.V.map(p=>{const q=[0,1,2,3].map(r=>R[r*4]*p[0]+R[r*4+1]*p[1]+R[r*4+2]*p[2]+R[r*4+3]*(p[3]||0));const k4=3/(3-q[3]),k3=4/(4-q[2]*k4);return[cx+q[0]*k4*k3*sc,cy-q[1]*k4*k3*sc,q[2]+q[3]]});
 let zmn=1e9,zmx=-1e9;P.forEach(p=>{zmn=Math.min(zmn,p[2]);zmx=Math.max(zmx,p[2])});const tz=p=>1-(p[2]-zmn)/Math.max(1e-6,zmx-zmn);
 const al=(dark?.36:.26)*(.4+o.z*.6);c.lineCap='round';
 if(dark){c.globalCompositeOperation='lighter';c.lineWidth=4;(m.E||[]).forEach(e=>{const a=P[e[0]],b=P[e[1]];c.strokeStyle=ramp((tz(a)+tz(b))/2,al*.16);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()})}
 c.lineWidth=1.1+o.z*.5;(m.E||[]).forEach(e=>{const a=P[e[0]],b=P[e[1]];c.strokeStyle=ramp((tz(a)+tz(b))/2,al);c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()});
 P.forEach(p=>{c.fillStyle=ramp(tz(p),al*1.2);c.beginPath();c.arc(p[0],p[1],1.3+o.z,0,TAU);c.fill()});c.globalCompositeOperation='source-over'}
function draw(ts){if(!ctx)return;const dt=Math.min(.05,(ts-last)/1000||0);last=ts;px+=(tx-px)*.04;py+=(ty-py)*.04;const c=ctx;c.setTransform(D,0,0,D,0,0);
 c.imageSmoothingEnabled=true;c.drawImage(neb,0,0,W,H);
 if(R4.classic()){if(dark){stars.forEach((st,i)=>{if(i%4)return;c.globalAlpha=.25+.5*st.z;c.fillStyle='#fff';c.beginPath();c.arc(st.x*W+px*10*st.z,st.y*H*.6+py*8*st.z,st.r*.7,0,TAU);c.fill()});c.globalAlpha=1}drawPrism(ts,RM?0:dt);return}
 /* stars */
 if(dark){const dr=ts/1000;stars.forEach(s=>{const x=((s.x+dr*.0025*s.z+px*.012*s.z)%1+1)%1*W,y=(s.y+py*.012*s.z)*H,tw=.55+.45*Math.sin(s.tw+dr*s.sp);c.globalAlpha=Math.min(1,(.25+.75*s.z)*tw);c.fillStyle=s.hue<.15?'#ffcf8a':s.hue<.27?'#b9ffd6':'#ffffff';c.beginPath();c.arc(x,y,s.r,0,TAU);c.fill();if(s.z>.92){c.globalAlpha*=.25;c.fillRect(x-s.r*4,y-.4,s.r*8,.8);c.fillRect(x-.4,y-s.r*4,.8,s.r*8)}});c.globalAlpha=1}
 else{stars.forEach((s,i)=>{if(i%3)return;const x=s.x*W+px*8*s.z,y=s.y*H*.6;c.fillStyle=ramp(s.hue,.18);c.beginPath();c.arc(x,y,s.r*.8,0,TAU);c.fill()})}
 grid(ts);objs.forEach(o=>poly(o,ts,RM?0:dt));
 /* shooting star */
 if(dark&&!RM){if(!shoot&&Math.random()<.004)shoot={x:rnd(.1,.9)*W,y:rnd(0,.3)*H,vx:rnd(-9,-5),vy:rnd(3,5),l:1};if(shoot){const s=shoot,g=c.createLinearGradient(s.x,s.y,s.x-s.vx*14,s.y-s.vy*14);g.addColorStop(0,'rgba(255,240,200,'+s.l+')');g.addColorStop(1,'rgba(255,138,43,0)');c.strokeStyle=g;c.lineWidth=1.6;c.beginPath();c.moveTo(s.x,s.y);c.lineTo(s.x-s.vx*14,s.y-s.vy*14);c.stroke();s.x+=s.vx;s.y+=s.vy;s.l-=.012;if(s.l<=0||s.x<-50||s.y>H)shoot=null}}}
function loop(ts){if(!on)return;raf=requestAnimationFrame(loop);if(document.hidden)return;if(ts-t0<(W*H>1.6e6?33:16))return;t0=ts;draw(ts)}
function start(){if(on)return;on=true;document.documentElement.classList.add('fx');if(!cv){cv=document.createElement('canvas');cv.id='bgfx';cv.setAttribute('aria-hidden','true');document.body.prepend(cv);ctx=cv.getContext('2d');addEventListener('resize',()=>{if(on)size()});
  addEventListener('pointermove',e=>{tx=e.clientX/innerWidth*2-1;ty=e.clientY/innerHeight*2-1},{passive:true});
  addEventListener('deviceorientation',e=>{if(e.gamma!=null){tx=Math.max(-1,Math.min(1,e.gamma/25));ty=Math.max(-1,Math.min(1,(e.beta-45)/25))}},{passive:true});
  const ask=()=>{removeEventListener('pointerdown',ask);try{if(window.DeviceOrientationEvent&&typeof DeviceOrientationEvent.requestPermission==='function')DeviceOrientationEvent.requestPermission().catch(()=>{})}catch(e){}};addEventListener('pointerdown',ask,{passive:true})}
 cv.style.display='';size();if(RM){draw(performance.now());return}raf=requestAnimationFrame(loop)}
function stop(){on=false;cancelAnimationFrame(raf);document.documentElement.classList.remove('fx');if(cv)cv.style.display='none'}
VN.fx={start,stop,set(v){S.fx=v?1:0;VN.save();v?start():stop();VN.emit('fx')},get on(){return on}};
VN.on('theme',()=>{if(on){dark=VN.dark();renderNebula();draw(performance.now())}});
VN.fx.parallax=()=>[px,py];
})();
