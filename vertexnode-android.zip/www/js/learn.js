/* Learn: hosts the two engines (geometry trainer, physics trainer) behind one segmented control + section pills. */
(function(){
'use strict';
const {T,esc,$,$$,S}=VN,D=VN.DATA;
const GT={mP:['Chơi','Play'],mF:['Khám phá','Explore'],mL:['Công thức','Formulas'],mJ:['Giải đề','Solver'],mS:['Bài test','Quiz'],mO:['Vectơ','Vectors'],mV:['Hình chiếu','Projections'],mD:['Hằng ngày','Daily'],mB:['Tra cứu','Reference'],mT:['Góc','Angles'],mR:['Biến hình','Transform'],mC:['Đố vui','Trivia'],mN:['Khai triển','Nets'],mX:['Mặt cắt','Sections'],mK:['Xếp hộp','Packing'],mA:['Sticker','Stickers']};
let root,st={eng:'geo',tab:{geo:'',phy:'play'},tabs:{geo:[],phy:[]}},ro;
function init(el){root=el;
 el.innerHTML='<div class="wrap" style="width:100%;display:flex;flex-direction:column;flex:1;min-height:0"><div class="row" style="margin-bottom:4px"><span class="seg" id="lE"></span></div><div class="pills" id="lK"></div><div class="pills" id="lT"></div><div id="engSlot"><div id="engLoad"></div></div></div>';
 $('#lE').onclick=e=>{const b=e.target.closest('button');if(b)switchEng(b.dataset.e)};
 $('#lT').onclick=e=>{const b=e.target.closest('.chip');if(b)setTab(b.dataset.t)};
 $('#lK').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;if(b.dataset.lab)return VN.go('lab',{lab:b.dataset.lab});const l=D.LINKS.find(x=>x.id===b.dataset.l);const o=b.dataset.to==='phy'?l.phy:l.geo;VN.open(o)};
 if(window.ResizeObserver)ro=new ResizeObserver(dock);ro&&ro.observe(el);window.addEventListener('resize',dock)}
function dock(){const h=$('#engHost'),s=$('#engSlot');if(!h)return;if(VN.cur!=='learn'||!s||!s.offsetParent){h.classList.remove('docked');h.style.cssText='';return}
 const r=s.getBoundingClientRect();h.classList.add('docked');h.style.left=r.left+'px';h.style.top=r.top+'px';h.style.width=r.width+'px';h.style.height=r.height+'px'}
async function refreshTabs(){const key=st.eng,en=VN.eng[key];try{const t=await en.call('tabs');st.tabs[key]=t}catch(e){}renderBar()}
function renderBar(){const g=st.eng==='geo';
 $('#lE').innerHTML='<button data-e="geo" class="'+(g?'on':'')+'">△ '+T('Hình học','Geometry')+'</button><button data-e="phy" class="'+(!g?'on':'')+'">⚛ '+T('Vật lý','Physics')+'</button>';
 const tabs=st.tabs[st.eng]||[];$('#lT').innerHTML=tabs.filter(t=>t.show!==false).map(t=>'<button class="chip'+(t.id===st.tab[st.eng]?' on':'')+'" data-t="'+t.id+'">'+esc(g?((t.ico||'')+' '+T((GT[t.id]||[t.vi,t.vi])[0],(GT[t.id]||[t.vi,t.vi])[1])):(S.lg==='en'?t.en:t.vi))+'</button>').join('');
 /* cross links relevant to the open section */
 const cur=st.tab[st.eng];let ls=D.LINKS.filter(l=>(g?l.geo.eng==='geo'&&l.geo.tab===cur:l.phy.tab===cur&&l.phy.eng==='phy'));if(!ls.length)ls=D.LINKS.filter(l=>g?l.geo.eng==='geo':l.phy.eng==='phy').slice(0,2);if(!ls.length)ls=D.LINKS.slice(0,2);
 $('#lK').innerHTML=ls.slice(0,3).map(l=>'<button class="chip" data-l="'+l.id+'" data-to="'+(g?'phy':'geo')+'">↔ '+esc(T(l.vi,l.en))+'</button>').join('')+'<button class="chip" data-lab="float">🧪 Lab</button>'}
async function setTab(id){const en=VN.eng[st.eng];st.tab[st.eng]=id;renderBar();try{if(st.eng==='geo')await en.call('mode',id);else await en.call('go',id)}catch(e){VN.toast(T('Không mở được mục này','Could not open this section'))}}
async function switchEng(k){st.eng=k;await showEng();}
async function showEng(){const en=VN.eng[st.eng];$('#engLoad').textContent=en.ready?'':T('Đang tải…','Loading…');
 Object.values(VN.eng).forEach(e=>e.frame&&e.frame.classList.toggle('on',e===en));
 await en.load();Object.values(VN.eng).forEach(e=>e.frame&&e.frame.classList.toggle('on',e===en));
 $('#engLoad').textContent='';await refreshTabs();dock();en.call('theme',{dark:VN.dark(),vars:VN.engVars(VN.dark())}).catch(()=>{});
 if(S.gk)VN.pushKey();
 try{en.frame.contentWindow.dispatchEvent(new Event('resize'))}catch(e){}}
async function show(p){p=p||{};if(p.eng)st.eng=p.eng;dock();await showEng();
 if(p.tab){await setTab(p.tab)}
 else if(!st.tab[st.eng]){const t=(st.tabs[st.eng]||[]).filter(x=>x.show!==false)[0];if(t)st.tab[st.eng]=t.id;renderBar()}
 if(p.q&&st.eng==='geo'){try{await VN.eng.geo.call('open',p.q)}catch(e){}}
 dock();setTimeout(dock,120);setTimeout(dock,500)}
function hide(){const h=$('#engHost');h.classList.remove('docked');h.style.cssText=''}
VN.views.learn={init,show,render:()=>{if(VN.cur==='learn')renderBar()},hide};
VN.on('age',()=>{VN.eng.geo.ready&&VN.eng.geo.call('age',S.age).then(refreshTabs).catch(()=>{})});
})();
