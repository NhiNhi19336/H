/* Home: the Dimension Tower (RPG spine), daily quests, cross-links. */
(function(){
'use strict';
const {T,esc,$,$$,S}=VN,D=VN.DATA,R4=VN.R4;
let root,hv;
const done=id=>!!(S.nodes[id]&&S.nodes[id].d);
const realmNodes=r=>D.NODES.filter(n=>n.r===r);
const unlocked=r=>r===0||(realmNodes(r-1).filter(n=>done(n.id)).length>=Math.ceil(realmNodes(r-1).length*.6));
VN.unlocked=unlocked;
function nextNode(){for(let r=0;r<5;r++){if(!unlocked(r))break;const n=realmNodes(r).find(n=>!done(n.id));if(n)return n}return null}
function init(el){root=el;el.innerHTML='<div class="wrap" id="hm"></div>';
 root.addEventListener('click',e=>{const n=e.target.closest('[data-n]');if(n)return nodeModal(n.dataset.n);
  const l=e.target.closest('[data-l]');if(l){const k=l.dataset.l,link=D.LINKS.find(x=>x.id===l.dataset.id);if(k==='geo')VN.open(link.geo);else if(k==='phy')VN.open(link.phy);else if(k==='lab')VN.go('lab',{lab:link.lab})}
  if(e.target.closest('#hInv')){const L=VN.lvOf(S.xp||0),url=/^https?:/.test(location.href)?location.href.split('#')[0]:'https://claude.ai',txt=VN.T('Mình đang ở cấp '+L+' trên VertexNode: học hình học + vật lý bằng thế giới 4D, có nông trại, cờ khối, gia sư offline. Vào chơi cùng nha!','I am level '+L+' on VertexNode: geometry + physics through a 4D world, with a farm, cube chess and an offline tutor. Join me!');if(navigator.share)navigator.share({title:'VertexNode',text:txt,url}).catch(()=>{});else{(navigator.clipboard?navigator.clipboard.writeText(txt+' '+url):Promise.reject()).then(()=>VN.toast(VN.T('Đã chép lời mời, dán gửi bạn bè nhé!','Invite copied, paste it to a friend!'))).catch(()=>VN.toast(url))}return}
  if(e.target.closest('#hCont')){const nn=nextNode();if(nn)nodeModal(nn.id)}})}
function render(){if(!root||!root.firstChild)return;const L=VN.lvOf(S.xp),rk=VN.RANKS[VN.rank()],nn=nextNode(),total=D.NODES.length,dn=D.NODES.filter(n=>done(n.id)).length;
 const q=VN.quests();
 const lo=(L-1)*(L-1)*25,hi=L*L*25,pr=Math.max(0,Math.min(1,(S.xp-lo)/(hi-lo))),CR=2*Math.PI*26;
 let h='<div class="hero"><div class="portal"><canvas class="cv" id="hCv"></canvas><div class="pbar"><div class="ring"><svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" class="rt"/><circle cx="32" cy="32" r="26" class="rp" stroke-dasharray="'+(CR*pr).toFixed(1)+' '+CR.toFixed(1)+'" transform="rotate(-90 32 32)"/></svg><b>'+L+'</b></div><div class="pinfo"><b>'+esc(T(rk[0],rk[1]))+'</b><small>'+S.xp+' XP · '+(hi-S.xp)+T(' XP nữa lên cấp',' XP to next level')+' · 🔥 '+S.streak+'</small></div>'+
  (nn?'<button class="btn" id="hCont"><span>▶ '+T('Học tiếp','Continue')+'</span><small>'+esc(T(nn.vi,nn.en))+'</small></button>':'<span class="tag">'+T('Đã chinh phục Tháp!','Tower conquered!')+'</span>')+'</div></div>'+
  '<div class="card" style="margin:0"><h3>🎯 '+T('Nhiệm vụ hôm nay','Today’s quests')+'</h3>'+q.map(x=>'<div class="q'+(x.done?' done':'')+'"><span class="p">'+esc(T(x.vi,x.en))+'</span><small class="mono">'+Math.min(x.have,x.need)+'/'+x.need+'</small><span class="tag">+'+x.xp+'</span></div>').join('')+
  '<div style="margin-top:8px"><small>'+T('Tiến độ Tháp','Tower progress')+': '+dn+'/'+total+'</small><div class="bar" style="margin-top:4px"><i style="width:'+Math.round(100*dn/total)+'%"></i></div></div><button class="btn g hinv" id="hInv">📣 '+T('Rủ bạn cùng học','Invite a friend')+'</button></div></div>';
 h+='<div class="h2">'+T('Tháp chiều: leo từ Điểm lên Siêu không gian','The Dimension Tower: climb from Point to Hyperspace')+'</div><div class="tower">'+D.REALMS.map(r=>{const ns=realmNodes(r.d),k=ns.filter(n=>done(n.id)).length,ul=unlocked(r.d);
  return '<div class="realm'+(ul?'':' lock')+'"><div class="row" style="justify-content:space-between"><div class="row"><span class="dim">'+r.d+'D</span><div><b>'+esc(T(r.vi,r.en))+'</b><br><small>'+esc(T(r.sub[0],r.sub[1]))+'</small></div></div><span class="tag">'+(ul?k+'/'+ns.length:'🔒 '+T('hoàn thành 60% chặng dưới','finish 60% of the realm below'))+'</span></div><div class="nodes">'+ns.map(n=>'<button class="node'+(done(n.id)?' done':'')+'" data-n="'+n.id+'">'+esc(T(n.vi,n.en))+'</button>').join('')+'</div></div>'}).join('')+'</div>';
 h+='<div class="h2" style="margin-top:16px">'+T('Cầu nối Hình ↔ Lý','Geometry ↔ Physics bridges')+'</div><div class="grid g3">'+D.LINKS.map(l=>'<div class="card" style="margin:0"><b>'+esc(T(l.vi,l.en))+'</b><div class="mu" style="margin:4px 0 6px">'+esc(T(l.d[0],l.d[1]))+'</div><div class="links"><button class="chip" data-l="geo" data-id="'+l.id+'">△ '+T('Hình','Geometry')+'</button><button class="chip" data-l="phy" data-id="'+l.id+'">⚛ '+T('Lý','Physics')+'</button>'+(l.lab?'<button class="chip" data-l="lab" data-id="'+l.id+'">🧪 Lab</button>':'')+'</div></div>').join('')+'</div>';
 root.firstChild.innerHTML=h;
 const cv=$('#hCv');if(cv){if(hv)hv.stop();hv=R4.View(cv,{h:window.innerWidth<700?250:300,lw:2.1});hv.spin4=true;hv.auto=true;hv.start();hv.set(R4.gen.tesseract())}}
function nodeModal(id){const n=D.NODES.find(x=>x.id===id),r=D.REALMS[n.r];
 if(!unlocked(n.r))return VN.toast(T('Hoàn thành 60% chặng dưới để mở khóa','Finish 60% of the realm below to unlock'));
 const dn=done(id);
 const m=VN.modal('<div class="row"><span class="tag">'+r.d+'D</span><h3 style="margin:0">'+esc(T(n.vi,n.en))+'</h3></div><p class="mu">'+(dn?T('Đã hoàn thành. Bạn có thể ôn lại.','Completed. You can review it.'):T('Xem phần học, rồi trả lời câu hỏi kiểm tra để nhận ','Study the topic, then answer the check question to earn ')+(dn?'':n.xp+' XP'))+'</p><div class="row"><button class="btn g" id="nGo">'+T('Đi tới nội dung','Go to the lesson')+'</button><button class="btn" id="nCk">'+T('Làm câu kiểm tra','Take the check')+'</button></div>');
 $('#nGo',m).onclick=()=>{VN.closeModal();const g=Object.assign({},n.go);if(g.view)VN.go(g.view,g);else VN.open(g)};
 $('#nCk',m).onclick=()=>{VN.closeModal();VN.ask(n.q,ok=>{if(ok){if(!done(id)){S.nodes[id]={d:1,ts:Date.now()};VN.save();VN.xp(n.xp,'node');VN.bump('node',1);VN.toast('✓ '+T(n.vi,n.en)+'  +'+n.xp+' XP')}VN.closeModal();render()}})}}
function show(){render()}
function hide(){if(hv)hv.stop()}
VN.on('theme',()=>hv&&hv.draw());VN.on('xp',()=>{if(VN.cur==='home')render()});
VN.views.home={init,show,render,hide};
})();
