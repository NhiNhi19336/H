/* Procedural questions with exact answers and plausible distractors (common mistakes), by band.
   VN.qgen(band) -> {q, opts:[4 strings], a:index, ex}. band: 'TH' | 'THCS' | 'THPT' | 'DH'. */
(function(){
'use strict';
const T=VN.T,PI=Math.PI;
const ri=(a,b)=>a+Math.floor(Math.random()*(b-a+1)),pick=a=>a[Math.floor(Math.random()*a.length)];
const nf=x=>VN.nf?VN.nf(x,2):String(Math.round(x*100)/100);
const clean=s=>{s=String(s).replace(/(^|[^\d,.])1(π|√)/g,'$1$2').replace(/(^|[^\d,.])1,33π/g,'$14π/3').replace(/(^|[^\d,.])0,67π/g,'$12π/3');if(VN.S&&VN.S.lg!=='en')s=s.replace(/(\d)\.(\d)/g,'$1,$2');return s};
function mk(q,right,wrongs,ex,fmt){const f0=fmt||(x=>String(x)),f=x=>clean(f0(x));const seen=new Set([f(right)]),opts=[f(right)];for(const w of wrongs){const s=f(w);if(!seen.has(s)&&opts.length<4){seen.add(s);opts.push(s)}}let k=1;while(opts.length<4){const v=typeof right==='number'?right+k*(k%2?1:-1)*Math.max(1,Math.round(Math.abs(right)*.15)):right;const s=f(v);if(!seen.has(s)){seen.add(s);opts.push(s)}k++;if(k>20)break}
 for(let i=opts.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[opts[i],opts[j]]=[opts[j],opts[i]]}return{q,opts,a:opts.indexOf(f(right)),ex}}
const G={
TH:[()=>{const a=ri(3,15),b=ri(2,a-1);return mk(T('Hình chữ nhật dài '+a+' cm, rộng '+b+' cm. Diện tích?','A rectangle is '+a+' cm by '+b+' cm. Area?'),a*b,[(a+b)*2,a+b,a*b*2],T('S = dài × rộng = '+a+' × '+b+' = '+a*b+' cm²','S = length × width = '+a*b+' cm²'),x=>x+' cm²')},
 ()=>{const a=ri(3,15),b=ri(2,a-1);return mk(T('Chu vi hình chữ nhật '+a+' cm × '+b+' cm?','Perimeter of a '+a+' cm × '+b+' cm rectangle?'),(a+b)*2,[a*b,a+b,a*2+b],T('P = (dài + rộng) × 2 = '+(a+b)*2+' cm','P = (l + w) × 2'),x=>x+' cm')},
 ()=>{const a=ri(4,20),h=ri(2,12)*2;return mk(T('Tam giác đáy '+a+' cm, cao '+h+' cm. Diện tích?','Triangle base '+a+' cm, height '+h+' cm. Area?'),a*h/2,[a*h,a+h,a*h/4],T('S = đáy × cao : 2 = '+a*h/2+' cm²','S = base × height : 2'),x=>nf(x)+' cm²')},
 ()=>{const r=ri(1,10);return mk(T('Hình tròn bán kính '+r+' cm (π ≈ 3,14). Diện tích?','Circle radius '+r+' cm (π ≈ 3.14). Area?'),r*r*3.14,[r*2*3.14,r*3.14,2*r*2*r*3.14],T('S = r × r × 3,14 = '+nf(r*r*3.14)+' cm²','S = r × r × 3.14'),x=>nf(x)+' cm²')},
 ()=>{const a=ri(2,9);return mk(T('Hình lập phương cạnh '+a+' cm. Thể tích?','Cube with edge '+a+' cm. Volume?'),a*a*a,[a*a*6,a*a,a*3],T('V = a × a × a = '+a*a*a+' cm³','V = a³'),x=>x+' cm³')},
 ()=>{const a=ri(3,9),b=ri(3,9),h=ri(2,8);return mk(T('Hình thang đáy '+a+' cm và '+b+' cm, cao '+h+' cm. Diện tích?','Trapezoid bases '+a+' and '+b+' cm, height '+h+' cm. Area?'),(a+b)*h/2,[(a+b)*h,a*b*h/2,(a+b)/2],T('S = (a + b) × h : 2','S = (a + b) × h : 2'),x=>nf(x)+' cm²')},
 ()=>{const m=ri(2,9);return mk(T(m+' m³ bằng bao nhiêu lít?','How many litres in '+m+' m³?'),m*1000,[m*100,m*10,m*10000],T('1 m³ = 1000 lít','1 m³ = 1000 L'),x=>x+T(' lít',' L'))}],
THCS:[()=>{const t=pick([[3,4,5],[5,12,13],[6,8,10],[8,15,17],[9,12,15],[7,24,25]]),k=ri(1,2);const [a,b,c]=t.map(x=>x*k);return mk(T('Tam giác vuông có hai cạnh góc vuông '+a+' và '+b+'. Cạnh huyền?','A right triangle has legs '+a+' and '+b+'. Hypotenuse?'),c,[a+b,c+1,Math.round(Math.sqrt(a*b)*10)/10],T('Pytago: c² = '+a+'² + '+b+'² = '+c*c,'Pythagoras: c² = '+c*c))},
 ()=>{const n=pick([5,6,8,9,10,12]);return mk(T('Mỗi góc trong của đa giác đều '+n+' cạnh?','Each interior angle of a regular '+n+'-gon?'),(n-2)*180/n,[360/n,(n-2)*180,180-(n-2)*180/n+10],T('(n − 2)·180°/n','(n − 2)·180°/n'),x=>nf(x)+'°')},
 ()=>{const A=ri(30,80),B=ri(20,90-Math.floor(A/3));return mk(T('Tam giác có hai góc '+A+'° và '+B+'°. Góc còn lại?','Two angles of a triangle are '+A+'° and '+B+'°. The third?'),180-A-B,[180-A,90-A,360-A-B],T('Tổng ba góc = 180°','Angles add to 180°'),x=>x+'°')},
 ()=>{const r=ri(1,6),h=ri(2,9);return mk(T('Hình trụ r = '+r+', h = '+h+'. Thể tích?','Cylinder r = '+r+', h = '+h+'. Volume?'),r*r*h,[2*r*h,r*h,r*r*h*2],T('V = πr²h = '+r*r*h+'π','V = πr²h'),x=>x+'π')},
 ()=>{const r=ri(1,6);return mk(T('Hình cầu bán kính '+r+'. Diện tích mặt cầu?','Sphere radius '+r+'. Surface area?'),4*r*r,[r*r,2*r*r,4*r*r*r/3],T('S = 4πr²','S = 4πr²'),x=>nf(x)+'π')},
 ()=>{const F=ri(2,20)*10,Sa=pick([.5,2,4,5]);return mk(T('Lực '+F+' N ép lên diện tích '+nf(Sa)+' m². Áp suất?','A force of '+F+' N on '+nf(Sa)+' m². Pressure?'),F/Sa,[F*Sa,F+Sa,Sa/F],T('p = F/S','p = F/S'),x=>nf(x)+' Pa')},
 ()=>{const U=pick([6,9,12,24]),R=pick([2,3,4,6]);return mk(T('Hiệu điện thế '+U+' V, điện trở '+R+' Ω. Cường độ dòng điện?','Voltage '+U+' V, resistance '+R+' Ω. Current?'),U/R,[U*R,R/U,U+R],T('I = U/R','I = U/R'),x=>nf(x)+' A')}],
THPT:[()=>{const A=[ri(-3,4),ri(-3,4),ri(-3,4)],d=pick([[1,2,2],[2,3,6],[2,6,9],[0,3,4],[1,4,8]]),B=A.map((x,i)=>x+d[i]);const L=Math.hypot(...d);return mk(T('A('+A.join('; ')+'), B('+B.join('; ')+'). Độ dài AB?','A('+A.join('; ')+'), B('+B.join('; ')+'). Length AB?'),L,[d[0]+d[1]+d[2],L*L,L+1],T('AB = √(Δx² + Δy² + Δz²)','AB = √(Δx² + Δy² + Δz²)'))},
 ()=>{const a=[ri(-3,4),ri(-3,4),ri(-3,4)],b=[ri(-3,4),ri(-3,4),ri(-3,4)];const d=a[0]*b[0]+a[1]*b[1]+a[2]*b[2];return mk(T('u = ('+a.join('; ')+'), v = ('+b.join('; ')+'). Tích vô hướng u·v?','u = ('+a.join('; ')+'), v = ('+b.join('; ')+'). Dot product?'),d,[d+2,-d||1,a[0]*b[0]],T('u·v = x₁x₂ + y₁y₂ + z₁z₂','u·v = x₁x₂ + y₁y₂ + z₁z₂'))},
 ()=>{const a=ri(1,6);return mk(T('Hình lập phương cạnh '+a+'. Độ dài đường chéo?','Cube edge '+a+'. Space diagonal?'),a+'√3',[a+'√2',3*a+'',a+'√6'],T('d = a√3','d = a√3'),x=>x)},
 ()=>{const a=ri(1,4);return mk(T('∫₀^'+a+' x² dx = ?','∫₀^'+a+' x² dx = ?'),a*a*a/3,[a*a*a,a*a/2,2*a],T('x³/3 từ 0 đến '+a,'x³/3 from 0 to '+a),x=>nf(x))},
 ()=>{const L=pick([.25,1,2.25,4]);return mk(T('Con lắc dài '+nf(L)+' m, g = π² m/s². Chu kì dao động nhỏ?','Pendulum '+nf(L)+' m, g = π² m/s². Small-angle period?'),2*Math.sqrt(L),[Math.sqrt(L),2*L,4*Math.sqrt(L)],T('T = 2π√(l/g) = 2√l','T = 2π√(l/g) = 2√l'),x=>nf(x)+' s')},
 ()=>{const v=pick([10,20,30]),g=10;return mk(T('Ném xiên 45° với v₀ = '+v+' m/s, g = 10. Tầm xa?','Launch at 45°, v₀ = '+v+' m/s, g = 10. Range?'),v*v/g,[v*v/(2*g),v*v*2/g,v/g],T('L = v₀²sin2α/g','L = v₀²sin2α/g'),x=>nf(x)+' m')},
 ()=>{const f=pick([10,15,20]),d=f*pick([2,3,4]);return mk(T('Thấu kính hội tụ f = '+f+' cm, vật cách '+d+' cm. Ảnh cách thấu kính?','Converging lens f = '+f+' cm, object at '+d+' cm. Image distance?'),d*f/(d-f),[d-f,d*f/(d+f),f],T("d' = d·f/(d − f)","d' = d·f/(d − f)"),x=>nf(x)+' cm')}],
DH:[()=>{const n=ri(3,7);return mk(T('Siêu lập phương '+n+' chiều có bao nhiêu đỉnh?','How many vertices has the '+n+'-cube?'),Math.pow(2,n),[2*n,n*n,Math.pow(2,n-1)])},
 ()=>{const n=ri(3,6);return mk(T('Siêu lập phương '+n+' chiều có bao nhiêu cạnh?','How many edges has the '+n+'-cube?'),n*Math.pow(2,n-1),[Math.pow(2,n),n*n,2*n*n])},
 ()=>mk(T('Tesseract có bao nhiêu khối lập phương (ô 3 chiều)?','How many cubic cells has the tesseract?'),8,[6,16,24],T('2n = 8 ô','2n = 8 cells')),
 ()=>mk(T('Đơn hình 4 chiều (5-cell) có bao nhiêu đỉnh?','How many vertices has the 4-simplex (5-cell)?'),5,[4,8,10]),
 ()=>{const a=ri(2,4);return mk(T('Siêu thể tích tesseract cạnh '+a+'?','Hypervolume of a tesseract with edge '+a+'?'),Math.pow(a,4),[a*a*a,4*a,8*a*a*a])},
 ()=>{const m=ri(1,5),R=pick([.5,1,2]);return mk(T('Mômen quán tính đĩa đặc m = '+m+' kg, R = '+nf(R)+' m?','Moment of inertia of a disc m = '+m+' kg, R = '+nf(R)+' m?'),m*R*R/2,[m*R*R,m*R/2,2*m*R*R/5],T('I = ½mR²','I = ½mR²'),x=>nf(x)+' kg·m²')},
 ()=>mk(T('Thể tích quả cầu đơn vị 4 chiều?','Volume of the unit 4-ball?'),'π²/2',['4π/3','π²','2π²'],T('V₄ = π²r⁴/2','V₄ = π²r⁴/2'),x=>x)]};
VN.qgen=function(band){const b=G[band]?band:'THCS';return pick(G[b])()};
VN.bandOf=()=>{const a=VN.S.age;return a===1?'TH':a===2?'THCS':'THPT'};
})();
