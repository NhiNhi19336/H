/* Community network adapter.
   online  : inside a claude.ai artifact with the `db` + `user` capabilities. One public doc per player at pub/<id>
             (rules: everyone reads, each writes only their own; the owner can moderate).
   local   : anywhere else (Android app, itch.io, file://). Everything stays on this device.
   A future server only needs to implement the same five calls: start, me, users, save, post. */
(function(){
'use strict';
const S=VN.S,T=VN.T;
const N=VN.NET={mode:'local',ready:false,uid:'me',users:{},mine:null,ro:false,err:'',_db:null,_user:null,_unsub:null,_names:{}};
const MAXM=40;
function blank(){return{xp:S.xp||0,lv:VN.lvOf(S.xp||0),srv:(S.w&&S.w.srv)||'',av:(S.w&&S.w.av)||0,m:[],own:[],join:[],dmg:{},ts:Date.now()}}
function local(){N.mode='local';N.uid='me';try{N.mine=JSON.parse(localStorage.getItem('vn2_pub')||'null')}catch(e){}N.mine=Object.assign(blank(),N.mine||{});N.users={me:N.mine};N.ready=true;VN.emit('net')}
function persistLocal(){try{localStorage.setItem('vn2_pub',JSON.stringify(N.mine))}catch(e){}}
N.start=async function(){if(N._started)return;N._started=true;
 const has=window.claude&&typeof window.claude.use==='function';if(!has){local();return}
 let db=null,user=null;try{[db,user]=await Promise.all([claude.use('db'),claude.use('user')])}catch(e){}
 if(!db){local();return}
 N._db=db;N._user=user;let id=null;try{id=user?await user.id():null}catch(e){}
 if(!id){/* signed out: read-only view of the community */N.ro=true;N.uid='guest'}else N.uid=id;
 N.mode='online';
 try{if(user&&user.can){const c=await user.can('data.write');if(c===false)N.ro=true}}catch(e){}
 /* my doc */
 if(!N.ro){try{const d=await db.doc('pub/'+N.uid).get();N.mine=Object.assign(blank(),d.exists?d.data():{})}catch(e){N.mine=blank()}}else N.mine=blank();
 /* everyone, live */
 let timer=setTimeout(()=>{N.err=T('Chưa kết nối được máy chủ cộng đồng, thử lại sau.','Cannot reach the community store yet.');VN.emit('net')},10000);
 N._unsub=db.collection('pub').orderBy('ts','desc').limit(300).onSnapshot(snap=>{if(!snap.metadata.fromCache){clearTimeout(timer);N.err=''}const u={};snap.docs.forEach(d=>{u[d.id]=d.data()});if(N.mine&&!N.ro)u[N.uid]=N.mine;N.users=u;N.ready=true;VN.emit('net')},e=>{clearTimeout(timer);N.err=T('Mất kết nối máy chủ cộng đồng','Lost the community connection')+' ('+e.code+')';VN.emit('net')});
 N.ready=true;VN.emit('net')};
/* one write at a time, coalesced */
let busy=false,again=false;
N.save=async function(patch){if(patch)Object.assign(N.mine,patch);N.mine.ts=Date.now();N.mine.xp=S.xp||0;N.mine.lv=VN.lvOf(S.xp||0);
 if(N.mode==='local'){persistLocal();VN.emit('net');return true}
 if(N.ro)return false;if(busy){again=true;return true}busy=true;
 try{await N._db.doc('pub/'+N.uid).set(JSON.parse(JSON.stringify(N.mine)))}catch(e){if(e&&e.code==='invalid_argument'){N.ro=true;VN.toast(T('Bạn chỉ có quyền xem cộng đồng này.','You can only view this community.'))}else if(e&&e.code==='quota_exceeded')VN.toast(T('Máy chủ cộng đồng đã đầy.','The community store is full.'))}
 busy=false;if(again){again=false;return N.save()}VN.emit('net');return true};
let lastPost=0;
N.post=async function(c,t,sys){t=String(t||'').replace(/\s+/g,' ').trim().slice(0,500);if(!t)return false;const now=Date.now();if(!sys&&now-lastPost<1500){VN.toast(T('Từ từ thôi, chờ 2 giây nhé.','Slow down a little.'));return false}lastPost=now;
 const m={id:now.toString(36)+Math.random().toString(36).slice(2,5),c,t,ts:now};N.mine.m=(N.mine.m||[]).concat([m]).slice(-MAXM);return N.save()};
N.unpost=function(id){N.mine.m=(N.mine.m||[]).filter(x=>x.id!==id);return N.save()};
/* all messages in a channel, merged from every player's doc */
N.msgs=function(c){const out=[];Object.entries(N.users).forEach(([uid,d])=>{(d.m||[]).forEach(m=>{if(m.c===c)out.push(Object.assign({uid},m))})});const hid=(S.w&&S.w.hide)||[];return out.filter(m=>!hid.includes(m.id)).sort((a,b)=>a.ts-b.ts).slice(-150)};
N.groups=function(){const g=[];Object.entries(N.users).forEach(([uid,d])=>(d.own||[]).forEach(x=>g.push(Object.assign({owner:uid},x))));return g};
N.members=function(gid){return Object.entries(N.users).filter(([uid,d])=>(d.join||[]).includes(gid)||(d.own||[]).some(x=>x.id===gid)).map(([uid])=>uid)};
N.online=function(uid){const d=N.users[uid];return d&&Date.now()-(d.ts||0)<6*60000};
/* display names: resolved per render, never stored */
N.names=async function(ids){if(N.mode==='local'||!N._user||!N._user.profiles){const o={};ids.forEach(i=>o[i]=i==='me'?T('Bạn','You'):i);return o}
 try{const ps=await N._user.profiles(ids);const o={};ids.forEach(i=>{const p=ps[i];o[i]=(p&&p.name)||T('Nhà thám hiểm ','Explorer ')+i.slice(-4).toUpperCase();if(p&&p.isMe)o[i]+=T(' (bạn)',' (you)')});return o}catch(e){const o={};ids.forEach(i=>o[i]=i.slice(-4));return o}};
N.label=()=>N.mode==='online'?(N.ro?T('Cộng đồng · chỉ xem','Community · read-only'):T('Cộng đồng trực tuyến','Online community')):T('Ngoài mạng · lưu trên máy','Offline · saved on this device');
})();
