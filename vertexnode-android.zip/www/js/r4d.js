/* r4d.js — thin-line n-D wireframe renderer + exact figure generators (0D…4D). Original code; style: depth-cued orange→yellow→green. */
(function(){
'use strict';
const TAU=Math.PI*2,PHI=(1+Math.sqrt(5))/2;
const R4=VN.R4={};
const V4=(x,y,z,w)=>[x||0,y||0,z||0,w||0];
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2],a[3]-b[3]);

/* ---------- colour ramp (t:0 near → 1 far) ---------- */
const hex=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
const RAMP={dark:[hex('#ff8a2b'),hex('#ffd23f'),hex('#3ddc84')],light:[hex('#e2580c'),hex('#d99a00'),hex('#139a54')]};
R4.neon=(t,dark,a)=>{t=Math.max(0,Math.min(1,t));const r=RAMP[dark?'dark':'light'],i=t<.5?0:1,u=t<.5?t*2:(t-.5)*2,A=r[i],B=r[i+1];
 return 'rgba('+Math.round(A[0]+(B[0]-A[0])*u)+','+Math.round(A[1]+(B[1]-A[1])*u)+','+Math.round(A[2]+(B[2]-A[2])*u)+','+(a==null?1:a)+')'};
R4.classic=()=>!(window.VN&&VN.S&&VN.S.vstyle==='neon');
R4.ramp=(t,dark,a)=>{if(!R4.classic())return R4.neon(t,dark,a);t=Math.max(0,Math.min(1,t));a=a==null?1:a;const A=dark?[246,246,250]:[22,23,28],B=dark?[132,136,150]:[128,133,146];return'rgba('+A.map((v,k)=>Math.round(v+(B[k]-v)*t)).join(',')+','+a+')'};

/* ---------- generic helpers ---------- */
function edgesByMin(V,tol){let m=1e9;for(let i=0;i<V.length;i++)for(let j=i+1;j<V.length;j++)m=Math.min(m,dist(V[i],V[j]));
 const E=[];for(let i=0;i<V.length;i++)for(let j=i+1;j<V.length;j++)if(Math.abs(dist(V[i],V[j])-m)<(tol||1e-6)*Math.max(1,m))E.push([i,j]);return{E,len:m}}
function norm(V){let r=0;V.forEach(p=>{r=Math.max(r,Math.hypot(p[0],p[1],p[2],p[3]))});return r}
const sub3=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],cross=(u,v)=>[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],dot=(u,v)=>u[0]*v[0]+u[1]*v[1]+u[2]*v[2];
/* faces of a convex polyhedron from its vertices (coplanar grouping), each ordered around its centroid */
R4.hullFaces=function(V){const n=V.length,seen={},F=[];
 for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)for(let k=j+1;k<n;k++){const u=sub3(V[j],V[i]),v=sub3(V[k],V[i]),N=cross(u,v),l=Math.hypot(...N);if(l<1e-9)continue;
  let ps=0,ng=0;const on=[];for(let m=0;m<n;m++){const d=dot(sub3(V[m],V[i]),N)/l;if(Math.abs(d)<1e-7)on.push(m);else d>0?ps++:ng++}
  if(ps&&ng)continue;const key=on.join(',');if(seen[key])continue;seen[key]=1;
  const c=[0,1,2].map(t=>on.reduce((s,m)=>s+V[m][t],0)/on.length),e1=(()=>{const a=sub3(V[on[0]],c),L=Math.hypot(...a);return a.map(x=>x/L)})(),e2=cross(N.map(x=>x/l),e1);
  on.sort((a,b)=>{const pa=sub3(V[a],c),pb=sub3(V[b],c);return Math.atan2(dot(pa,e2),dot(pa,e1))-Math.atan2(dot(pb,e2),dot(pb,e1))});F.push(on)}
 return F};
/* exact volume / area of a convex polyhedron from vertices (used in tests and in the atlas self-check) */
R4.polyMeasure=function(V){const F=R4.hullFaces(V),c=[0,1,2].map(t=>V.reduce((s,p)=>s+p[t],0)/V.length);let vol=0,area=0;
 F.forEach(f=>{for(let i=1;i<f.length-1;i++){const a=V[f[0]],b=V[f[i]],d=V[f[i+1]],N=cross(sub3(b,a),sub3(d,a));area+=Math.hypot(...N)/2;vol+=Math.abs(dot(sub3(a,c),N))/6}});return{vol,area,faces:F.length}};
function circle(r,z,n,cx,cy,plane){n=n||96;const a=[];for(let i=0;i<n;i++){const t=TAU*i/n,u=r*Math.cos(t),v=r*Math.sin(t);a.push(plane==='xz'?V4(cx+u,z,cy+v):plane==='yz'?V4(z,cx+u,cy+v):V4(cx+u,cy+v,z))}return{p:a,closed:1}}
function arrow(M,from,to,s){/* adds an arrow head at `to` */const d=[to[0]-from[0],to[1]-from[1],to[2]-from[2]],l=Math.hypot(...d)||1,u=d.map(x=>x/l);
 let n=Math.abs(u[2])<.9?[0,0,1]:[1,0,0];const a=cross(u,n),al=Math.hypot(...a);const b=a.map(x=>x/al*s*.45),h=to.map((x,i)=>x-u[i]*s);
 const i0=M.V.length;M.V.push(V4(to[0],to[1],to[2]),V4(h[0]+b[0],h[1]+b[1],h[2]+b[2]),V4(h[0]-b[0],h[1]-b[1],h[2]-b[2]));M.E.push([i0,i0+1],[i0,i0+2]);M.hid=(M.hid||[]).concat([i0+1,i0+2]);return i0}
const mk=(dim,V,E,o)=>Object.assign({dim,V:V.map(p=>V4(p[0],p[1],p[2],p[3])),E:E||[],C:[],L:[]},o||{});

/* ---------- generators ---------- */
const G=R4.gen={};
G.point=()=>{const M=mk(0,[[0,0,0]],[]);M.L=[{i:0,t:'A'}];M.big=1;return M};
G.segment=()=>{const M=mk(1,[[-1.2,-.3,0],[1.2,.3,0]],[[0,1]]);M.L=[{i:0,t:'A'},{i:1,t:'B'}];return M};
G.ray=()=>{const M=mk(1,[[-1.3,-.2,0],[1.5,.25,0]],[[0,1]]);M.L=[{i:0,t:'A'}];arrow(M,M.V[0],M.V[1],.22);return M};
G.line=()=>{const M=mk(1,[[-1.6,-.4,0],[1.6,.4,0],[.2,.05,0]],[[0,1]]);M.L=[{i:2,t:'M'}];arrow(M,M.V[0],M.V[1],.22);arrow(M,M.V[1],M.V[0],.22);return M};
G.vector=()=>{const M=mk(1,[[0,0,0],[1.5,.9,0]],[[0,1]]);M.L=[{i:0,t:'O'}];arrow(M,M.V[0],M.V[1],.22);return M};
G.plane=()=>{const V=[],E=[],n=5;for(let i=0;i<=n;i++)for(let j=0;j<=n;j++)V.push(V4(-1.3+2.6*i/n,-1.3+2.6*j/n,0));
 for(let i=0;i<=n;i++)for(let j=0;j<=n;j++){const k=i*(n+1)+j;if(j<n)E.push([k,k+1]);if(i<n)E.push([k,k+n+1])}
 const M=mk(2,V.map(p=>p),E);const o=M.V.length;M.V.push(V4(0,0,0),V4(0,0,1.3));M.E.push([o,o+1]);arrow(M,M.V[o],M.V[o+1],.2);M.L=[{i:o,t:'M'},{i:o+1,t:'n'}];M.hid=(M.hid||[]);M.fillPoly=[[0,n,(n+1)*(n+1)-1,n*(n+1)]];return M};
G.angle=(p)=>{const th=(p&&p.deg!=null?p.deg:60)*Math.PI/180,M=mk(2,[[0,0,0],[1.5,0,0],[1.5*Math.cos(th),1.5*Math.sin(th),0]],[[0,1],[0,2]]);M.L=[{i:0,t:'O'},{i:1,t:'A'},{i:2,t:'B'}];
 const a=[];for(let i=0;i<=40;i++){const t=th*i/40;a.push(V4(.55*Math.cos(t),.55*Math.sin(t),0))}M.C.push({p:a,closed:0});return M};
function poly(n,ratio,labels){const V=[];if(n===4&&ratio){V.push([-1.1*ratio,-1.1,0],[1.1*ratio,-1.1,0],[1.1*ratio,1.1,0],[-1.1*ratio,1.1,0])}else for(let i=0;i<n;i++){const t=-Math.PI/2+TAU*i/n;V.push([1.35*Math.cos(t),1.35*Math.sin(t),0])}
 const E=V.map((_,i)=>[i,(i+1)%V.length]);const M=mk(2,V,E);M.L=V.map((_,i)=>({i,t:'ABCDEFGH'[i]}));M.fillPoly=[V.map((_,i)=>i)];return M}
G.triangle=(p)=>{const M=poly(3);if(p&&p.a){/* triangle from sides a,b,c */const a=p.a,b=p.b,c=p.c;if(a+b>c&&a+c>b&&b+c>a){const x=(b*b+c*c-a*a)/(2*c),y=Math.sqrt(Math.max(0,b*b-x*x)),s=2.4/Math.max(a,b,c);M.V[0]=V4(-c*s/2,-y*s/2);M.V[1]=V4(c*s/2,-y*s/2);M.V[2]=V4((x-c/2)*s,y*s/2)}}return M};
G.square=()=>poly(4,1);G.rectangle=(p)=>poly(4,Math.max(.4,Math.min(2.2,p&&p.r||1.6)));
G.pentagon=()=>poly(5);G.hexagon=()=>poly(6);G.polygon=(p)=>poly(Math.max(3,Math.min(24,Math.round(p&&p.n||7))));
G.circle=()=>{const M=mk(2,[[0,0,0],[1.4,0,0]],[[0,1]]);M.C.push(circle(1.4,0,120));M.L=[{i:0,t:'O'}];M.fillCirc=1.4;return M};
G.ellipse=(p)=>{const a=1.6,b=Math.max(.3,Math.min(1.6,a*(p&&p.k||.6))),pts=[];for(let i=0;i<120;i++){const t=TAU*i/120;pts.push(V4(a*Math.cos(t),b*Math.sin(t),0))}
 const c=Math.sqrt(Math.max(0,a*a-b*b)),M=mk(2,[[-c,0,0],[c,0,0],[0,0,0]],[]);M.C.push({p:pts,closed:1});M.L=[{i:0,t:'F₁'},{i:1,t:'F₂'}];return M};
/* convex solids */
function solid(V,name,dim){const m=norm(V.map(p=>V4(p[0],p[1],p[2])));const W=V.map(p=>V4(p[0]/m*1.35,p[1]/m*1.35,p[2]/m*1.35)),{E,len}=edgesByMin(W);const M=mk(3,W,E);M.F=R4.hullFaces(W);M.edge=len;return M}
G.tetra=()=>solid([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]]);
G.cube=()=>solid([[1,1,1],[1,1,-1],[1,-1,1],[1,-1,-1],[-1,1,1],[-1,1,-1],[-1,-1,1],[-1,-1,-1]]);
G.octa=()=>solid([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]);
G.icosa=()=>{const V=[];[1,-1].forEach(a=>[1,-1].forEach(b=>{V.push([0,a,b*PHI],[a,b*PHI,0],[b*PHI,0,a])}));return solid(V)};
G.dodeca=()=>{const V=[];[1,-1].forEach(a=>[1,-1].forEach(b=>{[1,-1].forEach(c=>V.push([a,b,c]));V.push([0,a/PHI,b*PHI],[a/PHI,b*PHI,0],[b*PHI,0,a/PHI])}));return solid(V)};
G.cuboid=(p)=>{const a=(p&&p.a)||3,b=(p&&p.b)||2,c=(p&&p.c)||1.5,s=2.2/Math.max(a,b,c),V=[];[1,-1].forEach(x=>[1,-1].forEach(y=>[1,-1].forEach(z=>V.push([x*a*s/2,y*c*s/2,z*b*s/2]))));
 const W=V.map(q=>V4(q[0],q[1],q[2])),E=[];for(let i=0;i<8;i++)for(let j=i+1;j<8;j++){let d=0;for(let k=0;k<3;k++)if(Math.abs(W[i][k]-W[j][k])>1e-9)d++;if(d===1)E.push([i,j])}const M=mk(3,W,E);M.F=R4.hullFaces(W);return M};
G.prism=()=>{const n=6,V=[];for(let i=0;i<n;i++){const t=TAU*i/n;V.push([Math.cos(t),-.9,Math.sin(t)])}for(let i=0;i<n;i++){const t=TAU*i/n;V.push([Math.cos(t),.9,Math.sin(t)])}
 const E=[];for(let i=0;i<n;i++)E.push([i,(i+1)%n],[n+i,n+(i+1)%n],[i,n+i]);const M=mk(3,V.map(q=>V4(q[0]*1.3,q[1]*1.3,q[2]*1.3)),E);M.F=R4.hullFaces(M.V);return M};
G.pyramid=()=>{const V=[[-1,-.9,-1],[1,-.9,-1],[1,-.9,1],[-1,-.9,1],[0,1.1,0]].map(q=>V4(q[0]*1.25,q[1]*1.25,q[2]*1.25)),E=[[0,1],[1,2],[2,3],[3,0],[0,4],[1,4],[2,4],[3,4]];const M=mk(3,V,E);M.F=R4.hullFaces(V);return M};
G.cylinder=(p)=>{const r=1,h=Math.max(.5,Math.min(3,(p&&p.k)||1.8)),M=mk(3,[[0,-h/2,0],[0,h/2,0]],[[0,1]]);M.C.push(circle(r,-h/2,72,0,0,'xz'),circle(r,h/2,72,0,0,'xz'));for(let i=0;i<10;i++){const t=TAU*i/10;M.C.push({p:[V4(Math.cos(t),-h/2,Math.sin(t)),V4(Math.cos(t),h/2,Math.sin(t))],closed:0,dim:1})}return M};
G.cone=(p)=>{const r=1,h=Math.max(.5,Math.min(3,(p&&p.k)||1.9)),M=mk(3,[[0,-h/2,0],[0,h/2,0]],[[0,1]]);M.C.push(circle(r,-h/2,72,0,0,'xz'));for(let i=0;i<10;i++){const t=TAU*i/10;M.C.push({p:[V4(Math.cos(t),-h/2,Math.sin(t)),V4(0,h/2,0)],closed:0,dim:1})}return M};
G.sphere=()=>{const M=mk(3,[[0,0,0]],[]);const r=1.35;[-60,-30,0,30,60].forEach(la=>{const a=la*Math.PI/180;M.C.push(circle(r*Math.cos(a),r*Math.sin(a),72,0,0,'xz'))});
 for(let i=0;i<8;i++){const t=Math.PI*i/8,pts=[];for(let k=0;k<72;k++){const u=TAU*k/72;pts.push(V4(r*Math.cos(u)*Math.cos(t),r*Math.sin(u),r*Math.cos(u)*Math.sin(t)))}M.C.push({p:pts,closed:1})}return M};
G.torus=(p)=>{const R=1,r=Math.max(.2,Math.min(.8,(p&&p.k)||.42)),M=mk(3,[[0,0,0]],[]);
 for(let i=0;i<16;i++){const u=TAU*i/16,pts=[];for(let k=0;k<40;k++){const v=TAU*k/40;pts.push(V4((R+r*Math.cos(v))*Math.cos(u)*1.15,r*Math.sin(v)*1.15,(R+r*Math.cos(v))*Math.sin(u)*1.15))}M.C.push({p:pts,closed:1})}
 for(let k=0;k<10;k++){const v=TAU*k/10,pts=[];for(let i=0;i<72;i++){const u=TAU*i/72;pts.push(V4((R+r*Math.cos(v))*Math.cos(u)*1.15,r*Math.sin(v)*1.15,(R+r*Math.cos(v))*Math.sin(u)*1.15))}M.C.push({p:pts,closed:1})}return M};
/* 4D polytopes (vertex coordinates exact; edges = all pairs at the minimum distance) */
function poly4(V,sc){const m=norm(V),W=V.map(p=>V4(p[0]/m*(sc||1.25),p[1]/m*(sc||1.25),p[2]/m*(sc||1.25),p[3]/m*(sc||1.25))),{E,len}=edgesByMin(W);const M=mk(4,W,E);M.edge=len;return M}
const s5=Math.sqrt(5);
G.cell5=()=>poly4([[1,1,1,-1/s5],[1,-1,-1,-1/s5],[-1,1,-1,-1/s5],[-1,-1,1,-1/s5],[0,0,0,4/s5]]);
G.tesseract=(p)=>{const V=[];for(let i=0;i<16;i++)V.push([i&1?1:-1,i&2?1:-1,i&4?1:-1,i&8?1:-1]);const M=poly4(V,1.15);if(p&&p.t!=null){/* sweep animation: squash w */M.V.forEach(q=>{q[3]*=p.t})}return M};
G.cell16=()=>{const V=[];for(let i=0;i<4;i++){const a=[0,0,0,0],b=[0,0,0,0];a[i]=1;b[i]=-1;V.push(a,b)}return poly4(V,1.3)};
G.cell24=()=>{const V=[];for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)[1,-1].forEach(a=>[1,-1].forEach(b=>{const q=[0,0,0,0];q[i]=a;q[j]=b;V.push(q)}));return poly4(V,1.25)};
G.cliff=()=>{const M=mk(4,[[0,0,0,0]],[]);const n=18,m=40,k=1.25/Math.SQRT1_2*Math.SQRT1_2*1.0;
 for(let i=0;i<n;i++){const u=TAU*i/n,pts=[];for(let j=0;j<m;j++){const v=TAU*j/m;pts.push(V4(Math.cos(u)*k*.9,Math.sin(u)*k*.9,Math.cos(v)*k*.9,Math.sin(v)*k*.9))}M.C.push({p:pts,closed:1})}
 for(let j=0;j<12;j++){const v=TAU*j/12,pts=[];for(let i=0;i<m*2;i++){const u=TAU*i/(m*2);pts.push(V4(Math.cos(u)*k*.9,Math.sin(u)*k*.9,Math.cos(v)*k*.9,Math.sin(v)*k*.9))}M.C.push({p:pts,closed:1})}return M};
/* k-cube with last axis scaled by t (dimension-jump animation): point, segment, square, cube, tesseract */
R4.hyper=function(k,t){const n=1<<k,V=[];for(let i=0;i<n;i++){const q=[0,0,0,0];for(let a=0;a<k;a++)q[a]=(i>>a&1)?1:-1;if(k>0)q[k-1]*=t;V.push(q)}
 const E=[];for(let i=0;i<n;i++)for(let a=0;a<k;a++)if(!(i>>a&1))E.push([i,i|1<<a]);
 const sc=k<=1?1.2:k===2?1.1:k===3?1.0:.95;const M=mk(Math.min(4,k),V.map(q=>q.map(x=>x*sc)),E);if(k===0){M.V[0]=V4(0,0,0)}if(k===2||k===3){M.V.forEach(q=>{q[2]=k===2?q[2]:q[2]})}
 /* put 1-D segment on x, 2-D on x,y, 3-D on x,y,z (rotated a bit by the view); vertices already follow that */
 M.big=k===0;return M};
R4.fvec=k=>{const C=(n,r)=>{let x=1;for(let i=0;i<r;i++)x=x*(n-i)/(i+1);return Math.round(x)};const f=[];for(let j=0;j<=k;j++)f.push(C(k,j)*Math.pow(2,k-j));return f};

/* ---------- rotation ---------- */
const I4=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
function rotP(i,j,t){const m=I4(),c=Math.cos(t),s=Math.sin(t);m[i*4+i]=c;m[i*4+j]=-s;m[j*4+i]=s;m[j*4+j]=c;return m}
function mm(A,B){const R=new Array(16).fill(0);for(let i=0;i<4;i++)for(let j=0;j<4;j++){let s=0;for(let k=0;k<4;k++)s+=A[i*4+k]*B[k*4+j];R[i*4+j]=s}return R}
R4.rot=(a)=>mm(mm(mm(rotP(0,3,a.xw||0),rotP(1,3,a.yw||0)),mm(rotP(2,3,a.zw||0),rotP(1,2,a.yz||0))),mm(rotP(0,2,a.xz||0),rotP(0,1,a.xy||0)));
const ap4=(M,p)=>[M[0]*p[0]+M[1]*p[1]+M[2]*p[2]+M[3]*p[3],M[4]*p[0]+M[5]*p[1]+M[6]*p[2]+M[7]*p[3],M[8]*p[0]+M[9]*p[1]+M[10]*p[2]+M[11]*p[3],M[12]*p[0]+M[13]*p[1]+M[14]*p[2]+M[15]*p[3]];

/* ---------- View ---------- */
/* Classic "shape lab" look: white (dark) / ink (light) thin lines, hidden edges dashed by face visibility, turntable rings */
function classicDraw(V,m,P,c,dark,prj,R,zmin,zmax,cx,cy,sc,is4,o){const ink=dark?'rgba(244,244,248,':'rgba(20,21,26,',lw=(o.lw||1.6)*(V.W>600?1.15:1);
 if(V.ring!==false&&!m.flat&&m.dim>=3){const by=cy+V.rad*sc*1.02,rx=V.rad*sc*1.25,ry=rx*.2;c.save();c.lineWidth=1;c.strokeStyle=ink+(dark?.16:.18)+')';[1,.72,.44].forEach(k=>{c.beginPath();c.ellipse(cx,by,rx*k,ry*k,0,0,TAU);c.stroke()});for(let i=0;i<12;i++){const a=i/12*TAU;c.beginPath();c.moveTo(cx+Math.cos(a)*rx*.44,by+Math.sin(a)*ry*.44);c.lineTo(cx+Math.cos(a)*rx,by+Math.sin(a)*ry);c.stroke()}c.fillStyle=ink+(dark?.07:.08)+')';c.beginPath();c.ellipse(cx,by,rx*.4,ry*.4,0,0,TAU);c.fill();c.restore()}
 /* rotated 3D coords for visibility */
 const Q=m.V.map(p=>ap4(R,p)),cen=[0,1,2].map(k=>Q.reduce((s,q)=>s+q[k],0)/Q.length);const cam=[0,0,4.4];
 const fvis=[];const F=(!is4&&m.F)?m.F:[];F.forEach((f,fi)=>{const a=Q[f[0]],b=Q[f[1]],d=Q[f[2]];let n=[(b[1]-a[1])*(d[2]-a[2])-(b[2]-a[2])*(d[1]-a[1]),(b[2]-a[2])*(d[0]-a[0])-(b[0]-a[0])*(d[2]-a[2]),(b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0])];const fc=[0,1,2].map(k=>f.reduce((s,i)=>s+Q[i][k],0)/f.length);if(n[0]*(fc[0]-cen[0])+n[1]*(fc[1]-cen[1])+n[2]*(fc[2]-cen[2])<0)n=n.map(x=>-x);fvis[fi]=n[0]*(cam[0]-fc[0])+n[1]*(cam[1]-fc[1])+n[2]*(cam[2]-fc[2])>0});
 const adj={};F.forEach((f,fi)=>f.forEach((a,k)=>{const b=f[(k+1)%f.length],key=a<b?a+'|'+b:b+'|'+a;(adj[key]=adj[key]||[]).push(fi)}));
 /* faces: soft fill on visible faces */
 if(V.faces&&F.length){F.forEach((f,fi)=>{if(!fvis[fi])return;c.beginPath();f.forEach((i,k)=>k?c.lineTo(P[i][0],P[i][1]):c.moveTo(P[i][0],P[i][1]));c.closePath();c.fillStyle=dark?'rgba(255,255,255,.045)':'rgba(70,80,229,.07)';c.fill()})}
 else if(V.faces&&m.fillPoly){m.fillPoly.forEach(f=>{c.beginPath();f.forEach((i,k)=>k?c.lineTo(P[i][0],P[i][1]):c.moveTo(P[i][0],P[i][1]));c.closePath();c.fillStyle=dark?'rgba(255,255,255,.05)':'rgba(70,80,229,.08)';c.fill()})}
 const front=[],back=[];const mid=(zmin+zmax)/2;
 (m.E||[]).forEach(e=>{const a=P[e[0]],b=P[e[1]];let hidden;if(F.length){const fs=adj[e[0]<e[1]?e[0]+'|'+e[1]:e[1]+'|'+e[0]];hidden=fs?fs.every(fi=>!fvis[fi]):false}else hidden=is4?false:((a[2]+b[2])/2<mid-(zmax-zmin)*.15);(hidden?back:front).push([a,b])});
 (m.C||[]).forEach(cv=>{const Qc=cv.p.map(prj),n=Qc.length;for(let i=0;i<(cv.closed?n:n-1);i++)front.push([Qc[i],Qc[(i+1)%n]])});
 c.lineCap='round';c.lineJoin='round';
 c.setLineDash([5,5]);c.lineWidth=lw*.8;c.strokeStyle=ink+(dark?.42:.4)+')';c.beginPath();back.forEach(s=>{c.moveTo(s[0][0],s[0][1]);c.lineTo(s[1][0],s[1][1])});c.stroke();c.setLineDash([]);
 if(is4){const tz=p=>1-(p[2]-zmin)/Math.max(1e-6,zmax-zmin);front.forEach(s=>{const t=(tz(s[0])+tz(s[1]))/2;c.lineWidth=lw*(.7+.6*t);c.strokeStyle=ink+(.35+.6*t)+')';c.beginPath();c.moveTo(s[0][0],s[0][1]);c.lineTo(s[1][0],s[1][1]);c.stroke()})}
 else{c.lineWidth=lw;c.strokeStyle=ink+'.95)';c.beginPath();front.forEach(s=>{c.moveTo(s[0][0],s[0][1]);c.lineTo(s[1][0],s[1][1])});c.stroke()}
 const hid=new Set(m.hid||[]);P.forEach((p,i)=>{if(hid.has(i)||(m.C&&m.C.length&&!m.E.length&&!m.big&&!(m.L&&m.L.length)))return;c.beginPath();c.arc(p[0],p[1],m.big?4.5:2.4,0,TAU);c.fillStyle=ink+(m.big?1:.9)+')';c.fill()});
 if(V.labels&&m.L){c.font='700 13px "Be Vietnam Pro",system-ui';c.textAlign='center';c.textBaseline='middle';m.L.forEach(l=>{const p=P[l.i];if(!p)return;const dx=p[0]-cx,dy=p[1]-cy,L=Math.hypot(dx,dy)||1;c.fillStyle=dark?'#f4f4f8':'#14151a';c.fillText(l.t,p[0]+dx/L*15,p[1]+dy/L*15)})}}
R4.View=function(canvas,o){
 o=o||{};const V={cv:canvas,ctx:canvas.getContext('2d'),model:null,ang:{xy:0,xz:.6,yz:-.35,xw:0,yw:0,zw:0},auto:o.auto!==false,spin4:false,zoom:1,H:o.h||300,axes:false,faces:true,labels:true,on:false,vx:0,vy:0,drag:null,touches:new Map()};
 canvas.style.height=V.H+'px';
 V.set=function(m){V.model=m;let r=0;m.V.forEach(p=>{r=Math.max(r,Math.hypot(p[0],p[1],p[2],p[3]))});(m.C||[]).forEach(c=>c.p.forEach(p=>{r=Math.max(r,Math.hypot(p[0],p[1],p[2],p[3]))}));V.rad=r||1;V.draw()};
 V.size=function(){const d=Math.min(3,window.devicePixelRatio||1),w=canvas.clientWidth||300,h=V.H;if(canvas.width!==Math.round(w*d)||canvas.height!==Math.round(h*d)){canvas.width=Math.round(w*d);canvas.height=Math.round(h*d)}V.dpr=d;V.W=w};
 V.draw=function(){const m=V.model;if(!m)return;V.size();const c=V.ctx,d=V.dpr,W=V.W,H=V.H,dark=VN.dark();c.setTransform(d,0,0,d,0,0);c.clearRect(0,0,W,H);
  const R=R4.rot(V.ang),is4=m.dim===4,sc=Math.min(W,H)*.40/V.rad*V.zoom,cx=W/2,cy=H/2,d4=3.2,d3=4.4;
  const prj=p=>{let q=ap4(R,p);let w=q[3],k4=is4?d4/(d4-w):1;const x=q[0]*k4,y=q[1]*k4,z=q[2]*k4,k3=d3/(d3-z);return[cx+x*k3*sc,cy-y*k3*sc,z,w,k3]};
  const P=m.V.map(prj);let zmin=1e9,zmax=-1e9,wmin=1e9,wmax=-1e9;P.forEach(p=>{zmin=Math.min(zmin,p[2]);zmax=Math.max(zmax,p[2]);wmin=Math.min(wmin,p[3]);wmax=Math.max(wmax,p[3])});
  const tz=p=>(zmax-zmin<1e-6?.5:1-(p[2]-zmin)/(zmax-zmin)),tw=p=>(wmax-wmin<1e-6?.5:(p[3]-wmin)/(wmax-wmin));
  const tt=p=>is4?(.55*(1-tz(p))+.45*tw(p)):1-tz(p);                 /* 0 = near (orange) … 1 = far (green) */
  const lw=(o.lw||1.7)*(V.W>600?1.2:1);
  /* axes */
  if(V.axes){c.lineWidth=1;[[1,0,0,'x'],[0,1,0,'y'],[0,0,1,'z']].forEach(a=>{const e=prj(V4(a[0]*V.rad*1.25,a[1]*V.rad*1.25,a[2]*V.rad*1.25)),z0=prj(V4(0,0,0));c.strokeStyle=dark?'rgba(255,255,255,.28)':'rgba(0,0,0,.28)';c.setLineDash([4,4]);c.beginPath();c.moveTo(z0[0],z0[1]);c.lineTo(e[0],e[1]);c.stroke();c.setLineDash([]);c.fillStyle=dark?'rgba(255,255,255,.6)':'rgba(0,0,0,.55)';c.font='600 11px system-ui';c.fillText(a[3],e[0]+3,e[1]-3)})}
  /* translucent faces / polygons */
  if(V.faces){const polys=[];(m.F||[]).forEach(f=>polys.push(f));(m.fillPoly||[]).forEach(f=>polys.push(f));
   const fl=polys.map(f=>({f,z:f.reduce((s,i)=>s+P[i][2],0)/f.length})).sort((a,b)=>a.z-b.z);
   fl.forEach(o2=>{const f=o2.f;c.beginPath();f.forEach((i,k)=>k?c.lineTo(P[i][0],P[i][1]):c.moveTo(P[i][0],P[i][1]));c.closePath();const t=1-(o2.z-zmin)/Math.max(1e-6,zmax-zmin);c.fillStyle=R4.ramp(.15+.7*(1-t),dark,dark?.09:.11);c.fill()});
   if(m.fillCirc){const o0=prj(V4(0,0,0));c.beginPath();m.C[0].p.forEach((q,k)=>{const r=prj(q);k?c.lineTo(r[0],r[1]):c.moveTo(r[0],r[1])});c.closePath();c.fillStyle=R4.ramp(.4,dark,dark?.07:.1);c.fill()}}
  if(R4.classic()){classicDraw(V,m,P,c,dark,prj,R,zmin,zmax,cx,cy,sc,is4,o);return}
  /* edges + curves, glow pass then crisp pass */
  const segs=[];(m.E||[]).forEach(e=>segs.push([P[e[0]],P[e[1]],e]));
  (m.C||[]).forEach(cv=>{const Q=cv.p.map(prj),n=Q.length;for(let i=0;i<(cv.closed?n:n-1);i++)segs.push([Q[i],Q[(i+1)%n],null])});
  segs.sort((a,b)=>(b[0][2]+b[1][2])-(a[0][2]+a[1][2]));
  const draw=(glow)=>{segs.forEach(s=>{const a=s[0],b=s[1],ta=tt(a),tb=tt(b),mid=(ta+tb)/2,al=.72+.28*(1-mid),wk=.75+.5*(1-mid);
    c.lineWidth=glow?lw*wk*4.2:lw*wk;c.lineCap='round';
    if(glow){c.strokeStyle=R4.ramp(mid,dark,dark?.16:.07)}else{const g=c.createLinearGradient(a[0],a[1],b[0],b[1]);g.addColorStop(0,R4.ramp(ta,dark,al));g.addColorStop(1,R4.ramp(tb,dark,al));c.strokeStyle=g}
    c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(b[0],b[1]);c.stroke()})};
  if(segs.length<700){if(dark)c.globalCompositeOperation='lighter';draw(true);c.globalCompositeOperation='source-over';draw(false)}else{draw(false)}
  /* vertices */
  const hid=new Set(m.hid||[]);P.forEach((p,i)=>{if(hid.has(i)||(m.C&&m.C.length&&!m.E.length&&!m.big&&!m.L.length))return;const t=tt(p),r=(m.big?5:(m.dim>=3?2.8:3.4))*(.8+.4*(1-t));if(dark){c.beginPath();c.arc(p[0],p[1],r*2.6,0,TAU);c.fillStyle=R4.ramp(t,dark,.14);c.fill()}c.beginPath();c.arc(p[0],p[1],r,0,TAU);c.fillStyle=R4.ramp(t,dark,1);c.fill();if(m.big){c.beginPath();c.arc(p[0],p[1],11,0,TAU);c.strokeStyle=R4.ramp(t,dark,.35);c.lineWidth=1;c.stroke()}});
  if(V.labels&&m.L){c.font='700 13px "Be Vietnam Pro",system-ui';c.textAlign='center';c.textBaseline='middle';m.L.forEach(l=>{const p=P[l.i];if(!p)return;const dx=p[0]-cx,dy=p[1]-cy,L=Math.hypot(dx,dy)||1;c.fillStyle=dark?'#eef2fb':'#1b2233';c.fillText(l.t,p[0]+dx/L*15,p[1]+dy/L*15-(m.big?0:0))})}
 };
 V.loop=function(ts){if(!V.on)return;requestAnimationFrame(V.loop);if(document.hidden||!V.cv.offsetParent)return;const dt=Math.min(.05,((ts-(V.t||ts))/1000)||0);V.t=ts;
  if(!V.drag){if(V.auto){V.ang.xz+=dt*.55;V.ang.yz=-.35+Math.sin(ts/2600)*.12;if(V.spin4&&V.model&&V.model.dim===4){V.ang.xw+=dt*.5;V.ang.zw+=dt*.31}}
   V.ang.xz+=V.vx*dt*60;V.ang.yz+=V.vy*dt*60;V.vx*=.93;V.vy*=.93;if(Math.abs(V.vx)<1e-4)V.vx=0;if(Math.abs(V.vy)<1e-4)V.vy=0}
  V.draw()};
 V.start=function(){if(V.on)return;V.on=true;V.t=0;requestAnimationFrame(V.loop)};V.stop=function(){V.on=false};
 /* pointer: drag rotates (4D-mode → xw/yw), wheel/pinch zooms */
 canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture&&canvas.setPointerCapture(e.pointerId);V.touches.set(e.pointerId,[e.clientX,e.clientY]);V.drag={x:e.clientX,y:e.clientY};V.pd=null});
 canvas.addEventListener('pointermove',e=>{if(!V.touches.has(e.pointerId))return;const prev=V.touches.get(e.pointerId);V.touches.set(e.pointerId,[e.clientX,e.clientY]);
  if(V.touches.size===2){const a=[...V.touches.values()],dd=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);if(V.pd)V.zoom=Math.max(.5,Math.min(3,V.zoom*dd/V.pd));V.pd=dd;return}
  const dx=e.clientX-prev[0],dy=e.clientY-prev[1];if(V.rot4&&V.model&&V.model.dim===4){V.ang.xw+=dx*.012;V.ang.yw+=dy*.012}else{V.ang.xz+=dx*.012;V.ang.yz+=dy*.012;V.vx=dx*.0007;V.vy=dy*.0007}V.draw()});
 const up=e=>{V.touches.delete(e.pointerId);if(!V.touches.size){V.drag=null;V.pd=null}};canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
 canvas.addEventListener('wheel',e=>{e.preventDefault();V.zoom=Math.max(.5,Math.min(3,V.zoom*(e.deltaY<0?1.08:.93)));V.draw()},{passive:false});
 if(window.ResizeObserver)new ResizeObserver(()=>V.draw()).observe(canvas);
 return V};
})();
