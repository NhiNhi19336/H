/* Atlas: figure library 0D→4D + dimension-jump lab. Exact formulas; every number is computed, never typed in. */
(function(){
'use strict';
const {T,esc,fmt,$,$$}=VN,D=VN.DATA,R4=VN.R4;
const S2=Math.sqrt(2),S3=Math.sqrt(3),S5=Math.sqrt(5),PI=Math.PI,PHI=(1+S5)/2;
const num=(el,d)=>{const v=parseFloat(String(el).replace(',','.'));return isFinite(v)?v:d};
/* ---- calculators: in:[id,vi,en,default]; out(v)->[{l:[vi,en],v|t,e(exp of unit),f}] ---- */
const PL={ /* regular solids by edge a */
 tetra:{n:[4,6,4],V:a=>a**3*S2/12,S:a=>a*a*S3,R:a=>a*Math.sqrt(6)/4,r:a=>a*Math.sqrt(6)/12},
 cube:{n:[8,12,6],V:a=>a**3,S:a=>6*a*a,R:a=>a*S3/2,r:a=>a/2},
 octa:{n:[6,12,8],V:a=>a**3*S2/3,S:a=>2*S3*a*a,R:a=>a*S2/2,r:a=>a*Math.sqrt(6)/6},
 dodeca:{n:[20,30,12],V:a=>(15+7*S5)/4*a**3,S:a=>3*Math.sqrt(25+10*S5)*a*a,R:a=>a*S3*(1+S5)/4,r:a=>a/2*Math.sqrt((25+11*S5)/10)},
 icosa:{n:[12,30,20],V:a=>5*(3+S5)/12*a**3,S:a=>5*S3*a*a,R:a=>a/4*Math.sqrt(10+2*S5),r:a=>S3*(3+S5)/12*a}};
const P4={cell5:{f:[5,10,10,5],H:a=>S5/96*a**4,B:a=>5*S2/12*a**3,hf:['√5·a⁴/96','5√2·a³/12']},tesseract:{f:[16,32,24,8],H:a=>a**4,B:a=>8*a**3,hf:['a⁴','8a³']},cell16:{f:[8,24,32,16],H:a=>a**4/6,B:a=>4*S2/3*a**3,hf:['a⁴/6','4√2·a³/3']},cell24:{f:[24,96,96,24],H:a=>2*a**4,B:a=>8*S2*a**3,hf:['2a⁴','8√2·a³']}};
const C={
 dist:{in:[['x1','x₁','x₁',1],['y1','y₁','y₁',2],['z1','z₁','z₁',2],['x2','x₂','x₂',4],['y2','y₂','y₂',6],['z2','z₂','z₂',8]],
  out:v=>{const dx=v.x2-v.x1,dy=v.y2-v.y1,dz=v.z2-v.z1;return[{l:['Độ dài AB','Length AB'],v:Math.hypot(dx,dy,dz),e:0,f:'√(Δx²+Δy²+Δz²)'},{l:['Trung điểm M','Midpoint M'],t:'('+fmt((v.x1+v.x2)/2)+'; '+fmt((v.y1+v.y2)/2)+'; '+fmt((v.z1+v.z2)/2)+')',f:'(A+B)/2'}]}},
 vec2:{in:[['F1','F₁','F₁',3],['F2','F₂','F₂',4],['al','α (°)','α (°)',90]],
  out:v=>{const a=v.al*PI/180,F=Math.sqrt(Math.max(0,v.F1*v.F1+v.F2*v.F2+2*v.F1*v.F2*Math.cos(a)));const b=Math.atan2(v.F2*Math.sin(a),v.F1+v.F2*Math.cos(a))*180/PI;return[{l:['Hợp lực F','Net force F'],v:F,e:0,f:'√(F₁²+F₂²+2F₁F₂cosα)'},{l:['Góc giữa F và F₁ (°)','Angle between F and F₁ (°)'],v:b,e:0,f:'tanβ = F₂sinα / (F₁+F₂cosα)',nu:1}]}},
 plane:{in:[['A','A','A',1],['B','B','B',2],['Cc','C','C',2],['Dd','D','D',-3],['x0','x₀','x₀',1],['y0','y₀','y₀',1],['z0','z₀','z₀',1]],
  out:v=>{const n=Math.hypot(v.A,v.B,v.Cc);const num=v.A*v.x0+v.B*v.y0+v.Cc*v.z0+v.Dd;return[{l:['Khoảng cách d(M₀,(P))','Distance d(M₀,(P))'],v:n?Math.abs(num)/n:NaN,e:0,f:'|Ax₀+By₀+Cz₀+D| / √(A²+B²+C²)'},{l:['Độ dài pháp vectơ |n|','Normal length |n|'],v:n,e:0,nu:1,f:'√(A²+B²+C²)'}]}},
 angle:{in:[['deg','Góc θ (°)','Angle θ (°)',60]],shape:v=>({deg:Math.max(1,Math.min(179,v.deg))}),
  out:v=>{const t=v.deg*PI/180;return[{l:['Rađian','Radians'],v:t,e:0,nu:1,f:'θ·π/180'},{l:['Phụ (90°−θ)','Complement (90°−θ)'],v:90-v.deg,e:0,nu:1,f:'90° − θ'},{l:['Bù (180°−θ)','Supplement (180°−θ)'],v:180-v.deg,e:0,nu:1,f:'180° − θ'},{l:['sin θ','sin θ'],v:Math.sin(t),e:0,nu:1},{l:['cos θ','cos θ'],v:Math.cos(t),e:0,nu:1},{l:['tan θ','tan θ'],v:Math.abs(Math.cos(t))<1e-12?NaN:Math.tan(t),e:0,nu:1}]}},
 tri:{in:[['a','a','a',3],['b','b','b',4],['c','c','c',5]],shape:v=>({a:v.a,b:v.b,c:v.c}),
  out:v=>{const{a,b,c}=v;if(!(a>0&&b>0&&c>0&&a+b>c&&a+c>b&&b+c>a))return[{l:['Lỗi','Error'],t:T('Ba cạnh không lập được tam giác (cần tổng hai cạnh > cạnh còn lại).','These sides do not form a triangle (each side must be shorter than the sum of the others).')}];
   const p=(a+b+c)/2,S=Math.sqrt(p*(p-a)*(p-b)*(p-c)),ang=(x,y,z)=>Math.acos(Math.max(-1,Math.min(1,(y*y+z*z-x*x)/(2*y*z))))*180/PI;
   return[{l:['Diện tích S','Area S'],v:S,e:2,f:'√(p(p−a)(p−b)(p−c))'},{l:['Chu vi P','Perimeter P'],v:2*p,e:1,f:'a+b+c'},{l:['Góc A','Angle A'],v:ang(a,b,c),e:0,nu:1,f:'cosA = (b²+c²−a²)/2bc'},{l:['Góc B','Angle B'],v:ang(b,a,c),e:0,nu:1},{l:['Góc C','Angle C'],v:ang(c,a,b),e:0,nu:1},{l:['R ngoại tiếp','Circumradius R'],v:a*b*c/(4*S),e:1,f:'abc/4S'},{l:['r nội tiếp','Inradius r'],v:S/p,e:1,f:'S/p'},{l:['Đường cao h_a','Altitude h_a'],v:2*S/a,e:1,f:'2S/a'}]}},
 sq:{in:[['a','Cạnh a','Side a',4]],out:v=>[{l:['Diện tích','Area'],v:v.a*v.a,e:2,f:'a²'},{l:['Chu vi','Perimeter'],v:4*v.a,e:1,f:'4a'},{l:['Đường chéo','Diagonal'],v:v.a*S2,e:1,f:'a√2'}]},
 rect:{in:[['a','Dài a','Length a',5],['b','Rộng b','Width b',3]],shape:v=>({r:v.a/v.b}),out:v=>[{l:['Diện tích','Area'],v:v.a*v.b,e:2,f:'ab'},{l:['Chu vi','Perimeter'],v:2*(v.a+v.b),e:1,f:'2(a+b)'},{l:['Đường chéo','Diagonal'],v:Math.hypot(v.a,v.b),e:1,f:'√(a²+b²)'}]},
 ngon:{in:[['n','Số cạnh n','Sides n',6],['a','Cạnh a','Side a',2]],shape:v=>({n:v.n}),
  out:v=>{const n=Math.round(v.n),a=v.a;if(n<3)return[{l:['Lỗi','Error'],t:'n ≥ 3'}];const t=Math.tan(PI/n),s=Math.sin(PI/n);return[{l:['Góc trong (°)','Interior angle (°)'],v:(n-2)*180/n,e:0,nu:1,f:'(n−2)·180°/n'},{l:['Số đường chéo','Diagonals'],v:n*(n-3)/2,e:0,nu:1,f:'n(n−3)/2'},{l:['Diện tích','Area'],v:n*a*a/(4*t),e:2,f:'na²/(4tan(π/n))'},{l:['R ngoại tiếp','Circumradius R'],v:a/(2*s),e:1,f:'a/(2sin(π/n))'},{l:['r nội tiếp (trung đoạn)','Inradius r (apothem)'],v:a/(2*t),e:1,f:'a/(2tan(π/n))'}]}},
 circ:{in:[['r','Bán kính R','Radius R',5]],out:v=>[{l:['Chu vi','Circumference'],v:2*PI*v.r,e:1,f:'2πR'},{l:['Diện tích','Area'],v:PI*v.r*v.r,e:2,f:'πR²'},{l:['Đường kính','Diameter'],v:2*v.r,e:1,f:'2R'}]},
 ell:{in:[['a','Bán trục lớn a','Semi-major a',5],['b','Bán trục nhỏ b','Semi-minor b',3]],shape:v=>({k:v.b/v.a}),
  out:v=>{let{a,b}=v;if(b>a){const t=a;a=b;b=t}const c=Math.sqrt(a*a-b*b);return[{l:['Diện tích','Area'],v:PI*a*b,e:2,f:'πab'},{l:['Tiêu cự c','Focal distance c'],v:c,e:1,f:'√(a²−b²)'},{l:['Tâm sai e','Eccentricity e'],v:c/a,e:0,nu:1,f:'c/a'},{l:['Chu vi (xấp xỉ Ramanujan)','Perimeter (Ramanujan approx.)'],v:PI*(3*(a+b)-Math.sqrt((3*a+b)*(a+3*b))),e:1,f:'π[3(a+b)−√((3a+b)(a+3b))]'}]}},
 plato:{in:[['a','Cạnh a','Edge a',2]],out:(v,en)=>{const p=PL[en.s],a=v.a;return[{l:['Đỉnh / Cạnh / Mặt','V / E / F'],t:p.n.join(' / ')+'   (V−E+F = '+(p.n[0]-p.n[1]+p.n[2])+')'},{l:['Thể tích V','Volume V'],v:p.V(a),e:3},{l:['Diện tích toàn phần','Total surface area'],v:p.S(a),e:2},{l:['Bán kính cầu ngoại tiếp R','Circumradius R'],v:p.R(a),e:1},{l:['Bán kính cầu nội tiếp r','Inradius r'],v:p.r(a),e:1}]},ask:(v,u,en)=>en.s==='cube'?T('Hình lập phương cạnh '+v.a+' '+u+', tính thể tích, diện tích toàn phần','Cube with edge '+v.a+' '+u+', find volume and total surface area'):''},
 cub:{in:[['a','Dài a','Length a',4],['b','Rộng b','Width b',3],['c','Cao c','Height c',2]],shape:v=>({a:v.a,b:v.b,c:v.c}),out:v=>[{l:['Thể tích','Volume'],v:v.a*v.b*v.c,e:3,f:'abc'},{l:['Diện tích toàn phần','Total area'],v:2*(v.a*v.b+v.b*v.c+v.c*v.a),e:2,f:'2(ab+bc+ca)'},{l:['Đường chéo','Diagonal'],v:Math.sqrt(v.a*v.a+v.b*v.b+v.c*v.c),e:1,f:'√(a²+b²+c²)'}],ask:(v,u)=>T('Hình hộp chữ nhật dài '+v.a+' '+u+' rộng '+v.b+' '+u+' cao '+v.c+' '+u+', tính thể tích','Cuboid length '+v.a+' '+u+' width '+v.b+' '+u+' height '+v.c+' '+u+', find the volume')},
 hexp:{in:[['a','Cạnh đáy a','Base side a',2],['h','Chiều cao h','Height h',5]],out:v=>[{l:['Thể tích','Volume'],v:3*S3/2*v.a*v.a*v.h,e:3,f:'(3√3/2)a²h'},{l:['Diện tích xung quanh','Lateral area'],v:6*v.a*v.h,e:2,f:'6ah'},{l:['Diện tích toàn phần','Total area'],v:6*v.a*v.h+3*S3*v.a*v.a,e:2,f:'6ah + 3√3a²'}]},
 pyr:{in:[['a','Cạnh đáy a','Base side a',4],['h','Chiều cao h','Height h',3]],out:v=>{const l=Math.sqrt(v.h*v.h+v.a*v.a/4);return[{l:['Thể tích','Volume'],v:v.a*v.a*v.h/3,e:3,f:'a²h/3'},{l:['Trung đoạn l','Slant height l'],v:l,e:1,f:'√(h²+a²/4)'},{l:['Diện tích xung quanh','Lateral area'],v:2*v.a*l,e:2,f:'2al'},{l:['Cạnh bên','Lateral edge'],v:Math.sqrt(v.h*v.h+v.a*v.a/2),e:1,f:'√(h²+a²/2)'},{l:['Trọng tâm cách đáy','Centroid above base'],v:v.h/4,e:1,f:'h/4'}]}},
 cyl:{in:[['r','Bán kính r','Radius r',3],['h','Chiều cao h','Height h',5]],shape:v=>({k:v.h/v.r}),out:v=>[{l:['Thể tích','Volume'],v:PI*v.r*v.r*v.h,e:3,f:'πr²h'},{l:['Diện tích xung quanh','Lateral area'],v:2*PI*v.r*v.h,e:2,f:'2πrh'},{l:['Diện tích toàn phần','Total area'],v:2*PI*v.r*(v.r+v.h),e:2,f:'2πr(r+h)'}],ask:(v,u)=>T('Hình trụ bán kính '+v.r+' '+u+' chiều cao '+v.h+' '+u+', tính thể tích','Cylinder radius '+v.r+' '+u+' height '+v.h+' '+u+', find the volume')},
 cone:{in:[['r','Bán kính r','Radius r',3],['h','Chiều cao h','Height h',4]],shape:v=>({k:v.h/v.r}),out:v=>{const l=Math.hypot(v.r,v.h);return[{l:['Đường sinh l','Slant height l'],v:l,e:1,f:'√(r²+h²)'},{l:['Diện tích xung quanh','Lateral area'],v:PI*v.r*l,e:2,f:'πrl'},{l:['Diện tích toàn phần','Total area'],v:PI*v.r*(v.r+l),e:2,f:'πr(r+l)'},{l:['Thể tích','Volume'],v:PI*v.r*v.r*v.h/3,e:3,f:'πr²h/3'}]},ask:(v,u)=>T('Hình nón bán kính '+v.r+' '+u+' chiều cao '+v.h+' '+u+', tính thể tích','Cone radius '+v.r+' '+u+' height '+v.h+' '+u+', find the volume')},
 sph:{in:[['r','Bán kính R','Radius R',3]],out:v=>[{l:['Thể tích','Volume'],v:4*PI*v.r**3/3,e:3,f:'4πR³/3'},{l:['Diện tích mặt cầu','Surface area'],v:4*PI*v.r*v.r,e:2,f:'4πR²'},{l:['Chu vi đường tròn lớn','Great-circle circumference'],v:2*PI*v.r,e:1,f:'2πR'}],ask:(v,u)=>T('Hình cầu bán kính '+v.r+' '+u+', tính thể tích','Sphere radius '+v.r+' '+u+', find the volume')},
 tor:{in:[['R','R (tâm → ống)','R (centre → tube)',3],['r','r (ống)','r (tube)',1]],shape:v=>({k:v.r/v.R}),out:v=>v.r>=v.R?[{l:['Lỗi','Error'],t:T('Cần R > r.','Need R > r.')}]:[{l:['Thể tích','Volume'],v:2*PI*PI*v.R*v.r*v.r,e:3,f:'2π²Rr²'},{l:['Diện tích mặt','Surface area'],v:4*PI*PI*v.R*v.r,e:2,f:'4π²Rr'}]},
 poly4:{in:[['a','Cạnh a','Edge a',1]],out:(v,en)=>{const p=P4[en.s],a=v.a;const fv=p.f;const o=[{l:['Đỉnh / Cạnh / Mặt / Ô','Vertices / Edges / Faces / Cells'],t:fv.join(' / ')+'   (V−E+F−C = '+(fv[0]-fv[1]+fv[2]-fv[3])+')'},{l:['Siêu thể tích','Hypervolume'],v:p.H(a),e:4,f:p.hf[0]},{l:['Thể tích biên','Boundary volume'],v:p.B(a),e:3,f:p.hf[1]}];if(en.s==='tesseract')o.push({l:['Đường chéo lớn','Long diagonal'],v:2*a,e:1,f:'2a'});return o}}
};
const SUP={2:'²',3:'³',4:'⁴'};
let A={dim:0,key:'point',mode:'fig',V:null,hop:{k:3,t:1,anim:0}};
let root;
const figsOf=d=>D.ATLAS.filter(a=>a.d===d);
function init(el){root=el;el.innerHTML='<div class="wrap"><div class="h2" id="atT"></div><div class="dimrow" id="atD"></div><div class="row" style="margin-bottom:8px"><span class="seg" id="atM"></span></div><div class="pills" id="atP"></div><div id="atB"></div></div>';
 $('#atD').onclick=e=>{const b=e.target.closest('button');if(!b)return;A.mode='fig';A.dim=+b.dataset.d;const l=figsOf(A.dim);if(!l.some(a=>a.k===A.key))A.key=l[0].k;render()};
 $('#atM').onclick=e=>{const b=e.target.closest('button');if(!b)return;A.mode=b.dataset.m;render()};
 $('#atP').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;A.key=b.dataset.k;render()}}
function show(p){if(p&&p.key){const a=D.byKey(p.key);if(a){A.dim=a.d;A.key=a.k;A.mode=p.hop?'hop':'fig'}}if(p&&p.mode)A.mode=p.mode;render();A.V&&A.V.start()}
function stopV(){if(A.V)A.V.stop()}
VN.on('theme',()=>A.V&&A.V.draw());
function render(){if(!root)return;
 const dims=D.REALMS;$('#atT').textContent=T('Atlas hình học: từ Điểm lên Siêu khối','Geometry Atlas: from the Point to the Hypercube');
 $('#atD').innerHTML=dims.map(r=>'<button data-d="'+r.d+'" class="'+(A.mode==='fig'&&A.dim===r.d?'on':'')+'">'+r.d+'D<small>'+esc(T(r.vi,r.en))+'</small></button>').join('');
 $('#atM').innerHTML='<button data-m="fig" class="'+(A.mode==='fig'?'on':'')+'">'+T('Thư viện hình','Figure library')+'</button><button data-m="hop" class="'+(A.mode==='hop'?'on':'')+'">⬆ '+T('Nhảy chiều','Dimension jump')+'</button>';
 $('#atP').style.display=A.mode==='fig'?'':'none';
 if(A.mode==='fig'){$('#atP').innerHTML=figsOf(A.dim).map(a=>'<button class="chip'+(a.k===A.key?' on':'')+'" data-k="'+a.k+'">'+esc(T(a.vi,a.en))+'</button>').join('');renderFig()}else renderHop()}
/* ---------- figure view ---------- */
function mkView(h){const b=$('#atB');if(A.V){A.V.stop();A.V=null}const cv=$('#atCv');A.V=R4.View(cv,{h:h});A.V.start();return A.V}
function renderFig(){const a=D.byKey(A.key),en=a;VN.bump('atlas',1);
 const calc=C[a.calc],ins=calc?calc.in.filter(i=>!(a.calc==='ngon'&&a.n&&a.param!=='n'&&i[0]==='n')):[];
 const links=D.LINKS.filter(l=>l.geo&&l.geo.key===a.k);
 let h='<div class="grid g2"><div><div class="card" style="padding:8px"><canvas class="cv" id="atCv"></canvas><div class="row" style="padding:8px 4px 0"><button class="chip" id="atA">⟳ '+T('Tự quay','Auto')+'</button><button class="chip" id="atX">xyz '+T('Trục','Axes')+'</button>'+(a.d===4?'<button class="chip" id="atR">'+T('Kéo = xoay 4D','Drag = 4D')+'</button><button class="chip" id="atS">⟳ 4D</button>':'')+'</div>'+
  (a.d===4?'<div style="padding:6px 6px 0"><label>XW <input type="range" id="sxw" min="0" max="6.283" step=".01" value="0"></label><label>YW <input type="range" id="syw" min="0" max="6.283" step=".01" value="0"></label><label>ZW <input type="range" id="szw" min="0" max="6.283" step=".01" value="0"></label></div>':'')+'</div>'+
  (a.f?'<div class="card"><h3>'+T('Vectơ f (đếm các phần tử)','f-vector (counting elements)')+'</h3><table class="t"><tr><th>'+T('Đỉnh','Vertices')+'</th><th>'+T('Cạnh','Edges')+'</th><th>'+T('Mặt','Faces')+'</th><th>'+T('Ô','Cells')+'</th></tr><tr>'+a.f.slice(0,4).map(x=>'<td><b>'+x+'</b></td>').join('')+'</tr></table><small>V − E + F − C = '+(a.f[0]-a.f[1]+a.f[2]-a.f[3])+'</small></div>':'')+'</div>'+
  '<div><div class="card"><div class="row"><span class="tag">'+a.d+'D</span><h3 style="margin:0">'+esc(T(a.vi,a.en))+'</h3></div><p style="margin:8px 0 6px">'+esc(T(a.def[0],a.def[1]))+'</p>'+a.facts.map(f=>'<div class="step">'+esc(T(f[0],f[1]))+'</div>').join('')+'<div class="mu" style="margin-top:6px">💡 '+esc(T(a.tip[0],a.tip[1]))+'</div></div>'+
  '<div class="card" style="border-color:color-mix(in srgb,var(--c3) 45%,var(--bd))"><h3>⚛ '+T('Liên hệ vật lý','Physics connection')+'</h3><div>'+esc(T(a.phy[0],a.phy[1]))+'</div><div class="links">'+
   (a.lab?'<button class="chip" data-lab="'+a.lab+'">🧪 '+T('Mở lab liên ngành','Open cross-lab')+'</button>':'')+links.map(l=>'<button class="chip" data-lk="'+l.id+'">↔ '+esc(T(l.vi,l.en))+'</button>').join('')+(a.d===4?'<button class="chip" data-hop="1">⬆ '+T('Xem cách nhảy chiều','See the dimension jump')+'</button>':'')+'</div></div>'+
  (calc?'<div class="card"><h3>🧮 '+T('Tính nhanh (offline)','Quick calculator (offline)')+'</h3><div class="row" id="atI">'+ins.map(i=>'<label>'+esc(T(i[1],i[2]))+'<br><input data-v="'+i[0]+'" inputmode="decimal" value="'+((i[0]==='n'&&a.n)?a.n:i[3])+'" style="width:92px"></label>').join('')+(!['dist','plane','angle','vec2'].includes(a.calc)?'<label>'+T('Đơn vị','Unit')+'<br><input id="atU" value="cm" style="width:60px"></label>':'')+'</div><div id="atO" style="margin-top:8px"></div><div class="row" id="atQ" style="margin-top:8px"></div></div>':'')+'</div></div>';
 $('#atB').innerHTML=h;
 const V=mkView(window.innerWidth<700?290:360);V.set(R4.gen[a.k]());
 const upd=()=>{if(!calc)return;const v={};$$('#atI input[data-v]').forEach(i=>{v[i.dataset.v]=num(i.value,0)});if(a.n&&a.calc==='ngon'&&a.param!=='n')v.n=a.n;
  const u=($('#atU')&&$('#atU').value)||'';let out=[];try{out=calc.out(v,a)}catch(e){out=[{l:['Lỗi','Error'],t:String(e.message)}]}
  $('#atO').innerHTML=out.map(o=>'<div class="kv"><span>'+esc(T(o.l[0],o.l[1]))+(o.f?' <small>'+esc(o.f)+'</small>':'')+'</span><b class="mono">'+(o.t!=null?esc(o.t):fmt(o.v)+(o.nu?'':' '+esc(u)+(SUP[o.e]||'')))+'</b></div>').join('');
  if(calc.shape){try{const sv=calc.shape(v);const m=R4.gen[a.k](sv);if(m&&m.V.every(p=>p.every(isFinite)))V.set(m)}catch(e){}}
  const q=calc.ask?calc.ask(v,u||'cm',a):'';$('#atQ').innerHTML=q?'<button class="btn g" id="atAsk">🧠 '+T('Giải & giải thích trong "Giải"','Solve & explain in "Solve"')+'</button>':'';if(q)$('#atAsk').onclick=()=>VN.go('solve',{q:q,run:1})};
 if(calc){$('#atI').oninput=upd;upd()}
 /* controls */
 const tg=(id,get,set)=>{const b=$(id);if(!b)return;const f=()=>b.classList.toggle('on',!!get());f();b.onclick=()=>{set();f()}};
 tg('#atA',()=>V.auto,()=>{V.auto=!V.auto});tg('#atX',()=>V.axes,()=>{V.axes=!V.axes;V.draw()});tg('#atR',()=>V.rot4,()=>{V.rot4=!V.rot4});tg('#atS',()=>V.spin4,()=>{V.spin4=!V.spin4;if(V.spin4)V.auto=true});
 if(a.d===4){['xw','yw','zw'].forEach(k=>{$('#s'+k).oninput=e=>{V.ang[k]=+e.target.value;V.draw()}})}
 $$('#atB [data-lab]').forEach(b=>b.onclick=()=>VN.go('lab',{lab:b.dataset.lab}));
 $$('#atB [data-lk]').forEach(b=>b.onclick=()=>{const l=D.LINKS.find(x=>x.id===b.dataset.lk);VN.open(l.phy)});
 $$('#atB [data-hop]').forEach(b=>b.onclick=()=>{A.mode='hop';render()})}
/* ---------- dimension jump ---------- */
const NAMES=[['Điểm','Point'],['Đoạn thẳng','Segment'],['Hình vuông','Square'],['Hình lập phương','Cube'],['Siêu lập phương','Tesseract']];
function renderHop(){const k=A.hop.k;
 $('#atB').innerHTML='<div class="grid g2"><div><div class="card" style="padding:8px"><canvas class="cv" id="atCv"></canvas><div class="row" style="padding:8px 4px 0"><button class="btn" id="hUp">⬆ '+T('Nhảy lên chiều kế tiếp','Jump up one dimension')+'</button><button class="btn g" id="hDn">⬇ '+T('Xuống','Down')+'</button><button class="chip" id="hA">⟳</button></div><div style="padding:8px 6px 0"><label>'+T('Kéo trục mới','New axis')+' <input type="range" id="hT" min="0" max="1" step=".005" value="'+A.hop.t+'"></label></div></div></div><div><div class="card" id="hI"></div></div></div>';
 const V=mkView(window.innerWidth<700?290:360);A.V=V;const setM=()=>{V.set(R4.hyper(A.hop.k,A.hop.t));info()};
 const info=()=>{const k=A.hop.k,f=R4.fvec(k),names=[T('đỉnh','vertices'),T('cạnh','edges'),T('mặt vuông','square faces'),T('ô lập phương','cubic cells'),T('ô 4 chiều','4-cells')];
  let h='<div class="row"><span class="tag">'+k+'D</span><h3 style="margin:0">'+esc(T(NAMES[k][0],NAMES[k][1]))+'</h3></div><p>'+(k===0?T('Bắt đầu bằng một điểm.','Start with a single point.'):T('Kéo '+(k===1?'điểm':'hình '+(k-1)+'D')+' theo hướng mới, vuông góc với mọi hướng cũ: mỗi đỉnh vẽ ra một cạnh, mỗi cạnh vẽ ra một mặt, và cứ thế.','Drag the '+(k===1?'point':(k-1)+'D figure')+' along a new direction perpendicular to all old ones: each vertex sweeps out an edge, each edge a face, and so on.'))+'</p>'+
  '<table class="t"><tr><th>'+T('Phần tử','Element')+'</th>'+f.map((_,j)=>'<th>'+names[j]+'</th>').join('')+'</tr><tr><td>'+T('Số lượng','Count')+'</td>'+f.map(x=>'<td><b>'+x+'</b></td>').join('')+'</tr></table>'+
  '<div class="step">f<sub>j</sub> = C(n, j)·2<sup>n−j</sup> '+T('— số phần tử j chiều của siêu lập phương n chiều','— number of j-dimensional elements of the n-cube')+'</div><div class="step">V = 2<sup>n</sup> = '+f[0]+',  E = n·2<sup>n−1</sup> = '+(f[1]||0)+'</div>'+(k>=1?'<div class="step">'+T('Euler (xen kẽ dấu): ','Euler (alternating sum): ')+f.slice(0,k).map((x,i)=>(i?(i%2?'− ':'+ '):'')+x).join(' ')+' = '+f.slice(0,k).reduce((s,x,i)=>s+(i%2?-x:x),0)+(k>=2?'':'')+'</div>':'')+
  '<div class="mu">⚛ '+(k===4?T('Thêm trục thời gian: không-thời gian có 4 chiều (x, y, z, t).','Add a time axis: spacetime has 4 dimensions (x, y, z, t).'):k===3?T('Thể tích = a³; đây là chiều ta sống.','Volume = a³; this is the dimension we live in.'):T('Mỗi chiều thêm một bậc tự do chuyển động.','Each dimension adds one degree of freedom of motion.'))+'</div>';
  $('#hI').innerHTML=h};
 const anim=up=>{if(up&&A.hop.k>=4)return VN.toast(T('Đây là chiều cao nhất trong Atlas.','This is the top dimension in the Atlas.'));if(!up&&A.hop.k<=0)return;A.hop.k+=up?1:-1;A.hop.t=0;const t0=performance.now();A.hop.anim=1;const st=ts=>{const u=Math.min(1,(ts-t0)/1600),e=u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2;A.hop.t=up?e:1;$('#hT')&&($('#hT').value=A.hop.t);setM();if(u<1&&VN.cur==='atlas')requestAnimationFrame(st);else{A.hop.anim=0;A.hop.t=1;setM()}};requestAnimationFrame(st);if(up){VN.bump('hop',1)}};
 $('#hUp').onclick=()=>anim(true);$('#hDn').onclick=()=>anim(false);$('#hA').onclick=()=>{V.auto=!V.auto};$('#hT').oninput=e=>{A.hop.t=+e.target.value;setM()};setM()}
VN.views.atlas={init,show,render,hide:stopV};
})();
