/* Cross-labs: geometry × physics. All results are computed from exact formulas (see tests/t_xlab.js). */
(function(){
'use strict';
const {T,esc,fmt,$,$$,S}=VN,R4=VN.R4,PI=Math.PI,G0=9.81;
const X=VN.XLAB={};
const FLUIDS=[['Nước','Water',1000],['Nước biển','Seawater',1025],['Dầu ăn','Cooking oil',920],['Xăng','Petrol',750],['Glycerin','Glycerine',1260],['Thủy ngân','Mercury',13600]];
/* ============ FLOAT ============ */
const SHAPES={cube:{vi:'Lập phương',en:'Cube',V:s=>s**3,A:(s,z)=>s*s,Vh:(s,h)=>s*s*h,H:s=>s},
 cyl:{vi:'Hình trụ đứng',en:'Upright cylinder',V:s=>PI*s**3/4,A:(s,z)=>PI*s*s/4,Vh:(s,h)=>PI*s*s*h/4,H:s=>s},
 sph:{vi:'Hình cầu',en:'Sphere',V:s=>PI*s**3/6,A:(s,z)=>{const r=s/2;return PI*Math.max(0,r*r-(z-r)*(z-r))},Vh:(s,h)=>PI*h*h*(3*(s/2)-h)/3,H:s=>s},
 coneD:{vi:'Nón (đỉnh xuống)',en:'Cone (apex down)',V:s=>PI*s**3/12,A:(s,z)=>PI*(z/2)**2,Vh:(s,h)=>PI*h**3/12,H:s=>s},
 coneU:{vi:'Nón (đáy xuống)',en:'Cone (base down)',V:s=>PI*s**3/12,A:(s,z)=>PI*((s-z)/2)**2,Vh:(s,h)=>PI*s**3/12-PI*(s-h)**3/12,H:s=>s}};
X.SHAPES=SHAPES;
/* z-bar of the submerged part measured from the object's bottom */
function zbar(sh,s,h){const n=400;let a=0,m=0;for(let i=0;i<n;i++){const z=(i+.5)*h/n,A=SHAPES[sh].A(s,z);a+=A;m+=A*z}return a?m/a:0}
X.float=function(p){/* p:{sh,s(cm),rho(kg/m3),rf} -> results in SI */
 const sh=SHAPES[p.sh],s=p.s/100,V=sh.V(s),m=p.rho*V,q=p.rho/p.rf,W=m*G0;let r={V,m,W,q};
 if(q>=1){r.sink=true;r.h=s;r.Vsub=V;r.FB=p.rf*G0*V;r.app=W-r.FB;r.frac=1;r.zb=zbar(p.sh,s,s);return r}
 let lo=0,hi=s;for(let i=0;i<90;i++){const mid=(lo+hi)/2;sh.Vh(s,mid)<q*V?lo=mid:hi=mid}
 r.h=(lo+hi)/2;r.Vsub=sh.Vh(s,r.h);r.frac=r.Vsub/V;r.FB=p.rf*G0*r.Vsub;r.zb=zbar(p.sh,s,r.h);return r};
const col=()=>{const d=VN.dark();return{tx:d?'#eef2fb':'#1b2233',mu:d?'#9aa7c2':'#5c6780',w:d?'rgba(56,189,248,.26)':'rgba(14,165,233,.28)',wl:d?'rgba(125,211,252,.9)':'rgba(2,132,199,.9)',dk:d}};
function setup(cv,h){const d=Math.min(2,devicePixelRatio||1),w=cv.clientWidth||320;cv.style.height=h+'px';if(cv.width!==Math.round(w*d)||cv.height!==Math.round(h*d)){cv.width=Math.round(w*d);cv.height=Math.round(h*d)}const c=cv.getContext('2d');c.setTransform(d,0,0,d,0,0);c.clearRect(0,0,w,h);return{c,W:w,H:h}}
function arrow(c,x1,y1,x2,y2,color,lw){c.strokeStyle=color;c.fillStyle=color;c.lineWidth=lw||2;c.lineCap='round';c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();const a=Math.atan2(y2-y1,x2-x1),s=7;c.beginPath();c.moveTo(x2,y2);c.lineTo(x2-s*Math.cos(a-.45),y2-s*Math.sin(a-.45));c.lineTo(x2-s*Math.cos(a+.45),y2-s*Math.sin(a+.45));c.closePath();c.fill()}
function objPath(c,sh,x,yb,s,k){/* draws profile: x = left, yb = bottom (px), s = size px */c.beginPath();
 if(sh==='cube'||sh==='cyl'){c.rect(x,yb-s,s,s)}else if(sh==='sph'){c.arc(x+s/2,yb-s/2,s/2,0,2*PI)}else if(sh==='coneD'){c.moveTo(x+s/2,yb);c.lineTo(x,yb-s);c.lineTo(x+s,yb-s);c.closePath()}else{c.moveTo(x,yb);c.lineTo(x+s,yb);c.lineTo(x+s/2,yb-s);c.closePath()}}
function fill(c,x,y,w,h){const g=c.createLinearGradient(x,y,x,y+h);g.addColorStop(0,R4.ramp(.05,VN.dark(),.85));g.addColorStop(1,R4.ramp(.5,VN.dark(),.85));return g}
X.drawFloat=function(cv,p,r){const {c,W,H}=setup(cv,300),C=col(),wx=70,wy=105,k=Math.min(W/wx,H/wy),ox=(W-wx*k)/2,Y=z=>H-6-z*k;
 c.fillStyle=C.w;c.fillRect(ox,Y(50),wx*k,50*k);c.strokeStyle=C.wl;c.lineWidth=2;c.beginPath();c.moveTo(ox,Y(50));c.lineTo(ox+wx*k,Y(50));c.stroke();
 c.strokeStyle=C.mu;c.lineWidth=2;c.beginPath();c.moveTo(ox,Y(80));c.lineTo(ox,Y(0));c.lineTo(ox+wx*k,Y(0));c.lineTo(ox+wx*k,Y(80));c.stroke();
 const s=p.s,zb=r.sink?0:50-r.h*100,x=ox+(wx-s)/2*k;
 objPath(c,p.sh,x,Y(zb),s*k);c.fillStyle=fill(c,x,Y(zb+s),s*k,s*k);c.fill();c.strokeStyle=R4.ramp(.1,C.dk);c.lineWidth=1.5;c.stroke();
 const cx=ox+wx/2*k,top=Y(zb+s),mid=Y(zb+s/2),L=Math.min(70,18+r.W*.5);
 const wl=34,bl=r.sink?wl*r.FB/r.W:wl;                /* equal arrows when floating */
 arrow(c,cx-s*k*.22,mid,cx-s*k*.22,mid+wl,'#ef4444',2.5);arrow(c,cx+s*k*.22,Y(zb+r.zb*100),cx+s*k*.22,Y(zb+r.zb*100)-bl,'#22c55e',2.5);
 if(r.sink){const ns=Math.max(0,wl-bl);if(ns>1){arrow(c,cx,Y(0),cx,Y(0)-ns,'#a855f7',2)}}
 c.fillStyle=C.tx;c.font='600 11px "Be Vietnam Pro",system-ui';c.textAlign='left';c.fillText('P',cx-s*k*.22+5,mid+wl-2);c.fillText('F_A',cx+s*k*.22+5,Y(zb+r.zb*100)-bl+10)};
/* ============ PRESSURE ============ */
X.press=function(p){/* p:{W(cm),H(cm),d(cm),rf,atm} */const W=p.W/100,H=p.H/100,d=p.d/100,rg=p.rf*G0,p0=p.atm?101325:0,A=W*W;
 const pt=p0+rg*d,pb=p0+rg*(d+H),Ft=pt*A,Fb=pb*A,Fs=(p0+rg*(d+H/2))*H*W,V=A*H;
 const zcp=(2/3)*(((d+H)**3-d**3)/((d+H)**2-d**2||1e-12));const zc=d===0&&H===0?0:zcp;
 return{pt,pb,Ft,Fb,net:Fb-Ft,FA:p.rf*G0*V,Fs,zcp:d===0?2*H/3:zcp,V,mw:p.rf*V}};
X.drawPress=function(cv,p,r){const {c,W,H}=setup(cv,310),C=col(),wx=70,wy=150,k=Math.min(W/wx,H/(wy+6)),ox=(W-wx*k)/2,Y=z=>8+z*k;
 c.fillStyle=C.w;c.fillRect(ox,Y(0),wx*k,wy*k);c.strokeStyle=C.wl;c.lineWidth=2;c.beginPath();c.moveTo(ox,Y(0));c.lineTo(ox+wx*k,Y(0));c.stroke();
 c.strokeStyle=C.mu;c.lineWidth=2;c.beginPath();c.moveTo(ox,Y(0)-10);c.lineTo(ox,Y(wy));c.lineTo(ox+wx*k,Y(wy));c.lineTo(ox+wx*k,Y(0)-10);c.stroke();
 const bw=p.W,x=ox+(wx-bw)/2*k,y0=Y(p.d),bh=p.H*k;c.beginPath();c.rect(x,y0,bw*k,bh);c.fillStyle=fill(c,x,y0,bw*k,bh);c.fill();c.strokeStyle=R4.ramp(.1,C.dk);c.lineWidth=1.5;c.stroke();
 const pmax=Math.max(r.pb,1),sc=Math.min(70,W*.2)/ (p.atm?r.pb:pmax);
 const len=pp=>Math.max(3,(p.atm?pp/r.pb:pp/pmax)*Math.min(64,W*.19));
 arrow(c,x+bw*k*.5,y0-len(r.pt)-2,x+bw*k*.5,y0-1,'#ef4444',2.2);arrow(c,x+bw*k*.5,y0+bh+len(r.pb)+2,x+bw*k*.5,y0+bh+1,'#22c55e',2.2);
 for(let i=0;i<=4;i++){const z=p.d+p.H*i/4,pp=(p.atm?101325:0)+p.rf*G0*z/100,yy=Y(z),l=len(pp);arrow(c,x-l-2,yy,x-1,yy,'#f59e0b',1.6);arrow(c,x+bw*k+l+2,yy,x+bw*k+1,yy,'#f59e0b',1.6)}
 c.fillStyle=C.tx;c.font='600 11px "Be Vietnam Pro",system-ui';c.textAlign='center';c.fillText('p₁',x+bw*k*.5+14,y0-len(r.pt)/2);c.fillText('p₂',x+bw*k*.5+14,y0+bh+len(r.pb)/2+8);
 c.strokeStyle=C.mu;c.setLineDash([3,3]);c.beginPath();c.moveTo(ox+wx*k+4,Y(0));c.lineTo(ox+wx*k+4,y0);c.stroke();c.setLineDash([]);c.textAlign='left';c.fillText('d',Math.min(W-12,ox+wx*k+7),(Y(0)+y0)/2);
 const zc=Y(r.zcp);c.fillStyle='#a855f7';c.beginPath();c.arc(x+bw*k,zc,3.5,0,2*PI);c.fill()};
/* ============ CENTRE OF MASS ============ */
X.polyOf=function(sh,w,h){const t=.35*Math.min(w,h);switch(sh){
 case'rect':return[[0,0],[w,0],[w,h],[0,h]];case'tri':return[[0,0],[w,0],[w/2,h]];case'rtri':return[[0,0],[w,0],[0,h]];
 case'trap':return[[0,0],[w,0],[.75*w,h],[.25*w,h]];case'L':return[[0,0],[w,0],[w,t],[t,t],[t,h],[0,h]]}};
X.centroid=function(P){let A=0,cx=0,cy=0;for(let i=0;i<P.length;i++){const[a,b]=P[i],[c,d]=P[(i+1)%P.length],k=a*d-c*b;A+=k;cx+=(a+c)*k;cy+=(b+d)*k}A/=2;return{A:Math.abs(A),x:cx/(6*A),y:cy/(6*A)}};
X.cm=function(p){const P=X.polyOf(p.sh,p.w,p.h),cm=X.centroid(P),xr=Math.max(...P.map(q=>q[0])),xl=Math.min(...P.map(q=>q[0]));
 const tt=Math.atan((xr-cm.x)/cm.y)*180/PI,ts=Math.atan(p.mu)*180/PI;const th=p.th;let st='stay';if(th>=Math.min(tt,ts))st=ts<tt?'slide':'tip';
 return{P,cm,xl,xr,tip:tt,slide:ts,state:st,balance:cm.x>=xl&&cm.x<=xr}};
X.drawCM=function(cv,p,r){const {c,W,H}=setup(cv,310),C=col(),th=p.th*PI/180,sc=Math.min(W*.72,H*.7)/(Math.max(p.w,p.h)*1.9),ox=W*.5,oy=H*.64;
 c.save();c.translate(ox,oy);c.rotate(th);                     /* slope frame: +x downhill (right), surface at y = 0, up = −y */
 c.fillStyle=C.dk?'rgba(255,255,255,.06)':'rgba(0,0,0,.06)';c.fillRect(-W*2,0,W*4,H*2);c.strokeStyle=C.mu;c.lineWidth=3;c.beginPath();c.moveTo(-W*2,0);c.lineTo(W*2,0);c.stroke();
 const mx=(r.xl+r.xr)/2;c.beginPath();r.P.forEach((q,i)=>{const x=(q[0]-mx)*sc,y=-q[1]*sc;i?c.lineTo(x,y):c.moveTo(x,y)});c.closePath();
 const g=c.createLinearGradient(0,-p.h*sc,0,0);g.addColorStop(0,R4.ramp(.05,C.dk,.85));g.addColorStop(1,R4.ramp(.55,C.dk,.85));c.fillStyle=g;c.fill();c.strokeStyle=R4.ramp(.1,C.dk);c.lineWidth=1.6;c.stroke();
 c.strokeStyle=r.state==='tip'?'#ef4444':'#22c55e';c.lineWidth=5;c.beginPath();c.moveTo((r.xl-mx)*sc,0);c.lineTo((r.xr-mx)*sc,0);c.stroke();
 const lx=(r.cm.x-mx)*sc,ly=-r.cm.y*sc;c.restore();
 const gx=ox+lx*Math.cos(th)-ly*Math.sin(th),gy=oy+lx*Math.sin(th)+ly*Math.cos(th);
 c.setLineDash([5,4]);c.strokeStyle='#ef4444';c.lineWidth=1.5;c.beginPath();c.moveTo(gx,gy);c.lineTo(gx,H-4);c.stroke();c.setLineDash([]);
 arrow(c,gx,gy,gx,gy+40,'#ef4444',2.4);c.fillStyle='#ef4444';c.beginPath();c.arc(gx,gy,5,0,2*PI);c.fill();c.strokeStyle='#fff';c.lineWidth=1.2;c.stroke();
 c.fillStyle=C.tx;c.font='700 12px "Be Vietnam Pro",system-ui';c.textAlign='left';c.fillText('G',gx+8,gy-6);c.fillText('P',gx+8,gy+38);
 c.fillStyle=C.mu;c.font='600 11px "Be Vietnam Pro",system-ui';c.fillText('θ = '+p.th+'°',10,18)};
/* ============ ROLLING RACE ============ */
const BODIES=[['sph','Cầu đặc','Solid sphere',2/5,'#ff8a2b'],['cyl','Trụ đặc','Solid cylinder',1/2,'#ffd23f'],['hsph','Cầu rỗng','Hollow sphere',2/3,'#6ee7a0'],['ring','Vòng (ống)','Ring / hoop',1,'#38bdf8'],['blk','Trượt không ma sát','Frictionless block',0,'#c084fc']];
X.BODIES=BODIES;
X.roll=function(p){const th=p.th*PI/180,s=Math.sin(th),c=Math.cos(th);return BODIES.map(b=>{const k=b[3],mumin=k*Math.tan(th)/(1+k);let a,slip=false;if(k===0)a=G0*s;else if(p.mu>=mumin)a=G0*s/(1+k);else{slip=true;a=G0*(s-p.mu*c);if(a<=0)a=0}
 const t=a>0?Math.sqrt(2*p.L/a):Infinity;return{id:b[0],vi:b[1],en:b[2],k,a,t,v:a>0?Math.sqrt(2*a*p.L):0,mumin,slip,color:b[4]}})};
X.drawRoll=function(cv,p,res,tm){const {c,W,H}=setup(cv,300),C=col(),th=p.th*PI/180,n=res.length,x0=96,x1=W-24,top=46,lh=(H-top-8)/n,R=Math.max(6,Math.min(14,lh*.38));
 /* inset: the slope */c.strokeStyle=C.mu;c.lineWidth=2;c.beginPath();c.moveTo(12,34);c.lineTo(62,34);c.lineTo(12,34-50*Math.tan(th)*.6);c.closePath();c.stroke();c.fillStyle=C.mu;c.font='600 11px "Be Vietnam Pro",system-ui';c.textAlign='left';c.fillText(p.th+'°',44,30);
 c.fillText(T('Vạch xuất phát','Start'),x0-4,14);c.textAlign='right';c.fillText(T('Đích ('+p.L+' m)','Finish ('+p.L+' m)'),x1,14);
 c.strokeStyle='#22c55e';c.setLineDash([4,3]);c.beginPath();c.moveTo(x1,20);c.lineTo(x1,H-4);c.stroke();c.setLineDash([]);
 res.forEach((r,i)=>{const y=top+(i+.5)*lh;c.strokeStyle=C.dk?'rgba(255,255,255,.12)':'rgba(0,0,0,.1)';c.lineWidth=1;c.beginPath();c.moveTo(x0,y+R+1);c.lineTo(x1,y+R+1);c.stroke();
  c.fillStyle=C.tx;c.textAlign='left';c.font='600 11px "Be Vietnam Pro",system-ui';c.fillText(T(r.vi,r.en),6,y+4);
  const s=r.a>0?Math.min(p.L,.5*r.a*tm*tm):0,x=x0+R+(s/p.L)*(x1-x0-2*R),Rs=R;let rot=0;if(r.k>0){const ratio=r.slip?Math.max(0,p.mu*Math.cos(th)/(r.k*Math.max(1e-9,Math.sin(th)-p.mu*Math.cos(th)))):1;rot=(s/p.L)*(x1-x0-2*R)/R*Math.min(1,ratio)}
  c.save();c.translate(x,y);c.rotate(rot);c.fillStyle=r.color;c.strokeStyle=C.tx;c.lineWidth=1.2;
  if(r.id==='blk'){c.fillRect(-R,-R*.8,2*R,1.6*R);c.strokeRect(-R,-R*.8,2*R,1.6*R)}
  else{c.beginPath();c.arc(0,0,R,0,2*PI);if(r.id==='ring'||r.id==='hsph'){c.lineWidth=r.id==='ring'?3.4:2.4;c.strokeStyle=r.color;c.stroke()}else{c.fill();c.stroke()}c.strokeStyle=C.tx;c.lineWidth=1.2;c.beginPath();c.moveTo(0,0);c.lineTo(R,0);c.stroke()}
  c.restore();if(s>=p.L-1e-9&&r.a>0){c.fillStyle='#22c55e';c.textAlign='right';c.fillText(fmt(r.t,3)+' s',x1-R-4,y-R-1)}})};
/* ============ ORBIT / CONICS ============ */
X.orbit=function(p){const e=p.e,pp=1,GM=1,r={};r.type=e<1e-9?'circle':e<.9999?'ellipse':e<=1.0001?'parabola':'hyperbola';
 r.rp=pp/(1+e);r.vp=Math.sqrt(GM*(1+e)/pp);r.esc=Math.sqrt(2*GM/r.rp);
 if(e<1){r.a=pp/(1-e*e);r.b=r.a*Math.sqrt(1-e*e);r.c=r.a*e;r.ra=pp/(1-e);r.va=Math.sqrt(GM*(1-e)/pp);r.T=2*PI*Math.sqrt(r.a**3/GM);r.E=-GM/(2*r.a)}
 else if(e>1){r.a=pp/(e*e-1);r.c=r.a*e;r.E=GM/(2*r.a);r.vinf=Math.sqrt(GM/r.a)}else{r.E=0}
 const ca=Math.cos(p.alpha*PI/180),cb=e*ca;r.beta=cb<=1?Math.acos(cb)*180/PI:NaN;return r};
X.orbPt=function(e,phi){const r=1/(1+e*Math.cos(phi));return[r*Math.cos(phi),r*Math.sin(phi),r]};
X.drawOrbit=function(cv,p,r,st){const {c,W,H}=setup(cv,310),C=col(),e=p.e;
 const ext=e<1?(r.ra||2):4,sc=Math.min(W,H)*.42/Math.max(1,e<1?(r.a*(1+e)):ext*.55);
 const cx=e<1?W/2+ r.c*sc*.0 :W*.3,cy=H/2,fx=e<1?W/2-r.c*sc:cx,fy=cy;   /* focus; ellipse centred on screen */
 const P=(x,y)=>[fx+x*sc,fy-y*sc];
 c.lineWidth=1.6;c.strokeStyle=R4.ramp(.15,C.dk);c.beginPath();let first=1;const lim=e>=1?Math.acos(-1/Math.max(e,1.0001))*.985:PI;
 for(let i=0;i<=360;i++){const phi=e>=1?-lim+2*lim*i/360:2*PI*i/360,q=X.orbPt(e,phi),[x,y]=P(q[0],q[1]);if(e>=1&&(Math.abs(x-fx)>W*2||Math.abs(y-fy)>H*2)){first=1;continue}first?c.moveTo(x,y):c.lineTo(x,y);first=0}c.stroke();
 if(e<1&&e>0){const[f2x,f2y]=P(-2*r.c,0);c.fillStyle=C.mu;c.beginPath();c.arc(f2x,f2y,3,0,2*PI);c.fill();c.fillText('F₂',f2x+6,f2y-6)}
 /* swept wedge (equal areas in equal times) */
 if(st&&st.tr.length>1){c.beginPath();c.moveTo(fx,fy);st.tr.forEach(q=>{const[x,y]=P(q[0],q[1]);c.lineTo(x,y)});c.closePath();c.fillStyle=R4.ramp(.6,C.dk,.22);c.fill()}
 c.fillStyle=R4.ramp(.0,C.dk);c.beginPath();c.arc(fx,fy,6,0,2*PI);c.fill();c.fillStyle=C.tx;c.font='600 11px "Be Vietnam Pro",system-ui';c.fillText('F₁',fx+8,fy-8);
 if(st){const q=X.orbPt(e,st.phi),[x,y]=P(q[0],q[1]);c.fillStyle='#38bdf8';c.beginPath();c.arc(x,y,5,0,2*PI);c.fill();
  /* velocity vector: tangent direction, length ∝ speed (vis-viva) */
  const rr=q[2],v=Math.sqrt(Math.max(0,2/rr-(e<1?1/r.a:e>1?-1/r.a:0))),dphi=1/rr*Math.sqrt(1)/rr*1; /* dφ/dt = h/r², h=1 */
  const vr=e*Math.sin(st.phi)/1,vt=(1+e*Math.cos(st.phi));  /* components in units of sqrt(GM/p): v_r = e sinφ, v_t = 1+e cosφ */
  const vx=vr*Math.cos(st.phi)-vt*Math.sin(st.phi),vy=vr*Math.sin(st.phi)+vt*Math.cos(st.phi);arrow(c,x,y,x+vx*26,y-vy*26,'#22c55e',2)}};
X.orbStep=function(e,st,dt){/* integrate φ with dφ/dt = (1+e cosφ)² (h=1,p=1), RK4 */const f=ph=>Math.pow(1+e*Math.cos(ph),2);let ph=st.phi;const k1=f(ph),k2=f(ph+dt*k1/2),k3=f(ph+dt*k2/2),k4=f(ph+dt*k3);ph+=dt*(k1+2*k2+2*k3+k4)/6;
 if(e>=1){const lim=Math.acos(-1/Math.max(e,1.0001))*.985;if(ph>lim){ph=-lim;st.tr=[]}}else if(ph>PI)ph-=2*PI;st.phi=ph;st.tr.push(X.orbPt(e,ph));if(st.tr.length>26)st.tr.shift()};
/* ============ UI framework ============ */
const sl=(id,vi,en,min,max,step,val,unit)=>({id,vi,en,min,max,step,val,unit});
const LABS=[
 {id:'float',ico:'🧊',vi:'Chìm nổi',en:'Float & sink',sub:['Thể tích hình học quyết định lực đẩy Archimedes','Geometric volume decides the buoyant force'],
  st:{sh:'cube',s:20,rho:600,rf:0},ctl:[{id:'sh',sel:Object.keys(SHAPES).map(k=>[k,SHAPES[k].vi,SHAPES[k].en])},sl('s','Kích thước (cm)','Size (cm)',5,40,1,20,'cm'),sl('rho','Khối lượng riêng vật (kg/m³)','Body density (kg/m³)',100,3000,10,600,'kg/m³'),{id:'rf',sel:FLUIDS.map((f,i)=>[i,f[0]+' ('+f[2]+')',f[1]+' ('+f[2]+')'])}],
  calc:s=>X.float({sh:s.sh,s:s.s,rho:s.rho,rf:FLUIDS[s.rf][2]}),draw:(cv,s,r)=>X.drawFloat(cv,{sh:s.sh,s:s.s},r),
  rows:(s,r)=>[[T('Thể tích V','Volume V'),fmt(r.V*1000,4)+' L'],[T('Khối lượng m = ρV','Mass m = ρV'),fmt(r.m,4)+' kg'],[T('Trọng lực P = mg','Weight P = mg'),fmt(r.W,4)+' N'],[T('Kết luận','Verdict'),r.sink?T('Chìm','Sinks'):Math.abs(r.q-1)<1e-9?T('Lơ lửng','Neutral'):T('Nổi','Floats')],
   [T('Phần chìm','Submerged'),fmt(r.frac*100,4)+' %'],[T('Độ chìm sâu h','Draft h'),fmt(r.h*100,4)+' cm'],[T('Lực đẩy F_A = ρ_l·g·V_chìm','Buoyancy F_A = ρ_f·g·V_sub'),fmt(r.FB,4)+' N'],...(r.sink?[[T('Trọng lượng biểu kiến P − F_A','Apparent weight P − F_A'),fmt(r.app,4)+' N']]:[])],
  why:()=>T('Khối nổi khi ρ_vật < ρ_lỏng, và phần chìm = ρ_vật/ρ_lỏng. Với khối nón hay cầu, "phần chìm" không còn tỉ lệ với độ sâu: phải giải V_chìm(h) = (ρ_vật/ρ_lỏng)·V (bậc 3).','A body floats when ρ_body < ρ_fluid, and the submerged fraction is ρ_body/ρ_fluid. For cones and spheres the fraction is not proportional to depth: solve V_sub(h) = (ρ_body/ρ_fluid)·V (a cubic).'),
  ask:(s,r)=>T(({cube:'Khối lập phương cạnh '+s.s+' cm',cyl:'Khối trụ đứng đường kính và cao '+s.s+' cm',sph:'Khối cầu đường kính '+s.s+' cm',coneD:'Khối nón đỉnh xuống',coneU:'Khối nón đáy xuống'})[s.sh]+' có khối lượng riêng '+s.rho+' kg/m3 thả vào chất lỏng '+FLUIDS[s.rf][2]+' kg/m3. Tính phần chìm và lực đẩy Archimedes',({cube:'A cube with edge '+s.s+' cm',cyl:'An upright cylinder with diameter and height '+s.s+' cm',sph:'A sphere with diameter '+s.s+' cm',coneD:'A cone apex down',coneU:'A cone base down'})[s.sh]+' has density '+s.rho+' kg/m3 and is placed in a liquid of '+FLUIDS[s.rf][2]+' kg/m3. Find the submerged fraction and the buoyant force'),
  chal:[ 'Chỉnh khối lượng riêng để khối nổi với đúng 75% thể tích chìm (±2%).','Tune the density so the body floats with exactly 75% of its volume submerged (±2%).'],ok:(s,r)=>!r.sink&&Math.abs(r.frac-.75)<=.02,
  geo:{view:'atlas',key:'sphere'},phy:{eng:'phy',tab:'lib'}},
 {id:'press',ico:'💧',vi:'Áp suất lên khối',en:'Pressure on a solid',sub:['Áp suất từng mặt → lực đẩy Archimedes xuất hiện thế nào','Face-by-face pressure → where buoyancy comes from'],
  st:{W:20,H:20,d:30,rf:0,atm:0},ctl:[sl('W','Cạnh đáy (cm)','Base side (cm)',5,40,1,20,'cm'),sl('H','Chiều cao (cm)','Height (cm)',5,60,1,20,'cm'),sl('d','Độ sâu mặt trên (cm)','Depth of top face (cm)',0,80,1,30,'cm'),{id:'rf',sel:FLUIDS.map((f,i)=>[i,f[0]+' ('+f[2]+')',f[1]+' ('+f[2]+')'])},{id:'atm',sel:[[0,'Áp suất dư (bỏ khí quyển)','Gauge pressure (no atmosphere)'],[1,'Cộng áp suất khí quyển 101 325 Pa','Add atmosphere 101 325 Pa']]}],
  calc:s=>X.press({W:s.W,H:s.H,d:s.d,rf:FLUIDS[s.rf][2],atm:+s.atm}),draw:(cv,s,r)=>X.drawPress(cv,{W:s.W,H:s.H,d:s.d,rf:FLUIDS[s.rf][2],atm:+s.atm},r),
  rows:(s,r)=>[[T('Áp suất mặt trên p₁ = ρgd','Top pressure p₁ = ρgd'),fmt(r.pt,5)+' Pa'],[T('Áp suất mặt dưới p₂ = ρg(d+H)','Bottom pressure p₂ = ρg(d+H)'),fmt(r.pb,5)+' Pa'],[T('Lực lên mặt trên (xuống)','Force on top (down)'),fmt(r.Ft,5)+' N'],[T('Lực lên mặt dưới (lên)','Force on bottom (up)'),fmt(r.Fb,5)+' N'],
   [T('Hợp lực thẳng đứng F₂ − F₁','Net vertical F₂ − F₁'),fmt(r.net,5)+' N'],[T('So với ρ·g·V (Archimedes)','Compare ρ·g·V (Archimedes)'),fmt(r.FA,5)+' N'],[T('Lực lên mỗi mặt bên','Force on each side face'),fmt(r.Fs,5)+' N'],[T('Điểm đặt áp lực mặt bên (độ sâu)','Centre of pressure of a side (depth)'),fmt(r.zcp*100,4)+' cm'],[T('Hợp lực nằm ngang','Net horizontal force'),'0 N']],
  why:()=>T('Áp suất tăng theo độ sâu (p = ρgh) nên mặt dưới bị đẩy lên mạnh hơn mặt trên bị ép xuống. Hiệu hai lực đúng bằng ρ·g·V: lực đẩy Archimedes. Lực lên hai mặt bên đối nhau triệt tiêu. Áp suất khí quyển cộng như nhau ở mọi mặt nên không đổi hợp lực.','Pressure grows with depth (p = ρgh), so the bottom is pushed up harder than the top is pushed down. The difference is exactly ρ·g·V: the buoyant force. Opposite side forces cancel. Atmospheric pressure adds equally everywhere and changes nothing.'),
  ask:s=>T('Khối hộp đáy vuông cạnh '+s.W+' cm cao '+s.H+' cm, mặt trên cách mặt nước '+s.d+' cm trong '+FLUIDS[s.rf][0].toLowerCase()+'. Tính áp suất và lực lên mặt trên, mặt dưới và lực đẩy Archimedes','A box with a square base of side '+s.W+' cm and height '+s.H+' cm, top face '+s.d+' cm below the surface of '+FLUIDS[s.rf][1].toLowerCase()+'. Find pressures and forces on the top and bottom and the buoyant force'),
  chal:['Đặt độ sâu sao cho áp suất mặt dưới khối đúng 20 kPa (±0,5 kPa), nước, bỏ khí quyển.','Set the depth so the bottom pressure is exactly 20 kPa (±0.5 kPa) in water, no atmosphere.'],ok:(s,r)=>+s.rf===0&&+s.atm===0&&Math.abs(r.pb-20000)<=500,
  geo:{view:'atlas',key:'cuboid'},phy:{eng:'phy',tab:'lib'}},
 {id:'cm',ico:'⚖️',vi:'Trọng tâm & cân bằng',en:'Centre of mass & balance',sub:['Trọng tâm hình học quyết định khi nào vật lật','The geometric centroid decides when a body tips'],
  st:{sh:'rect',w:10,h:16,th:20,mu:.6},ctl:[{id:'sh',sel:[['rect','Hình chữ nhật','Rectangle'],['tri','Tam giác cân','Isosceles triangle'],['rtri','Tam giác vuông','Right triangle'],['trap','Hình thang','Trapezoid'],['L','Chữ L','L-shape']]},sl('w','Rộng đáy (cm)','Base width (cm)',4,30,1,10,'cm'),sl('h','Cao (cm)','Height (cm)',4,30,1,16,'cm'),sl('th','Góc nghiêng θ (°)','Incline θ (°)',0,60,1,20,'°'),sl('mu','Hệ số ma sát μ','Friction μ',.05,1.5,.05,.6,'')],
  calc:s=>X.cm({sh:s.sh,w:s.w,h:s.h,th:s.th,mu:s.mu}),draw:(cv,s,r)=>X.drawCM(cv,s,r),
  rows:(s,r)=>[[T('Diện tích','Area'),fmt(r.cm.A,5)+' cm²'],[T('Trọng tâm G (x; y)','Centroid G (x; y)'),'('+fmt(r.cm.x,4)+'; '+fmt(r.cm.y,4)+') cm'],[T('Chiếu của G nằm trong đáy (θ=0)?','G above the base (θ=0)?'),r.balance?T('Có: đứng vững','Yes: stable'):T('Không: đổ','No: falls')],
   [T('Góc bắt đầu lật: tanθ = (x_phải − x_G)/y_G','Tipping angle: tanθ = (x_right − x_G)/y_G'),fmt(r.tip,4)+'°'],[T('Góc bắt đầu trượt: tanθ = μ','Sliding angle: tanθ = μ'),fmt(r.slide,4)+'°'],[T('Ở θ hiện tại','At the current θ'),r.state==='stay'?T('Đứng yên','Stays put'):r.state==='slide'?T('Trượt (trượt trước khi lật)','Slides (before tipping)'):T('Lật (lật trước khi trượt)','Tips (before sliding)')]],
  why:()=>T('Trọng tâm hình học của hình đồng chất tính bằng công thức đa giác (shoelace). Vật còn đứng vững khi đường thẳng đứng qua trọng tâm còn rơi trong đáy. Trên dốc θ, vật lật khi tanθ > (khoảng cách từ G tới mép dưới theo phương dốc)/(độ cao G), và trượt khi tanθ > μ: cái nào xảy ra ở góc nhỏ hơn thì thắng.','The centroid of a uniform shape comes from the polygon (shoelace) formula. A body stays up while the vertical through G falls inside its base. On a slope θ it tips when tanθ > (distance from G to the lower edge along the slope)/(height of G) and slides when tanθ > μ: whichever happens at the smaller angle wins.'),
  ask:s=>T('Khối chữ nhật rộng '+s.w+' cm cao '+s.h+' cm đặt trên mặt phẳng nghiêng, hệ số ma sát '+s.mu+'. Tìm góc nghiêng để khối bắt đầu lật và bắt đầu trượt','A rectangular block '+s.w+' cm wide and '+s.h+' cm tall sits on an incline, friction coefficient '+s.mu+'. Find the angles at which it begins to tip and to slide'),
  chal:['Với hình chữ nhật, chỉnh kích thước để khối bắt đầu lật ở 30° (±2°). Cần μ đủ lớn để không trượt trước.','With the rectangle, tune the size so it starts to tip at 30° (±2°). Keep μ large enough so it does not slide first.'],ok:(s,r)=>s.sh==='rect'&&Math.abs(r.tip-30)<=2&&r.tip<r.slide,
  geo:{view:'atlas',key:'triangle'},phy:{eng:'phy',tab:'con'}},
 {id:'roll',ico:'🏁',vi:'Cuộc đua lăn',en:'Rolling race',sub:['Hình dạng khối lượng (moment quán tính) quyết định ai về đích trước','The mass distribution (moment of inertia) decides who wins'],
  st:{th:20,L:3,mu:.6},ctl:[sl('th','Góc dốc θ (°)','Slope θ (°)',5,40,1,20,'°'),sl('L','Chiều dài dốc (m)','Slope length (m)',1,5,.1,3,'m'),sl('mu','Hệ số ma sát μ','Friction μ',0,1.2,.05,.6,'')],anim:true,
  calc:s=>X.roll({th:s.th,L:s.L,mu:s.mu}),draw:null,
  rows:(s,r)=>r.slice().sort((a,b)=>a.t-b.t).map(b=>[T(b.vi,b.en)+(b.k?' (k = '+(b.k===.4?'2/5':b.k===.5?'1/2':b.k===1?'1':'2/3')+')':'')+(b.slip?' ⚠':''),isFinite(b.t)?'a = '+fmt(b.a,4)+' m/s² · t = '+fmt(b.t,4)+' s · v = '+fmt(b.v,4)+' m/s':T('không trượt xuống','does not move')]).concat([[T('μ tối thiểu để lăn không trượt: k·tanθ/(1+k)','Min μ for rolling without slip: k·tanθ/(1+k)'),r.filter(b=>b.k).map(b=>fmt(b.mumin,3)).join(' · ')]]),
  why:()=>T('Lăn không trượt: a = g·sinθ/(1+k) với k = I/(mR²). Kết quả không phụ thuộc khối lượng hay bán kính: chỉ phụ thuộc cách khối lượng phân bố (hình dạng). Khối trượt (k = 0) luôn nhanh nhất; vòng rỗng (k = 1) chậm nhất. Nếu μ nhỏ hơn mức tối thiểu, vật vừa trượt vừa lăn với a = g(sinθ − μcosθ) (ma sát trượt).','Rolling without slipping: a = g·sinθ/(1+k) with k = I/(mR²). The result does not depend on mass or radius, only on how mass is distributed (the shape). A sliding block (k = 0) is always fastest; the hoop (k = 1) is slowest. If μ is below the minimum, the body slips while rolling with a = g(sinθ − μcosθ) (kinetic friction).'),
  ask:s=>T('Vòng rỗng (ống) lăn không trượt xuống mặt phẳng nghiêng góc '+s.th+' độ dài '+s.L+' m. Tính gia tốc và thời gian xuống','A hoop rolls without slipping down an incline of '+s.th+' degrees and length '+s.L+' m. Find the acceleration and the time'),
  chal:['Với L = 3 m, chỉnh góc dốc để vòng (ring) xuống dốc trong 2,0 s (±0,1 s). Cần μ đủ để lăn không trượt.','With L = 3 m, set the slope so the ring takes 2.0 s (±0.1 s). Keep μ high enough for pure rolling.'],ok:(s,r)=>{const z=r.find(b=>b.id==='ring');return Math.abs(+s.L-3)<.01&&!z.slip&&Math.abs(z.t-2)<=.1},
  geo:{view:'atlas',key:'cylinder'},phy:{eng:'phy',tab:'con'}},
 {id:'orbit',ico:'🪐',vi:'Conic & quỹ đạo',en:'Conics & orbits',sub:['Mặt cắt nón chính là quỹ đạo dưới lực hấp dẫn','Cone sections are the orbits under gravity'],
  st:{e:.5,alpha:30},ctl:[sl('e','Tâm sai e','Eccentricity e',0,2,.01,.5,''),sl('alpha','Nửa góc ở đỉnh nón α (°)','Cone half-angle α (°)',10,60,1,30,'°')],anim:true,
  calc:s=>X.orbit({e:+s.e,alpha:+s.alpha}),draw:null,
  rows:(s,r)=>{const e=+s.e,o=[[T('Dạng quỹ đạo','Orbit type'),({circle:T('Đường tròn (e = 0)','Circle (e = 0)'),ellipse:T('Elip (0 < e < 1): vật bị buộc','Ellipse (0 < e < 1): bound'),parabola:T('Parabol (e = 1): vừa đủ thoát','Parabola (e = 1): just escapes'),hyperbola:T('Hypebol (e > 1): thoát','Hyperbola (e > 1): escapes')})[r.type]],[T('Cận điểm r_p = p/(1+e)','Periapsis r_p = p/(1+e)'),fmt(r.rp,4)+' p'],[T('Vận tốc ở cận điểm v_p','Speed at periapsis v_p'),fmt(r.vp,4)+' √(GM/p)'],[T('Vận tốc thoát tại r_p','Escape speed at r_p'),fmt(r.esc,4)+' √(GM/p)']];
   if(e<1){o.push([T('Bán trục lớn a = p/(1−e²)','Semi-major a = p/(1−e²)'),fmt(r.a,4)+' p'],[T('Bán trục nhỏ b = a√(1−e²)','Semi-minor b = a√(1−e²)'),fmt(r.b,4)+' p'],[T('Viễn điểm r_a = p/(1−e)','Apoapsis r_a = p/(1−e)'),fmt(r.ra,4)+' p'],[T('Chu kỳ T = 2π√(a³/GM)','Period T = 2π√(a³/GM)'),fmt(r.T,4)+' √(p³/GM)'],[T('Năng lượng ε = −GM/2a','Energy ε = −GM/2a'),fmt(r.E,4)+' GM/p'])}
   else if(e>1)o.push([T('Bán trục thực a = p/(e²−1)','Semi-axis a = p/(e²−1)'),fmt(r.a,4)+' p'],[T('Vận tốc xa vô cực v∞','Speed at infinity v∞'),fmt(r.vinf,4)+' √(GM/p)'],[T('Năng lượng ε > 0','Energy ε > 0'),fmt(r.E,4)+' GM/p']);
   o.push([T('Mặt phẳng cắt nón (α='+s.alpha+'°) hợp trục góc β, e = cosβ/cosα','Plane cutting a cone (α='+s.alpha+'°) at angle β to the axis, e = cosβ/cosα'),isFinite(r.beta)?'β = '+fmt(r.beta,4)+'°':T('không tồn tại (e·cosα > 1)','none (e·cosα > 1)')]);return o},
  why:()=>T('Cắt nón bằng mặt phẳng: vuông góc trục cho đường tròn; nghiêng nhẹ cho elip; song song một đường sinh cho parabol; nghiêng nhiều (cắt cả hai nhánh) cho hypebol. Cùng các đường cong đó là quỹ đạo dưới lực hấp dẫn r = p/(1 + e·cosφ), với tâm sai e = cosβ/cosα. Vật trên elip quét diện tích bằng nhau trong thời gian bằng nhau (Kepler 2).','Cutting a cone with a plane: perpendicular to the axis gives a circle; slightly tilted gives an ellipse; parallel to a generator gives a parabola; steeper (cutting both nappes) gives a hyperbola. The same curves are orbits under gravity, r = p/(1 + e·cosφ), with e = cosβ/cosα. A body on an ellipse sweeps equal areas in equal times (Kepler 2).'),
  ask:s=>T('Quỹ đạo có tâm sai '+s.e+' quanh một thiên thể. Đó là đường conic nào và vận tốc ở cận điểm so với vận tốc thoát ra sao','An orbit has eccentricity '+s.e+' around a body. Which conic is it and how does the periapsis speed compare to escape speed'),
  chal:['Đặt tâm sai để vật có quỹ đạo parabol (e = 1,00): vừa đủ thoát khỏi thiên thể.','Set the eccentricity for a parabolic orbit (e = 1.00): just enough to escape.'],ok:(s,r)=>Math.abs(+s.e-1)<.0051,
  geo:{view:'atlas',key:'ellipse'},phy:{eng:'phy',tab:'uni'}}];

/* ===== new labs: pendulum, projectile, thin lens, lever ===== */
const GS=[[9.81,'Trái Đất (9,81)','Earth (9.81)'],[1.62,'Mặt Trăng (1,62)','Moon (1.62)'],[3.71,'Sao Hỏa (3,71)','Mars (3.71)'],[24.79,'Sao Mộc (24,79)','Jupiter (24.79)']];
const agm=(a,b)=>{for(let i=0;i<30;i++){const c=(a+b)/2;b=Math.sqrt(a*b);a=c;if(Math.abs(a-b)<1e-15)break}return a};
X.pend=s=>{const L=+s.L,a=+s.a*PI/180,g=GS[+s.g][0];const T0=2*PI*Math.sqrt(L/g),Tx=T0/agm(1,Math.cos(a/2));return{T0,Tx,err:(Tx-T0)/Tx*100,h:L*(1-Math.cos(a)),vm:Math.sqrt(2*g*L*(1-Math.cos(a))),arc:L*a,Tm:g*(3-2*Math.cos(a)),g,L,a}};
X.drawPend=(cv,s,r,V)=>{const {c,W,H}=setup(cv,280),k=col();const px=W/2,py=26,sc=Math.min((H-60)/r.L,(W/2-30)/(r.L*Math.max(.2,Math.sin(r.a))));const th=V.pth!=null?V.pth:r.a;
 c.strokeStyle=k.mu;c.setLineDash([4,4]);c.beginPath();c.moveTo(px,py);c.lineTo(px,py+r.L*sc);c.stroke();c.beginPath();c.arc(px,py,r.L*sc,PI/2-r.a,PI/2+r.a);c.stroke();c.setLineDash([]);
 const hy=py+r.L*sc*Math.cos(r.a);c.strokeStyle=R4.ramp(.5,k.dk,.6);c.setLineDash([3,3]);c.beginPath();c.moveTo(px-r.L*sc*Math.sin(r.a)-10,hy);c.lineTo(px+r.L*sc*Math.sin(r.a)+10,hy);c.moveTo(px-30,py+r.L*sc);c.lineTo(px+30,py+r.L*sc);c.stroke();c.setLineDash([]);
 c.fillStyle=k.mu;c.font='12px system-ui';c.fillText('h = '+fmt(r.h*100,3)+' cm',px+r.L*sc*Math.sin(r.a)+12,(hy+py+r.L*sc)/2+4);
 (V.ptr||[]).forEach((q,i,a)=>{c.fillStyle=R4.ramp(i/a.length,k.dk,.12+.5*i/a.length);c.beginPath();c.arc(q[0],q[1],2,0,2*PI);c.fill()});
 const bx=px+r.L*sc*Math.sin(th),by=py+r.L*sc*Math.cos(th);c.lineWidth=2.5;const gr=c.createLinearGradient(px,py,bx,by);gr.addColorStop(0,R4.ramp(.9,k.dk,1));gr.addColorStop(1,R4.ramp(.1,k.dk,1));c.strokeStyle=gr;c.beginPath();c.moveTo(px,py);c.lineTo(bx,by);c.stroke();
 c.fillStyle=k.tx;c.fillRect(px-40,py-4,80,4);const bg=c.createRadialGradient(bx-4,by-4,2,bx,by,14);bg.addColorStop(0,'#fff3c4');bg.addColorStop(1,R4.ramp(.05,k.dk,1));c.fillStyle=bg;c.shadowColor=R4.ramp(.1,k.dk,.8);c.shadowBlur=k.dk?18:6;c.beginPath();c.arc(bx,by,12,0,2*PI);c.fill();c.shadowBlur=0;
 V.ptr=V.ptr||[];if(V.playing){V.ptr.push([bx,by]);if(V.ptr.length>70)V.ptr.shift()}};
X.pendTick=(V,dt,s)=>{const r=X.pend(s);if(V.pth==null){V.pth=r.a;V.pw=0}const f=(th)=>-r.g/r.L*Math.sin(th);const n=8,h=dt/n;for(let i=0;i<n;i++){const k1=V.pw,l1=f(V.pth),k2=V.pw+h/2*l1,l2=f(V.pth+h/2*k1),k3=V.pw+h/2*l2,l3=f(V.pth+h/2*k2),k4=V.pw+h*l3,l4=f(V.pth+h*k3);V.pth+=h/6*(k1+2*k2+2*k3+k4);V.pw+=h/6*(l1+2*l2+2*l3+l4)}};
X.proj=s=>{const v=+s.v,a=+s.a*PI/180,h0=+s.h,g=GS[+s.g][0],vx=v*Math.cos(a),vy=v*Math.sin(a),t=(vy+Math.sqrt(vy*vy+2*g*h0))/g,R=vx*t,Hm=h0+vy*vy/(2*g),p=vx*vx/(2*g),xv=vx*vy/g;const cl=x=>Math.abs(x)<1e-9?0:x;return{vx,vy,t,R,Hm,p,fx:cl(xv),fy:cl(Hm-p),dir:h0+v*v/(2*g),g,h0,a,v,vimp:Math.sqrt(v*v+2*g*h0)}};
X.drawProj=(cv,s,r,V)=>{const {c,W,H}=setup(cv,280),k=col();const xm=Math.max(r.R,10)*1.08,ym=Math.max(r.dir,r.Hm,2)*1.12,sc=Math.min((W-40)/xm,(H-40)/ym),X0=26,Y0=H-22,P=(x,y)=>[X0+x*sc,Y0-y*sc];
 c.strokeStyle=k.mu;c.lineWidth=1;c.beginPath();c.moveTo(X0,Y0);c.lineTo(W-8,Y0);c.stroke();
 const dy=P(0,r.dir)[1];c.setLineDash([5,4]);c.strokeStyle=R4.ramp(.9,k.dk,.7);c.beginPath();c.moveTo(X0,dy);c.lineTo(W-8,dy);c.stroke();c.setLineDash([]);c.fillStyle=R4.ramp(.9,k.dk,.95);c.font='11px system-ui';c.fillText(T('đường chuẩn y = h₀ + v₀²/2g','directrix y = h₀ + v₀²/2g'),X0+4,dy-4);
 if(r.h0>0){const b=P(0,0),tp=P(0,r.h0);c.fillStyle=k.dk?'rgba(255,255,255,.08)':'rgba(0,0,0,.06)';c.fillRect(b[0]-14,tp[1],14,b[1]-tp[1])}
 c.lineWidth=2.4;c.beginPath();for(let i=0;i<=80;i++){const t=r.t*i/80,q=P(r.vx*t,r.h0+r.vy*t-r.g*t*t/2);i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1])}const gr=c.createLinearGradient(X0,0,P(r.R,0)[0],0);gr.addColorStop(0,R4.ramp(0,k.dk,1));gr.addColorStop(.5,R4.ramp(.5,k.dk,1));gr.addColorStop(1,R4.ramp(1,k.dk,1));c.strokeStyle=gr;c.stroke();
 const F=P(r.fx,r.fy);c.fillStyle=R4.ramp(.5,k.dk,1);c.beginPath();c.arc(F[0],F[1],3.5,0,2*PI);c.fill();c.fillText(T('tiêu điểm','focus'),F[0]+6,F[1]+4);
 const tg=P(+s.tx,0);c.strokeStyle='#ff5d5d';c.lineWidth=2;c.beginPath();c.arc(tg[0],tg[1],6,0,2*PI);c.stroke();c.beginPath();c.arc(tg[0],tg[1],2,0,2*PI);c.stroke();
 const tt=Math.min(V.tm||0,r.t),bq=P(r.vx*tt,r.h0+r.vy*tt-r.g*tt*tt/2);c.fillStyle='#fff3c4';c.shadowColor=R4.ramp(.1,k.dk,1);c.shadowBlur=14;c.beginPath();c.arc(bq[0],bq[1],6,0,2*PI);c.fill();c.shadowBlur=0;
 c.fillStyle=k.tx;c.font='12px system-ui';c.fillText('R = '+fmt(r.R,4)+' m',P(r.R,0)[0]-40,Y0+16)};
X.lens=s=>{const f=(+s.type?-1:1)*+s.f,d=+s.d,h=+s.h;if(Math.abs(d-f)<1e-9)return{inf:true,f,d,h};const dp=d*f/(d-f),k=-dp/d;return{f,d,dp,k,h,hp:k*h,real:dp>0,inf:false}};
X.drawLens=(cv,s,r)=>{const {c,W,H}=setup(cv,260),k=col();const span=Math.max(Math.abs(r.d),Math.abs(r.f)*2.2,r.inf?0:Math.min(Math.abs(r.dp),200))*1.15,sc=(W/2-14)/span,cx=W/2,cy=H/2+8,X=x=>cx+x*sc,hs=Math.min(60/Math.max(r.h,Math.abs(r.hp||0),1),18);
 c.strokeStyle=k.mu;c.lineWidth=1;c.beginPath();c.moveTo(0,cy);c.lineTo(W,cy);c.stroke();
 c.strokeStyle=R4.ramp(.5,k.dk,.9);c.lineWidth=3;c.beginPath();c.moveTo(cx,cy-95);c.lineTo(cx,cy+95);c.stroke();c.lineWidth=2;const tip=r.f>0?1:-1;[[cy-95,-1],[cy+95,1]].forEach(([y,sg])=>{c.beginPath();c.moveTo(cx-7,y-sg*tip*8);c.lineTo(cx,y);c.lineTo(cx+7,y-sg*tip*8);c.stroke()});
 [[r.f,'F′'],[-r.f,'F']].forEach(([x,l])=>{c.fillStyle=k.tx;c.beginPath();c.arc(X(x),cy,3,0,2*PI);c.fill();c.font='12px system-ui';c.fillText(l,X(x)-4,cy+16)});
 const ob=[X(-r.d),cy-r.h*hs];const ar=(x,y1,y2,col_,dash)=>{c.setLineDash(dash?[4,3]:[]);arrow(c,x,y1,x,y2,col_,2.5);c.setLineDash([])};ar(ob[0],cy,ob[1],k.tx);
 if(r.inf){c.fillStyle=k.mu;c.fillText(T('Ảnh ở vô cực','Image at infinity'),cx+10,cy-100);return}
 const im=[X(r.dp),cy-r.hp*hs];const ray=(pts,dash,al)=>{c.strokeStyle=R4.ramp(.15,k.dk,al||.95);c.lineWidth=1.4;c.setLineDash(dash?[4,3]:[]);c.beginPath();pts.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.stroke();c.setLineDash([])};
 const ext=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
 /* ray 1: parallel then through F' */ const p1=[cx,ob[1]],f2=[X(r.f),cy];ray([ob,p1,ext(p1,f2,r.f>0?3:-3)]);if(!r.real||r.f<0)ray([p1,im],true,.6);
 /* ray 2: through centre */ ray([ob,ext(ob,[cx,cy],2.6)]);if(!r.real)ray([[cx,cy],im],true,.6);
 ar(im[0],cy,im[1],R4.ramp(.85,k.dk,1),!r.real)};
X.lever=s=>{const g=9.81,M1=+s.m1*g*+s.d1,M2=+s.m2*g*+s.d2,net=M2-M1;return{M1,M2,net,need:+s.m1*+s.d1/+s.m2,ang:Math.max(-18,Math.min(18,net*2))*PI/180}};
X.drawLever=(cv,s,r)=>{const {c,W,H}=setup(cv,240),k=col();const cx=W/2,cy=H/2+10,sc=(W/2-40)/2.2,a=r.ang;const P=x=>[cx+x*sc*Math.cos(a),cy+x*sc*Math.sin(a)];
 c.fillStyle=k.mu;c.beginPath();c.moveTo(cx,cy+2);c.lineTo(cx-18,cy+40);c.lineTo(cx+18,cy+40);c.closePath();c.fill();
 const L=P(-2.2),Rr=P(2.2);const gr=c.createLinearGradient(L[0],L[1],Rr[0],Rr[1]);gr.addColorStop(0,R4.ramp(0,k.dk,1));gr.addColorStop(.5,R4.ramp(.5,k.dk,1));gr.addColorStop(1,R4.ramp(1,k.dk,1));c.strokeStyle=gr;c.lineWidth=6;c.lineCap='round';c.beginPath();c.moveTo(L[0],L[1]);c.lineTo(Rr[0],Rr[1]);c.stroke();
 for(let i=-2;i<=2;i+=.5){const q=P(i);c.fillStyle=k.mu;c.fillRect(q[0]-.5,q[1]-6,1,4)}
 const box=(x,m,col_)=>{const q=P(x),sz=10+Math.sqrt(m)*7;c.fillStyle=col_;c.shadowColor=col_;c.shadowBlur=k.dk?12:0;c.fillRect(q[0]-sz/2,q[1]-sz-3,sz,sz);c.shadowBlur=0;c.fillStyle=k.tx;c.font='12px system-ui';c.fillText(m+' kg',q[0]-14,q[1]-sz-8)};
 box(-+s.d1,+s.m1,R4.ramp(.05,k.dk,1));box(+s.d2,+s.m2,R4.ramp(.95,k.dk,1));c.fillStyle=k.tx;c.fillText(Math.abs(r.net)<.05?T('⚖ Cân bằng','⚖ Balanced'):(r.net>0?T('Lệch phải','Tips right'):T('Lệch trái','Tips left')),cx-34,22)};
LABS.push(
 {id:'pend',ico:'🕰️',vi:'Con lắc & cung tròn',en:'Pendulum & arcs',sub:['Quỹ đạo là cung tròn; chu kì đúng cần tích phân elliptic','The bob moves on a circular arc; the exact period needs an elliptic integral'],anim:true,
  st:{L:1,a:20,g:0},ctl:[sl('L','Chiều dài l (m)','Length l (m)',.2,3,.01,1,'m'),sl('a','Biên độ góc α₀ (°)','Amplitude α₀ (°)',2,85,1,20,'°'),{id:'g',sel:GS.map((x,i)=>[i,x[1],x[2]])}],
  calc:s=>X.pend(s),draw:(cv,s,r,V)=>X.drawPend(cv,s,r,V),tick:(V,dt,s)=>X.pendTick(V,dt,s),reset:V=>{V.pth=null;V.ptr=[]},
  rows:(s,r)=>[[T('Chu kì dao động nhỏ T₀ = 2π√(l/g)','Small-angle period T₀ = 2π√(l/g)'),fmt(r.T0,5)+' s'],[T('Chu kì chính xác T = T₀/AGM(1, cos(α₀/2))','Exact period T = T₀/AGM(1, cos(α₀/2))'),fmt(r.Tx,5)+' s'],[T('Sai số của công thức gần đúng','Error of the small-angle formula'),fmt(r.err,3)+' %'],[T('Độ cao cực đại h = l(1 − cos α₀)','Max height h = l(1 − cos α₀)'),fmt(r.h*100,4)+' cm'],[T('Độ dài cung biên s = l·α₀','Arc to the turning point s = l·α₀'),fmt(r.arc*100,4)+' cm'],[T('Tốc độ cực đại √(2gh)','Max speed √(2gh)'),fmt(r.vm,4)+' m/s'],[T('Lực căng cực đại / m = g(3 − 2cos α₀)','Max tension / m = g(3 − 2cos α₀)'),fmt(r.Tm,4)+' N/kg']],
  why:()=>T('Vật nặng chạy trên cung tròn bán kính l, nên độ cao h = l(1 − cos α) là hình học thuần. Công thức T = 2π√(l/g) chỉ đúng khi góc nhỏ (sin α ≈ α); với góc lớn, chu kì dài hơn và tính chính xác bằng trung bình cộng – nhân (AGM), một thuật toán hội tụ rất nhanh.','The bob runs on a circle of radius l, so the height h = l(1 − cos α) is pure geometry. T = 2π√(l/g) holds only for small angles (sin α ≈ α); at large angles the period is longer and is computed exactly with the arithmetic–geometric mean (AGM), which converges very fast.'),
  ask:s=>T('Con lắc đơn dài '+s.L+' m, biên độ góc '+s.a+' độ, g = '+GS[+s.g][0]+' m/s2. Tính chu kì dao động','A simple pendulum '+s.L+' m long swings with amplitude '+s.a+' degrees, g = '+GS[+s.g][0]+' m/s2. Find the period'),
  chal:['Làm "con lắc giây" trên Trái Đất: chu kì chính xác 2,000 s (±0,005 s) với biên độ 5°.','Build a "seconds pendulum" on Earth: exact period 2.000 s (±0.005 s) at a 5° amplitude.'],ok:(s,r)=>+s.g===0&&Math.abs(+s.a-5)<.5&&Math.abs(r.Tx-2)<=.005,
  geo:{view:'atlas',key:'circle'},phy:{eng:'phy',tab:'lib'}},
 {id:'proj',ico:'🎯',vi:'Ném xiên & parabol',en:'Projectiles & parabolas',sub:['Quỹ đạo là parabol có tiêu điểm và đường chuẩn','The path is a parabola with a focus and a directrix'],anim:true,
  st:{v:18,a:45,h:0,g:0,tx:30},ctl:[sl('v','Vận tốc ban đầu v₀ (m/s)','Launch speed v₀ (m/s)',2,40,.5,18,'m/s'),sl('a','Góc ném α (°)','Launch angle α (°)',0,90,1,45,'°'),sl('h','Độ cao ban đầu h₀ (m)','Launch height h₀ (m)',0,30,.5,0,'m'),{id:'g',sel:GS.map((x,i)=>[i,x[1],x[2]])},sl('tx','Bia cách (m)','Target at (m)',5,80,1,30,'m')],
  calc:s=>X.proj(s),draw:(cv,s,r,V)=>X.drawProj(cv,s,r,V),tick:(V,dt,s)=>{V.tm=(V.tm||0)+dt;const r=X.proj(s);if(V.tm>r.t+.4){V.tm=r.t;V.playing=false}},reset:V=>{V.tm=0},
  rows:(s,r)=>[[T('Thời gian bay','Flight time'),fmt(r.t,4)+' s'],[T('Tầm xa R','Range R'),fmt(r.R,4)+' m'],[T('Độ cao cực đại H','Max height H'),fmt(r.Hm,4)+' m'],[T('Tiêu cự parabol p = vₓ²/2g','Focal length p = vₓ²/2g'),fmt(r.p,4)+' m'],[T('Tiêu điểm','Focus'),'('+fmt(r.fx,4)+'; '+fmt(r.fy,4)+') m'],[T('Đường chuẩn y = h₀ + v₀²/2g','Directrix y = h₀ + v₀²/2g'),fmt(r.dir,4)+' m'],[T('Tốc độ chạm đất √(v₀² + 2gh₀)','Impact speed √(v₀² + 2gh₀)'),fmt(r.vimp,4)+' m/s'],[T('Trúng bia?','Hit the target?'),Math.abs(r.R-s.tx)<=.5?T('Trúng 🎯','Hit 🎯'):T('Lệch ','Off by ')+fmt(r.R-s.tx,3)+' m']],
  why:()=>T('Quỹ đạo y = h₀ + x·tanα − g·x²/(2v₀²cos²α) là một parabol. Đường chuẩn của nó luôn ở độ cao h₀ + v₀²/(2g) cho mọi góc ném: đó chính là độ cao mà vật đạt được nếu ném thẳng đứng, nhờ bảo toàn năng lượng. Khoảng cách từ vật tới tiêu điểm bằng khoảng cách tới đường chuẩn.','The path y = h₀ + x·tanα − g·x²/(2v₀²cos²α) is a parabola. Its directrix sits at height h₀ + v₀²/(2g) for every launch angle: the height reached when thrown straight up, by energy conservation. The distance from the body to the focus equals its distance to the directrix.'),
  ask:s=>T('Một vật được ném xiên góc '+s.a+' độ với vận tốc '+s.v+' m/s từ độ cao '+s.h+' m, g = '+GS[+s.g][0]+' m/s2. Tính tầm xa và độ cao cực đại','A body is launched at '+s.a+' degrees with speed '+s.v+' m/s from a height of '+s.h+' m, g = '+GS[+s.g][0]+' m/s2. Find the range and the maximum height'),
  chal:['Trên Trái Đất, ném từ mặt đất trúng bia 30 m (±0,5 m) với vận tốc nhỏ nhất có thể (≤ 17,4 m/s).','On Earth, from ground level, hit the 30 m target (±0.5 m) with the smallest possible speed (≤ 17.4 m/s).'],ok:(s,r)=>+s.g===0&&+s.h===0&&+s.tx===30&&Math.abs(r.R-30)<=.5&&+s.v<=17.4,
  geo:{view:'atlas',key:'ellipse'},phy:{eng:'phy',tab:'lib'}},
 {id:'lens',ico:'🔍',vi:'Thấu kính & tam giác đồng dạng',en:'Lenses & similar triangles',sub:['Dựng ảnh bằng tia sáng = hai cặp tam giác đồng dạng','Ray diagrams are two pairs of similar triangles'],
  st:{type:0,f:10,d:30,h:3},ctl:[{id:'type',sel:[[0,'Thấu kính hội tụ','Converging lens'],[1,'Thấu kính phân kì','Diverging lens']]},sl('f','Tiêu cự |f| (cm)','Focal length |f| (cm)',3,30,1,10,'cm'),sl('d','Khoảng cách vật d (cm)','Object distance d (cm)',2,80,1,30,'cm'),sl('h','Chiều cao vật (cm)','Object height (cm)',1,6,.5,3,'cm')],
  calc:s=>X.lens(s),draw:(cv,s,r)=>X.drawLens(cv,s,r),
  rows:(s,r)=>r.inf?[[T('Vật tại tiêu điểm','Object at the focus'),T('Ảnh ở vô cực','Image at infinity')]]:[[T("Vị trí ảnh d' = d·f/(d − f)","Image distance d' = d·f/(d − f)"),fmt(r.dp,4)+' cm'],[T("Số phóng đại k = −d'/d","Magnification k = −d'/d"),fmt(r.k,4)],[T('Chiều cao ảnh','Image height'),fmt(Math.abs(r.hp),4)+' cm'],[T('Tính chất','Nature'),(r.real?T('thật','real'):T('ảo','virtual'))+', '+(r.k<0?T('ngược chiều','inverted'):T('cùng chiều','upright'))+', '+(Math.abs(r.k)>1?T('lớn hơn vật','enlarged'):T('nhỏ hơn vật','reduced'))]],
  why:()=>T('Tia qua quang tâm đi thẳng: tam giác vật và tam giác ảnh đồng dạng cho h′/h = d′/d. Tia song song trục ló qua tiêu điểm F′: cặp tam giác thứ hai cho h′/h = (d′ − f)/f. Cho hai tỉ số bằng nhau là ra 1/f = 1/d + 1/d′.','The ray through the centre goes straight: the object and image triangles are similar, h′/h = d′/d. The ray parallel to the axis exits through F′: a second similar pair gives h′/h = (d′ − f)/f. Equate them and you get 1/f = 1/d + 1/d′.'),
  ask:s=>T('Thấu kính '+(+s.type?'phân kì':'hội tụ')+' có tiêu cự '+s.f+' cm, vật cách thấu kính '+s.d+' cm, cao '+s.h+' cm. Xác định vị trí, tính chất và chiều cao ảnh',(+s.type?'A diverging':'A converging')+' lens has focal length '+s.f+' cm, object distance '+s.d+' cm, height '+s.h+' cm. Find the image position, nature and height').replace(/vat cach/,'vật cách'),
  chal:['Với thấu kính hội tụ, tạo ảnh thật cao gấp đôi vật (k = −2 ± 0,05).','With the converging lens, make a real image twice the object’s size (k = −2 ± 0.05).'],ok:(s,r)=>!r.inf&&+s.type===0&&Math.abs(r.k+2)<=.05,
  geo:{view:'atlas',key:'triangle'},phy:{eng:'phy',tab:'lib'}},
 {id:'lever',ico:'⚖',vi:'Đòn bẩy & mômen',en:'Levers & moments',sub:['Cân bằng khi tích lực × khoảng cách hai bên bằng nhau','Balanced when force × distance matches on both sides'],
  st:{m1:3,d1:1,m2:2,d2:1},ctl:[sl('m1','Khối lượng trái (kg)','Left mass (kg)',.5,10,.5,3,'kg'),sl('d1','Cách điểm tựa (m)','Distance (m)',.1,2.2,.05,1,'m'),sl('m2','Khối lượng phải (kg)','Right mass (kg)',.5,10,.5,2,'kg'),sl('d2','Cách điểm tựa (m)','Distance (m)',.1,2.2,.05,1,'m')],
  calc:s=>X.lever(s),draw:(cv,s,r)=>X.drawLever(cv,s,r),
  rows:(s,r)=>[[T('Mômen trái M₁ = m₁·g·d₁','Left moment M₁ = m₁·g·d₁'),fmt(r.M1,4)+' N·m'],[T('Mômen phải M₂ = m₂·g·d₂','Right moment M₂ = m₂·g·d₂'),fmt(r.M2,4)+' N·m'],[T('Chênh lệch','Net moment'),fmt(r.net,4)+' N·m'],[T('d₂ để cân bằng = m₁·d₁/m₂','d₂ for balance = m₁·d₁/m₂'),fmt(r.need,4)+' m']],
  why:()=>T('Mômen lực là lực nhân cánh tay đòn (khoảng cách vuông góc tới điểm tựa). Thanh cân bằng khi tổng mômen hai bên bằng nhau: đó cũng là lý do trọng tâm của hệ nằm đúng trên điểm tựa.','A moment is force times lever arm (perpendicular distance to the pivot). The beam balances when the moments on both sides match: which is also why the system’s centre of mass sits right above the pivot.'),
  ask:s=>T('Đòn bẩy: vật '+s.m1+' kg cách điểm tựa '+s.d1+' m, vật '+s.m2+' kg cách điểm tựa '+s.d2+' m. Đòn bẩy có cân bằng không','Lever: a '+s.m1+' kg mass '+s.d1+' m from the pivot and a '+s.m2+' kg mass '+s.d2+' m from it. Is it balanced'),
  chal:['Giữ trái 3 kg cách 1 m, phải 2 kg: tìm d₂ để cân bằng (|ΔM| < 0,05 N·m).','Keep 3 kg at 1 m on the left and 2 kg on the right: find d₂ for balance (|ΔM| < 0.05 N·m).'],ok:(s,r)=>+s.m1===3&&+s.d1===1&&+s.m2===2&&Math.abs(r.net)<.05,
  geo:{view:'atlas',key:'segment'},phy:{eng:'phy',tab:'lib'}});

X.LABS=LABS;
/* ---- view ---- */
let root,cur=null,ste={},V={t:0,run:false,raf:0,orb:{phi:0,tr:[]},tm:0,playing:false,moves:0};
const today=()=>VN.dkey();
function init(el){root=el;el.innerHTML='<div class="wrap"><div class="h2">'+'<span id="xlT"></span></div><div class="grid g3" id="xlG"></div><div id="xlB"></div></div>';
 $('#xlG').onclick=e=>{const b=e.target.closest('[data-lab]');if(b)open(b.dataset.lab)}}
function render(){if(!root)return;$('#xlT').textContent=T('Phòng lab liên ngành: Hình học × Vật lý','Cross-lab: Geometry × Physics');
 $('#xlG').innerHTML=LABS.map(l=>'<button class="card" data-lab="'+l.id+'" style="margin:0;text-align:left;'+(cur&&cur.id===l.id?'outline:2px solid var(--c1)':'')+'"><div style="font-size:26px">'+l.ico+'</div><b>'+esc(T(l.vi,l.en))+'</b><div class="mu" style="font-size:12.5px">'+esc(T(l.sub[0],l.sub[1]))+'</div></button>').join('');
 if(cur)build()}
function show(p){render();if(p&&p.lab)open(p.lab);else if(!cur)open('float');else resume()}
function hide(){stop()}
function open(id){stop();cur=LABS.find(l=>l.id===id);ste=Object.assign({},cur.st);V.moves=0;V.orb={phi:0,tr:[]};V.tm=0;V.playing=false;V.pth=null;V.ptr=[];render();VN.bump('lab',0);try{$('#xlB').scrollIntoView({block:'nearest'})}catch(e){}}
function ctlHtml(){return cur.ctl.map(c=>c.sel?'<label>'+(c.id==='sh'?T('Hình dạng','Shape'):c.id==='rf'?T('Chất lỏng','Fluid'):c.id==='atm'?T('Khí quyển','Atmosphere'):'')+'<br><select data-c="'+c.id+'">'+c.sel.map(o=>'<option value="'+o[0]+'"'+(String(ste[c.id])===String(o[0])?' selected':'')+'>'+esc(T(o[1],o[2]))+'</option>').join('')+'</select></label>':'<label>'+esc(T(c.vi,c.en))+': <b class="mono" data-o="'+c.id+'">'+ste[c.id]+'</b> '+(c.unit||'')+'<br><input type="range" data-c="'+c.id+'" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'" value="'+ste[c.id]+'"></label>').join('')}
function build(){const l=cur,sel=ste;
 $('#xlB').innerHTML='<div class="xl" style="margin-top:12px"><div><div class="card" style="padding:8px"><canvas class="cv" id="xlC"></canvas>'+(l.anim?'<div class="row" style="padding:8px 4px 0"><button class="btn" id="xlP">▶ '+T('Chạy','Run')+'</button><button class="btn g" id="xlR">↺</button></div>':'')+'</div><div class="card"><h3>'+T('Kết quả (tính chính xác)','Results (exact)')+'</h3><div id="xlO"></div></div></div>'+
  '<div><div class="card"><h3>'+esc(T(l.vi,l.en))+'</h3><div class="grid" style="gap:10px">'+ctlHtml()+'</div></div><div class="card"><h3>💡 '+T('Vì sao?','Why?')+'</h3><div>'+esc(l.why())+'</div><div class="links"><button class="chip" id="xlGeo">△ '+T('Hình học liên quan','Related geometry')+'</button><button class="chip" id="xlPhy">⚛ '+T('Vật lý liên quan','Related physics')+'</button></div></div>'+
  '<div class="card" id="xlCh"><h3>🎯 '+T('Thử thách','Challenge')+'</h3><div>'+esc(T(l.chal[0],l.chal[1]))+'</div><div id="xlOk" class="mu" style="margin-top:6px"></div><div class="row" style="margin-top:8px"><button class="btn g" id="xlAsk">🧠 '+T('Giải & giải thích bằng gia sư','Solve & explain with the tutor')+'</button></div></div></div></div>';
 const c=$('#xlC');
 $('#xlB').oninput=e=>{const t=e.target;if(!t.dataset.c)return;const k=t.dataset.c;ste[k]=t.tagName==='SELECT'?(isNaN(+t.value)||t.value===''?t.value:+t.value):+t.value;const o=$('[data-o="'+k+'"]');if(o)o.textContent=t.value;V.moves++;if(cur.reset&&k!=='tx')cur.reset(V);if(V.moves===4){VN.bump('lab',1);VN.xp(3,'lab')}upd()};
 $('#xlB').onchange=$('#xlB').oninput;
 if(l.anim){$('#xlP').onclick=()=>{V.playing=!V.playing;if(V.playing&&l.id==='roll'&&V.tm>=maxT())V.tm=0;$('#xlP').textContent=(V.playing?'⏸ ':'▶ ')+(V.playing?T('Tạm dừng','Pause'):T('Chạy','Run'));start()};$('#xlR').onclick=()=>{V.tm=0;V.orb={phi:0,tr:[]};if(l.reset)l.reset(V);upd()}}
 $('#xlGeo').onclick=()=>VN.open(l.geo);$('#xlPhy').onclick=()=>VN.open(l.phy);
 $('#xlAsk').onclick=()=>VN.go('solve',{q:l.ask(ste,l.calc(ste)),run:1});
 upd();if(l.anim)start()}
function maxT(){const r0=cur.calc(ste);if(!Array.isArray(r0))return 3;const r=r0.filter(b=>isFinite(b.t));return r.length?Math.max(...r.map(b=>b.t))+.3:3}
function upd(){const l=cur;if(!l)return;let r;try{r=l.calc(ste)}catch(e){console.error(e);return}
 $('#xlO').innerHTML=l.rows(ste,r).map(x=>'<div class="kv"><span>'+esc(x[0])+'</span><b class="mono">'+esc(x[1])+'</b></div>').join('');
 const ok=l.ok(ste,r);$('#xlOk').innerHTML=ok?'<b class="ok">✓ '+T('Đạt!','Done!')+'</b>':T('Chưa đạt.','Not yet.');
 if(ok&&S.labs[l.id+'_d']!==today()){S.labs[l.id+'_d']=today();VN.save();VN.xp(15,'chal');VN.bump('lab',1);VN.toast('🎯 '+T('Hoàn thành thử thách','Challenge complete')+'  +15 XP')}
 paint(r)}
function paint(r){const l=cur,c=$('#xlC');if(!c||!l)return;
 if(l.id==='roll')X.drawRoll(c,{th:ste.th,L:ste.L,mu:ste.mu},r,V.tm);
 else if(l.id==='orbit')X.drawOrbit(c,{e:+ste.e},r,V.orb);
 else l.draw(c,ste,r,V)}
function start(){if(V.raf)return;let last=0;const f=ts=>{V.raf=requestAnimationFrame(f);if(VN.cur!=='lab'||!cur||!cur.anim){return}const dt=Math.min(.05,(ts-(last||ts))/1000);last=ts;
  if(V.playing&&cur.tick){cur.tick(V,dt,ste);if(!V.playing){const b=$('#xlP');b&&(b.textContent='▶ '+T('Chạy','Run'))}}else if(V.playing){if(cur.id==='roll'){V.tm+=dt;if(V.tm>maxT()){V.tm=maxT();V.playing=false;const b=$('#xlP');b&&(b.textContent='▶ '+T('Chạy','Run'))}}else if(cur.id==='orbit'){const e=+ste.e;X.orbStep(e,V.orb,dt*(e<1?.9:.5)*1.2)}}
  else if(cur.id==='orbit'&&!V.playing){/* idle: draw static */}
  paint(cur.calc(ste))};V.raf=requestAnimationFrame(f)}
function stop(){if(V.raf){cancelAnimationFrame(V.raf);V.raf=0}}
function resume(){if(cur&&cur.anim)start();if(cur)upd()}
VN.on('theme',()=>cur&&VN.cur==='lab'&&upd());
VN.views.lab={init,show,render,hide};
})();
