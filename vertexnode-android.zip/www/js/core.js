/* VertexNode core: store, i18n, theme, router, engine host (iframe + postMessage RPC), XP/quests. No network. */
(function(){
'use strict';
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const KEY='vn2';
const DEF=()=>({lg:'',theme:'auto',age:2,xp:0,streak:0,days:0,last:'',nodes:{},qd:'',ql:[],hist:[],methods:{},gk:'',geoLast:0,phyLast:0,labs:{},stat:{},voice:1,onb:0});
let S=DEF();
try{const j=JSON.parse(localStorage.getItem(KEY)||'null');if(j&&typeof j==='object')Object.assign(S,j)}catch(e){}
if(!S.lg)S.lg=((navigator.language||'vi').slice(0,2)==='vi')?'vi':'en';
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const VN=window.VN={S,$,$$,save,views:{},eng:{},listeners:{}};
VN.T=(vi,en)=>S.lg==='en'?en:vi;
VN.esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
VN.fold=s=>String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
VN.fmt=(x,d)=>{if(!isFinite(x))return'—';d=d==null?4:d;let v=+(+x).toPrecision(d+1);let r=Math.abs(v)>=1e7||(Math.abs(v)<1e-3&&v!==0)?v.toExponential(2):String(+v.toFixed(d));r=r.replace('-','−');return S.lg==='en'?r:r.replace('.',',')};
VN.on=(e,f)=>{(VN.listeners[e]=VN.listeners[e]||[]).push(f)};
VN.emit=(e,d)=>{(VN.listeners[e]||[]).forEach(f=>{try{f(d)}catch(x){console.error(x)}})};
const lvOf=xp=>Math.floor(Math.sqrt(Math.max(0,xp)/25))+1;VN.lvOf=lvOf;
VN.rank=()=>{const L=lvOf(S.xp);return Math.min(4,Math.floor((L-1)/4))};
VN.RANKS=[['Điểm','Point'],['Đường','Line'],['Mặt phẳng','Plane'],['Khối','Solid'],['Siêu khối','Hypercube']];

/* ---- toast ---- */
let tt;VN.toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),2200)};

/* ---- day / streak / XP ---- */
const dkey=d=>{d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};VN.dkey=dkey;
function touchDay(){const k=dkey();if(S.last===k)return;const y=dkey(new Date(Date.now()-864e5));S.streak=S.last===y?S.streak+1:1;S.days=(S.days||0)+1;S.last=k;rollQuests()}
VN.xp=(n,why)=>{n=Math.max(0,Math.round(n));if(!n)return;const L0=lvOf(S.xp);touchDay();S.xp+=n;S.stat.xpToday=(S.stat.xpDay===dkey()?S.stat.xpToday||0:0)+n;S.stat.xpDay=dkey();save();renderTop();VN.emit('xp',{n,why});bump('xp',n);
 const L1=lvOf(S.xp);if(L1>L0)VN.toast('⭐ '+VN.T('Lên cấp ','Level up ')+L1+' · '+VN.T(VN.RANKS[VN.rank()][0],VN.RANKS[VN.rank()][1]))};

/* ---- quests (3 per day, deterministic by date) ---- */
const QPOOL=[
 {id:'solve2',k:'solve',need:2,xp:15,vi:'Giải 2 bài trong Giải đề',en:'Solve 2 problems in Solver'},
 {id:'node1',k:'node',need:1,xp:20,vi:'Hoàn thành 1 nút trong Tháp chiều',en:'Complete 1 node in the Tower'},
 {id:'lab1',k:'lab',need:1,xp:15,vi:'Chơi 1 phòng lab liên ngành',en:'Play 1 cross-lab'},
 {id:'atlas2',k:'atlas',need:2,xp:10,vi:'Xem 2 hình trong Atlas',en:'View 2 figures in the Atlas'},
 {id:'xp30',k:'xp',need:30,xp:15,vi:'Kiếm 30 XP luyện tập',en:'Earn 30 XP practising'},
 {id:'hop',k:'hop',need:1,xp:15,vi:'Nhảy chiều: kéo hình lên chiều kế tiếp',en:'Dimension jump: lift a figure one dimension up'},
 {id:'cross1',k:'cross',need:1,xp:20,vi:'Giải 1 bài liên ngành (hình × lý)',en:'Solve 1 cross problem (geometry × physics)'}];
function rollQuests(){const k=dkey();if(S.qd===k)return;let h=0;for(const c of k)h=(h*31+c.charCodeAt(0))>>>0;const pool=QPOOL.slice(),pick=[];while(pick.length<3){const i=h%pool.length;pick.push(pool.splice(i,1)[0]);h=(h*1103515245+12345)>>>0}
 S.qd=k;S.ql=pick.map(q=>({id:q.id,have:0,done:0}));save()}
function bump(kind,n){rollQuests();let any=0;S.ql.forEach(q=>{const d=QPOOL.find(x=>x.id===q.id);if(!d||q.done||d.k!==kind)return;q.have+=n||1;if(q.have>=d.need){q.done=1;S.xp+=d.xp;any=1;VN.toast('🎯 '+VN.T(d.vi,d.en)+'  +'+d.xp+' XP')}});if(any){save();renderTop()}save()}
VN.bump=bump;VN.QPOOL=QPOOL;
VN.quests=()=>{rollQuests();return S.ql.map(q=>Object.assign({},QPOOL.find(x=>x.id===q.id),q))};

/* ---- theme ---- */
const mq=window.matchMedia?matchMedia('(prefers-color-scheme:dark)'):null;
VN.dark=()=>S.theme==='dark'||(S.theme==='auto'&&!!(mq&&mq.matches));
VN.engVars=dark=>(VN.S.vstyle!=='neon')?(dark?{'--vncl':'1','--bg':'#0d0d10','--card':'rgba(20,13,46,.62)','--tx':'#f3f3f6','--mu':'#9b9ca6','--ac':'#ffffff','--hl':'rgba(255,255,255,.2)','--ok':'#4ade80','--bad':'#ff7b7b','--bd':'rgba(255,255,255,.12)','--br':'rgba(255,255,255,.12)','--grid':'transparent','--ink':'#f3f3f6','--on':'#f3f3f6','--onx':'#111114','--g1':'#0d0d10','--g2':'#121217','--g3':'#16141d'}:{'--vncl':'1','--bg':'#ffffff','--card':'rgba(255,255,255,.78)','--tx':'#15161a','--mu':'#5d6270','--ac':'#4f46e5','--hl':'rgba(79,70,229,.18)','--ok':'#16874a','--bad':'#c62828','--bd':'rgba(20,22,30,.11)','--br':'rgba(20,22,30,.11)','--grid':'transparent','--ink':'#15161a','--on':'#4f46e5','--onx':'#ffffff','--g1':'#f3f4f7','--g2':'#eceef3','--g3':'#f3f4f7'}):dark?{'--bg':'rgba(0,0,0,.28)','--card':'rgba(255,255,255,.07)','--tx':'#eef2fb','--mu':'#9aa7c2','--ac':'#ff8a2b','--hl':'#ffd23f','--ok':'#4ade80','--bad':'#ff7b7b','--bd':'rgba(255,255,255,.16)','--grid':'transparent','--ink':'#eef2fb','--on':'#ff8a2b','--onx':'#1a0e02','--g1':'#06080d','--g2':'#0b1220','--g3':'#1b1209'}:
 {'--bg':'rgba(255,255,255,.55)','--card':'rgba(255,255,255,.62)','--tx':'#1b2233','--mu':'#5c6780','--ac':'#e2580c','--hl':'#ffd23f','--ok':'#16874a','--bad':'#c62828','--bd':'rgba(27,34,51,.16)','--grid':'transparent','--ink':'#1b2233','--on':'#e2580c','--onx':'#ffffff','--g1':'#f7f2ea','--g2':'#e9f3ea','--g3':'#fff1dc'};
function applyTheme(){const d=VN.dark();document.documentElement.dataset.theme=d?'dark':'light';document.documentElement.classList.toggle('neon',S.vstyle==='neon');const m=document.querySelector('meta[name=theme-color]');if(m)m.content=d?'#06080d':'#f7f2ea';
 Object.values(VN.eng).forEach(e=>{if(e.ready)e.call('theme',{dark:d,vars:VN.engVars(d)}).catch(()=>{})});VN.emit('theme',d)}
VN.applyTheme=applyTheme;if(mq&&mq.addEventListener)mq.addEventListener('change',()=>S.theme==='auto'&&applyTheme());

/* ---- engine host ---- */
let rid=0;const pend={};
window.addEventListener('message',e=>{const m=e.data;if(!m||m.vn!==1)return;
 if(m.t==='ai'){const src=e.source;Promise.resolve().then(()=>VN.aiAsk(String(m.q||'').slice(0,1500),Array.isArray(m.hist)?m.hist:[])).then(text=>src.postMessage({vn:1,t:'airet',id:m.id,text},'*')).catch(er=>src.postMessage({vn:1,t:'airet',id:m.id,err:String(er&&er.message||er),code:/hết lượt|used up/i.test(String(er&&er.message))?429:503},'*'));return}
 if(m.t==='ret'){const p=pend[m.id];if(p){delete pend[m.id];m.err?p.rej(new Error(m.err)):p.res(m.r)}return}
 const en=Object.values(VN.eng).find(x=>x.frame&&x.frame.contentWindow===e.source);if(!en)return;
 if(m.ev==='ready'){en.ready=true;en._res&&en._res();applyTheme();VN.pushKey()}
 else if(m.ev==='save'){const d=m.d||{};if(en.name==='geo'){const n=+d.n||0;if(S.geoLast<=n){const g=n-S.geoLast;S.geoLast=n;if(g>0)VN.xp(g*3,'geo')}else S.geoLast=n}
  else{const x=+d.xp||0;if(S.phyLast<=x){const g=x-S.phyLast;S.phyLast=x;if(g>0)VN.xp(g,'phy')}else S.phyLast=x}save()}});
function mkEng(name){
 const en={name,ready:false,frame:null,loading:null,
  load(){if(en.loading)return en.loading;
   en.loading=new Promise(res=>{en._res=res;const f=document.createElement('iframe');f.title=name;f.src='engines/'+name+'.html?emb=1&lg='+S.lg+'&age='+S.age;f.setAttribute('allow','autoplay');en.frame=f;$('#engHost').appendChild(f);
    setTimeout(()=>{if(!en.ready){en.ready=true;res()}},9000)});return en.loading},
  call(fn,...args){return en.load().then(()=>new Promise((res,rej)=>{const id=++rid;pend[id]={res,rej};setTimeout(()=>{if(pend[id]){delete pend[id];rej(new Error('timeout '+fn))}},20000);en.frame.contentWindow.postMessage({vn:1,t:'call',id,fn,args},'*')}))}};
 VN.eng[name]=en;return en}
mkEng('geo');mkEng('phy');

/* ---- router ---- */
let cur='';
VN.go=function(v,p){if(!VN.views[v])return;const old=cur;cur=v;$$('.view').forEach(x=>x.classList.toggle('on',x.id==='v-'+v));$$('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
 const ov=VN.views[old];if(ov&&old!==v&&ov.hide)ov.hide();const m=VN.views[v];if(!m.inited){m.inited=true;m.init&&m.init($('#v-'+v))}m.show&&m.show(p||{},old);VN.cur=v;touchDay();if(old!==v)try{$('#v-'+v).scrollTop=0}catch(e){}};
VN.open=function(t){/* t: {eng:'geo'|'phy', tab, q} or {view,...} */if(t.view)return VN.go(t.view,t);VN.go('learn',t)};

/* ---- top bar ---- */
function renderTop(){const L=lvOf(S.xp),a=25*(L-1)*(L-1),b=25*L*L,p=Math.round(100*(S.xp-a)/(b-a));
 $('#xpc').innerHTML='<span>⭐ '+L+'</span><span class="bar" style="width:46px"><i style="width:'+p+'%"></i></span><b class="mono">'+S.xp+'</b><span title="streak">🔥'+S.streak+'</span>'}
VN.renderTop=renderTop;

/* ---- modal helpers ---- */
VN.modal=(html,onClose)=>{const m=$('#modal');m.onclick=null;m.innerHTML='<div class="card" role="dialog" aria-modal="true">'+(/id="qx"/.test(html)?'':'<button class="mx" aria-label="'+VN.T('Đóng','Close')+'">✕</button>')+html+'</div>';m.classList.add('on');document.documentElement.classList.add('mopen');m._close=onClose;const x=m.querySelector('.mx');if(x)x.addEventListener('click',e=>{e.stopPropagation();VN.closeModal()});return m};
VN.closeModal=()=>{const m=$('#modal');m.onclick=null;document.documentElement.classList.remove('mopen');m.classList.remove('on');m.innerHTML='';m._close&&m._close();m._close=null};
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')VN.closeModal()});
/* multiple-choice check. q:{q:[vi,en],o:[[vi,en]..],a:index,e:[vi,en]} */
VN.ask=function(q,done){const T=VN.T;let h='<h3>'+VN.esc(T(q.q[0],q.q[1]))+'</h3>'+q.o.map((o,i)=>'<button class="opt" data-i="'+i+'">'+VN.esc(T(o[0],o[1]))+'</button>').join('')+'<div id="qfb" class="mu" style="margin-top:8px"></div><div class="row" style="margin-top:8px;justify-content:flex-end"><button class="btn g" id="qx">'+T('Đóng','Close')+'</button></div>';
 const m=VN.modal(h);let fin=0;m.onclick=e=>{if(e.target.id==='modal')VN.closeModal();if(e.target.id==='qx')VN.closeModal();const b=e.target.closest('.opt');if(!b||fin)return;const i=+b.dataset.i;
  if(i===q.a){fin=1;b.classList.add('ok');$('#qfb',m).innerHTML='<b class="ok">'+T('Chính xác!','Correct!')+'</b> '+VN.esc(q.e?T(q.e[0],q.e[1]):'');setTimeout(()=>{done&&done(true)},900)}
  else{b.classList.add('no');$('#qfb',m).textContent=T('Chưa đúng, thử lại nhé.','Not quite, try again.')}}};

/* ---- settings ---- */
function settings(){const T=VN.T;
 const h='<h3>'+T('Cài đặt','Settings')+'</h3>'+
 '<div class="kv"><span>'+T('Ngôn ngữ','Language')+'</span><span class="seg" id="sl"><button data-v="vi" class="'+(S.lg==='vi'?'on':'')+'">VI</button><button data-v="en" class="'+(S.lg==='en'?'on':'')+'">EN</button></span></div>'+
 '<div class="kv"><span>'+T('Giao diện','Theme')+'</span><span class="seg" id="st">'+[['auto','Auto'],['light',T('Sáng','Light')],['dark',T('Tối','Dark')]].map(x=>'<button data-v="'+x[0]+'" class="'+(S.theme===x[0]?'on':'')+'">'+x[1]+'</button>').join('')+'</span></div>'+
 '<div class="kv"><span>'+T('Độ tuổi / chế độ','Age mode')+'</span><span class="seg" id="sa">'+[[1,'5–10'],[2,'11–14'],[3,'15+']].map(x=>'<button data-v="'+x[0]+'" class="'+(S.age===x[0]?'on':'')+'">'+x[1]+'</button>').join('')+'</span></div>'+
 '<div class="kv"><span>'+T('Kiểu hình học','Geometry style')+'</span><span class="seg" id="svs"><button data-v="classic" class="'+(S.vstyle!=='neon'?'on':'')+'">'+T('Cổ điển','Classic')+'</button><button data-v="neon" class="'+(S.vstyle==='neon'?'on':'')+'">Neon</button></span></div>'+
 '<div class="kv"><span>'+T('Đồ họa 3D','3D graphics')+'<br><small class="mu">'+T('Tự động: tự giảm độ nét khi máy nóng/lag','Auto: lowers resolution when the device struggles')+'</small></span><span class="seg" id="sgq">'+[['auto',T('Tự động','Auto')],['low',T('Nhẹ','Low')],['mid',T('Vừa','Mid')],['high',T('Đẹp','High')]].map(x=>'<button data-v="'+x[0]+'" class="'+((S.gq||'auto')===x[0]?'on':'')+'">'+x[1]+'</button>').join('')+'</span></div>'+
 '<div class="kv"><span>'+T('Nền không gian động','Living space background')+'</span><span class="seg" id="sfx"><button data-v="1" class="'+(S.fx!==0?'on':'')+'">'+T('Bật','On')+'</button><button data-v="0" class="'+(S.fx===0?'on':'')+'">'+T('Tắt','Off')+'</button></span></div>'+
 '<div class="kv"><span>'+T('Đọc to lời giải','Read answers aloud')+'</span><span class="seg" id="sv"><button data-v="1" class="'+(S.voice?'on':'')+'">'+T('Bật','On')+'</button><button data-v="0" class="'+(!S.voice?'on':'')+'">'+T('Tắt','Off')+'</button></span></div>'+
 '<p class="mu" style="margin:10px 0 4px"><b>'+T('Khóa Gemini (tùy chọn)','Gemini key (optional)')+'</b><br>'+T('Ứng dụng giải offline hoàn toàn. Nếu bạn dán khóa Gemini của riêng mình, câu hỏi tự do sẽ được gửi thẳng tới Google; khóa chỉ lưu trên máy này.','The app solves fully offline. If you paste your own Gemini key, free-form questions go straight to Google; the key stays on this device only.')+'</p>'+
 '<div class="row"><input id="gk" type="password" placeholder="AIza…" value="'+VN.esc(S.gk||'')+'" style="flex:1"><button class="btn g" id="gks">'+T('Lưu','Save')+'</button></div>'+
 '<div class="row" style="margin-top:12px"><button class="btn g" id="bk">'+T('Sao lưu tiến độ','Back up progress')+'</button><button class="btn g" id="rs">'+T('Nhập sao lưu','Restore backup')+'</button><button class="btn g" id="rz">'+T('Xóa tiến độ','Reset progress')+'</button></div>'+
 '<div id="bkx" style="display:none;margin-top:8px"><textarea id="bkt" rows="4"></textarea><button class="btn" id="bkok" style="margin-top:6px">OK</button></div>'+
 '<p class="mu" style="font-size:12px;margin-top:12px">VertexNode · '+T('Không tài khoản, không quảng cáo, không theo dõi. Mọi tiến độ chỉ nằm trên thiết bị.','No account, no ads, no tracking. All progress stays on this device.')+'</p>'+
 '<div class="row" style="justify-content:flex-end"><button class="btn" id="cl">'+T('Xong','Done')+'</button></div>';
 const m=VN.modal(h);
 const seg=(id,fn)=>$(id,m).onclick=e=>{const b=e.target.closest('button');if(b)fn(b.dataset.v)};
 seg('#sl',v=>{VN.setLang(v);settings()});seg('#st',v=>{S.theme=v;save();applyTheme();settings()});
 seg('#sa',v=>{S.age=+v;save();Object.values(VN.eng).forEach(e=>e.ready&&e.name==='geo'&&e.call('age',S.age).catch(()=>{}));settings();VN.emit('age')});seg('#sv',v=>{S.voice=+v;save();settings()});seg('#svs',v=>{S.vstyle=v;save();applyTheme();VN.emit('theme');settings()});seg('#sfx',v=>{VN.fx&&VN.fx.set(+v);settings()});seg('#sgq',v=>{S.gq=v;delete S.gqAuto;delete S.gqPr;save();if(VN.REALM&&VN.REALM.on){const h=document.querySelector('#r3host');if(h){VN.REALM.unmount();VN.REALM.mount(h)}}settings()});
 $('#gks',m).onclick=()=>{S.gk=$('#gk',m).value.trim();save();VN.pushKey();VN.toast(VN.T('Đã lưu khóa','Key saved'))};
 $('#bk',m).onclick=()=>{$('#bkx',m).style.display='';$('#bkt',m).value=JSON.stringify(S);$('#bkok',m).onclick=()=>{try{navigator.clipboard.writeText($('#bkt',m).value)}catch(e){};VN.toast(VN.T('Đã chép','Copied'))}};
 $('#rs',m).onclick=()=>{$('#bkx',m).style.display='';$('#bkt',m).value='';$('#bkok',m).onclick=()=>{try{const j=JSON.parse($('#bkt',m).value);if(!j||typeof j.xp!=='number')throw 0;Object.assign(S,DEF(),j);save();location.reload()}catch(e){VN.toast(VN.T('Dữ liệu không hợp lệ','Invalid data'))}}};
 $('#rz',m).onclick=()=>{if($('#rz',m).dataset.s!=='1'){$('#rz',m).dataset.s='1';$('#rz',m).textContent=VN.T('Bấm lần nữa để xác nhận','Tap again to confirm');return}try{localStorage.removeItem(KEY);['vlo','vlo_b','hk3d'].forEach(k=>localStorage.removeItem(k))}catch(e){}location.reload()};
 $('#cl',m).onclick=VN.closeModal}
VN.settings=settings;
VN.pushKey=()=>Object.values(VN.eng).forEach(e=>e.ready&&e.call('key',S.gk||(window.VN_CFG&&VN_CFG.proxy?'__vnproxy__':'')).catch(()=>{}));
VN.setLang=v=>{S.lg=v;save();document.documentElement.lang=v;Object.values(VN.eng).forEach(e=>e.ready&&e.call('lang',v).catch(()=>{}));buildNav();Object.values(VN.views).forEach(m=>m.inited&&m.render&&m.render());renderTop()};

/* ---- nav ---- */
const ICON={home:'<svg viewBox="0 0 24 24"><path d="M12 3 4 7v4l8 4 8-4V7z"/><path d="M4 11v4l8 4 8-4v-4M12 15v4"/></svg>',
 atlas:'<svg viewBox="0 0 24 24"><path d="M12 3 4 7.5v9L12 21l8-4.5v-9z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/></svg>',
 lab:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.2"/><ellipse cx="12" cy="12" rx="9" ry="3.6"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(120 12 12)"/></svg>',
 solve:'<svg viewBox="0 0 24 24"><path d="M12 3l1.8 4.6L18.5 9l-4.7 1.4L12 15l-1.8-4.6L5.5 9l4.7-1.4z"/><path d="M18 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/></svg>',
 learn:'<svg viewBox="0 0 24 24"><path d="M3 8.5 12 4l9 4.5-9 4.5z"/><path d="M7 11v4.5c0 1.2 2.2 2.5 5 2.5s5-1.3 5-2.5V11"/></svg>',world:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="6.5"/><ellipse cx="12" cy="12" rx="11" ry="3.6" transform="rotate(-18 12 12)"/><circle cx="18.6" cy="5" r="1"/></svg>'};
const NAV=[['home','Tháp','Tower'],['atlas','Atlas','Atlas'],['lab','Lab','Lab'],['solve','Giải','Solve'],['learn','Học','Learn'],['world','Thế giới','World']];
function buildNav(){$('#nav').innerHTML=NAV.map(n=>'<button data-v="'+n[0]+'" aria-label="'+n[1]+'">'+ICON[n[0]]+'<span>'+VN.T(n[1],n[2])+'</span></button>').join('');
 $$('#nav button').forEach(b=>{b.onclick=()=>VN.go(b.dataset.v);b.classList.toggle('on',b.dataset.v===cur)})}

/* ---- boot ---- */
VN.boot=function(){document.documentElement.lang=S.lg;applyTheme();rollQuests();buildNav();renderTop();
 $('#bset').onclick=settings;const bf=$('#bfx');if(bf){const sync=()=>{bf.classList.toggle('on',S.fx!==0);bf.title=S.fx!==0?VN.T('Tắt nền không gian','Turn the space background off'):VN.T('Bật nền không gian','Turn the space background on')};bf.onclick=()=>{VN.fx.set(S.fx===0);sync();VN.toast(S.fx!==0?VN.T('✦ Nền không gian: bật','✦ Space background: on'):VN.T('Nền không gian: tắt (tiết kiệm pin)','Space background: off (saves battery)'))};VN.on('fx',sync);sync()}if(VN.fx&&S.fx!==0)VN.fx.start();$('#blg').onclick=()=>VN.setLang(S.lg==='vi'?'en':'vi');
 $('#blg').textContent='VI/EN';
 if(!S.onb)onboard();
 VN.go('home');
 if('serviceWorker' in navigator&&/^https?:/.test(location.protocol)&&location.hostname!=='localhost')navigator.serviceWorker.register('sw.js').catch(()=>{});
 window.addEventListener('keydown',e=>{if(e.key==='Escape')VN.closeModal()})};
function onboard(){const T=VN.T;const h='<h3>'+T('Chào mừng đến VertexNode','Welcome to VertexNode')+'</h3><p class="mu">'+T('Hình học và vật lý trong một app: leo từ Điểm lên Siêu khối 4D, giải bài offline, thí nghiệm liên ngành. Chọn chế độ:','Geometry and physics in one app: climb from the Point to the 4D hypercube, solve offline, run cross-disciplinary labs. Pick a mode:')+'</p>'+
 [[1,'🟢 5–10',T('Nhiều hình, ít chữ','More pictures, less text')],[2,'🔵 11–14',T('Công thức và khai triển','Formulas and nets')],[3,'🟣 15+',T('Vectơ, bản vẽ, vật lý đầy đủ','Vectors, drawings, full physics')]].map(x=>'<button class="opt" data-a="'+x[0]+'"><b>'+x[1]+'</b><br><small>'+x[2]+'</small></button>').join('');
 const m=VN.modal(h);m.onclick=e=>{const b=e.target.closest('.opt');if(!b)return;S.age=+b.dataset.a;S.onb=1;save();VN.closeModal()}}
document.addEventListener('DOMContentLoaded',()=>{});
})();
