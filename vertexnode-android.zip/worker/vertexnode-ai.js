// @ts-nocheck
/* VertexNode AI proxy (Cloudflare Worker).
   The Gemini key lives ONLY in the Worker secret GEMINI_KEY; the app never sees it.
   Protection: per-device + per-IP daily quota, global daily cap, short prompts only, cheap model, CORS allowlist.
   Bindings: DB (D1 database, optional: without it limits are kept in memory per server, looser). Vars (optional): PER_DEVICE=20, PER_IP=40, DAY_MAX=800, MODEL=gemini-flash-latest, ORIGINS="*" */
const SYS_VI='Bạn là gia sư hình học và vật lý trong ứng dụng học tập VertexNode, người học có thể là trẻ em. Giải từng bước, chính xác, đúng cấp lớp được cho; tiểu học dùng cách tiểu học (π ≈ 3,14). Kiểm tra lại phép tính, nói rõ nếu chưa chắc. Ngắn gọn. Chỉ trả lời về toán, hình học, vật lý; từ chối lịch sự chủ đề khác và không xin hay lưu thông tin cá nhân.';
const SYS_EN='You are the geometry and physics tutor in the VertexNode learning app; learners may be children. Solve step by step, accurately, at the given grade level. Double-check arithmetic and say when unsure. Be concise. Only answer about maths, geometry and physics; politely decline other topics and never ask for personal information.';
const J=(o,s,h)=>new Response(JSON.stringify(o),{status:s||200,headers:Object.assign({'Content-Type':'application/json'},h||{})});
function cors(req,env){const o=req.headers.get('Origin')||'';const allow=(env.ORIGINS||'*').split(',').map(x=>x.trim());const ok=allow.includes('*')||allow.includes(o);return{'Access-Control-Allow-Origin':ok?(o||'*'):'null','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'86400','Vary':'Origin'}}
const MEM=new Map();
async function bump(env,key,max){if(!env.DB){if(MEM.size>20000)MEM.clear();const n=(MEM.get(key)||0)+1;MEM.set(key,n);return n<=max?max-n:-1}await env.DB.prepare('CREATE TABLE IF NOT EXISTS q (k TEXT PRIMARY KEY, n INTEGER)').run();const r=await env.DB.prepare('INSERT INTO q (k,n) VALUES (?1,1) ON CONFLICT(k) DO UPDATE SET n=n+1 RETURNING n').bind(key).first();return r.n<=max?max-r.n:-1}
export default{async fetch(req,env){env=Object.assign({},env,{GEMINI_KEY:env.GEMINI_KEY||env.My_Key||env.MY_KEY});const h=cors(req,env);
 if(req.method==='OPTIONS')return new Response(null,{headers:h});
 if(req.method!=='POST')return J({ok:true,service:'vertexnode-ai',key:!!env.GEMINI_KEY,db:!!env.DB},200,h);
 if(!env.GEMINI_KEY)return J({error:'missing key secret (GEMINI_KEY or My_Key)'},500,h);
 let b;try{b=await req.json()}catch(e){return J({error:'bad json'},400,h)}
 const q=String(b.q||'').slice(0,1200).trim();if(q.length<3)return J({error:'empty'},400,h);
 const did=String(b.did||'').replace(/[^a-z0-9]/gi,'').slice(0,40)||'anon',ip=req.headers.get('CF-Connecting-IP')||'0',day=new Date().toISOString().slice(0,10);
 const PD=+(env.PER_DEVICE||20),PI=+(env.PER_IP||40),DM=+(env.DAY_MAX||800);
 const g=await bump(env,'all:'+day,DM);if(g<0)return J({error:'quota',scope:'day'},429,h);
 const ipl=await bump(env,'ip:'+ip+':'+day,PI);if(ipl<0)return J({error:'quota',scope:'ip'},429,h);
 const left=await bump(env,'d:'+did+':'+day,PD);if(left<0)return J({error:'quota',scope:'device'},429,h);
 const lg=b.lg==='en'?'en':'vi',grade=String(b.grade||'').slice(0,20);
 const hist=(Array.isArray(b.hist)?b.hist:[]).slice(-4).map(m=>({role:m.role==='model'?'model':'user',parts:[{text:String((m.parts&&m.parts[0]&&m.parts[0].text)||'').slice(0,1500)}]}));
 const parts=[{text:(grade?(lg==='vi'?'[Cấp lớp: '+grade+'] ':'[Grade: '+grade+'] '):'')+q}];
 if(b.img&&typeof b.img==='string'&&b.img.length<1400000)parts.push({inline_data:{mime_type:'image/jpeg',data:b.img.replace(/^data:image\/\w+;base64,/,'')}});
 const model=env.MODEL||'gemini-flash-latest';
 const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:lg==='vi'?SYS_VI:SYS_EN}]},contents:hist.concat([{role:'user',parts}]),generationConfig:{temperature:.3,maxOutputTokens:1400},safetySettings:[{category:'HARM_CATEGORY_HARASSMENT',threshold:'BLOCK_LOW_AND_ABOVE'},{category:'HARM_CATEGORY_HATE_SPEECH',threshold:'BLOCK_LOW_AND_ABOVE'},{category:'HARM_CATEGORY_SEXUALLY_EXPLICIT',threshold:'BLOCK_LOW_AND_ABOVE'},{category:'HARM_CATEGORY_DANGEROUS_CONTENT',threshold:'BLOCK_LOW_AND_ABOVE'}]})});
 const d=await r.json().catch(()=>({}));if(!r.ok||d.error)return J({error:'upstream',detail:(d.error&&d.error.status)||r.status},502,h);
 const c=((d.candidates||[])[0]||{}).content,text=c&&c.parts?c.parts.map(p=>p.text||'').join(''):'';if(!text)return J({error:'empty answer'},502,h);
 return J({text,left},200,h)}};
