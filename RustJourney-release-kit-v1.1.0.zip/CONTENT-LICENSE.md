# Content license / Giấy phép nội dung

Lesson text, quiz questions, hints, trick descriptions, Rust code samples written for the lessons, and the translations
(Vietnamese and English) are © 2026 Chillvibes, licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**.

- Full text: <https://creativecommons.org/licenses/by/4.0/legalcode>
- Summary: you may share and adapt the material, even commercially, **as long as you give credit, link to the license and say if you changed it.**
- Suggested credit: "Hành Trình Rust · Rust Journey by Chillvibes, CC BY 4.0".

Không bao gồm: tên "Hành Trình Rust / Rust Journey", biểu tượng, intro (hình và giọng) và ảnh cửa hàng, những thứ này được bảo lưu mọi quyền.
Câu danh ngôn là trích dẫn ngắn có ghi tác giả; tục ngữ thuộc về cộng đồng.
