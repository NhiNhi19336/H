# NOTICE

**Hành Trình Rust · Rust Journey** v1.1.0, © 2026 Chillvibes.

- Source code: MIT (`LICENSE`). Lesson content: CC BY 4.0 (`CONTENT-LICENSE.md`).
- Name, icon, intro animation and voice, store graphics: all rights reserved by Chillvibes.
- The intro pack (animation script and voice track) was supplied by the project owner and is shipped unchanged except that the text can be switched by language.
- "Rust" and the Rust logo are trademarks of the Rust Foundation. This is an unofficial learning project, not affiliated with or endorsed by the Rust Foundation. The icon is an original hexagon, not the Rust logo.
- No third-party libraries, fonts or images are bundled in the release build (system fonts are used, no network calls). Links to doc.rust-lang.org and play.rust-lang.org open only when the user taps them.
- Every Rust sample in the lessons was compiled with rustc 1.97 (edition 2021) while the game was built.
