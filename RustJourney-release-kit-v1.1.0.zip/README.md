# Hành Trình Rust — bộ phát hành v1.1.0

Game tự học Rust từ cơ bản đến bậc thầy: 32 bài, mỗi bài có phần học, thử thách (không gian, toán, logic, mật mã) và xưởng ráp đoạn code mẹo.
Ngôn ngữ trong game: Tiếng Việt và English (nút chọn ngôn ngữ ở màn hình chính và trong Cài đặt).

> Lưu ý thật thà: gói này đã được kiểm thử phần game (mọi đoạn Rust đều biên dịch thật bằng rustc, mọi thử thách đều giải được),
> nhưng **chưa được build ra .apk/.aab** vì môi trường tạo gói không có Android SDK và không có mạng. Các bước bên dưới theo tài liệu của PWABuilder và Capacitor.

## Trong gói có gì

| Thư mục | Dùng để |
|---|---|
| `web/` | Ứng dụng web hoàn chỉnh (PWA, chạy offline, không gọi mạng). Gốc có `index.html`: tải lên hosting HTTPS hoặc nén lại để đưa vào công cụ chuyển đổi |
| `android-capacitor/` | Cấu hình Capacitor sẵn: `www/` (bản web), `assets/` (icon và splash), `res-extra/` (tên app tiếng Việt) |
| `store/` | Mô tả cửa hàng (VI/EN), chính sách riêng tư mẫu, icon 512, ảnh feature graphic, ảnh chụp màn hình |
| `source/` | Mã nguồn đầy đủ + công cụ kiểm thử và đóng gói |

## Cách A: PWABuilder (dễ nhất, không cần cài gì)

1. Đưa thư mục `web/` lên một hosting tĩnh có HTTPS (miễn phí: Netlify Drop kéo thả, Cloudflare Pages, GitHub Pages, Vercel).
2. Vào <https://www.pwabuilder.com>, dán địa chỉ trang, bấm Start. Manifest và service worker phải báo đạt.
3. Chọn **Package for stores → Android**. Đặt Package ID (ví dụ `vn.hanhtrinhrust.app`), version `1.1.0` (version code 1), chọn tạo khóa ký mới.
4. Tải về: file **.aab** (đưa lên Google Play), file **.apk** (cài thử trực tiếp) và **signing.keystore** cùng file thông tin khóa. **Sao lưu keystore và mật khẩu**, mất là không cập nhật app được.
5. Để app chạy toàn màn hình không có thanh địa chỉ, đặt file `assetlinks.json` mà PWABuilder đưa vào đường dẫn `/.well-known/assetlinks.json` trên hosting rồi build lại nếu cần.

## Cách B: Capacitor + Android Studio (không cần hosting)

Cần: Node.js LTS, Android Studio bản mới nhất (kèm JDK), có mạng khi chạy `npm`.

```
cd android-capacitor
npm install
npx cap add android
npm run assets          # sinh icon thích ứng và splash từ thư mục assets/
npx cap sync android
npx cap open android    # mở Android Studio
```

Trong Android Studio: **Build → Generate Signed App Bundle / APK**. Chọn *Android App Bundle* (.aab) để lên Google Play, hoặc *APK* để cài trực tiếp. Tạo keystore mới ở bước này và sao lưu cẩn thận.
Muốn tên app hiện tiếng Việt trên máy tiếng Việt: chép `res-extra/values-vi` vào `android/app/src/main/res/` sau khi chạy `npx cap add android`.
Tăng `versionCode` và `versionName` trong `android/app/build.gradle` cho mỗi lần phát hành mới.

## Lên Google Play

- Cần tài khoản nhà phát triển Google Play (có phí đăng ký một lần). Tài khoản cá nhân mới thường phải chạy thử nghiệm kín với một số người thử trong vài tuần trước khi phát hành chính thức: hãy kiểm tra yêu cầu hiện hành trong Play Console.
- Dùng nội dung trong `store/`: mô tả, icon 512, feature graphic, ảnh chụp màn hình.
- **Chính sách riêng tư**: Play yêu cầu một đường dẫn. Đăng nội dung `store/privacy-policy.md` lên một trang web (điền email liên hệ).
- Mục An toàn dữ liệu: game không thu thập và không chia sẻ dữ liệu. Phân loại nội dung: phù hợp mọi lứa tuổi, không quảng cáo, không mua trong ứng dụng.
- Nhắm API mới nhất mà Play yêu cầu tại thời điểm phát hành: bản mới nhất của PWABuilder và Capacitor đã tự cập nhật.

## Cập nhật nội dung sau này

```
node tools/build.js && node tools/test.js --full   # kiểm tra mọi bài bằng rustc thật
node tools/release.js                              # tạo lại gói trong release/
```

Tiến độ người chơi lưu trong máy (localStorage) và có "mã lưu" để chuyển máy. Đổi số phiên bản trong `src/app.js` (`VERSION`).

## Giấy phép và bản quyền (mặc định mình đặt, đổi được)

Đây không phải tư vấn pháp lý, chỉ là lựa chọn hợp lý để bạn **vẫn là chủ** của game:

- **Mã nguồn**: MIT (file `LICENSE`). Ai cũng được dùng và sửa, miễn giữ dòng bản quyền của bạn.
- **Nội dung bài học, câu hỏi, mẹo**: CC BY 4.0 (file `CONTENT-LICENSE.md`). Ai cũng được chia sẻ, dịch, sửa, kể cả thương mại, nhưng **phải ghi tên bạn**.
- **Tên game, biểu tượng, intro, ảnh cửa hàng**: bảo lưu mọi quyền, để người khác không đăng lại app dưới tên của họ với đúng biểu tượng của bạn.
- Không có thư viện, phông chữ hay hình ảnh của bên thứ ba trong bản phát hành.

**Vì sao không dùng CC0?** CC0 là "tặng cho công chúng": ai cũng có thể tải app lên cửa hàng dưới tên họ, không cần ghi tên bạn, và bạn không rút lại được. Chỉ nên dùng nếu bạn thật sự muốn cho đi hoàn toàn. Muốn vậy thì thay nội dung `CONTENT-LICENSE.md` và chuỗi `content` trong `src/brand.js`.

Đổi tên chủ sở hữu: sửa `src/brand.js` (`owner`, `year`) rồi chạy `node tools/release.js`. Không có Node thì tìm chữ "Chillvibes" trong `web/index.html`, `LICENSE`, `CONTENT-LICENSE.md`, `NOTICE.md` và thay tay.

## Intro, câu danh ngôn, bố cục

- **Intro 3,8 giây** (gói intro bạn đưa) phát mỗi lần mở game, chạm hoặc Esc để bỏ qua; tắt/bật và xem lại trong Cài đặt. Giọng đọc là tiếng Việt nên bản English chạy hình, không tiếng. Trình duyệt thường chặn tự phát tiếng ở lần mở đầu (intro vẫn chạy hình). Nếu app Android bị câm, kiểm tra WebView có cho phát media không cần chạm (`mediaPlaybackRequiresUserGesture = false`).
- **Câu danh ngôn mỗi ngày** và **chuỗi ngày học** hiện sau intro, mỗi ngày một lần (36 câu, sửa trong `src/quotes.js`).
- **Bố cục co giãn**: từ màn hình ngoài của điện thoại gập (~280px) tới iPad, gập mở và máy tính. Mê cung hai cột trên màn hình rộng; trên điện thoại, bảng mê cung và nút Chạy được ghim để bấm Chạy là thấy Bot chạy ngay (tắt được trong Cài đặt).
- Màu nền của app (`background_color`, splash) là xanh đậm của intro để màn hình chờ nối liền với intro.

## Lưu ý pháp lý

Đây là dự án học tập không chính thức, không liên kết với Rust Foundation. "Rust" là nhãn hiệu của Rust Foundation. Biểu tượng của game là hình ốc lục giác riêng, không dùng logo Rust.
Link ngoài duy nhất trong game là các liên kết học tiếp và nút chạy thử trên play.rust-lang.org; chúng chỉ mở khi người chơi bấm.

---

# English summary

**Rust Journey** v1.1.0: a self-study game that teaches Rust from first steps to mastery (32 lessons, mazes, math, logic and ciphers, a "trick workshop" after each lesson). It ships in Vietnamese and English.
It has **not** been built into an .apk/.aab inside the sandbox that produced this kit (no Android SDK, no network); the steps follow the PWABuilder and Capacitor docs.

- **Fastest:** host `web/` on any HTTPS static host, open pwabuilder.com, Package for stores → Android, download the signed .aab/.apk and back up the keystore.
- **Without hosting:** `cd android-capacitor && npm install && npx cap add android && npm run assets && npx cap sync android && npx cap open android`, then Build → Generate Signed App Bundle / APK in Android Studio.
- The app makes no network requests by itself, stores progress only on the device, and works offline. See `store/` for listing text, a privacy-policy template and graphics.
- Unofficial project, not affiliated with the Rust Foundation; the icon does not use the Rust logo.
