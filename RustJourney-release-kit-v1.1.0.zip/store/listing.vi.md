# Mô tả cửa hàng (Tiếng Việt)

**Tên (≤30 ký tự):** Hành Trình Rust

**Mô tả ngắn (≤80 ký tự):** Tự học Rust qua mê cung, toán và logic: 32 bài từ cơ bản đến bậc thầy.

**Mô tả đầy đủ:**

Muốn học Rust nhưng thấy khô và khó? Hành Trình Rust biến việc học thành một chuyến phiêu lưu từ dễ đến khó, để bạn tự học ở bất cứ đâu, kể cả khi không có mạng.

32 bài trong 8 vùng, đi từ "Chào Rust!" tới đa luồng, macro và trùm cuối mê cung. Mỗi bài có 3 chặng:
• Học: giải thích ngắn gọn, đoạn code mẫu và kết quả chạy.
• Thử thách: lập trình Bot đi mê cung, bắt lỗi trình biên dịch, giải mã, bật tắt bit, ghép code... dùng tư duy không gian, toán học và logic.
• Xưởng mẹo: tự tay ráp một đoạn code mẹo và cất vào Sổ mẹo để dùng lại.

Điểm nổi bật:
• Lộ trình từ dễ nhất tới khó nhất: biến, vòng lặp, hàm, sở hữu, mượn, struct, trait, lifetime, closure, iterator, Rc/RefCell, thread, macro.
• Mọi đoạn code Rust trong game đều đã được biên dịch và chạy thử bằng trình biên dịch thật.
• Có gợi ý, xem lời giải, chấm sao và điểm kinh nghiệm.
• Chạy offline, không quảng cáo, không thu thập dữ liệu, chuyển tiến độ sang máy khác bằng mã lưu.
• Chế độ sáng, tối và tự động.
• Song ngữ Việt - Anh: đổi ngôn ngữ bất cứ lúc nào trong game.
• Mỗi ngày mở app có một câu danh ngôn và chuỗi ngày học liên tiếp để giữ nhịp.
• Giao diện co giãn cho điện thoại, điện thoại gập, máy tính bảng và màn hình lớn.

Dự án học tập không chính thức, không liên kết với Rust Foundation.

**Danh mục:** Giáo dục (Education). **Gắn thẻ gợi ý:** học lập trình, Rust, giáo dục, câu đố.
