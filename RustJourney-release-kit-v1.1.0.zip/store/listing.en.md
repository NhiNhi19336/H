# Store listing (English)

**Title (≤30 chars):** Rust Journey: Learn Rust

**Short description (≤80 chars):** Learn Rust with mazes, math and logic puzzles. 32 lessons, zero to master.

**Full description:**

Want to learn Rust without the dry textbook? Rust Journey turns it into an adventure that goes from the easiest ideas to the hardest, so you can teach yourself anywhere, even offline.

32 lessons in 8 zones, from "Hello, Rust!" to threads, macros and a final maze boss. Every lesson has three steps:
• Learn: a short explanation, sample code and its real output.
• Challenge: program a Bot through a maze, hunt compiler errors, crack ciphers, flip bits, assemble code... using spatial thinking, math and logic.
• Trick Workshop: build a handy code trick yourself and keep it in your Trick Book.

Highlights:
• A path from the easiest to the hardest topics: variables, loops, functions, ownership, borrowing, structs, traits, lifetimes, closures, iterators, Rc/RefCell, threads, macros.
• Every Rust snippet in the game was compiled and run with the real compiler.
• Hints, solutions, star ratings and XP.
• Works offline, no ads, no data collection, and a save code to move your progress between devices.
• Light, dark and automatic themes.
• Bilingual (English and Vietnamese): switch language any time in the game.
• A quote of the day and a learning streak when you open the app, to keep you going.
• A layout that adapts to phones, foldables, tablets and big screens.

An unofficial learning project, not affiliated with the Rust Foundation.

**Category:** Education. **Suggested tags:** learn to code, Rust, programming, puzzles.
