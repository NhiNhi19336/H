# Chính sách riêng tư / Privacy policy: Hành Trình Rust · Rust Journey

**Tiếng Việt.** Ứng dụng không thu thập, không gửi và không chia sẻ dữ liệu cá nhân. Không có tài khoản, quảng cáo hay công cụ theo dõi. Tiến độ học và cài đặt chỉ lưu trên thiết bị của bạn (bộ nhớ cục bộ của ứng dụng) và bị xóa khi bạn xóa dữ liệu ứng dụng hoặc gỡ cài đặt. Khi bạn bấm vào liên kết ngoài (ví dụ nút "Chạy thử trên Playground"), trình duyệt của bạn mở trang đó và trang đó có chính sách riêng. Liên hệ: [điền email của bạn].

**English.** The app does not collect, transmit or share personal data. There are no accounts, ads or trackers. Progress and settings are stored only on your device (the app's local storage) and are removed when you clear the app's data or uninstall it. If you tap an external link (for example "Run in the Playground"), your browser opens that site, which has its own policy. Contact: [your email].

Cập nhật / Last updated: [ngày / date]
