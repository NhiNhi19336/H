/*! Hành Trình Rust · Intro 3,8s
 *  Dùng:  RustIntro.play({ onDone: function(){ ...vào màn chính... } });
 *  Tuỳ chọn: audio (đường dẫn file giọng), muted, skippable (mặc định true), zIndex, onDone
 *  Trả về Promise, xong intro thì tự gỡ khỏi trang.
 */
(function (global) {
  'use strict';

  // ===== Chỉnh ở đây =====
  var WORDS = ['Hành', 'Trình'], BIG = 'Rust', TAG = 'Từ con số 0 đến bậc thầy';
  var BEATS = [0.38, 0.70, 1.18];            // 3 nhịp của giọng (giây): Hành, Trình, Rust
  var TOTAL = 3.8;
  var C = { deep: '#1B271F', mid: '#2C3F2F', moss: '#7C8B4E', soft: '#A9B67F', cream: '#F7F0E3', rust: '#D4521A', ink: '#14100D' };
  var FONT = "'Bricolage Grotesque','Segoe UI',system-ui,sans-serif";
  var AUDIO = 'rust-intro-audio.m4a';
  // =======================

  var HEX = 'M25 0H75L100 44L75 88H25L0 44Z';
  var HTML =
    '<div class="ri-flash"></div><div class="ri-in">' +
    '<svg class="ri-logo" viewBox="0 0 100 88"><path class="ri-f" d="' + HEX + '" opacity="0"/>' +
    '<path class="ri-o" d="' + HEX + '" pathLength="1" stroke-dasharray="1" stroke-dashoffset="1"/>' +
    '<circle class="ri-c" cx="50" cy="44" r="26" opacity="0"/><text x="50" y="53" opacity="0">Rs</text></svg>' +
    '<h1 class="ri-title"><span class="ri-top"><span class="ri-wrap"><span class="ri-w">' + WORDS[0] + '</span></span>' +
    '<span class="ri-wrap"><span class="ri-w">' + WORDS[1] + '</span></span></span>' +
    '<span class="ri-big"><span class="ri-wrap"><span class="ri-w">' + BIG + '</span></span></span></h1>' +
    '<div class="ri-trail"><div class="ri-ln"></div><i class="ri-n" style="left:0"></i><i class="ri-n" style="left:25%"></i>' +
    '<i class="ri-n" style="left:50%"></i><i class="ri-n" style="left:75%"></i><i class="ri-n" style="left:100%"></i></div>' +
    '<p class="ri-tag">' + TAG + '</p></div>';

  function css() {
    var u = function (n) { return 'calc(var(--u)*' + n + ')'; };
    return [
      '.ri-root{position:fixed;left:0;top:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;overflow:hidden;',
      'box-sizing:border-box;padding:env(safe-area-inset-top,0px) 0 env(safe-area-inset-bottom,0px);color:' + C.cream + ';font-family:' + FONT + ';',
      'background:radial-gradient(120% 75% at 50% 38%,' + C.mid + ' 0%,' + C.deep + ' 62%);touch-action:none;-webkit-user-select:none;user-select:none}',
      '.ri-flash{position:absolute;left:0;top:0;right:0;bottom:0;opacity:0;pointer-events:none;background:radial-gradient(62% 38% at 50% 60%,rgba(212,82,26,.5),transparent 72%)}',
      '.ri-in{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:' + u(5) + ';will-change:transform}',
      '.ri-logo{width:' + u(25) + ';height:auto;overflow:visible}',
      '.ri-o{fill:none;stroke:' + C.soft + ';stroke-width:3;stroke-linejoin:round}.ri-f{fill:' + C.rust + '}',
      '.ri-c{fill:none;stroke:' + C.cream + ';stroke-opacity:.55;stroke-width:3}',
      '.ri-logo text{fill:' + C.cream + ';font:800 26px ' + FONT + ';text-anchor:middle}',
      '.ri-title{margin:0;text-align:center;font-weight:800;letter-spacing:-.025em;line-height:1;white-space:nowrap}',
      '.ri-top{display:block;font-size:' + u(13.5) + '}.ri-big{display:block;font-size:' + u(27) + ';margin-top:' + u(1) + ';color:' + C.rust + '}',
      '.ri-wrap{display:inline-block;overflow:hidden;vertical-align:top;padding:.16em .05em .12em;margin:-.16em -.05em -.12em}',
      '.ri-w{display:inline-block}.ri-top .ri-wrap+.ri-wrap{margin-left:.22em}',
      '.ri-trail{position:relative;width:' + u(64) + ';height:' + u(5) + ';margin-top:' + u(1) + '}',
      '.ri-ln{position:absolute;left:0;right:0;top:50%;height:' + u(.7) + ';margin-top:' + u(-.35) + ';background:' + C.moss + ';border-radius:' + u(1) + ';transform-origin:left center}',
      '.ri-n{position:absolute;top:50%;width:' + u(4.6) + ';height:' + u(4) + ';margin:' + u(-2) + ' 0 0 ' + u(-2.3) + ';background:' + C.soft + ';',
      'clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);-webkit-clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%)}',
      '.ri-n:last-child{background:' + C.rust + '}',
      '.ri-tag{margin:0;font-size:' + u(4.9) + ';font-weight:500;color:' + C.soft + ';letter-spacing:.01em}'
    ].join('');
  }

  var clamp = function (x, a, b) { return Math.min(b === undefined ? 1 : b, Math.max(a === undefined ? 0 : a, x)); };
  var P = function (t, a, b) { return clamp((t - a) / (b - a)); };
  var out = function (x) { return 1 - Math.pow(1 - x, 3); };
  var back = function (x) { var c = 1.7; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };

  function play(o) {
    o = o || {};
    return new Promise(function (resolve) {
      var doc = global.document;
      var reduce = !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
      var st = doc.createElement('style'); st.textContent = css();
      var root = doc.createElement('div'); root.className = 'ri-root'; root.style.zIndex = o.zIndex || 2147483000; root.innerHTML = HTML;
      doc.head.appendChild(st); doc.body.appendChild(root);

      var $ = function (s) { return root.querySelector(s); }, $$ = function (s) { return [].slice.call(root.querySelectorAll(s)); };
      var inn = $('.ri-in'), flash = $('.ri-flash'), logo = $('.ri-logo'), hexO = $('.ri-o'), hexF = $('.ri-f'), hexC = $('.ri-c'), hexT = $('.ri-logo text');
      var words = $$('.ri-w'), nodes = $$('.ri-n'), ln = $('.ri-ln'), tag = $('.ri-tag');
      var U = 1, raf = 0, t0 = 0, done = false, a = null;

      function fit() { U = Math.min(global.innerWidth, global.innerHeight * 9 / 16) / 100; root.style.setProperty('--u', U + 'px'); }
      fit(); global.addEventListener('resize', fit);

      function render(t) {
        hexO.style.strokeDashoffset = 1 - out(P(t, 0, 0.45));
        hexF.style.opacity = P(t, 0.15, 0.4); hexC.style.opacity = P(t, 0.25, 0.5); hexT.style.opacity = P(t, 0.3, 0.5);
        var pulse = Math.sin(Math.PI * P(t, BEATS[2] - 0.05, BEATS[2] + 0.3)) * 0.09;
        logo.style.transform = 'scale(' + (0.8 + 0.2 * back(P(t, 0.05, 0.5)) + pulse) + ')';
        words.forEach(function (w, i) {
          var s = BEATS[i] - 0.1, k = back(P(t, s, s + 0.3));
          w.style.transform = 'translateY(' + ((1 - k) * 110) + '%)'; w.style.opacity = P(t, s, s + 0.06);
        });
        ln.style.transform = 'scaleX(' + out(P(t, 1.4, 2.2)) + ')';
        nodes.forEach(function (n, j) { var s = 1.4 + j * 0.2; n.style.transform = 'scale(' + Math.max(back(P(t, s, s + 0.25)), 0) + ')'; });
        var g = out(P(t, 2.25, 2.6));
        tag.style.opacity = g; tag.style.transform = 'translateY(' + ((1 - g) * 1.8 * U) + 'px)';
        var h = P(t, 1.12, 1.6), k2 = (h > 0 && h < 1) ? Math.pow(1 - h, 2) : 0;
        flash.style.opacity = k2;
        inn.style.transform = 'translate(' + (Math.sin(h * 42) * k2 * 1.2 * U) + 'px,' + (Math.cos(h * 35) * k2 * 0.9 * U) + 'px)';
      }

      function end() {
        if (done) return; done = true;
        global.cancelAnimationFrame(raf); global.removeEventListener('resize', fit);
        if (a) { try { a.pause(); } catch (e) {} }
        if (root.parentNode) root.parentNode.removeChild(root);
        if (st.parentNode) st.parentNode.removeChild(st);
        if (typeof o.onDone === 'function') { try { o.onDone(); } catch (e) {} }
        resolve();
      }

      function frame(now) {
        if (done) return;
        var t = (a && !a.paused && a.currentTime > 0) ? a.currentTime : (now - t0) / 1000;
        if (t >= TOTAL || (a && a.ended)) return end();
        render(reduce ? 2.9 : t);
        root.style.opacity = 1 - P(t, 3.4, 3.8);
        raf = global.requestAnimationFrame(frame);
      }

      function start() {
        if (done) return;
        if (!o.muted) {
          try {
            a = new global.Audio(o.audio || AUDIO); a.preload = 'auto';
            var pr = a.play();
            if (pr && pr.catch) pr.catch(function () { a = null; }); // bị chặn tiếng thì cứ chạy hình, không dừng
          } catch (e) { a = null; }
        }
        t0 = global.performance.now(); raf = global.requestAnimationFrame(frame);
      }

      render(0);
      if (o.skippable !== false) root.addEventListener('click', end);
      var fonts = doc.fonts && doc.fonts.ready;
      var wait = new Promise(function (r) { setTimeout(r, 800); });
      Promise.race([fonts || wait, wait]).then(start, start);
    });
  }

  global.RustIntro = { play: play, TOTAL: TOTAL };
})(typeof window !== 'undefined' ? window : this);
