# Intro "Hành Trình Rust" (3,8 giây)

## Cách gắn vào app HTML / WebView

**Cách 1: app 1 file HTML (không cần file rời)**
Dán nội dung `rust-intro.inline.js` vào thẻ `<script>` (hoặc `<script src="rust-intro.inline.js">`). Giọng đã nhúng sẵn trong file.

**Cách 2: app nhiều file**
Để `rust-intro.js` và `rust-intro-audio.m4a` cùng thư mục với trang, rồi:
```html
<script src="rust-intro.js"></script>
```
Nếu để file giọng ở chỗ khác: `RustIntro.play({ audio: 'duong/dan/rust-intro-audio.m4a' })`.

**Gọi lúc mở app**
```js
RustIntro.play({
  onDone: function () { /* vào màn chính */ }
});
// hoặc: RustIntro.play().then(function () { ... });
```
Intro phủ kín màn hình, chạy xong tự mờ đi và tự gỡ khỏi trang. Chạm màn hình để bỏ qua.

Tuỳ chọn: `audio` (đường dẫn giọng), `muted: true` (chạy hình, không tiếng), `skippable: false` (không cho bỏ qua), `zIndex`, `onDone`.

## Lưu ý
- **Android WebView**: nếu tự viết WebView, bật `settings.mediaPlaybackRequiresUserGesture = false` để giọng tự phát. Bị chặn thì intro vẫn chạy hình, chỉ không có tiếng.
- **Font**: chữ dùng Bricolage Grotesque. App đã nạp font này thì tự khớp, chưa thì sẽ rơi về font hệ thống. Muốn đổi font sửa `FONT` đầu file JS.
- **Đổi chữ, màu, nhịp**: sửa khối "Chỉnh ở đây" ở đầu `rust-intro.js` (`WORDS`, `BIG`, `TAG`, `BEATS`, bảng màu `C`).

## Danh sách file
- `rust-intro.js`: script intro, dùng với file giọng rời
- `rust-intro.inline.js`: bản nhúng sẵn giọng (1 file)
- `rust-intro-audio.m4a` / `.mp3`: giọng đã chỉnh, kèm tiếng gió và tiếng "ùm" (3,8 giây)
- `rust-intro-voice-only.m4a`: chỉ giọng đã hạ tông, không hiệu ứng
- `rust-intro-preview.html`: bản xem trước độc lập (mở bằng trình duyệt)
- `demo.html`: ví dụ gắn vào 1 màn hình
