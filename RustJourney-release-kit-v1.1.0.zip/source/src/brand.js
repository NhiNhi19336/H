/* Thông tin chủ sở hữu và giấy phép. Đổi ở đây, rồi chạy lại `node tools/release.js`
   (hoặc tìm chuỗi "Chillvibes" trong web/index.html, LICENSE, CONTENT-LICENSE.md, NOTICE.md để sửa tay). */
const BRAND = { owner: 'Chillvibes', year: 2026, code: 'MIT', content: 'CC BY 4.0' };
