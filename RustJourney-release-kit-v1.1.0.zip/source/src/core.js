'use strict';
var G = { zones: [], engines: {}, errs: {}, all: [] };

/* ---------- tiện ích ---------- */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const md = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
const clone = o => JSON.parse(JSON.stringify(o));
const sleep = ms => new Promise(r => setTimeout(r, ms));
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function shuffled(arr, seed) {
  const r = rng(seed || 1); let a = arr.slice();
  for (let n = 0; n < 12; n++) {
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    if (a.length < 2 || a.some((v, i) => v !== arr[i])) break;
  }
  return a;
}

/* ---------- tô màu cú pháp Rust ---------- */
const KW = new Set('fn let mut if else match for while loop in return break continue struct enum impl trait pub use mod const static as ref move where unsafe dyn type self Self crate super true false'.split(' '));
const HL_RE = /(\/\/[^\n]*)|("(?:\\.|[^"\\])*")|(b?'(?:\\.|[^'\\])')|('[a-z_]+\b)|(#!?\[[^\]\n]*\])|(\b0b[01_]+|\b0x[0-9a-fA-F_]+|\b\d[\d_]*(?:\.\d[\d_]*)?(?:[iu](?:8|16|32|64|128|size)|f32|f64)?)|([A-Za-z_][A-Za-z0-9_]*!)|([A-Za-z_][A-Za-z0-9_]*)/g;
function hl(src) {
  let out = '', last = 0, m; HL_RE.lastIndex = 0;
  while ((m = HL_RE.exec(src))) {
    out += esc(src.slice(last, m.index));
    const t = m[0]; let c = '';
    if (m[1]) c = 'c'; else if (m[2] || m[3]) c = 's'; else if (m[4]) c = 'l'; else if (m[5]) c = 'a'; else if (m[6]) c = 'n'; else if (m[7]) c = 'm';
    else if (KW.has(t)) c = 'k'; else if (/^[A-Z]/.test(t)) c = 't'; else if (src[m.index + t.length] === '(') c = 'f';
    out += c ? `<span class="${c}">${esc(t)}</span>` : esc(t);
    last = m.index + t.length;
  }
  return out + esc(src.slice(last));
}
const codeHTML = (src, cls) => `<pre class="code ${cls || ''}"><code>${hl(String(src).replace(/\n$/, ''))}</code></pre>`;
const termHTML = out => `<div class="term"><span class="prompt">$ cargo run</span>\n${esc(out)}</div>`;
function errHTML(t) {
  return `<pre class="errmsg">${esc(t).split('\n').map(l =>
    /^(error|warning)/.test(l) ? `<span class="e1">${l}</span>` :
    /^\s*-->/.test(l) ? `<span class="e2">${l}</span>` :
    l.replace(/(\^+[^\n]*)/, '<span class="e1">$1</span>').replace(/(-{2,}[^\n]*)/, '<span class="e2">$1</span>')).join('\n')}</pre>`;
}

/* ---------- biểu tượng ---------- */
const ICO = {
  back: '<path d="M15 5l-7 7 7 7"/>', book: '<path d="M5 4h10a3 3 0 013 3v13H8a3 3 0 01-3-3V4z"/><path d="M5 17a3 3 0 013-3h10"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1"/>',
  bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0012 3z"/>',
  play: '<path d="M8 5l11 7-11 7V5z" fill="currentColor"/>', reset: '<path d="M4 12a8 8 0 108-8M4 4v5h5"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7"/>', lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>', undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 010 12h-3"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>', next: '<path d="M9 5l7 7-7 7"/>', prev: '<path d="M15 5l-7 7 7 7"/>', trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  quote: '<path d="M10 7H6a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h3v1a3 3 0 0 1-3 3M19 7h-4a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h3v1a3 3 0 0 1-3 3"/>', flame: '<path d="M12 3c.8 3.2 5 5.2 5 10a5 5 0 0 1-10 0c0-2 1-3.2 2-4.2 0 2 .9 3 2 3 .3-3-.8-5 1-8.8z"/>', info: '<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7.5v.01"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  bolt: '<path d="M13 2L5 14h6l-1 8 8-12h-6l1-8z"/>', map: '<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2V6zM9 4v14M15 6v14"/>',
};
const ico = (n, s) => `<svg class="ico" viewBox="0 0 24 24" width="${s || 18}" height="${s || 18}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICO[n]}</svg>`;
const STAR = 'M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z';
const stars = (n, s) => `<span class="stars" role="img" aria-label="${n} ${T('sao', 'stars')}">${[1, 2, 3].map(i => `<svg viewBox="0 0 24 24" width="${s || 14}" height="${s || 14}" class="${i <= n ? 'on' : ''}"><path d="${STAR}"/></svg>`).join('')}</span>`;
const nut = (label, cls) => `<svg class="nut ${cls || ''}" viewBox="0 0 56 56" aria-hidden="true"><polygon points="54,28 41,50.5 15,50.5 2,28 15,5.5 41,5.5"/><circle cx="28" cy="28" r="15"/><text x="28" y="34" text-anchor="middle">${label}</text></svg>`;

/* ---------- trạng thái & lưu ---------- */
const KEY = 'hanhtrinhrust.v1';
const ST = { done: {}, trick: {}, cfg: { sound: true, free: false } };
function load() { try { const j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j) { Object.assign(ST, j); ST.cfg = Object.assign({ sound: true, free: false }, j.cfg); } } catch (e) { } }
function save() { try { localStorage.setItem(KEY, JSON.stringify(ST)); } catch (e) { } }
G.xp = () => Object.keys(ST.done).reduce((n, k) => n + 20 + (ST.done[k].stars || 1) * 10, 0) + Object.keys(ST.trick).length * 30;
const nib = L => { const d = ST.done[L.n]; return ((d ? 8 | (((d.stars || 1) & 3) << 1) : 0) | (ST.trick[L.n] ? 1 : 0)); };
const ckSum = s => s.split('').reduce((a, c) => (a * 7 + parseInt(c, 16) + 3) % 256, 0);
function saveCode() { const s = G.all.map(L => nib(L).toString(16)).join(''); return 'HT-' + (s + ckSum(s).toString(16).padStart(2, '0')).toUpperCase().match(/.{1,4}/g).join('-'); }
function loadCode(code) {
  const h = String(code).toUpperCase().replace(/^\s*HT-?/, '').replace(/[^0-9A-F]/g, '');
  if (h.length !== G.all.length + 2) return false;
  const s = h.slice(0, -2); if (ckSum(s) !== parseInt(h.slice(-2), 16)) return false;
  const done = {}, trick = {};
  s.split('').forEach((c, i) => { const v = parseInt(c, 16); if (v & 8) done[i + 1] = { stars: Math.max(1, (v >> 1) & 3) }; if (v & 1) trick[i + 1] = true; });
  ST.done = done; ST.trick = trick; save(); return true;
}

/* ---------- âm thanh, pháo giấy, thông báo ---------- */
let AC = null;
const SF = { ok: [[660, 0, .09], [880, .09, .12]], bad: [[170, 0, .18, 'sawtooth']], tap: [[520, 0, .04]], win: [[523, 0, .1], [659, .1, .1], [784, .2, .1], [1046, .3, .25]], trick: [[392, 0, .1], [523, .1, .1], [659, .2, .1], [784, .3, .1], [1046, .4, .35]], step: [[300, 0, .03]] };
function sfx(n) {
  if (!ST.cfg.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume();
    (SF[n] || []).forEach(([f, t, d, ty]) => { const o = AC.createOscillator(), g = AC.createGain(), t0 = AC.currentTime + t; o.type = ty || 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(.05, t0 + .01); g.gain.exponentialRampToValueAtTime(.0001, t0 + d); o.connect(g); g.connect(AC.destination); o.start(t0); o.stop(t0 + d + .03); });
  } catch (e) { }
}
function confetti(n) {
  try { if (matchMedia('(prefers-reduced-motion: reduce)').matches) return; } catch (e) { }
  const c = document.createElement('canvas'); c.className = 'confetti'; c.width = innerWidth; c.height = innerHeight; document.body.appendChild(c);
  const x = c.getContext('2d'), cols = ['#ff7a3d', '#e6b34a', '#3dc4ae', '#f1e7d6', '#ff9a62'];
  const P = Array.from({ length: n || 80 }, () => ({ x: innerWidth / 2 + (Math.random() - .5) * 90, y: innerHeight * .55, vx: (Math.random() - .5) * 10, vy: -Math.random() * 12 - 4, s: 5 + Math.random() * 6, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[(Math.random() * cols.length) | 0] }));
  let t = 0; (function f() { x.clearRect(0, 0, c.width, c.height); P.forEach(p => { p.vy += .35; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * .6); x.restore(); }); if (++t < 95) requestAnimationFrame(f); else c.remove(); })();
}
let toastT = 0;
function toast(msg, kind) {
  let el = $('#toast'); if (!el) { el = document.createElement('div'); el.id = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
  el.className = 'on ' + (kind || ''); el.textContent = msg; clearTimeout(toastT); toastT = setTimeout(() => { el.className = ''; }, 2400);
}
async function copyText(t) { try { await navigator.clipboard.writeText(t); toast(T('Đã sao chép', 'Copied')); return true; } catch (e) { toast(T('Không tự sao chép được, hãy chọn và copy thủ công', 'Could not copy automatically, please select and copy by hand'), 'bad'); return false; } }

/* ---------- ngôn ngữ & đăng ký bài học ---------- */
/* Mỗi ngôn ngữ là một "gói" riêng: lessons/<lang>/_lang.js gọi G.defZones, các file zN.js gọi G.add.
   Số bài (L.n) giống nhau ở mọi gói nên tiến độ dùng chung khi đổi ngôn ngữ. */
G.packs = {}; G.pack = 'vi'; G.lang = 'vi';
G.LANGS = [['vi', 'Tiếng Việt', 'VI'], ['en', 'English', 'EN']];
const T = (vi, en) => (G.lang === 'en' && en != null ? en : vi);
G.defZones = (lang, zs) => { G.pack = lang; G.packs[lang] = { zones: zs.map((z, i) => ({ id: i + 1, name: z[0], rank: z[1], blurb: z[2], lessons: [] })), all: [] }; };
G.add = (z, L) => G.packs[G.pack].zones[z - 1].lessons.push(L);
G.setLang = l => {
  if (!G.ready(l)) l = 'vi';
  G.lang = l; G.zones = G.packs[l].zones; G.all = G.packs[l].all;
  try { document.documentElement.lang = l; document.title = T('Hành Trình Rust', 'Rust Journey'); } catch (e) { }
};
G.finalize = () => {
  Object.keys(G.packs).forEach(k => { const p = G.packs[k]; p.all = []; p.zones.forEach(z => z.lessons.forEach(L => { L.n = p.all.length + 1; L.z = z.id; L.lang = k; p.all.push(L); })); });
  G.setLang(G.lang);
};
/* ngôn ngữ ban đầu: lấy theo cài đặt đã lưu, nếu chưa có thì theo ngôn ngữ của trình duyệt */
/* một ngôn ngữ chỉ hiện ra khi gói của nó có đủ số bài như gói gốc (vi) */
G.ready = l => !!(G.packs[l] && G.packs.vi && G.packs[l].all.length === G.packs.vi.all.length);
G.multi = () => G.LANGS.filter(x => G.ready(x[0])).length > 1;
G.detectLang = () => { try { return /^vi/i.test((navigator.languages && navigator.languages[0]) || navigator.language || '') ? 'vi' : 'en'; } catch (e) { return 'vi'; } };
