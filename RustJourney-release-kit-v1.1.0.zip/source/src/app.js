/* ===== App: bản đồ, bài học, xưởng mẹo, sổ mẹo, cài đặt ===== */
const app = { view: 'map', n: 1, stage: 0 };
let CH = null;
const unlocked = L => ST.cfg.free || L.n === 1 || !!ST.done[L.n - 1];
const doneCount = () => Object.keys(ST.done).length;
const totalStars = () => Object.keys(ST.done).reduce((a, k) => a + (ST.done[k].stars || 1), 0);
function rank() { if (doneCount() >= G.all.length) return G.zones[G.zones.length - 1].rank; let z = 1; G.all.forEach(L => { if (ST.done[L.n]) z = Math.max(z, L.z); }); return G.zones[z - 1].rank; }
const tagsHTML = L => `<span class="tags">${(L.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}</span>`;
const trickCode = L => { const k = L.trick; return G.fmt([].concat(k.pre || ['fn main() {'], k.lines, k.post || ['}'])).join('\n'); };
function applyTheme() { const t = ST.cfg.theme || 'auto', r = document.documentElement; if (t === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', t); }
function go(view, n, stage) { app.view = view; if (n) app.n = n; app.stage = stage || 0; render(); window.scrollTo(0, 0); }

const VERSION = '1.1.0';
const moreHTML = () => {
  const L = [['The Rust Book', 'https://doc.rust-lang.org/book/', T('Sách chính thức, đọc miễn phí', 'The official book, free to read')], ['Rust by Example', 'https://doc.rust-lang.org/rust-by-example/', T('Học qua ví dụ chạy được', 'Learn from runnable examples')], ['Rustlings', 'https://rustlings.rust-lang.org/', T('Bài tập nhỏ: sửa lỗi biên dịch', 'Small exercises: fix the compiler errors')], ['Exercism: Rust', 'https://exercism.org/tracks/rust', T('Luyện tập có người hướng dẫn miễn phí', 'Practice with free mentoring')], ['Rust Playground', 'https://play.rust-lang.org/', T('Chạy code Rust ngay trên trình duyệt', 'Run Rust code right in your browser')]];
  return `<section class="more"><h3>${T('Học tiếp ngoài game', 'Keep learning beyond the game')}</h3><ul>${L.map(x => `<li><a href="${x[1]}" target="_blank" rel="noopener noreferrer">${x[0]}</a><span class="muted"> · ${x[2]}</span></li>`).join('')}</ul></section>`;
};
/* ---------- ngày học, chuỗi ngày, câu danh ngôn ---------- */
const pad2 = n => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const dayNum = k => { const p = String(k).split('-').map(Number); return p.length === 3 ? Math.floor(Date.UTC(p[0], p[1] - 1, p[2]) / 864e5) : NaN; };
function touchStreak() {
  const c = ST.cfg, today = dayKey(); if (c.lastDay === today) return;
  c.streak = dayNum(today) - dayNum(c.lastDay) === 1 ? (c.streak || 0) + 1 : 1; c.best = Math.max(c.best || 0, c.streak); c.lastDay = today; save();
}
const quoteOfDay = () => { const n = G.quotes.length, q = G.quotes[((dayNum(dayKey()) % n) + n) % n]; return { text: T(q[0], q[1]), by: T(q[2], q[3]) }; };
function openQuote() {
  closeSheet(); const q = quoteOfDay(), s = ST.cfg.streak || 1;
  const b = document.createElement('div'); b.className = 'sheet-b q'; b.id = 'sheet';
  b.innerHTML = `<div class="sheet q" role="dialog" aria-modal="true" aria-labelledby="qt">
    <div class="q-top">${ico('quote', 22)}<span>${T('Câu danh ngôn hôm nay', 'Quote of the day')}</span></div>
    <blockquote class="q-t" id="qt">“${esc(q.text)}”</blockquote><p class="q-by">— ${esc(q.by)}</p>
    <p class="q-streak">${ico('flame', 18)} ${s > 1 ? T(`Chuỗi học ${s} ngày liên tiếp`, `${s}-day learning streak`) : T('Ngày đầu của chuỗi mới. Cùng đi tiếp nhé!', 'Day one of a new streak. Let’s keep going!')}</p>
    <div class="actions"><button class="btn primary" data-act="close" type="button">${T('Vào học thôi', 'Let’s learn')}</button></div></div>`;
  b.addEventListener('click', e => { if (e.target === b) closeSheet(); });
  document.body.appendChild(b); const pb = $('.btn.primary', b); if (pb) pb.focus();
}
const PLAY = c => `https://play.rust-lang.org/?version=stable&mode=debug&edition=2021&code=${encodeURIComponent(c)}`;
const playLink = c => `<a class="btn sm ghost play" href="${PLAY(c)}" target="_blank" rel="noopener noreferrer">${ico('ext', 15)} ${T('Chạy thử trên Playground', 'Run in the Playground')}</a>`;
const langBtn = () => { if (!G.multi()) return ''; const o = G.lang === 'vi' ? 'en' : 'vi', nm = G.LANGS.find(x => x[0] === o); return `<button class="iconbtn lang" data-act="lang" data-v="${o}" type="button" aria-label="${T('Switch to English', 'Chuyển sang Tiếng Việt')}" title="${nm[1]}">${ico('globe', 18)}<b>${nm[2]}</b></button>`; };

/* ---------- bản đồ ---------- */
function viewMap() {
  const dn = doneCount(), tot = G.all.length, nxt = G.all.find(L => !ST.done[L.n] && unlocked(L));
  const zones = G.zones.filter(z => z.lessons.length).map(z => {
    const dz = z.lessons.filter(L => ST.done[L.n]).length, off = !z.lessons.some(unlocked);
    return `<section class="zone${off ? ' off' : ''}"><div class="zone-h">${nut(z.id, dz === z.lessons.length ? 'done' : off ? 'lock' : '')}<div class="grow"><span class="zn">${T('Vùng', 'Zone')} ${z.id} · ${esc(z.rank)}</span><h2>${esc(z.name)}</h2><p>${esc(z.blurb)}</p></div><span class="pill">${dz}/${z.lessons.length}</span></div>
      <div class="lessons">${z.lessons.map(L => {
        const d = ST.done[L.n], lk = !unlocked(L);
        return `<button class="node${nxt && nxt.n === L.n ? ' cur' : ''}" data-act="open" data-v="${L.n}" type="button"${lk ? ' disabled' : ''}>${nut(L.n, d ? 'done' : lk ? 'lock' : '')}<span class="nt"><b>${esc(L.title)}</b><small>${esc(L.sub)}</small>${tagsHTML(L)}</span>${d ? stars(d.stars, 15) : lk ? ico('lock', 18) : ico('next', 18)}${ST.trick[L.n] ? `<span title="${T('Đã chế mẹo', 'Trick crafted')}" style="color:var(--gold)">${ico('bolt', 16)}</span>` : ''}</button>`;
      }).join('')}</div></section>`;
  }).join('');
  return `<div class="wrap"><div class="top"><div class="brand">${nut('Rs', 'done').replace('class="nut', 'style="width:34px;height:34px" class="nut')}<span class="brand-t">${T('Hành Trình Rust', 'Rust Journey')}</span></div><div class="grow"></div>
    ${langBtn()}<button class="iconbtn" data-act="book" type="button" aria-label="${T('Sổ mẹo', 'Trick book')}">${ico('book', 22)}</button><button class="iconbtn" data-act="settings" type="button" aria-label="${T('Cài đặt', 'Settings')}">${ico('gear', 22)}</button></div>
    <div class="hero"><h1>${T('Học <em>Rust</em> từ con số 0 đến bậc thầy', 'Learn <em>Rust</em> from zero to master')}</h1>
      <p>${T(`${tot} bài đi từ dễ đến khó. Mỗi bài có phần học, một thử thách bằng tư duy không gian, toán hoặc logic, và một xưởng để chế <b>đoạn code mẹo</b> của riêng bạn.`, `${tot} lessons from easy to hard. Each one has a short lesson, a challenge built on spatial thinking, math or logic, and a workshop where you craft your own <b>code trick</b>.`)}</p>
      <div class="stats"><div class="stat"><small>${T('Cấp bậc', 'Rank')}</small><b>${esc(rank())}</b></div><div class="stat"><small>${T('Điểm', 'Points')}</small><b>${G.xp()}</b></div><div class="stat"><small>${T('Sao', 'Stars')}</small><b>${totalStars()}/${tot * 3}</b></div><div class="stat"><small>${T('Mẹo', 'Tricks')}</small><b>${Object.keys(ST.trick).length}/${tot}</b></div></div>
      <div class="bar" role="progressbar" aria-label="${T('Tiến độ', 'Progress')}" aria-valuenow="${dn}" aria-valuemin="0" aria-valuemax="${tot}"><i style="width:${dn / tot * 100}%"></i></div>
      <div class="actions">${nxt ? `<button class="btn primary" data-act="open" data-v="${nxt.n}" type="button">${ico('play', 16)} ${dn ? T('Tiếp tục', 'Continue') : T('Bắt đầu', 'Start')}: ${T('bài', 'lesson')} ${nxt.n}</button>` : `<button class="btn primary" data-act="book" type="button">${ico('book', 16)} ${T('Mở sổ mẹo của bạn', 'Open your Trick Book')}</button>`}</div>
      ${dn >= tot ? T('<p style="margin:12px 0 0"><b>Bạn đã hoàn thành cả hành trình.</b> Sổ mẹo là bộ đồ nghề của một Bậc thầy Rust, hãy giữ nó bên mình.</p>', '<p style="margin:12px 0 0"><b>You completed the whole journey.</b> Your Trick Book is a Rust Master\'s toolbox, keep it close.</p>') : ''}</div>
    ${zones}${moreHTML()}<p class="muted" style="text-align:center">${T('Mọi đoạn mã Rust trong game đều đã được biên dịch thử bằng Rust 1.97.', 'Every Rust snippet in the game was compiled and run with Rust 1.97.')}</p></div>`;
}

/* ---------- bài học ---------- */
function learnHTML(L) {
  const l = L.learn;
  return `<p class="intro">${md(l.intro)}</p><ul class="points">${l.points.map(p => `<li>${md(p)}</li>`).join('')}</ul>${codeHTML(l.code)}<div class="actions play-row">${playLink(l.code)}</div>${l.out != null ? termHTML(l.out) : ''}${l.note ? `<div class="callout">${ico('bulb', 18)}<span>${md(l.note)}</span></div>` : ''}`;
}
function viewLesson() {
  const L = G.all[app.n - 1], z = G.zones[L.z - 1], d = ST.done[L.n], st = app.stage, can2 = !!d || ST.cfg.free;
  const tab = (i, name, sub, ok, dis) => `<button class="stp-tab${st === i ? ' on' : ''}${ok ? ' ok' : ''}" data-act="stage" data-v="${i}" type="button"${dis ? ' disabled' : ''}>${name}<small>${sub}</small></button>`;
  return `<div class="wrap"><div class="top"><button class="iconbtn" data-act="map" type="button" aria-label="${T('Về bản đồ', 'Back to the map')}">${ico('back', 22)}</button><div class="grow"></div><span class="pill">${T('Bài', 'Lesson')} <b>${L.n}</b>/${G.all.length}</span></div>
    <div class="lhead"><span class="zn">${T('Vùng', 'Zone')} ${z.id} · ${esc(z.name)}</span><h1>${esc(L.title)}</h1>${tagsHTML(L)}</div>
    <div class="steps">${tab(0, T('1. Học', '1. Learn'), T('đọc và xem mã', 'read and run code'), st > 0 || d)}${tab(1, T('2. Thử thách', '2. Challenge'), d ? T('xong', 'done') : T('chơi thử', 'play it'), !!d)}${tab(2, T('3. Xưởng mẹo', '3. Trick Workshop'), ST.trick[L.n] ? T('đã chế', 'crafted') : T('phần thưởng', 'reward'), !!ST.trick[L.n], !can2)}</div>
    <div class="panel" id="panel"></div></div>`;
}
function fillPanel() {
  const L = G.all[app.n - 1], p = $('#panel'), st = app.stage;
  if (st === 0) {
    p.innerHTML = `<h2>${esc(L.sub)}</h2>${learnHTML(L)}<div class="actions"><button class="btn primary" data-act="stage" data-v="1" type="button">${ico('play', 16)} ${T('Sang thử thách', 'Go to the challenge')}</button></div>`;
  } else if (st === 1) {
    p.innerHTML = `<div class="brief">${md(L.ch.brief)}</div><div id="eng"></div>
      <div class="tools"><button class="btn sm ghost" data-act="hint" type="button">${ico('bulb', 15)} ${T('Gợi ý', 'Hint')}</button><button class="btn sm ghost" data-act="peek" type="button" id="peek"></button></div>
      <div id="hintbox"></div><div id="solbox"></div><div id="winbox"></div>`;
    mountChallenge(L);
  } else {
    p.innerHTML = `<div class="trick-h">${ico('bolt', 24)}<h2>${T('Xưởng mẹo', 'Trick Workshop')}: ${esc(L.trick.name)}</h2></div><p>${md(L.trick.why)}</p><div id="teng"></div><div id="tgot"></div>`;
    mountTrick(L);
  }
}
function updPeek() {
  const b = $('#peek'); if (!b || !CH) return;
  const ok = CH.mistakes >= 3 || ST.done[CH.L.n] || ST.cfg.free;
  b.disabled = !ok; b.innerHTML = ok ? T('Xem lời giải', 'Show the solution') : T(`Xem lời giải (mở sau ${3 - CH.mistakes} lần sai nữa)`, `Show the solution (unlocks after ${3 - CH.mistakes} more mistakes)`);
}
function mountChallenge(L) {
  CH = { L, mistakes: 0, hinted: false, peeked: false, won: false, ctl: null };
  const api = {
    mistake() { CH.mistakes++; updPeek(); },
    win(o) {
      if (CH.won) return; CH.won = true;
      let cap = Math.min((o && o.cap) || 3, CH.hinted ? 2 : 3); if (CH.peeked) cap = 1;
      const s = Math.max(1, Math.min(cap, 3 - Math.floor(CH.mistakes / 2))), prev = ST.done[L.n], gain = prev ? 0 : 20 + s * 10;
      ST.done[L.n] = { stars: Math.max(prev ? prev.stars : 0, s) }; save(); sfx('win'); confetti(80);
      $('#winbox').innerHTML = `<div class="win"><h3>${T('Hoàn thành thử thách!', 'Challenge complete!')}</h3>${stars(s, 26)}<p>${gain ? `+${gain} ${T('điểm', 'points')}. ` : ''}${s < 3 ? T('Chơi lại để lấy đủ 3 sao.', 'Play again to earn all 3 stars.') : T('Hoàn hảo, đủ 3 sao.', 'Perfect, all 3 stars.')}</p><div class="actions" style="justify-content:center"><button class="btn primary" data-act="stage" data-v="2" type="button">${ico('bolt', 16)} ${T('Vào xưởng mẹo', 'Enter the Trick Workshop')}</button></div></div>`;
      $$('[data-act="stage"][data-v="2"]').forEach(b => { b.disabled = false; });
      $('#winbox').scrollIntoView({ behavior: 'smooth', block: 'center' });
    },
  };
  CH.ctl = G.engines[L.ch.type].mount($('#eng'), L.ch, api); updPeek();
}
function mountTrick(L) {
  const K = L.trick, host = $('#teng'), nl = G.all[L.n];
  const card = () => `<div class="trick-got"><h3>${ico('bolt', 18)} ${T('Mẹo đã vào sổ', 'Trick added to your book')}: ${esc(K.name)}</h3>${codeHTML(trickCode(L))}${termHTML(K.out)}<p>${md(K.how)}</p>
    <div class="actions"><button class="btn sm" data-act="copytrick" data-v="${L.n}" type="button">${ico('copy', 15)} ${T('Sao chép mã mẹo', 'Copy the trick code')}</button>${nl ? `<button class="btn primary" data-act="next" data-v="${nl.n}" type="button">${T('Bài', 'Lesson')} ${nl.n}: ${esc(nl.title)} ${ico('next', 15)}</button>` : `<button class="btn primary" data-act="map" type="button">${T('Về bản đồ', 'Back to the map')}</button>`}</div></div>`;
  const build = () => {
    $('#tgot').innerHTML = '';
    G.engines.order.mount(host, { lines: K.lines, pre: K.pre || ['fn main() {'], post: K.post || ['}'], out: K.out, btn: T('Chế tạo mẹo', 'Craft the trick') }, {
      mistake() { },
      win() { ST.trick[L.n] = true; save(); sfx('trick'); confetti(60); $('#tgot').innerHTML = card(); $('#tgot').scrollIntoView({ behavior: 'smooth', block: 'center' }); },
    });
  };
  if (ST.trick[L.n]) { $('#tgot').innerHTML = card() + `<div class="actions"><button class="btn ghost sm" data-act="redo" type="button">${ico('reset', 15)} ${T('Chế lại từ đầu', 'Craft it again')}</button></div>`; } else build();
  app.rebuildTrick = build;
}

/* ---------- sổ mẹo ---------- */
function viewBook() {
  const got = G.all.filter(L => ST.trick[L.n]);
  return `<div class="wrap"><div class="top"><button class="iconbtn" data-act="map" type="button" aria-label="${T('Về bản đồ', 'Back to the map')}">${ico('back', 22)}</button><div class="grow"></div><span class="pill">${T('Đã chế', 'Crafted')} <b>${got.length}</b>/${G.all.length}</span></div>
    <h1 style="margin:6px 0 4px">${T('Sổ mẹo', 'Trick Book')}</h1><p class="muted">${T('Mỗi bài học xong, bạn chế một đoạn code mẹo. Chúng được cất ở đây để sao chép dùng lại.', 'After each lesson you craft a code trick. They are kept here so you can copy and reuse them.')}</p>
    <div class="actions" style="margin:0 0 16px"><button class="btn primary" data-act="copyall" type="button"${got.length ? '' : ' disabled'}>${ico('copy', 16)} ${T('Sao chép tất cả', 'Copy all')}</button></div>
    ${G.all.map(L => ST.trick[L.n]
      ? `<article class="tcard"><h3>${L.n}. ${esc(L.trick.name)}</h3><p class="muted">${md(L.trick.why)}</p>${codeHTML(trickCode(L))}<button class="btn sm" data-act="copytrick" data-v="${L.n}" type="button">${ico('copy', 15)} ${T('Sao chép', 'Copy')}</button></article>`
      : `<article class="tcard off"><h3>${ico('lock', 16)} ${T('Mẹo của bài', 'Trick of lesson')} ${L.n}</h3><p class="muted" style="margin:0">${T(`Hoàn thành bài “${esc(L.title)}” rồi chế mẹo ở xưởng để mở.`, `Finish “${esc(L.title)}”, then craft the trick in the workshop to unlock it.`)}</p></article>`).join('')}</div>`;
}

/* ---------- cài đặt ---------- */
function openSheet(confirm) {
  closeSheet();
  const b = document.createElement('div'); b.className = 'sheet-b'; b.id = 'sheet';
  const th = ST.cfg.theme || 'auto';
  b.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="${T('Cài đặt', 'Settings')}"><h2>${T('Cài đặt', 'Settings')}</h2>
    <div class="row"><span>${T('Âm thanh', 'Sound')}</span><button class="tog" data-act="sound" type="button" aria-pressed="${!!ST.cfg.sound}" aria-label="${T('Bật tắt âm thanh', 'Sound on or off')}"></button></div>
    <div class="row"><span>${T('Mở khóa mọi bài', 'Unlock every lesson')}<br><span class="muted">${T('để nhảy cóc nếu bạn đã biết', 'to skip ahead if you already know it')}</span></span><button class="tog" data-act="free" type="button" aria-pressed="${!!ST.cfg.free}" aria-label="${T('Mở khóa mọi bài', 'Unlock every lesson')}"></button></div>
    <div class="row"><span>${T('Câu danh ngôn mỗi ngày', 'Quote of the day')}<br><span class="muted">${T('Chuỗi học', 'Streak')}: ${ST.cfg.streak || 1} ${T('ngày', (ST.cfg.streak || 1) === 1 ? 'day' : 'days')} · ${T('dài nhất', 'best')}: ${Math.max(ST.cfg.best || 1, ST.cfg.streak || 1)}</span></span><span class="rowctl"><button class="btn sm ghost" data-act="quote" type="button">${T('Xem', 'Show')}</button><button class="tog" data-act="qtog" type="button" aria-pressed="${ST.cfg.quote !== false}" aria-label="${T('Bật tắt câu danh ngôn mỗi ngày', 'Daily quote on or off')}"></button></span></div>
    <div class="row"><span>${T('Intro mở đầu', 'Opening intro')}<br><span class="muted">${T('phát khi mở game, chạm để bỏ qua', 'plays when the game opens, tap to skip')}</span></span><span class="rowctl"><button class="btn sm ghost" data-act="intro" type="button">${T('Xem lại', 'Replay')}</button><button class="tog" data-act="itog" type="button" aria-pressed="${ST.cfg.intro !== false}" aria-label="${T('Bật tắt intro mở đầu', 'Opening intro on or off')}"></button></span></div>
    <div class="row"><span>${T('Ghim bảng mê cung khi cuộn', 'Keep the maze in view')}<br><span class="muted">${T('bảng và nút Chạy luôn hiện, khỏi cuộn lên xuống', 'the board and Run button stay on screen while you scroll')}</span></span><button class="tog" data-act="stick" type="button" aria-pressed="${ST.cfg.stick !== false}" aria-label="${T('Bật tắt ghim bảng mê cung', 'Pin the maze board on or off')}"></button></div>
    ${G.multi() ? `<div class="row"><span>${T('Ngôn ngữ', 'Language')}</span><span class="actions" style="margin:0">${G.LANGS.map(x => `<button class="btn sm${G.lang === x[0] ? ' primary' : ' ghost'}" data-act="lang" data-v="${x[0]}" type="button" lang="${x[0]}">${x[1]}</button>`).join('')}</span></div>` : ''}
    <div class="row"><span>${T('Giao diện', 'Theme')}</span><span class="actions" style="margin:0">${['auto', 'light', 'dark'].map(t => `<button class="btn sm${th === t ? ' primary' : ' ghost'}" data-act="theme" data-v="${t}" type="button">${{ auto: T('Tự động', 'Auto'), light: T('Sáng', 'Light'), dark: T('Tối', 'Dark') }[t]}</button>`).join('')}</span></div>
    <div style="padding:10px 0"><b>${T('Mã lưu', 'Save code')}</b><p class="muted" style="margin:2px 0">${T('Chép mã này để chuyển tiến độ sang máy khác.', 'Copy this code to move your progress to another device.')}</p><div class="codebox" id="savecode">${esc(saveCode())}</div><button class="btn sm" data-act="copycode" type="button">${ico('copy', 15)} ${T('Sao chép mã', 'Copy code')}</button></div>
    <div style="padding:6px 0 10px"><b>${T('Nạp mã lưu', 'Load a save code')}</b><input class="fld" id="codein" placeholder="HT-XXXX-XXXX-..." autocomplete="off" spellcheck="false" aria-label="${T('Mã lưu', 'Save code')}"><div class="actions"><button class="btn sm" data-act="loadcode" type="button">${T('Nạp mã', 'Load')}</button></div></div>
    <p class="muted" style="margin:6px 0 12px;font-size:.82rem">${T('Tiến độ chỉ được lưu trên thiết bị của bạn. Game không thu thập dữ liệu cá nhân và chạy được khi không có mạng.', 'Your progress is stored only on your device. The game collects no personal data and works offline.')} · v${VERSION}</p>
    <p class="muted" style="margin:0 0 12px;font-size:.78rem">${ico('info', 13)} © ${BRAND.year} ${esc(BRAND.owner)} · ${T('Mã nguồn', 'Code')}: ${BRAND.code} · ${T('Nội dung bài học', 'Lesson content')}: ${BRAND.content}. ${T('Dự án không chính thức, không liên kết với Rust Foundation. “Rust” là nhãn hiệu của Rust Foundation.', 'Unofficial project, not affiliated with the Rust Foundation. “Rust” is a trademark of the Rust Foundation.')}</p>
    <div class="actions"><button class="btn sm ghost" data-act="reset" type="button">${confirm ? T('Chạm lần nữa để xóa hết tiến độ', 'Tap again to erase all progress') : T('Xóa tiến độ', 'Erase progress')}</button><button class="btn primary" data-act="close" type="button">${T('Xong', 'Done')}</button></div></div>`;
  b.addEventListener('click', e => { if (e.target === b) closeSheet(); });
  document.body.appendChild(b);
}
const closeSheet = () => { const s = $('#sheet'); if (s) s.remove(); };

/* ---------- điều phối ---------- */
function render() {
  const el = $('#app'); CH = null;
  el.innerHTML = app.view === 'lesson' ? viewLesson() : app.view === 'book' ? viewBook() : viewMap();
  if (app.view === 'lesson') fillPanel();
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t || t.disabled) return;
  const a = t.dataset.act, v = t.dataset.v;
  if (a === 'open') go('lesson', +v, ST.done[+v] ? 1 : 0);
  else if (a === 'next') go('lesson', +v, 0);
  else if (a === 'map') go('map');
  else if (a === 'book') go('book');
  else if (a === 'stage') { app.stage = +v; render(); window.scrollTo(0, 0); }
  else if (a === 'hint') { if (!CH) return; CH.hinted = true; $('#hintbox').innerHTML = `<div class="hintbox">${ico('bulb', 16)} ${md(CH.L.ch.hint || T('Hãy đọc kỹ đề, thử từng bước nhỏ.', 'Read the task carefully and try one small step at a time.'))}</div>`; }
  else if (a === 'peek') { if (!CH) return; CH.peeked = true; $('#solbox').innerHTML = `<div class="solbox"><b>${T('Lời giải mẫu', 'Sample solution')}</b>${CH.ctl.solution()}</div>`; }
  else if (a === 'redo') { $('#tgot').innerHTML = ''; app.rebuildTrick(); }
  else if (a === 'copytrick') copyText(trickCode(G.all[+v - 1]));
  else if (a === 'copyall') copyText(G.all.filter(L => ST.trick[L.n]).map(L => `// ===== ${T('Bài', 'Lesson')} ${L.n}: ${L.trick.name} =====\n${trickCode(L)}`).join('\n\n'));
  else if (a === 'lang') { ST.cfg.lang = v === 'en' ? 'en' : 'vi'; save(); G.setLang(ST.cfg.lang); if ($('#sheet')) openSheet(); render(); }
  else if (a === 'qtog') { ST.cfg.quote = ST.cfg.quote === false; save(); openSheet(); }
  else if (a === 'quote') openQuote();
  else if (a === 'itog') { ST.cfg.intro = ST.cfg.intro === false; save(); openSheet(); }
  else if (a === 'intro') playIntro();
  else if (a === 'stick') { ST.cfg.stick = ST.cfg.stick === false; save(); applyStick(); openSheet(); }
  else if (a === 'settings') openSheet();
  else if (a === 'close') closeSheet();
  else if (a === 'sound') { ST.cfg.sound = !ST.cfg.sound; save(); openSheet(); }
  else if (a === 'free') { ST.cfg.free = !ST.cfg.free; save(); openSheet(); if (app.view === 'map') render(); }
  else if (a === 'theme') { ST.cfg.theme = v; save(); applyTheme(); openSheet(); }
  else if (a === 'copycode') copyText(saveCode());
  else if (a === 'loadcode') { if (loadCode($('#codein').value)) { toast(T('Đã nạp tiến độ', 'Progress loaded')); closeSheet(); go('map'); } else toast(T('Mã không hợp lệ, kiểm tra lại', 'Invalid code, please check it'), 'bad'); }
  else if (a === 'reset') { if (t.dataset.arm) { ST.done = {}; ST.trick = {}; save(); closeSheet(); go('map'); toast(T('Đã xóa tiến độ', 'Progress erased')); } else { openSheet(true); $('[data-act="reset"]').dataset.arm = '1'; } }
});
const applyStick = () => document.documentElement.setAttribute('data-stick', ST.cfg.stick === false ? 'off' : 'on');
/* intro mở đầu (gói do chủ dự án cung cấp): chữ theo ngôn ngữ, giọng tiếng Việt nên bản English chạy hình không tiếng */
function playIntro(done) {
  const RI = window.RustIntro; if (!RI) { if (done) done(); return; }
  const en = G.lang !== 'vi';
  RI.play({ muted: !ST.cfg.sound || en, words: en ? ['Journey', 'into'] : null, big: 'Rust', tag: T('Từ con số 0 đến bậc thầy', 'From zero to master'), onDone: done });
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeSheet();
  const ri = document.querySelector('.ri-root'); if (ri && (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); ri.click(); }
});
function init() {
  G.finalize(); load(); G.setLang(ST.cfg.lang || G.detectLang()); applyTheme(); applyStick(); touchStreak(); render();
  const after = () => { if (ST.cfg.quote !== false && ST.cfg.qday !== dayKey()) { ST.cfg.qday = dayKey(); save(); openQuote(); } };
  if (ST.cfg.intro !== false) playIntro(after); else after();
  document.documentElement.classList.remove('boot');
}
