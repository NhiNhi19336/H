/* ===== Ba engine chữ: quiz (trắc nghiệm), order (ghép mã), bug (bắt lỗi) ===== */
(() => {
  const perm = (n, seed) => shuffled(Array.from({ length: n }, (_, i) => i), seed);

  /* tự thụt lề giống rustfmt để mảnh ghép không lộ thứ tự qua khoảng trắng */
  const fmt = ls => {
    let d = 0;
    return ls.map(t => {
      t = t.trim();
      const s = t.replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])'/g, '');
      const lead = (s.match(/^[})\]]+/) || [''])[0].length;
      const net = (s.match(/[{(\[]/g) || []).length - (s.match(/[})\]]/g) || []).length;
      d = Math.max(0, d - lead); const o = '    '.repeat(d) + t; d = Math.max(0, d + net + lead); return o;
    });
  };
  G.fmt = fmt;

  /* ---- quiz ---- */
  G.engines.quiz = {
    mount(host, st, api) {
      const qs = st.qs; let qi = 0, done = false;
      function draw() {
        const q = qs[qi], ord = perm(q.opts.length, hashStr(q.q)); done = false;
        host.innerHTML = `<div class="qz"><span class="pill">${T('Câu', 'Question')} <b>${qi + 1}</b>/${qs.length}</span>
          <p class="qz-q">${md(q.q)}</p>${q.code ? codeHTML(q.code) : ''}
          <div class="opts">${ord.map((i, n) => `<button class="opt" data-i="${i}" type="button"><span class="lt">${'ABCDEF'[n]}</span><span class="o">${md(q.opts[i])}</span></button>`).join('')}</div>
          <div class="fb" role="status"></div></div>`;
      }
      host.onclick = e => {
        if (e.target.closest('[data-next]')) { qi++; draw(); return; }
        const b = e.target.closest('.opt'); if (!b || done || b.disabled) return;
        const q = qs[qi], fb = $('.fb', host);
        if (+b.dataset.i === q.ans) {
          done = true; b.classList.add('good'); $$('.opt', host).forEach(x => { x.disabled = true; }); sfx('ok');
          const last = qi === qs.length - 1;
          fb.className = 'fb ok';
          fb.innerHTML = `<b>${T('Chính xác.', 'Correct.')}</b> ${md(q.why || '')}` + (last ? '' : ` <button class="btn sm primary" data-next type="button">${T('Câu tiếp', 'Next question')} ${ico('next', 14)}</button>`);
          if (last) api.win({ cap: 3 });
        } else {
          b.disabled = true; b.classList.add('bad'); sfx('bad'); api.mistake();
          fb.className = 'fb bad'; fb.textContent = T('Chưa đúng, thử đáp án khác.', 'Not quite, try another answer.');
        }
      };
      draw();
      return { solution: () => qs.map(q => `<p class="sol-q">${md(q.q)}</p><p class="sol-a">${md(q.opts[q.ans])}</p>`).join('') };
    }
  };

  /* ---- order: ghép các mảnh mã thành chương trình đúng ---- */
  G.engines.order = {
    mount(host, st, api) {
      const exp = st.lines.map(t => t.trim()), pre = [].concat(st.pre || []), post = [].concat(st.post || []);
      const items = shuffled(exp.concat(st.decoys || []), hashStr(exp.join('|'))).map((t, id) => ({ t, id }));
      let placed = [];
      host.innerHTML = `<div class="ord"><div class="ord-prog code"></div><div class="ord-bank"></div><p class="msg" role="status"></p><div class="out"></div>
        <div class="actions"><button class="btn primary" data-run type="button">${ico('play', 16)} ${esc(st.btn || T('Chạy', 'Run'))}</button><button class="btn ghost" data-clear type="button">${ico('reset', 16)} ${T('Làm lại', 'Start over')}</button></div></div>`;
      const msg = (t, k) => { const m = $('.msg', host); m.textContent = t || ''; m.className = 'msg ' + (k || ''); };
      function draw(bad) {
        const f = fmt(pre.concat(placed.map(id => items[id].t), post));
        $('.ord-prog', host).innerHTML = f.map((t, i) => {
          const p = i - pre.length;
          return p >= 0 && p < placed.length
            ? `<button class="oline${bad && bad.includes(p) ? ' err' : ''}" data-rm="${p}" type="button" aria-label="${T('Bỏ dòng này ra', 'Remove this line')}">${hl(t)}</button>`
            : `<div class="oline fixed">${hl(t)}</div>`;
        }).join('') + (placed.length < exp.length ? `<div class="oline ph">${T('Chạm một mảnh mã bên dưới để đặt vào đây', 'Tap a code piece below to place it here')}</div>` : '');
        const used = new Set(placed);
        $('.ord-bank', host).innerHTML = items.filter(it => !used.has(it.id)).map(it => `<button class="chip" data-add="${it.id}" type="button">${hl(it.t)}</button>`).join('') || `<span class="muted">${T('Đã dùng hết các mảnh.', 'All pieces are used.')}</span>`;
      }
      function check() {
        const got = placed.map(id => items[id].t);
        if (got.length < exp.length) { msg(T(`Cần ${exp.length} dòng, bạn mới đặt ${got.length}.`, `You need ${exp.length} lines, but you have placed ${got.length}.`), 'bad'); return; }
        const bad = []; got.forEach((t, i) => { if (t !== exp[i]) bad.push(i); });
        if (!bad.length && got.length === exp.length) {
          if (st.out != null) $('.out', host).innerHTML = termHTML(st.out);
          msg(''); sfx('ok'); api.win({ cap: 3 });
        } else { draw(bad); msg(T('Có dòng chưa đúng chỗ (viền đỏ). Chạm vào dòng để gỡ ra, rồi đặt lại.', 'Some lines are in the wrong place (red edge). Tap a line to remove it, then place it again.'), 'bad'); sfx('bad'); api.mistake(); }
      }
      host.onclick = e => {
        const t = e.target.closest('[data-add],[data-rm],[data-run],[data-clear]'); if (!t || host.classList.contains('locked')) return;
        if (t.dataset.add) { placed.push(+t.dataset.add); sfx('tap'); msg(''); draw(); }
        else if (t.dataset.rm) { placed.splice(+t.dataset.rm, 1); msg(''); draw(); }
        else if (t.dataset.clear !== undefined) { placed = []; msg(''); draw(); }
        else if (t.dataset.run !== undefined) check();
      };
      draw();
      return { solution: () => codeHTML(fmt(pre.concat(exp, post)).join('\n')) };
    }
  };

  /* ---- bug: chạm dòng bị trình biên dịch từ chối rồi chọn cách sửa ---- */
  G.engines.bug = {
    mount(host, st, api) {
      const L = st.code.replace(/\n$/, '').split('\n'), at = st.fixAt == null ? st.bad : st.fixAt;
      let phase = 1; const tried = new Set();
      const fixed = () => L.map((t, i) => (i === at ? t.match(/^\s*/)[0] + st.fixes[st.fix].trim() : t)).join('\n');
      function draw() {
        const lines = L.map((t, i) => `<button class="bl${phase === 2 && i === st.bad ? ' hot' : ''}${tried.has(i) ? ' bad' : ''}" data-l="${i}" type="button"><span class="no">${i + 1}</span><span class="tx">${hl(t) || '&nbsp;'}</span></button>`).join('');
        let h = `<p class="bug-q">${phase === 1 ? T('Trình biên dịch sẽ <b>từ chối</b> chương trình này. Chạm vào dòng bị báo lỗi.', 'The compiler will <b>reject</b> this program. Tap the line it complains about.') : T('Đây là lời của trình biên dịch. Chọn cách sửa đúng.', 'This is what the compiler says. Choose the right fix.')}</p><div class="code bugcode">${lines}</div>`;
        if (phase === 2) h += errHTML(st.err) + `<div class="opts">${perm(st.fixes.length, hashStr(st.code)).map(i => `<button class="opt codeopt" data-f="${i}" type="button"><span class="o">${hl(st.fixes[i].trim())}</span></button>`).join('')}</div>`;
        host.innerHTML = `<div class="bug">${h}<div class="fb" role="status"></div></div>`;
      }
      host.onclick = e => {
        const l = e.target.closest('[data-l]'), f = e.target.closest('[data-f]'), fb = $('.fb', host);
        if (phase === 1 && l) {
          const i = +l.dataset.l;
          if (i === st.bad) { phase = 2; sfx('ok'); draw(); }
          else { tried.add(i); l.classList.add('bad'); sfx('bad'); api.mistake(); fb.className = 'fb bad'; fb.textContent = T('Dòng này vẫn hợp lệ. Đọc lại từng dòng và xem biến nào đang bị dùng sai.', 'This line is fine. Read each line again and look for a variable that is used wrongly.'); }
        } else if (phase === 2 && f) {
          if (+f.dataset.f === st.fix) {
            phase = 3; sfx('ok');
            host.innerHTML = `<div class="bug"><p class="bug-q">${T('Đã sửa xong, chương trình biên dịch được.', 'Fixed! The program compiles now.')}</p>${codeHTML(fixed())}<div class="fb ok">${md(st.why || '')}</div></div>`;
            api.win({ cap: 3 });
          } else { f.disabled = true; f.classList.add('bad'); sfx('bad'); api.mistake(); fb.className = 'fb bad'; fb.textContent = T('Cách sửa này chưa làm lỗi biến mất. Thử cách khác.', 'This fix does not remove the error. Try another one.'); }
        }
      };
      draw();
      return { solution: () => codeHTML(fixed()) };
    }
  };
})();
