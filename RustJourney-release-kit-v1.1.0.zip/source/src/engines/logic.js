/* ===== logic: bảng chân trị bằng công tắc  |  cells: chạm đúng ô (chỉ số, tọa độ, lát cắt) ===== */
(() => {
  const evalE = (expr, vars, vals) => !!new Function(...vars, 'return (' + expr + ');')(...vals);
  const bulb = on => `<svg class="bulb${on ? ' on' : ''}" viewBox="0 0 48 60" width="44" height="54" aria-hidden="true"><path d="M24 4a15 15 0 00-8.5 27.4c1.6 1.2 2.5 3 2.5 5V40h12v-3.6c0-2 .9-3.8 2.5-5A15 15 0 0024 4z"/><path d="M18 46h12M20 52h8"/></svg>`;

  /* ---- logic ---- */
  G.engines.logic = {
    rows(R) { const n = R.vars.length, out = []; for (let m = 0; m < (1 << n); m++) { const v = R.vars.map((_, i) => !!(m >> (n - 1 - i) & 1)); out.push({ v, r: evalE(R.expr, R.vars, v) }); } return out; },
    mount(host, st, api) {
      let ri = 0, R, rows, val, found, seen, need;
      const key = v => v.map(b => +b).join('');
      function start() {
        R = st.rounds[ri]; rows = G.engines.logic.rows(R); val = R.vars.map(() => false); found = new Set(); seen = new Set();
        need = rows.filter(r => r.r === R.want).length; draw();
      }
      function draw(msg, cls) {
        const cur = evalE(R.expr, R.vars, val);
        host.innerHTML = `<div class="lg"><span class="pill">${T('Vòng', 'Round')} <b>${ri + 1}</b>/${st.rounds.length}</span>
          <p class="qz-q">${md(R.q || T(`Bật tắt công tắc để đèn **${R.want ? 'sáng' : 'tắt'}** (biểu thức bằng \`${R.want}\`). Tìm đủ **${need}** cách khác nhau.`, `Flip the switches so the lamp is **${R.want ? 'on' : 'off'}** (the expression equals \`${R.want}\`). Find **${need}** different ways.`))}</p>
          ${codeHTML('let den = ' + R.expr + ';')}
          <div class="lg-row"><div class="sws">${R.vars.map((v, i) => `<button class="sw${val[i] ? ' on' : ''}" data-sw="${i}" type="button" aria-pressed="${val[i]}"><span class="sn">${v}</span><span class="st">${val[i]}</span></button>`).join('')}</div>
          <div class="lamp">${bulb(cur)}<code>${cur}</code></div></div>
          <table class="tt"><thead><tr>${R.vars.map(v => `<th>${v}</th>`).join('')}<th>den</th></tr></thead><tbody>${rows.map(r => { const k = key(r.v); return `<tr class="${found.has(k) ? 'good' : seen.has(k) ? 'dim' : ''}">${r.v.map(b => `<td>${b}</td>`).join('')}<td>${seen.has(k) ? r.r : '?'}</td></tr>`; }).join('')}</tbody></table>
          <p class="msg ${cls || ''}" role="status">${esc(msg || T(`Đã tìm ${found.size}/${need}`, `Found ${found.size}/${need}`))}</p>
          <div class="actions"><button class="btn primary" data-rec type="button">${ico('check', 16)} ${T('Ghi lại cách này', 'Record this combination')}</button></div></div>`;
      }
      host.onclick = e => {
        const s = e.target.closest('[data-sw]'), r = e.target.closest('[data-rec]');
        if (s) { val[+s.dataset.sw] = !val[+s.dataset.sw]; sfx('tap'); draw(); }
        else if (r) {
          const k = key(val), res = evalE(R.expr, R.vars, val);
          if (res !== R.want) { seen.add(k); sfx('bad'); api.mistake(); draw(T(`Đèn đang ${res ? 'sáng' : 'tắt'}, chưa đúng yêu cầu.`, `The lamp is ${res ? 'on' : 'off'}, which is not what was asked.`), 'bad'); }
          else if (found.has(k)) draw(T('Cách này bạn ghi rồi, hãy thử tổ hợp khác.', 'You already recorded this one, try another combination.'), 'bad');
          else {
            found.add(k); seen.add(k); sfx('ok');
            if (found.size === need) { if (ri === st.rounds.length - 1) { draw(T('Đã tìm đủ!', 'Found them all!'), 'ok'); api.win({ cap: 3 }); } else { ri++; draw(T('Đủ rồi! Sang vòng tiếp theo.', 'That is all of them! On to the next round.'), 'ok'); setTimeout(start, 900); } }
            else draw(T(`Đúng! Đã tìm ${found.size}/${need}`, `Correct! Found ${found.size}/${need}`), 'ok');
          }
        }
      };
      start();
      return { solution: () => st.rounds.map(R => `<p class="sol-q">${codeHTML('let den = ' + R.expr + ';')}</p><p class="sol-a">${G.engines.logic.rows(R).filter(r => r.r === R.want).map(r => `<code>${R.vars.map((v, i) => `${v}=${r.v[i]}`).join(', ')}</code>`).join(' ')}</p>`).join('') };
    }
  };

  /* ---- cells ---- */
  G.engines.cells = {
    mount(host, st, api) {
      let ri = 0, R, sel, done;
      const isAns = i => (Array.isArray(R.ans) ? R.ans.includes(i) : i === R.ans);
      function start() { R = st.rounds[ri]; sel = []; done = false; draw(); }
      function draw(msg, cls) {
        const W = R.W || R.vals.length, lo = sel.length ? Math.min(...sel) : -1, hi = sel.length ? Math.max(...sel) : -1;
        const ax = R.axes, H = Math.ceil(R.vals.length / W);
        let cells = '';
        if (ax) { cells += '<span class="ax"></span>'; for (let x = 0; x < W; x++) cells += `<span class="ax">${x}</span>`; }
        R.vals.forEach((v, i) => {
          if (ax && i % W === 0) cells += `<span class="ax">${Math.floor(i / W)}</span>`;
          const on = sel.length && i >= lo && i <= hi;
          cells += `<button class="cell${on ? ' sel' : ''}${done && R.kind !== 'range' && isAns(i) ? ' good' : ''}" data-i="${i}" type="button"${done ? ' disabled' : ''}><span class="v">${esc(v)}</span>${R.show || done ? `<i>${i}</i>` : ''}</button>`;
        });
        host.innerHTML = `<div class="cl"><span class="pill">${T('Câu', 'Question')} <b>${ri + 1}</b>/${st.rounds.length}</span>
          <p class="qz-q">${md(R.q)}</p>${R.code ? codeHTML(R.code) : ''}
          <div class="cgrid${R.sm ? ' sm' : ''}" style="--w:${W + (ax ? 1 : 0)}">${cells}</div>
          <p class="msg ${cls || ''}" role="status">${md(msg || '')}</p>
          ${done && ri < st.rounds.length - 1 ? `<div class="actions"><button class="btn primary" data-next type="button">${T('Câu tiếp', 'Next question')} ${ico('next', 14)}</button></div>` : ''}</div>`;
      }
      function good() {
        done = true; sfx('ok');
        if (ri === st.rounds.length - 1) { draw(R.why || T('Chính xác!', 'Correct!'), 'ok'); api.win({ cap: 3 }); } else draw(R.why || T('Chính xác!', 'Correct!'), 'ok');
      }
      host.onclick = e => {
        if (e.target.closest('[data-next]')) { ri++; start(); return; }
        const c = e.target.closest('[data-i]'); if (!c || done) return; const i = +c.dataset.i;
        if (R.kind === 'range') {
          sel.push(i);
          if (sel.length === 1) { sfx('tap'); draw(T('Chạm tiếp ô cuối của lát cắt.', 'Now tap the last cell of the slice.')); return; }
          const lo = Math.min(...sel), hi = Math.max(...sel);
          if (lo === R.ans[0] && hi === R.ans[1]) { good(); }
          else { sel = []; sfx('bad'); api.mistake(); draw(T('Chưa đúng. Nhớ rằng `a..b` lấy từ a và dừng **trước** b.', 'Not quite. Remember that `a..b` starts at a and stops **before** b.'), 'bad'); }
        } else if (isAns(i)) good();
        else { sfx('bad'); api.mistake(); draw(R.miss || T('Chưa đúng ô. Tính lại chỉ số rồi thử tiếp.', 'Not that cell. Work out the index again and retry.'), 'bad'); }
      };
      start();
      return { solution: () => st.rounds.map(R => `<p class="sol-q">${md(R.q)}</p><p class="sol-a">${R.kind === 'range' ? T(`ô ${R.ans[0]} đến ô ${R.ans[1]}`, `cell ${R.ans[0]} to cell ${R.ans[1]}`) : T(`ô số ${R.ans}`, `cell ${R.ans}`)}</p>`).join('') };
    }
  };
})();
