/* ===== Bot: lập trình robot trên lưới (tư duy không gian) ===== */
G.robot = (() => {
  const S = 40;
  const DIRS = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  const DCH = { N: 0, E: 1, S: 2, W: 3 };
  const COND = { wall_ahead: 'bot.wall_ahead()', wall_left: 'bot.wall_left()', wall_right: 'bot.wall_right()', at_goal: 'bot.at_goal()', on_coin: 'bot.on_coin()' };
  const ctext = c => (c[0] === '!' ? '!' : '') + COND[c.replace('!', '')];

  function parse(level) {
    const rows = level.grid, H = rows.length, W = rows[0].length;
    let s = null, g = null; const coins = [], wall = [];
    for (let y = 0; y < H; y++) {
      wall[y] = [];
      for (let x = 0; x < W; x++) { const c = rows[y][x]; wall[y][x] = c === '#'; if (c === 'S') s = [x, y]; else if (c === 'G') g = [x, y]; else if (c === '*') coins.push([x, y]); }
    }
    return { W, H, wall, s, g, coins };
  }
  function make(id) {
    const [k, a] = id.split(':');
    switch (k) {
      case 'forward': case 'left': case 'right': case 'grab': case 'break': return { k };
      case 'for': return { k, n: +a || 3, body: [] };
      case 'while': return { k, c: a, body: [] };
      case 'loop': return { k, body: [] };
      case 'if': return { k, c: a, then: [] };
      case 'ifelse': return { k: 'if', c: a, then: [], els: [] };
      case 'call': return { k, f: a };
    }
  }
  function label(b, ctx) {
    switch (b.k) {
      case 'forward': return 'bot.forward();';
      case 'left': return 'bot.turn_left();';
      case 'right': return 'bot.turn_right();';
      case 'grab': return 'bot.grab();';
      case 'break': return 'break;';
      case 'for': return `for _ in 0..${b.n} {`;
      case 'while': return `while ${ctext(b.c)} {`;
      case 'loop': return 'loop {';
      case 'if': return `if ${ctext(b.c)} {`;
      case 'call': return ctx === 'fn' ? `${b.f}(bot);` : `${b.f}(&mut bot);`;
    }
    return '';
  }
  const cnt = l => l.reduce((n, b) => n + (b.locked ? 0 : 1) + (b.body ? cnt(b.body) : 0) + (b.then ? cnt(b.then) : 0) + (b.els ? cnt(b.els) : 0), 0);
  const count = p => cnt(p.main || []) + Object.keys(p.fns || {}).reduce((n, f) => n + cnt(p.fns[f]), 0);

  /* Cú pháp rút gọn để viết lời giải: F L R G B, for:3{ }, while:c{ }, loop{ }, if:c{ }else{ }, call:f, fn:f{ }, tiền tố ! = khối khóa */
  function parseProg(src) {
    const TK = src.replace(/([{}])/g, ' $1 ').trim().split(/\s+/).filter(Boolean), SIMPLE = { F: 'forward', L: 'left', R: 'right', G: 'grab', B: 'break' }, fns = {};
    let i = 0;
    function list() {
      const out = [];
      while (i < TK.length && TK[i] !== '}') {
        let t = TK[i++], lock = false; if (t[0] === '!') { lock = true; t = t.slice(1); }
        let b;
        if (SIMPLE[t]) b = { k: SIMPLE[t] };
        else {
          const [k, a] = t.split(':');
          if (k === 'fn') { i++; fns[a] = list(); i++; continue; }
          if (k === 'call') b = { k, f: a };
          else {
            b = k === 'if' ? { k, c: a, then: [] } : k === 'for' ? { k, n: +a, body: [] } : k === 'while' ? { k, c: a, body: [] } : { k: 'loop', body: [] };
            i++; const body = list(); i++;
            if (k === 'if') { b.then = body; if (TK[i] === 'else') { i += 2; b.els = list(); i++; } } else b.body = body;
          }
        }
        if (lock) b.locked = true; out.push(b);
      }
      return out;
    }
    const main = list(); return { main, fns };
  }

  function run(level, prog, lim) {
    const M = parse(level), maxSteps = (lim && lim.steps) || 3000;
    let x = M.s[0], y = M.s[1], d = DCH[level.dir || 'E'], steps = 0, fail = null;
    const got = new Set(), trace = [{ x, y, d, got: [], id: null }];
    const wallAt = (nx, ny) => nx < 0 || ny < 0 || nx >= M.W || ny >= M.H || M.wall[ny][nx];
    const ahead = dd => { const v = DIRS[((dd % 4) + 4) % 4]; return wallAt(x + v[0], y + v[1]); };
    const cond = c => {
      let neg = false; if (c[0] === '!') { neg = true; c = c.slice(1); }
      let v = false;
      if (c === 'wall_ahead') v = ahead(d); else if (c === 'wall_left') v = ahead(d + 3); else if (c === 'wall_right') v = ahead(d + 1);
      else if (c === 'at_goal') v = x === M.g[0] && y === M.g[1];
      else if (c === 'on_coin') v = M.coins.some(k => k[0] === x && k[1] === y) && !got.has(x + ',' + y);
      return neg ? !v : v;
    };
    const snap = id => trace.push({ x, y, d, got: Array.from(got), id });
    const bad = (why, id) => { fail = { why, id }; return 'x'; };
    function exec(list, depth) {
      for (const b of list) {
        if (++steps > maxSteps) return bad('limit', b.id);
        switch (b.k) {
          case 'forward': { const v = DIRS[d]; if (wallAt(x + v[0], y + v[1])) { snap(b.id); return bad('crash', b.id); } x += v[0]; y += v[1]; snap(b.id); break; }
          case 'left': d = (d + 3) % 4; snap(b.id); break;
          case 'right': d = (d + 1) % 4; snap(b.id); break;
          case 'grab': if (M.coins.some(k => k[0] === x && k[1] === y)) got.add(x + ',' + y); snap(b.id); break;
          case 'break': return 'b';
          case 'for': for (let i = 0; i < b.n; i++) { const r = exec(b.body, depth); if (r === 'x') return r; if (r === 'b') break; } break;
          case 'while': case 'loop':
            for (let g = 0; ; g++) {
              if (g > 500) return bad('limit', b.id);
              if (b.k === 'while') { snap(b.id); if (!cond(b.c)) break; }
              const r = exec(b.body, depth); if (r === 'x') return r; if (r === 'b') break;
            }
            break;
          case 'if': { snap(b.id); const l = cond(b.c) ? b.then : b.els; if (l) { const r = exec(l, depth); if (r === 'x' || r === 'b') return r; } break; }
          case 'call': { if (depth > 40) return bad('limit', b.id); const f = prog.fns && prog.fns[b.f]; if (f) { const r = exec(f, depth + 1); if (r === 'x') return r; } break; }
        }
      }
      return null;
    }
    exec(prog.main || [], 0);
    let ok = false, why = fail ? fail.why : null;
    if (!fail) {
      const atG = x === M.g[0] && y === M.g[1];
      const needAll = level.need === 'all' || (level.need !== 'goal' && M.coins.length > 0);
      const allC = M.coins.every(k => got.has(k[0] + ',' + k[1]));
      if (!atG) why = 'nogoal'; else if (needAll && !allC) why = 'coins'; else ok = true;
    }
    return { ok, why, trace, steps, blocks: count(prog), fail };
  }

  function toRust(prog) {
    const out = [];
    const emit = (list, ind, ctx) => list.forEach(b => {
      const p = '    '.repeat(ind);
      if (b.body) { out.push(p + label(b, ctx)); emit(b.body, ind + 1, ctx); out.push(p + '}'); }
      else if (b.then) { out.push(p + label(b, ctx)); emit(b.then, ind + 1, ctx); if (b.els) { out.push(p + '} else {'); emit(b.els, ind + 1, ctx); } out.push(p + '}'); }
      else out.push(p + label(b, ctx));
    });
    Object.keys(prog.fns || {}).forEach(f => { out.push(`fn ${f}(bot: &mut Bot) {`); emit(prog.fns[f], 1, 'fn'); out.push('}', ''); });
    out.push('fn main() {', '    let mut bot = Bot::new();'); emit(prog.main, 1, 'main'); out.push('}');
    return out.join('\n');
  }

  function board(M) {
    let s = `<svg viewBox="0 0 ${M.W * S} ${M.H * S}" class="board" role="img" aria-label="${T('Bàn cờ của Bot', 'The Bot board')}">`;
    for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
      const X = x * S, Y = y * S;
      if (M.wall[y][x]) s += `<g class="wall"><rect x="${X}" y="${Y}" width="${S}" height="${S}"/><path d="M${X + 3} ${Y + S / 2}H${X + S - 3}M${X + S / 2} ${Y + 3}V${Y + S / 2}M${X + S / 4} ${Y + S / 2}V${Y + S - 3}M${X + 3 * S / 4} ${Y + S / 2}V${Y + S - 3}"/></g>`;
      else s += `<rect class="t${(x + y) & 1}" x="${X}" y="${Y}" width="${S}" height="${S}"/>`;
    }
    s += `<g class="goal" transform="translate(${M.g[0] * S + S / 2} ${M.g[1] * S + S / 2})"><circle r="16"/><circle r="10"/><path d="M-3 -8V8M-3 -8L7 -4L-3 0"/></g>`;
    M.coins.forEach(c => { s += `<g class="coin" data-k="${c[0]},${c[1]}" transform="translate(${c[0] * S + S / 2} ${c[1] * S + S / 2})"><rect x="-7" y="-7" width="14" height="14" rx="2" transform="rotate(45)"/><path d="M-3 -1L0 -5L3 -1"/></g>`; });
    s += '<g id="rb-bot" class="bot"><rect class="bb" x="-13" y="-12" width="26" height="25" rx="7"/><rect class="bv" x="-9" y="-10" width="18" height="9" rx="3"/><circle class="be" cx="-4" cy="-5.5" r="2"/><circle class="be" cx="4" cy="-5.5" r="2"/><path class="bn" d="M-5 -14L0 -21L5 -14Z"/><circle class="bt" cx="0" cy="8" r="2.5"/></g></svg>';
    return s;
  }

  const FAIL = () => ({
    crash: T('Bot đâm vào tường! Xem lại số bước đi hoặc hướng rẽ.', 'The Bot hit a wall! Check the number of steps or the turns.'),
    limit: T('Chương trình chạy mãi không dừng. Kiểm tra điều kiện lặp.', 'The program never stops. Check the loop condition.'),
    nogoal: T('Chương trình chạy xong nhưng Bot chưa đứng trên ô cờ đích.', 'The program finished, but the Bot is not on the goal flag.'),
    coins: T('Bot tới đích rồi nhưng còn gem chưa nhặt. Thêm bot.grab(); đúng chỗ.', 'The Bot reached the goal but left some gems behind. Add bot.grab(); in the right place.'),
  });

  function mount(host, st, api) {
    const M = parse(st), maxB = st.max || 99, pal = st.palette || [];
    const prog = st.pre ? clone(typeof st.pre === 'string' ? parseProg(st.pre) : st.pre) : { main: [], fns: {} }; prog.fns = prog.fns || {};
    (st.fns || []).forEach(f => { prog.fns[f] = prog.fns[f] || []; });
    let nid = 1; const ids = l => l.forEach(b => { b.id = nid++; ids(b.body || []); ids(b.then || []); ids(b.els || []); });
    ids(prog.main); Object.keys(prog.fns).forEach(f => ids(prog.fns[f]));
    let cur = st.cursor || 'main', busy = false, spd = 0, token = 0, finished = false;
    const d0 = DCH[st.dir || 'E']; let ang = d0 * 90, curD = d0;

    host.innerHTML = `<div class="rb"><div class="rb-grid"><div class="rb-left">
      <div class="rb-board" style="--bw:${M.W};--bh:${M.H};--mw:${Math.min(540, M.W * 62)}px;--k:${Math.max(M.W, M.H) >= 9 ? 1.3 : 1}">${board(M)}</div>
      <div class="rb-bar"><span class="pill">${T('Khối', 'Blocks')} <b id="rb-cnt"></b></span><span class="grow"></span><button class="btn sm ghost" data-speed type="button">${T('Tốc độ ×1', 'Speed ×1')}</button></div>
      <p class="msg" id="rb-msg" role="status"></p></div>
      <div class="rb-right"><div class="rb-code code" id="rb-prog"></div>
      <div class="rb-pal" id="rb-pal"></div></div></div>
      <div class="actions rb-actions"><button class="btn primary" data-run type="button">${ico('play', 16)} ${T('Chạy', 'Run')}</button><button class="btn ghost" data-reset type="button" aria-label="${T('Đặt lại Bot', 'Reset Bot')}" title="${T('Đặt lại Bot', 'Reset Bot')}">${ico('reset', 16)}<span class="bt"> ${T('Đặt lại Bot', 'Reset Bot')}</span></button><button class="btn ghost" data-clear type="button" aria-label="${T('Xóa hết', 'Clear all')}" title="${T('Xóa hết', 'Clear all')}">${ico('trash', 16)}<span class="bt"> ${T('Xóa hết', 'Clear all')}</span></button></div></div>`;
    const botEl = $('#rb-bot', host), msgEl = $('#rb-msg', host);
    const msg = (t, k) => { msgEl.textContent = t || ''; msgEl.className = 'msg ' + (k || ''); };

    const res = p => { const sg = p.split('/'); let l = sg[0] === 'main' ? prog.main : prog.fns[sg[0].slice(3)]; for (let i = 1; i < sg.length; i++) { const t = sg[i].split('.'); l = l[+t[0]][t[1]]; } return l; };
    const slot = (p, ind) => `<button class="slot${p === cur ? ' on' : ''}" style="--i:${ind}" data-cur="${p}" type="button" aria-label="${T('Chèn lệnh vào đây', 'Insert a command here')}">${p === cur ? T('+ chọn khối bên dưới', '+ pick a block below') : '⋯'}</button>`;
    const closer = (t, ind) => `<div class="ln dim" style="--i:${ind}"><span class="tx">${t}</span></div>`;
    function line(b, path, i, ind, ctx) {
      const del = b.locked ? '' : `<button class="x" data-del="${path}#${i}" type="button" aria-label="${T('Xóa lệnh', 'Delete command')}">${ico('x', 14)}</button>`;
      const stp = b.k === 'for' && !b.locked ? `<span class="stp"><button data-n="${path}#${i}|-1" type="button" aria-label="${T('Giảm số lần', 'Fewer times')}">−</button><button data-n="${path}#${i}|1" type="button" aria-label="${T('Tăng số lần', 'More times')}">+</button></span>` : '';
      let h = `<div class="ln${b.locked ? ' lk' : ''}" style="--i:${ind}" data-bid="${b.id}"><span class="tx">${hl(label(b, ctx))}</span>${stp}${del}</div>`;
      if (b.body) h += lines(b.body, `${path}/${i}.body`, ind + 1, ctx) + closer('}', ind);
      else if (b.then) { h += lines(b.then, `${path}/${i}.then`, ind + 1, ctx); if (b.els) h += closer('} else {', ind) + lines(b.els, `${path}/${i}.els`, ind + 1, ctx); h += closer('}', ind); }
      return h;
    }
    const lines = (list, path, ind, ctx) => list.map((b, i) => line(b, path, i, ind, ctx)).join('') + slot(path, ind);
    function drawProg() {
      let h = '';
      Object.keys(prog.fns).forEach(f => { h += `<div class="fnh">${hl(`fn ${f}(bot: &mut Bot) {`)}</div>` + lines(prog.fns[f], 'fn_' + f, 1, 'fn') + '<div class="fnh">}</div>'; });
      h += `<div class="fnh">${hl('fn main() {')}</div><div class="ln dim" style="--i:1"><span class="tx">${hl('let mut bot = Bot::new();')}</span></div>` + lines(prog.main, 'main', 1, 'main') + '<div class="fnh">}</div>';
      $('#rb-prog', host).innerHTML = h;
      $('#rb-cnt', host).textContent = `${count(prog)} / ${maxB}`;
    }
    function drawPal() {
      const full = count(prog) >= maxB;
      $('#rb-pal', host).innerHTML = pal.map(id => `<button class="pal" data-add="${id}" type="button"${full || busy ? ' disabled' : ''}>${hl(label(make(id), 'main'))}</button>`).join('');
    }
    function add(id) {
      if (count(prog) >= maxB) { msg(T('Hết khối rồi! Hãy dùng vòng lặp hoặc hàm để chương trình gọn hơn.', 'Out of blocks! Use a loop or a function to make the program shorter.'), 'bad'); return; }
      let list; try { list = res(cur); } catch (e) { cur = 'main'; list = prog.main; }
      const b = make(id); b.id = nid++; list.push(b);
      if (b.body) cur = `${cur}/${list.length - 1}.body`; else if (b.then) cur = `${cur}/${list.length - 1}.then`;
      sfx('tap'); msg(''); drawProg(); drawPal();
    }
    function setBot(s, instant) {
      const dd = ((s.d - curD) + 4) % 4; if (dd === 1) ang += 90; else if (dd === 3) ang -= 90; else if (dd === 2) ang += 180; curD = s.d;
      if (instant) botEl.style.transition = 'none';
      botEl.style.transform = `translate(${s.x * S + S / 2}px,${s.y * S + S / 2}px) rotate(${ang}deg)`;
      if (instant) { void botEl.getBoundingClientRect(); botEl.style.transition = ''; }
    }
    const mark = (id, bad) => { $$('.ln.run,.ln.err', host).forEach(e => e.classList.remove('run', 'err')); if (id != null) { const e = $(`.ln[data-bid="${id}"]`, host); if (e) e.classList.add(bad ? 'err' : 'run'); } };
    const coins = got => $$('.coin', host).forEach(c => c.classList.toggle('got', got.includes(c.dataset.k)));
    function reset() { token++; busy = false; ang = d0 * 90; curD = d0; setBot({ x: M.s[0], y: M.s[1], d: d0 }, true); mark(null); coins([]); drawPal(); }
    async function play() {
      if (busy || finished) return; reset(); const my = token, r = run(st, prog);
      busy = true; drawPal(); msg('');
      { const bd = $('.rb-board', host).getBoundingClientRect(); if (bd.top < 0 || bd.bottom > innerHeight) $('.rb-board', host).scrollIntoView({ behavior: 'smooth', block: 'center' }); }
      for (let i = 1; i < r.trace.length; i++) {
        const s = r.trace[i], q = r.trace[i - 1]; setBot(s); mark(s.id); coins(s.got); if (s.id != null) sfx('step');
        const moved = s.x !== q.x || s.y !== q.y || s.d !== q.d || (s.got || []).length !== (q.got || []).length;
        await sleep((moved ? [230, 70, 18] : [80, 28, 3])[spd]); if (my !== token) return;
      }
      busy = false;
      if (r.ok) { finished = true; mark(null); msg(T('Bot đã tới đích!', 'The Bot reached the goal!'), 'ok'); drawPal(); api.win({ cap: st.par && r.blocks > st.par + 2 ? 2 : 3 }); }
      else { if (r.fail && r.fail.id != null) mark(r.fail.id, true); msg(FAIL()[r.why], 'bad'); drawPal(); api.mistake(); }
    }
    host.addEventListener('click', e => {
      const t = e.target.closest('[data-add],[data-cur],[data-del],[data-n],[data-run],[data-reset],[data-clear],[data-speed]'); if (!t || !host.contains(t)) return;
      if (t.dataset.speed !== undefined) { spd = (spd + 1) % 3; t.textContent = T('Tốc độ ×', 'Speed ×') + ['1', '3', '10'][spd]; return; }
      if (t.dataset.reset !== undefined) { if (!finished) { reset(); msg(''); } return; }
      if (busy || finished) return;
      if (t.dataset.run !== undefined) return void play();
      if (t.dataset.add) return add(t.dataset.add);
      if (t.dataset.cur) { cur = t.dataset.cur; drawProg(); return; }
      if (t.dataset.del) { const [p, i] = t.dataset.del.split('#'); const l = res(p); if (l[+i] && !l[+i].locked) { l.splice(+i, 1); cur = p; msg(''); drawProg(); drawPal(); } return; }
      if (t.dataset.n) { const [pi, dl] = t.dataset.n.split('|'), [p, i] = pi.split('#'); const b = res(p)[+i]; b.n = Math.max(1, Math.min(9, b.n + (+dl))); drawProg(); return; }
      if (t.dataset.clear !== undefined) { const keep = l => l.filter(b => b.locked).map(b => { if (b.body) b.body = keep(b.body); if (b.then) b.then = keep(b.then); if (b.els) b.els = keep(b.els); return b; }); prog.main = keep(prog.main); Object.keys(prog.fns).forEach(f => { prog.fns[f] = keep(prog.fns[f]); }); cur = st.cursor || 'main'; msg(''); reset(); drawProg(); drawPal(); }
    });
    reset(); drawProg(); drawPal();
    const sol = typeof st.sol === 'string' ? parseProg(st.sol) : st.sol;
    return { solution: () => codeHTML(toRust(sol || prog)) };
  }
  return { parse, make, label, count, run, toRust, mount, parseProg };
})();
G.engines.robot = G.robot;
