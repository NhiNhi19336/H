/* ===== bits: thao tác bit trên thanh ghi 8 bit  |  cipher: giải mã bản mã bằng cách chỉnh đoạn code ===== */
(() => {
  const bin = x => '0b' + x.toString(2).padStart(8, '0').replace(/(\d{4})(\d{4})/, '$1_$2');
  const apply = (x, o) => (o.op === '<<' ? (x << o.v) & 255 : o.op === '>>' ? x >> o.v : o.op === '&' ? x & o.v : o.op === '|' ? x | o.v : o.op === '^' ? x ^ o.v : (~x) & 255);
  const otxt = o => (o.op === '!' ? '!x' : `x ${o.op} ${o.op === '<<' || o.op === '>>' ? o.v : bin(o.v)}`);

  G.engines.bits = {
    bin, apply, otxt,
    /* tìm lời giải ngắn nhất bằng BFS để kiểm thử */
    solve(R) {
      const q = [[R.start, []]], seen = new Set([R.start]);
      while (q.length) { const [x, p] = q.shift(); if (x === R.target) return p; if (p.length >= R.max) continue; R.palette.forEach((o, i) => { const y = apply(x, o); if (!seen.has(y)) { seen.add(y); q.push([y, p.concat(i)]); } }); }
      return null;
    },
    mount(host, st, api) {
      let ri = 0, R, x, hist, flip = 0;
      function start() { R = st.rounds[ri]; x = R.mode === 'set' ? 0 : R.start; hist = []; flip = 0; draw(); }
      function draw(msg, cls) {
        const bitsH = Array.from({ length: 8 }, (_, k) => { const b = 7 - k; return `<button class="bit${x >> b & 1 ? ' on' : ''}${flip >> b & 1 ? ' flip' : ''}" data-b="${b}" type="button"${R.mode === 'set' ? '' : ' tabindex="-1"'} aria-label="bit ${b}"><small>${1 << b}</small><b>${x >> b & 1}</b></button>`; }).join('');
        const tb = R.target;
        host.innerHTML = `<div class="bt"><span class="pill">${T('Vòng', 'Round')} <b>${ri + 1}</b>/${st.rounds.length}</span>
          <p class="qz-q">${md(R.q)}</p>
          <div class="bitrow${R.mode === 'set' ? ' tap' : ''}">${bitsH}</div>
          <div class="bitval"><span><small>${T('thập phân', 'decimal')}</small><b>${x}</b></span><span><small>${T('nhị phân', 'binary')}</small><b>${bin(x)}</b></span><span><small>${T('thập lục', 'hex')}</small><b>0x${x.toString(16).toUpperCase().padStart(2, '0')}</b></span><span class="tg"><small>${T('mục tiêu', 'target')}</small><b>${R.mode === 'set' ? tb : bin(tb)}</b></span></div>
          ${R.mode === 'ops' ? `<div class="rb-pal">${R.palette.map((o, i) => `<button class="pal" data-op="${i}" type="button"${hist.length >= R.max ? ' disabled' : ''}>${hl(otxt(o))}</button>`).join('')}</div>
          <div class="code hist">${hl(`let x = ${bin(R.start)}u8;`)}${hist.map(i => '\n' + hl(`let x = ${otxt(R.palette[i])};`)).join('')}</div><p class="pill">${T('Lượt', 'Moves')} <b>${hist.length}</b>/${R.max}</p>` : ''}
          <p class="msg ${cls || ''}" role="status">${md(msg || '')}</p>
          ${R.mode === 'ops' ? `<div class="actions"><button class="btn ghost" data-undo type="button">${ico('undo', 16)} ${T('Hoàn tác', 'Undo')}</button><button class="btn ghost" data-reset type="button">${ico('reset', 16)} ${T('Đặt lại', 'Reset')}</button></div>` : ''}</div>`;
      }
      function check() {
        if (x !== R.target) return false;
        sfx('ok'); if (ri === st.rounds.length - 1) { draw(T('Đúng mục tiêu!', 'Target hit!'), 'ok'); api.win({ cap: 3 }); } else { draw(T('Đúng! Sang vòng tiếp theo.', 'Correct! On to the next round.'), 'ok'); ri++; setTimeout(start, 900); }
        return true;
      }
      host.onclick = e => {
        const b = e.target.closest('[data-b]'), o = e.target.closest('[data-op]');
        if (b && R.mode === 'set') { const k = +b.dataset.b; x ^= 1 << k; flip = 1 << k; sfx('tap'); draw(); if (!check() && false) { } }
        else if (o) {
          const prev = x; x = apply(x, R.palette[+o.dataset.op]); flip = prev ^ x; hist.push(+o.dataset.op); sfx('tap'); draw();
          if (!check() && hist.length >= R.max) { sfx('bad'); api.mistake(); draw(T('Hết lượt mà chưa tới mục tiêu. Hoàn tác hoặc đặt lại.', 'Out of moves before reaching the target. Undo or reset.'), 'bad'); }
        } else if (e.target.closest('[data-undo]')) { if (hist.length) { hist.pop(); x = hist.reduce((v, i) => apply(v, R.palette[i]), R.start); flip = 0; draw(); } }
        else if (e.target.closest('[data-reset]')) { x = R.start; hist = []; flip = 0; draw(); }
      };
      start();
      return { solution: () => st.rounds.map(R => R.mode === 'set' ? `<p class="sol-a">${R.target} = <code>${bin(R.target)}</code></p>` : `<p class="sol-a">${G.engines.bits.solve(R).map(i => `<code>${esc(otxt(R.palette[i]))}</code>`).join(T(' rồi ', ' then '))}</p>`).join('') };
    }
  };

  /* ---- cipher ---- */
  const FORMS = {
    same: { code: 'c', f: i => i, inv: 'same' }, atbash: { code: "b'Z' - (c - b'A')", f: i => 25 - i, inv: 'atbash' },
    rot13: { code: "(c - b'A' + 13) % 26 + b'A'", f: i => (i + 13) % 26, inv: 'rot13' }, next: { code: "(c - b'A' + 1) % 26 + b'A'", f: i => (i + 1) % 26, inv: 'prev' },
    prev: { code: "(c - b'A' + 25) % 26 + b'A'", f: i => (i + 25) % 26, inv: 'next' },
  };
  const mapL = (s, f) => s.replace(/[A-Z]/g, ch => String.fromCharCode(65 + f(ch.charCodeAt(0) - 65)));
  const C = G.cipher = {
    FORMS,
    prep(R) {
      if (R.kind === 'digits') return { cipher: R.plain.replace(/\d/g, d => (+d + R.shift) % 10), key: (10 - R.shift) % 10 };
      if (R.kind === 'caesar') return { cipher: mapL(R.plain, i => (i + R.shift) % 26), key: (26 - R.shift) % 26 };
      if (R.kind === 'xor') return { cipher: R.plain.split('').map(c => c.charCodeAt(0) ^ R.key), key: R.key };
      return { cipher: mapL(R.plain, FORMS[FORMS[R.use].inv].f), key: R.use };
    },
    dec(R, cipher, k) {
      if (R.kind === 'digits') return cipher.replace(/\d/g, d => (+d + k) % 10);
      if (R.kind === 'caesar') return mapL(cipher, i => (i + k) % 26);
      if (R.kind === 'xor') return cipher.map(b => { const v = b ^ k; return v >= 32 && v < 127 ? String.fromCharCode(v) : '·'; }).join('');
      return mapL(cipher, FORMS[k].f);
    },
    code(R, k) {
      if (R.kind === 'digits') return `let p = (d + ${k}) % 10;`;
      if (R.kind === 'caesar') return `let p = (c - b'A' + ${k}) % 26 + b'A';`;
      if (R.kind === 'xor') return `const KEY: u8 = ${bin(k)};\nlet p = c ^ KEY;`;
      return `let p = ${FORMS[k].code};`;
    },
  };
  const tiles = (arr, cls) => `<div class="tiles ${cls || ''}">${arr.map(t => t === ' ' ? '<span class="tl sp"></span>' : `<span class="tl">${esc(t)}</span>`).join('')}</div>`;

  G.engines.cipher = {
    mount(host, st, api) {
      let ri = 0, R, P, k;
      function start() { R = st.rounds[ri]; P = C.prep(R); k = R.kind === 'xor' || R.kind === 'forms' ? (R.kind === 'xor' ? 0 : R.forms[0]) : 0; draw(); }
      function draw(msg, cls) {
        const cArr = R.kind === 'xor' ? P.cipher.map(b => b.toString(16).toUpperCase().padStart(2, '0')) : P.cipher.split(''), out = C.dec(R, P.cipher, k);
        let knob = '';
        if (R.kind === 'digits' || R.kind === 'caesar') { const mx = R.kind === 'digits' ? 9 : 25; knob = `<div class="knob"><button data-k="-1" type="button" aria-label="${T('Giảm', 'Decrease')}">−</button><span>K = <b>${k}</b></span><button data-k="1" type="button" aria-label="${T('Tăng', 'Increase')}">+</button></div>`; knob = knob.replace('data-k="-1"', `data-k="-1"${k <= 0 ? ' disabled' : ''}`).replace('data-k="1"', `data-k="1"${k >= mx ? ' disabled' : ''}`); }
        else if (R.kind === 'xor') knob = `<div class="bitrow tap sm">${Array.from({ length: 8 }, (_, i) => { const b = 7 - i; return `<button class="bit${k >> b & 1 ? ' on' : ''}" data-b="${b}" type="button" aria-label="bit ${b}"><small>${1 << b}</small><b>${k >> b & 1}</b></button>`; }).join('')}</div><p class="muted">KEY = ${k} = 0x${k.toString(16).toUpperCase().padStart(2, '0')}</p>`;
        else knob = `<div class="opts">${R.forms.map(f => `<button class="opt codeopt${f === k ? ' good' : ''}" data-f="${f}" type="button"><span class="o">${hl('let p = ' + FORMS[f].code + ';')}</span></button>`).join('')}</div>`;
        host.innerHTML = `<div class="cp"><span class="pill">${T('Bản mã', 'Cipher')} <b>${ri + 1}</b>/${st.rounds.length}</span>
          <p class="qz-q">${md(R.q || T('Chỉnh đoạn code cho đến khi bản mã hiện ra một câu có nghĩa.', 'Adjust the code until the ciphertext turns into a meaningful sentence.'))}</p>
          ${R.clue ? `<p class="clue">${ico('bulb', 16)}<span>${md(R.clue)}</span></p>` : ''}
          <div class="lbl">${T('Bản mã', 'Ciphertext')}</div>${tiles(cArr, 'enc')}
          ${codeHTML(C.code(R, k))}${knob}
          <div class="lbl">${T('Kết quả giải mã', 'Decoded result')}</div>${tiles(R.kind === 'xor' ? out.split('') : out.split(''), 'dec')}
          <p class="msg ${cls || ''}" role="status">${md(msg || '')}</p>
          <div class="actions"><button class="btn primary" data-ok type="button">${ico('check', 16)} ${T('Đã giải mã xong', 'I decoded it')}</button></div></div>`;
      }
      host.onclick = e => {
        const kb = e.target.closest('[data-k]'), bb = e.target.closest('[data-b]'), fb = e.target.closest('[data-f]');
        if (kb) { const mx = R.kind === 'digits' ? 9 : 25; k = Math.max(0, Math.min(mx, k + +kb.dataset.k)); sfx('tap'); draw(); }
        else if (bb) { k ^= 1 << +bb.dataset.b; sfx('tap'); draw(); }
        else if (fb) { k = fb.dataset.f; sfx('tap'); draw(); }
        else if (e.target.closest('[data-ok]')) {
          if (C.dec(R, P.cipher, k) === R.plain) {
            sfx('ok'); if (ri === st.rounds.length - 1) { draw(T(`Giải mã thành công: **${R.plain}**`, `Decoded: **${R.plain}**`), 'ok'); api.win({ cap: 3 }); } else { draw(T(`Đúng rồi: **${R.plain}**. Sang bản mã tiếp theo.`, `Correct: **${R.plain}**. On to the next cipher.`), 'ok'); ri++; setTimeout(start, 1100); }
          } else { sfx('bad'); api.mistake(); draw(T('Kết quả chưa phải một câu có nghĩa. Chỉnh tiếp nhé.', 'The result is not a meaningful sentence yet. Keep adjusting.'), 'bad'); }
        }
      };
      start();
      return { solution: () => st.rounds.map(R => { const P = C.prep(R); return `<p class="sol-q">${md(R.plain)}</p>${codeHTML(C.code(R, P.key))}`; }).join('') };
    }
  };
})();
