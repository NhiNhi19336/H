/* ===== Zone 7: Streams and Pointers ===== */
const GRID7 = []; for (let y = 3; y >= -3; y--) for (let x = -3; x <= 3; x++) GRID7.push(x + ',' + y);
const AT7 = (x, y) => (3 - y) * 7 + (x + 3);
G.add(7, {
  title: 'Iterators: a data assembly line', sub: 'iter, map, filter, sum, collect', tags: ['Ciphers', 'Operators'],
  learn: {
    intro: 'An iterator is an **assembly line**: data goes in, passes through stations (`filter`, `map`…), and comes out at the end (`sum`, `collect`). The stations are all **lazy**: until someone “pulls” at the end, no station runs. Rust compiles this line into an optimized loop, as fast as a hand-written `for`.',
    points: ['`.iter()` borrows each element, `.into_iter()` takes them over, `.iter_mut()` borrows them to modify.', 'Middle stations (lazy): `map`, `filter`, `enumerate`, `skip`, `take`, `zip`, `rev`.', 'End stations (they pull the data): `sum`, `count`, `max`, `min`, `fold`, `any`, `all`, `collect`.', '`collect()` needs to know what to gather into: `Vec<_>`, `String`, `HashMap<_, _>`…'],
    code: 'fn main() {\n    let nums = [1, 2, 3, 4, 5, 6];\n    let sum_even_squares: i32 = nums\n        .iter()\n        .filter(|x| *x % 2 == 0)\n        .map(|x| x * x)\n        .sum();\n    println!("{sum_even_squares}");\n    let names: Vec<String> = ["ana", "sam"].iter().map(|s| s.to_uppercase()).collect();\n    println!("{:?}", names);\n    for (i, x) in nums.iter().enumerate().skip(4) {\n        println!("{i}: {x}");\n    }\n    let coded: Vec<u8> = "RUST".bytes().map(|c| c ^ 42).collect();\n    println!("{:?}", coded);\n}',
    out: '56\n["ANA", "SAM"]\n4: 5\n5: 6\n[120, 127, 121, 126]',
    note: 'The last line is an XOR cipher made of a single station, `.map(|c| c ^ 42)`. Use that very same assembly line to decode in the challenge.',
  },
  ch: {
    type: 'cipher', brief: 'The ciphertexts below have gone through the assembly line `.map(|c| c ^ KEY)`. Flip the bits of KEY until the ciphertext turns into readable text.',
    hint: 'XOR twice with the same key and you are back where you started: `a ^ k ^ k = a`. If you know one encrypted byte and its original letter, you can work out the key: `KEY = encrypted_byte ^ original_letter`.',
    rounds: [
      { kind: 'xor', plain: 'RUST', key: 42, q: 'Cipher 1.', clue: 'The first byte is 0x78 and the first letter is R (code 0x52). So KEY = 0x78 ^ 0x52. Flip the bits on the board and check whether the first letter has become R.' },
      { kind: 'xor', plain: 'MAP FILTER', key: 19, q: 'Cipher 2, a different key.', clue: 'The 4th byte is where the space is. A space has code 0x20, so its encrypted byte is 0x20 ^ KEY. Look at the 4th cell of the ciphertext and work backwards to KEY.' },
    ],
  },
  trick: {
    name: 'Dot product with zip', why: 'Multiply matching components and add them up, in one short assembly line.',
    lines: ['let a = [1, 2, 3];', 'let b = [4, 5, 6];', 'let dot: i32 = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum();', 'println!("{dot}");'],
    out: '32',
    how: '`zip` pairs up the elements at the same position, `map` multiplies the two components, `sum` adds them all: exactly the definition of the dot product of two vectors (1×4 + 2×5 + 3×6 = 32).',
  },
});

G.add(7, {
  title: 'Box, the heap and recursion', sub: 'Box<T> and recursive types', tags: ['Spatial', 'Math'],
  learn: {
    intro: 'By default values live on the **stack**: fast, but their size must be known in advance. `Box<T>` moves a value onto the **heap** and keeps a small pointer. That lets us build **recursive** types (a type that contains itself), such as trees and linked lists.',
    points: ['`Box::new(5)` creates a box on the heap. `*b` opens the box to get the value.', 'When a `Box` goes out of scope, its heap memory is freed automatically.', 'A directly recursive type such as `enum Tree { Leaf(i32), Node(Tree, Tree) }` would have infinite size, so it does not compile. With `Box<Tree>` the size is just one pointer.', 'A recursive function calls itself and always needs a **stopping condition**.'],
    code: 'enum Tree {\n    Leaf(i32),\n    Node(Box<Tree>, Box<Tree>),\n}\n\nfn sum(t: &Tree) -> i32 {\n    match t {\n        Tree::Leaf(v) => *v,\n        Tree::Node(left, right) => sum(left) + sum(right),\n    }\n}\n\nfn depth(t: &Tree) -> u32 {\n    match t {\n        Tree::Leaf(_) => 1,\n        Tree::Node(left, right) => 1 + depth(left).max(depth(right)),\n    }\n}\n\nfn main() {\n    let tree = Tree::Node(\n        Box::new(Tree::Node(Box::new(Tree::Leaf(1)), Box::new(Tree::Leaf(2)))),\n        Box::new(Tree::Leaf(3)),\n    );\n    println!("sum = {}, depth = {}", sum(&tree), depth(&tree));\n}',
    out: 'sum = 6, depth = 3',
    note: 'A tree is the spatial picture of recursion: every node is again a smaller tree. The function `sum` has exactly the same shape as the data it walks through.',
  },
  ch: {
    type: 'robot', brief: 'Write a **recursive** function `chay` (it means “run” in Vietnamese): if the Bot has not reached the goal yet, it takes one step (turn right at a wall, otherwise go forward) and then calls `chay` again. The condition “not at the goal yet” is the stopping condition.',
    hint: 'Inside `fn chay`, use the `if !at_goal` block. Put an `if … else` block inside it (if branch: turn right, else branch: go forward), then put `chay(bot);` at the **end** of the `if !at_goal` block. Finally call `chay(&mut bot);` in `main`.',
    grid: ['#########', '#S......#', '#######.#', '##G####.#', '##.####.#', '##......#', '#########'], dir: 'E', fns: ['chay'], cursor: 'fn_chay',
    palette: ['if:!at_goal', 'ifelse:wall_ahead', 'forward', 'right', 'call:chay'], max: 8, par: 6,
    sol: 'fn:chay { if:!at_goal { if:wall_ahead { R } else { F } call:chay } } call:chay',
  },
  trick: {
    name: 'Euclid’s algorithm', why: 'Find the greatest common divisor of two numbers with the shortest recursive function possible.',
    pre: [], post: [],
    lines: ['fn gcd(a: u32, b: u32) -> u32 {', 'if b == 0 { a } else { gcd(b, a % b) }', '}', 'fn main() {', 'println!("{}", gcd(48, 18));', '}'],
    out: '6',
    how: 'The stopping condition is `b == 0`. If we have not stopped, replace the pair `(a, b)` with `(b, a % b)`: the remainder is always smaller than `b`, so it must reach 0 eventually. For 48 and 18: (48,18) → (18,12) → (12,6) → (6,0) gives 6.',
  },
});

G.add(7, {
  title: 'Rc and RefCell', sub: 'many owners and mutating while shared', tags: ['Spatial', 'Logic'],
  learn: {
    intro: 'Sometimes a piece of data needs **many owners**, like several nodes pointing at one shared node. `Rc<T>` keeps an **owner counter**: only when the last owner leaves is the data freed. `RefCell<T>` lets you **modify** data even though you only hold an immutable reference: Rust checks the borrowing rules at **run time** instead of compile time.',
    points: ['`Rc::new(x)` creates one. `Rc::clone(&a)` only raises the counter and does **not** copy the data. `Rc::strong_count(&a)` tells you the number of owners.', '`Rc<T>` is read-only. To modify, wrap it with a `RefCell`: `Rc<RefCell<T>>`.', '`cell.borrow()` borrows to read, `cell.borrow_mut()` borrows to write. Breaking the borrowing rules **panics** at run time.', '`Rc` is for a single thread only. For many threads use `Arc` (lesson 30).'],
    code: 'use std::cell::RefCell;\nuse std::rc::Rc;\n\nfn main() {\n    let score = Rc::new(RefCell::new(0));\n    let a = Rc::clone(&score);\n    let b = Rc::clone(&score);\n    *a.borrow_mut() += 10;\n    *b.borrow_mut() += 5;\n    println!("{} (owners: {})", score.borrow(), Rc::strong_count(&score));\n    drop(a);\n    println!("owners left: {}", Rc::strong_count(&score));\n}',
    out: '15 (owners: 3)\nowners left: 2',
    note: 'Picture a sticky note on the wall of a shared room: everyone can read it (`Rc`), and one pen hangs next to it that only one person can hold at a time (`RefCell`).',
  },
  ch: {
    type: 'quiz', brief: 'Four questions about many owners and mutating while shared. The first two ask you to guess the output.', hint: '`Rc::clone` only adds one owner: the counter goes up by 1, and when an owner leaves its scope the counter goes down by 1.',
    qs: [
      { q: 'What does this program print?', code: 'use std::rc::Rc;\nfn main() {\n    let a = Rc::new(String::from("data"));\n    let b = Rc::clone(&a);\n    {\n        let _c = Rc::clone(&a);\n        println!("{}", Rc::strong_count(&a));\n    }\n    println!("{}", Rc::strong_count(&b));\n}', run: true, opts: ['3\n2', '2\n2', '3\n3', '2\n1'], ans: 0, why: 'Inside the block there are 3 owners (`a`, `b`, `_c`). When the block ends `_c` is dropped, leaving 2.' },
      { q: 'What does this program print?', code: 'use std::cell::RefCell;\nfn main() {\n    let o = RefCell::new(vec![1, 2]);\n    o.borrow_mut().push(3);\n    println!("{:?} {}", o.borrow(), o.borrow().len());\n}', run: true, opts: ['[1, 2, 3] 3', '[1, 2] 2', 'Compile error because `o` is not `mut`', 'Panic at run time'], ans: 0, why: '`RefCell` allows modification through `borrow_mut()` even though `o` has no `mut`. Two `borrow()` calls at the same time, both for reading, are fine.' },
      { q: 'What does `Rc::clone(&a)` do?', opts: ['Only raises the owner counter, without copying the data', 'Copies all the data into new memory', 'Moves ownership from `a` to the new copy', 'Creates a mutable reference'], ans: 0, why: 'That is why `Rc::clone` is very cheap: it only adds 1 to a counter.' },
      { q: 'With `RefCell`, what happens if you call `borrow_mut()` while a `borrow()` has not been released?', opts: ['The program panics at run time', 'Compile error', 'Rust queues up and waits', 'The value is copied'], ans: 0, why: '`RefCell` moves the check of the borrowing rules from compile time to run time, so breaking them panics.' },
    ],
  },
  trick: {
    name: 'A shared store that many people write to', why: 'Two owners both add items to one single list.',
    pre: ['use std::cell::RefCell;', 'use std::rc::Rc;', 'fn main() {'], post: ['}'],
    lines: ['let store = Rc::new(RefCell::new(Vec::new()));', 'let person_a = Rc::clone(&store);', 'let person_b = Rc::clone(&store);', 'person_a.borrow_mut().push("apple");', 'person_b.borrow_mut().push("pear");', 'println!("{:?}", store.borrow());'],
    out: '["apple", "pear"]',
    how: 'Three variables point at one `Vec`. Anyone can `push` because `RefCell` checks the borrowing rules at run time, and each `borrow_mut()` holds the write permission for just one statement.',
  },
});

G.add(7, {
  title: 'Operators for your own types', sub: 'impl Add, Mul, Neg for vectors', tags: ['Math', 'Operators', 'Spatial'],
  learn: {
    intro: 'Operators such as `+`, `-`, `*` are really **shortcuts** for traits in `std::ops`: `a + b` is exactly `a.add(b)` from the trait `Add`. Implement that trait for your own type and `+` works with vectors, matrices, complex numbers… The two-dimensional plane is a great place to try it.',
    points: ['`impl Add for Vec2 { type Output = Vec2; fn add(self, o: Vec2) -> Vec2 { ... } }`.', 'Operator traits: `Add`, `Sub`, `Mul`, `Neg` (the unary minus), `AddAssign` (`+=`), `Index` (`[]`).', 'Comparison `==` and `<` come from `PartialEq` and `PartialOrd`, which usually only need `#[derive(...)]`.', 'Keep the familiar meaning of operators: a `+` that does something strange makes code hard to understand.'],
    code: 'use std::ops::{Add, Mul, Neg};\n\n#[derive(Debug, Clone, Copy, PartialEq)]\nstruct Vec2 {\n    x: i32,\n    y: i32,\n}\n\nimpl Add for Vec2 {\n    type Output = Vec2;\n    fn add(self, o: Vec2) -> Vec2 {\n        Vec2 { x: self.x + o.x, y: self.y + o.y }\n    }\n}\n\nimpl Mul<i32> for Vec2 {\n    type Output = Vec2;\n    fn mul(self, k: i32) -> Vec2 {\n        Vec2 { x: self.x * k, y: self.y * k }\n    }\n}\n\nimpl Neg for Vec2 {\n    type Output = Vec2;\n    fn neg(self) -> Vec2 {\n        Vec2 { x: -self.x, y: -self.y }\n    }\n}\n\nfn main() {\n    let a = Vec2 { x: 1, y: 2 };\n    let b = Vec2 { x: 3, y: -1 };\n    println!("{:?}", a + b);\n    println!("{:?}", a * 3);\n    println!("{:?}", -(a + b) * 2);\n}',
    out: 'Vec2 { x: 4, y: 1 }\nVec2 { x: 3, y: 6 }\nVec2 { x: -8, y: -2 }',
    note: 'Adding two vectors means **walking on**: reach point a, then walk another stretch b. We use exactly this picture in the challenge.',
  },
  ch: {
    type: 'cells', brief: 'Each cell shows an `x,y` pair (the y axis points up). Work out the operation on `Vec2`, then tap the cell where the result lands.',
    hint: 'Adding vectors means adding each component: `(x1 + x2, y1 + y2)`. Multiplying by a number `k` multiplies both components. The minus sign flips the sign of both components.',
    rounds: [
      { W: 7, vals: GRID7, sm: true, q: 'Given `a = Vec2 { x: 1, y: 2 }`. Tap the cell for `a + Vec2 { x: 2, y: -3 }`.', ans: AT7(3, -1), why: '(1 + 2, 2 + (-3)) = (3, -1).' },
      { W: 7, vals: GRID7, sm: true, q: 'Given `a = Vec2 { x: 1, y: 1 }`. Tap the cell for `a * 3`.', ans: AT7(3, 3), why: '(1 × 3, 1 × 3) = (3, 3).' },
      { W: 7, vals: GRID7, sm: true, q: 'Given `a = Vec2 { x: 2, y: 1 }`. Tap the cell for `-a + Vec2 { x: 1, y: 0 }`.', ans: AT7(-1, -1), why: '-a = (-2, -1); adding (1, 0) gives (-1, -1).' },
      { W: 7, vals: GRID7, sm: true, q: 'Given `a = Vec2 { x: 1, y: 0 }` and `b = Vec2 { x: 0, y: 1 }`. Tap the cell for `(a + b) * 2`.', ans: AT7(2, 2), why: 'a + b = (1, 1); times 2 gives (2, 2).' },
    ],
  },
  trick: {
    name: 'Accumulate steps with +=', why: 'Update a position in place with the `+=` operator on your own type.',
    pre: [], post: [],
    lines: ['use std::ops::AddAssign;', '#[derive(Debug)]', 'struct V { x: i32, y: i32 }', 'impl AddAssign for V {', 'fn add_assign(&mut self, o: V) { self.x += o.x; self.y += o.y; }', '}', 'fn main() {', 'let mut p = V { x: 0, y: 0 };', 'p += V { x: 2, y: -1 };', 'p += V { x: 1, y: 5 };', 'println!("{:?}", p);', '}'],
    out: 'V { x: 3, y: 4 }',
    how: '`+=` comes from the trait `AddAssign`, which takes `&mut self` and changes the left-hand side directly, unlike `Add`, which returns a new value. Each step is a displacement vector, and adding them up gives the final position.',
  },
});
