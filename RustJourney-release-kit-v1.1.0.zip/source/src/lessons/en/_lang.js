/* ===== Language pack: English (zone names, ranks, blurbs) ===== */
G.defZones('en', [
  ['Starter Village', 'Apprentice', 'Your first program, variables, numbers and operators.'],
  ['Crossroads of Flow', 'Pathfinder', 'Branching, loops, pattern matching and functions.'],
  ['Data Vault', 'Keeper', 'Arrays, Vec, strings and hash maps.'],
  ['Ownership Tower', 'Key Holder', 'Moves, borrowing, slices and automatic cleanup.'],
  ['Type Workshop', 'Architect', 'struct, enum, Option and Result.'],
  ['The Laboratory', 'Inventor', 'Generics, traits, lifetimes and closures.'],
  ['Streams and Pointers', 'Wizard', 'Iterators, smart pointers and custom operators.'],
  ['Summit of Mastery', 'Rust Master', 'Bits, threads, macros and the final boss.'],
]);
