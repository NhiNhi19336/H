/* ===== Zone 3: Data Vault ===== */
const ARR7 = ['7', '3', '9', '1', '5', '8', '2'], LET12 = 'ABCDEFGHIJKL'.split('');
G.add(3, {
  title: 'Arrays and indexes', sub: 'arrays [T; N], indexes and len', tags: ['Spatial', 'Math'],
  learn: {
    intro: 'An array is a row of boxes sitting side by side, all of the same type, and there is a fixed number of them. You find a box by its **index**, counting from 0, like numbering the seats in a row where the first seat is number 0.',
    points: ['`let a = [10, 20, 30];` has type `[i32; 3]`. `a[0]` is 10 and `a[2]` is 30.', '`a.len()` gives the number of elements. The last element is `a[a.len() - 1]`.', 'An index out of range makes the program **panic** (stop safely); it never reads some other part of memory by accident. To try an index without panicking, use `a.get(i)`.', '`for x in a` or `for i in 0..a.len()` walks through every box.'],
    code: 'fn main() {\n    let a = [10, 20, 30, 40, 50];\n    println!("{} {}", a[0], a[a.len() - 1]);\n    let mut total = 0;\n    for i in 0..a.len() {\n        total += a[i];\n    }\n    println!("total = {total}");\n    println!("{:?}", a.get(9));\n}',
    out: '10 50\ntotal = 150\nNone',
    note: 'Counting from 0 sounds odd, but it makes sense: the index is the **distance** from the first box.',
  },
  ch: {
    type: 'cells', brief: 'The numbers below are the array `a`. Tap the cell that the index expression points to.', hint: 'Indexes count from 0. The array has 7 elements, so `a.len()` is 7 and the last cell is `a[6]`.',
    rounds: [
      { W: 7, vals: ARR7, q: 'Tap the cell `a[2]`.', ans: 2, why: 'Count from 0: cell 0, cell 1, cell 2.' },
      { W: 7, vals: ARR7, q: 'Tap the cell `a[a.len() - 1]`.', ans: 6, why: '`a.len()` is 7, so the last index is 6.' },
      { W: 7, vals: ARR7, q: 'Tap the cell `a[a.len() / 2]` (integer division).', ans: 3, why: '7 / 2 = 3 (the remainder is dropped), and that is the middle cell.' },
      { W: 7, vals: ARR7, q: 'Given `let i = 1;`, tap the cell `a[i + 3]`.', ans: 4, why: '1 + 3 = 4.' },
    ],
  },
  trick: {
    name: 'Find the maximum and where it is', why: 'Keep the position instead of the value, so you get both pieces of information at once.',
    lines: ['let a = [7, 3, 9, 1, 5];', 'let mut pos = 0;', 'for i in 1..a.len() {', 'if a[i] > a[pos] {', 'pos = i;', '}', '}', 'println!("the largest is {} at position {}", a[pos], pos);'],
    out: 'the largest is 9 at position 2',
    how: 'From `pos` we can get both the value `a[pos]` and the place where it sits. The loop starts at 1 because element 0 is already the first candidate.',
  },
});

G.add(3, {
  title: 'Vec and the 2D grid', sub: 'Vec, push and the formula y * W + x', tags: ['Spatial', 'Math'],
  learn: {
    intro: '`Vec<T>` is an array that can **grow** or shrink while the program runs. A 2D grid is often stored flat inside one `Vec`: the cell in column `x` and row `y` sits at index `y * W + x`, where `W` is the number of columns.',
    points: ['`let mut v = Vec::new();` or `vec![1, 2, 3]`.', '`v.push(x)` adds to the end, `v.pop()` takes from the end (and returns an `Option`).', 'From coordinates to index: `y * W + x`. From index to coordinates: `x = i % W`, `y = i / W`.', '`v.len()`, `v.is_empty()` and `for x in &v` are everyday tools.'],
    code: 'fn main() {\n    let w = 4;\n    let mut grid = Vec::new();\n    for y in 0..3 {\n        for x in 0..w {\n            grid.push(y * 10 + x);\n        }\n    }\n    println!("{:?}", grid);\n    let (x, y) = (2, 1);\n    println!("cell ({x}, {y}) = {}", grid[y * w + x]);\n    let i = 11;\n    println!("index {i} is in column {}, row {}", i % w, i / w);\n}',
    out: '[0, 1, 2, 3, 10, 11, 12, 13, 20, 21, 22, 23]\ncell (2, 1) = 12\nindex 11 is in column 3, row 2',
    note: 'The `%` and `/` operators here are the “column and row” pair: divide by W, and the quotient is the row while the remainder is the column.',
  },
  ch: {
    type: 'cells', brief: 'This 4-column grid is stored flat in a `Vec` named `v`. The labels on the top and on the left show the column and the row. Use `%` and `/` to find the right cell.',
    hint: 'Divide the index by 4: the quotient is the row and the remainder is the column. For example 9 = 2 × 4 + 1, so row 2, column 1.',
    rounds: [
      { W: 4, axes: true, vals: LET12, q: 'Tap the cell `v[5]`.', ans: 5, why: '5 = 1 × 4 + 1: row 1, column 1.' },
      { W: 4, axes: true, vals: LET12, q: 'Tap the cell `v[9]`.', ans: 9, why: '9 = 2 × 4 + 1: row 2, column 1.' },
      { W: 4, axes: true, vals: LET12, q: 'Tap the cell `v[11]`.', ans: 11, why: '11 = 2 × 4 + 3: row 2, column 3.' },
      { W: 4, axes: true, vals: LET12, q: 'Tap the cell with `x = 2, y = 2`, that is `v[y * 4 + x]`.', ans: 10, why: '2 × 4 + 2 = 10.' },
    ],
  },
  trick: {
    name: 'Switch between index and coordinates', why: 'A pair of functions that works for every grid game: chess, crosswords, minesweeper.',
    pre: [], post: [],
    lines: ['fn coords(i: usize, w: usize) -> (usize, usize) {', '(i % w, i / w)', '}', 'fn index(x: usize, y: usize, w: usize) -> usize {', 'y * w + x', '}', 'fn main() {', 'let (x, y) = coords(11, 4);', 'println!("({x}, {y}) -> {}", index(x, y, 4));', '}'],
    out: '(3, 2) -> 11',
    how: 'The two functions are inverses of each other: `% w` and `/ w` split an index into (column, row), and `y * w + x` puts it back together. Going out to coordinates and back to an index always gives the original number.',
  },
});

G.add(3, {
  title: 'Strings and the Caesar cipher', sub: 'String, &str, char and byte', tags: ['Ciphers', 'Math'],
  learn: {
    intro: 'Text inside a computer is really numbers. Every ASCII character has a `u8` code: `b\'A\'` is 65, `b\'B\'` is 66… Rust has two string types: `&str` (a borrowed string, fixed) and `String` (an owned string that can grow). Both are UTF-8.',
    points: ['`String::from("hello")` or `"hello".to_string()`; `s.push_str("!")` adds more text.', '`s.len()` counts **bytes**, while `s.chars().count()` counts **characters**. Letters with accents take more than one byte.', '`b\'A\'` is the byte code of the letter A. `(b\'A\' + 2) as char` gives `\'C\'`.', 'Shift letters around the circle of 26 letters: `(c - b\'A\' + k) % 26 + b\'A\'`. That is exactly the Caesar cipher.'],
    code: 'fn encrypt(s: &str, k: u8) -> String {\n    let mut result = String::new();\n    for c in s.bytes() {\n        if c.is_ascii_uppercase() {\n            result.push(((c - b\'A\' + k) % 26 + b\'A\') as char);\n        } else {\n            result.push(c as char);\n        }\n    }\n    result\n}\n\nfn main() {\n    let secret = encrypt("HELLO RUST", 3);\n    println!("{secret}");\n    println!("{}", encrypt(&secret, 23));\n    let s = "café";\n    println!("{} bytes, {} characters", s.len(), s.chars().count());\n}',
    out: 'KHOOR UXVW\nHELLO RUST\n5 bytes, 4 characters',
    note: 'The `% 26` makes Z wrap around to A: that is the circle idea from lesson 3. Shift by 3 and then by 23 and you have made a full 26, back where you started.',
  },
  ch: {
    type: 'cipher', brief: 'Decode two Caesar letters. Every letter was pushed forward a number of places in the alphabet. Adjust K so that `(c - b\'A\' + K) % 26 + b\'A\'` brings them back.',
    hint: 'If the letter was pushed forward by 3, then pushing it 23 more places (3 + 23 = 26, exactly one lap) brings it back.',
    rounds: [
      { kind: 'caesar', plain: 'HELLO RUST', shift: 3, q: 'Letter 1.', clue: 'The first word has two identical letters side by side. Which familiar 5-letter English word has “LL” in the middle?' },
      { kind: 'caesar', plain: 'RUST IS SAFE', shift: 11, q: 'Letter 2: the sender used a different number.', clue: 'Every time K goes up by 1, every letter moves one more place around the circle of 26 letters. Stop when you can read English.' },
    ],
  },
  trick: {
    name: 'ROT13: one function, two jobs', why: 'Encrypt and decrypt with the same function, because 13 + 13 = 26.',
    pre: [], post: [],
    lines: ['fn rot13(s: &str) -> String {', 'let mut result = String::new();', 'for c in s.bytes() {', "let m = if c.is_ascii_uppercase() { (c - b'A' + 13) % 26 + b'A' } else { c };", 'result.push(m as char);', '}', 'result', '}', 'fn main() {', 'let a = rot13("RUST");', 'println!("{a} {}", rot13(&a));', '}'],
    out: 'EHFG RUST',
    how: '13 is exactly half of the 26-letter circle, so applying it twice makes a full lap and returns each letter to where it started. A self-inverse cipher like this is neat: you do not need to write a separate decrypt function.',
  },
});

G.add(3, {
  title: 'The HashMap', sub: 'HashMap, entry and substitution tables', tags: ['Ciphers', 'Logic'],
  learn: {
    intro: '`HashMap<K, V>` is a dictionary: look up a **key** and you get the **value**, almost instantly, no matter how thick the dictionary is. Use it to count things, to look up substitution tables, or to group data.',
    points: ['You need `use std::collections::HashMap;` at the top of the file.', '`m.insert(key, value)` adds an entry, and `m.get(&key)` returns an `Option<&V>`.', '`*m.entry(key).or_insert(0) += 1;` is the classic way to count: if the key is missing, create it with 0, then add 1.', 'The iteration order of a `HashMap` is **not fixed**. If you want ordered output, collect the pairs and sort them first.'],
    code: 'use std::collections::HashMap;\n\nfn main() {\n    let text = "hello rust";\n    let mut count: HashMap<char, u32> = HashMap::new();\n    for c in text.chars() {\n        if c != \' \' {\n            *count.entry(c).or_insert(0) += 1;\n        }\n    }\n    let mut pairs: Vec<_> = count.into_iter().collect();\n    pairs.sort();\n    println!("{:?}", pairs);\n}',
    out: "[('e', 1), ('h', 1), ('l', 2), ('o', 1), ('r', 1), ('s', 1), ('t', 1), ('u', 1)]",
    note: 'A cipher substitution table is also just a `HashMap<char, char>`. Counting how often each letter appears was once the weapon that broke many classic ciphers.',
  },
  ch: {
    type: 'cipher', brief: 'Each letter uses a **substitution table**: look up every letter in a “dictionary” to get a different letter. Pick the code snippet that builds the right table so you can read the ciphertext.',
    hint: 'Try each snippet in turn and look at the result line. A substitution table that reverses the alphabet is A↔Z, B↔Y, C↔X…',
    rounds: [
      { kind: 'forms', plain: 'HASH MAP', use: 'atbash', forms: ['same', 'next', 'rot13', 'atbash'], q: 'Letter 1.', clue: 'The ciphertext starts with S and Z. In the reversed-alphabet table, which letter maps to S?' },
      { kind: 'forms', plain: 'FAST LOOKUP', use: 'rot13', forms: ['same', 'prev', 'rot13', 'atbash'], q: 'Letter 2: a different table.' },
    ],
  },
  trick: {
    name: 'Group by key in one line', why: 'Gather words with the same first letter into one group without checking “does the key exist yet?”.',
    pre: ['use std::collections::HashMap;', 'fn main() {'], post: ['}'],
    lines: ['let words = ["rust", "ruby", "go", "gleam", "gcc"];', 'let mut groups: HashMap<char, Vec<&str>> = HashMap::new();', 'for w in words {', 'groups.entry(w.chars().next().unwrap()).or_default().push(w);', '}', "println!(\"{:?}\", groups[&'g']);"],
    out: '["go", "gleam", "gcc"]',
    how: '`entry(key).or_default()` returns a `&mut Vec` (empty if the key is new), so `push` always works. “If it is not there, create it, then add to it” fits in one line.',
  },
});
