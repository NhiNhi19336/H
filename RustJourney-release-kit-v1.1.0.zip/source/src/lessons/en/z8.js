/* ===== Zone 8: Master Summit (lessons 29–32) ===== */

/* ---- Lesson 29: Bit manipulation ---- */
G.add(8, {
  title: 'Bit manipulation', sub: 'The operators & | ^ ! << >> on individual switches', tags: ['Operators', 'Math'],
  learn: {
    intro: 'Every number in the machine is a row of on/off switches called **bits**. Rust lets you touch each switch directly with the bit operators. They are fast and compact, and they are the foundation of cryptography, graphics, state flags and network protocols.',
    points: [
      '`&` (AND) keeps only the bits that are on in **both** values, so it works as a **mask** to filter or clear bits. `|` (OR) turns a bit on if **either** one is on.',
      '`^` (XOR) is on when the two bits are **different**. XOR with the same value twice brings you back to the start, which is why it shows up in cryptography. `!x` flips every bit of `x`.',
      '`x << n` shifts left by n bits, the same as multiplying by 2ⁿ. `x >> n` shifts right, the same as integer division by 2ⁿ.',
      'Write binary numbers as `0b0001_0110` (the underscores are only for readability) and print them with `{:08b}`. Unlike C, in Rust `&` is evaluated before `==`.',
    ],
    code: 'fn main() {\n    let x: u8 = 0b0001_0110; // 22\n    println!("{}", x << 1);\n    println!("{}", x >> 2);\n    println!("{:08b}", x & 0b0000_1111);\n    println!("{:08b}", x | 0b1000_0000);\n    println!("{:08b}", x ^ 0b0000_1111);\n    println!("{:08b}", !x);\n    println!("{}", x.count_ones());\n}',
    out: '44\n5\n00000110\n10010110\n00011001\n11101001\n3',
    note: 'Shifting by the type’s number of bits or more (for example `x << 8` with a `u8`) is an error: Rust reports it at compile time or panics at run time. For signed numbers, `>>` keeps the sign bit.',
  },
  ch: {
    type: 'bits', brief: 'An 8-bit register is waiting for you. The first round is about switching the right bits on. In the later rounds you choose operators to transform the number, and fewer moves is better.',
    hint: 'Round 1: the switches are worth 128, 64, 32, 16, 8, 4, 2, 1; add them up. After that: `|` turns a bit on, `&` with a mask clears bits, `^` flips bits, `<<` doubles.',
    rounds: [
      { mode: 'set', target: 77, q: 'Switch on the bits so the register equals **77**.' },
      { mode: 'ops', start: 4, target: 3, palette: [{ op: '|', v: 2 }, { op: '|', v: 1 }, { op: '&', v: 251 }, { op: '^', v: 4 }, { op: '<<', v: 1 }], max: 4, q: 'The file currently has **read** permission (bit 2). Change it so it has only **write** (bit 1) and **execute** (bit 0).' },
      { mode: 'ops', start: 5, target: 40, palette: [{ op: '<<', v: 1 }, { op: '<<', v: 2 }, { op: '>>', v: 1 }, { op: '|', v: 1 }], max: 3, q: 'Multiply **5** by **8** using only bit shifts.' },
      { mode: 'ops', start: 22, target: 30, palette: [{ op: '&', v: 240 }, { op: '|', v: 1 }, { op: '^', v: 15 }, { op: '>>', v: 1 }], max: 4, q: 'Turn **22** into **30**.' },
    ],
  },
  trick: {
    name: 'Power of 2 in one AND', why: 'Check whether a number is a power of 2 with no loop and no logarithm.',
    pre: [], post: [],
    lines: ['fn is_pow2(n: u32) -> bool {', 'n != 0 && n & (n - 1) == 0', '}', 'fn main() {', 'for n in [1, 6, 8, 12, 64] {', 'println!("{n}: {}", is_pow2(n));', '}', '}'],
    out: '1: true\n6: false\n8: true\n12: false\n64: true',
    how: 'A power of 2 has exactly **one** bit on. Subtracting 1 turns that bit off and turns every lower bit on, so `n & (n - 1)` clears the lowest set bit. The result is 0 exactly when `n` has just one bit. Because `&` is evaluated before `==`, no extra parentheses are needed.',
  },
});

/* ---- Lesson 30: Parallel threads ---- */
G.add(8, {
  title: 'Parallel threads', sub: 'thread, mpsc, Arc and Mutex', tags: ['Logic', 'Sequence'],
  learn: {
    intro: 'Modern machines have many cores, and **threads** let several pieces of code run at the same time. The classic pain is the **data race**: two threads change the same data with nobody watching. Rust turns this bug into a **compile error**, which is why people call it “fearless concurrency”.',
    points: [
      '`thread::spawn(move || { ... })` starts a new thread and returns a `JoinHandle`. Call `.join()` to wait for the thread to finish and receive its result.',
      'A thread can outlive the function that created it, so the closure must **own** the data it uses. The keyword `move` transfers ownership into the closure.',
      'The channel `mpsc::channel()` lets threads send messages to one place: `tx.send(v)` on the sending end, `rx` on the receiving end. `tx.clone()` lets many threads send.',
      'Shared data needs `Arc<Mutex<T>>`: `Arc` is a reference counter that is safe across threads (the thread-ready version of `Rc` from lesson 27), and `Mutex` is a lock, so only one thread at a time may `lock()` to modify the data. `Rc` is forbidden from crossing threads.',
    ],
    code: 'use std::sync::{mpsc, Arc, Mutex};\nuse std::thread;\n\nfn main() {\n    // 1) A thread returns its result through join\n    let total = thread::spawn(|| (1..=100).sum::<u32>());\n    println!("total = {}", total.join().unwrap());\n\n    // 2) Channel: three threads send to one place\n    let (tx, rx) = mpsc::channel();\n    for id in 1..=3 {\n        let tx = tx.clone();\n        thread::spawn(move || tx.send(id * 10).unwrap());\n    }\n    drop(tx);\n    let mut received: Vec<i32> = rx.iter().collect();\n    received.sort();\n    println!("received {:?}", received);\n\n    // 3) Arc<Mutex>: a shared counter\n    let counter = Arc::new(Mutex::new(0));\n    let mut handles = Vec::new();\n    for _ in 0..4 {\n        let counter = Arc::clone(&counter);\n        handles.push(thread::spawn(move || {\n            for _ in 0..1000 {\n                *counter.lock().unwrap() += 1;\n            }\n        }));\n    }\n    for h in handles {\n        h.join().unwrap();\n    }\n    println!("count = {}", *counter.lock().unwrap());\n}',
    out: 'total = 5050\nreceived [10, 20, 30]\ncount = 4000',
    note: 'Two pairs of twins: `Rc` ↔ `Arc` and `RefCell` ↔ `Mutex`. The multi-thread versions are a little slower because they have to synchronize, so Rust makes you choose on purpose. The compiler tells them apart with two marker traits, `Send` and `Sync`.',
  },
  ch: {
    type: 'bug', brief: 'A new thread is created, but it is only borrowing data from `main`, while the thread may run longer than the function. Find the line the compiler rejects and choose the fix.',
    hint: 'The new thread must not hold a reference to a variable of `main`, because nobody guarantees `main` is still alive. Let the closure **own** `nums`.',
    code: 'use std::thread;\n\nfn main() {\n    let nums = vec![1, 2, 3];\n    let t = thread::spawn(|| println!("{:?}", nums));\n    t.join().unwrap();\n}',
    bad: 4, ecode: 'E0373',
    err: 'error[E0373]: closure may outlive the current function, but it borrows `nums`, which is owned by the current function\n --> src/main.rs:5:27\n  |\n5 |     let t = thread::spawn(|| println!("{:?}", nums));\n  |                           ^^                  ---- `nums` is borrowed here\n  |                           |\n  |                           may outlive borrowed value `nums`\n  |\nnote: function requires argument type to outlive `\'static`\n --> src/main.rs:5:13\n  |\n5 |     let t = thread::spawn(|| println!("{:?}", nums));\n  |             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^',
    fixes: ['let t = thread::spawn(move || println!("{:?}", nums));', 'let t = thread::spawn(|| println!("{:?}", nums.clone()));', 'let t = thread::spawn(|| println!("{:?}", &nums));', 'let t = thread::spawn(&|| println!("{:?}", nums));'], fix: 0,
    why: '`thread::spawn` demands a closure that lives long enough (`\'static`), but `|| println!(.., nums)` only **borrows** `nums` from `main`. `move` transfers ownership of `nums` into the closure so the thread keeps its own data. Calling `nums.clone()` inside the closure does not help: the closure still has to borrow `nums` to call `clone`.',
  },
  trick: {
    name: 'Split the work in two with thread::scope', why: 'Let two threads borrow local data without `move`, `Arc` or `clone`.',
    lines: ['let nums = [1, 2, 3, 4, 5, 6];', 'let (left, right) = nums.split_at(3);', 'let (a, b) = std::thread::scope(|s| {', 'let ha = s.spawn(|| left.iter().sum::<i32>());', 'let hb = s.spawn(|| right.iter().sum::<i32>());', '(ha.join().unwrap(), hb.join().unwrap())', '});', 'println!("{a} {b} {}", a + b);'],
    out: '6 15 21',
    how: '`thread::scope` guarantees that every thread inside it **finishes before** it returns, so the threads may safely borrow local variables (`left`, `right`). This is another fix for error E0373 when the data does not need to outlive the function.',
  },
});

/* ---- Lesson 31: Macros ---- */
G.add(8, {
  title: 'Macros: code that writes code', sub: 'macro_rules! and the exclamation mark', tags: ['Logic', 'Sequence'],
  learn: {
    intro: 'A function receives **values**. A macro receives **source code** and returns new source code at compile time. You have used macros since the very first lesson: `println!`, `vec!` and `assert_eq!` are all macros, which is why they carry a `!`.',
    points: [
      '`macro_rules! name { (pattern) => { generated code }; }` declares a macro. Each arm has a **pattern** on the left and a **code template** on the right, like `match` but for syntax.',
      '`$x:expr` captures an expression, `$t:ty` captures a type, `$i:ident` captures a name. An expression is kept as one block, so you do not fall into the operator-precedence trap of C macros.',
      '`$( ... ),*` repeats the pattern for each comma-separated element. One arm for the shortest case plus a recursive call handles a list of any length.',
      'A macro sees only syntax, not types or values, and errors inside macros are harder to read than function errors. Use a macro when a function cannot do the job.',
    ],
    code: 'macro_rules! biggest {\n    ($a:expr) => { $a };\n    ($a:expr, $($rest:expr),+) => {{\n        let rest_max = biggest!($($rest),+);\n        if $a > rest_max { $a } else { rest_max }\n    }};\n}\n\nfn main() {\n    println!("{}", biggest!(7));\n    println!("{}", biggest!(3, 9, 4));\n    println!("{}", biggest!(1 + 1, 2 * 5, 8));\n}',
    out: '7\n9\n10',
    note: 'The expression `$a` is copied into two places, so it runs twice. For an expression with side effects, assign it to a variable first. Besides `macro_rules!`, Rust also has procedural macros such as `#[derive(Debug)]`, written in ordinary Rust code to transform syntax.',
  },
  ch: {
    type: 'quiz', brief: 'Four questions about macros. For the first three you need to predict what happens when the program is compiled and run.', hint: 'Expand the macro by hand: replace `$x` with the argument, then calculate. Remember that `$x:expr` is kept as one block.',
    qs: [
      { q: 'What does this program print?', code: 'macro_rules! double {\n    ($x:expr) => { $x * 2 };\n}\n\nfn main() {\n    println!("{}", double!(3 + 4));\n}', run: true, opts: ['14', '11', '10', 'Does not compile'], ans: 0, why: '`$x:expr` is one whole expression, so `3 + 4` is evaluated first and then doubled. A C macro only substitutes text and would give `3 + 4 * 2 = 11`; Rust macros do not fall into this trap.' },
      { q: 'What does this program print?', code: 'macro_rules! total {\n    () => { 0 };\n    ($d:expr $(, $rest:expr)*) => { $d + total!($($rest),*) };\n}\n\nfn main() {\n    println!("{}", total!(1, 2, 3, 4));\n}', run: true, opts: ['10', '4', '1234', 'Does not compile'], ans: 0, why: '`total!(1, 2, 3, 4)` expands to `1 + total!(2, 3, 4)`, then `1 + (2 + (3 + (4 + 0)))`. The empty arm `()` is the stopping condition of the recursion.' },
      { q: 'What does this program print?', code: 'macro_rules! make_fn {\n    ($name:ident, $v:expr) => {\n        fn $name() -> i32 { $v }\n    };\n}\n\nmake_fn!(five, 5);\nmake_fn!(six, 6);\n\nfn main() {\n    println!("{}", five() * six());\n}', run: true, opts: ['30', '56', '11', 'Does not compile'], ans: 0, why: 'The macro generates two functions: `fn five() -> i32 { 5 }` and `fn six() -> i32 { 6 }`. Then `five() * six()` is `5 * 6 = 30`. A macro can even create declarations, which a function cannot do.' },
      { q: 'What is the real difference between a macro and a function?', opts: ['A macro expands into code at compile time, so it can take any number of arguments and even syntax patterns', 'A macro always runs faster than a function', 'A macro never causes a compile error', 'A macro can only be used in the standard library'], ans: 0, why: 'A function has a fixed number of parameters and fixed types. A macro works on syntax before compilation, which is how `println!` can take any number of arguments. Run-time speed is not a reason to use a macro.' },
    ],
  },
  trick: {
    name: 'An inspector macro: print the expression and its value', why: 'Print the code you wrote together with its result, handy for checking calculations.',
    pre: [], post: [],
    lines: ['macro_rules! show {', '($e:expr) => {', 'println!("{} = {}", stringify!($e), $e)', '};', '}', 'fn main() {', 'show!(2 + 3 * 4);', 'show!(10 % 4);', '}'],
    out: '2 + 3 * 4 = 14\n10 % 4 = 2',
    how: '`stringify!($e)` turns the very characters of the expression into a string, while `$e` is evaluated to a value. An ordinary function cannot do this because by the time it runs, the text of the expression is gone. The standard library already has a macro `dbg!` that does something similar.',
  },
});

/* ---- Lesson 32: Final boss ---- */
G.add(8, {
  title: 'Final Boss: The Maze', sub: 'putting everything you learned together', tags: ['Spatial', 'Math', 'Logic'],
  learn: {
    intro: 'You have come all the way from the first `println!` line to here. Look back: the Bot throughout the journey is really a `struct` with a position, a direction and a map. The direction is a number from 0 to 3, and turning is just adding and subtracting **modulo 4**. The program below is the Bot’s insides, running the **right-hand rule**.',
    points: [
      'The direction is a number `h` in `0..4` (North, East, South, West). **Turning right** is `(h + 1) % 4`, **turning left** is `(h + 3) % 4`, because adding 3 is the same as subtracting 1 in modulo 4.',
      'The two constant arrays `DX` and `DY` are **direction vectors**: moving one cell in direction `h` means adding `(DX[h], DY[h])` to the coordinates. Math and space meet here.',
      '**The right-hand rule**: every round, if the right side is open, turn right; while there is a wall ahead, turn left; then step forward. The Bot needs no map and no memory, only sensors around itself.',
      'This rule always finds the way out of a maze without loops, but it does not choose the shortest path: the Bot even walks into dead ends. For the shortest path you need an algorithm that sees the whole map, like BFS.',
    ],
    code: 'const DX: [i32; 4] = [0, 1, 0, -1]; // North, East, South, West\nconst DY: [i32; 4] = [-1, 0, 1, 0];\n\nstruct Bot {\n    x: i32,\n    y: i32,\n    h: usize, // direction: 0 North, 1 East, 2 South, 3 West\n    grid: Vec<Vec<char>>,\n}\n\nimpl Bot {\n    fn cell_at(&self, h: usize) -> char {\n        let h = h % 4;\n        self.grid[(self.y + DY[h]) as usize][(self.x + DX[h]) as usize]\n    }\n    fn step(&mut self) {\n        self.x += DX[self.h];\n        self.y += DY[self.h];\n    }\n}\n\nfn main() {\n    let map = ["#######", "#S..#G#", "#.#.#.#", "#.#...#", "#######"];\n    let grid: Vec<Vec<char>> = map.iter().map(|row| row.chars().collect()).collect();\n    let mut bot = Bot { x: 1, y: 1, h: 1, grid };\n    let mut steps = 0;\n    while bot.grid[bot.y as usize][bot.x as usize] != \'G\' {\n        if bot.cell_at(bot.h + 1) != \'#\' {\n            bot.h = (bot.h + 1) % 4; // turn right\n        }\n        while bot.cell_at(bot.h) == \'#\' {\n            bot.h = (bot.h + 3) % 4; // turn left\n        }\n        bot.step();\n        steps += 1;\n    }\n    println!("Reached the goal ({}, {}) after {steps} steps", bot.x, bot.y);\n}',
    out: 'Reached the goal (5, 1) after 12 steps',
    note: 'The shortest path in this little maze is only 8 steps, while the right-hand Bot takes 12 because it walks into a dead end. You just used `struct`, `impl`, constant arrays, nested loops, modulo arithmetic and `&self` in one program: every piece was learned in the earlier zones.',
  },
  ch: {
    type: 'robot', brief: 'This maze is too big to write step by step, and it has 3 coins lying in dead ends. Teach the Bot the **right-hand rule**. Each loop round: pick up a coin if standing on one; if the right side is open, turn right; while there is a wall ahead, turn left; then move forward one cell. Repeat until the Bot reaches the goal. At most 9 blocks.',
    hint: 'The program frame is `while !at_goal { ... }`. Inside, in this order: `if on_coin { grab }`, `if !wall_right { right }`, `while wall_ahead { left }`, and finally `forward`.',
    grid: ['###########', '#S..#.....#', '###.#####.#', '#*#.......#', '#.#######.#', '#......*#.#', '#.#.#.###.#', '#.#.#*#...#', '#.#.###.###', '#G#.......#', '###########'], dir: 'E',
    palette: ['forward', 'left', 'right', 'grab', 'while:!at_goal', 'while:wall_ahead', 'if:on_coin', 'if:!wall_right', 'if:wall_ahead'], max: 9, par: 8,
    sol: 'while:!at_goal { if:on_coin { G } if:!wall_right { R } while:wall_ahead { L } F }',
  },
  trick: {
    name: 'Turn with the remainder', why: 'Change direction on a compass without a chain of `if` for each direction.',
    lines: ['let names = ["North", "East", "South", "West"];', 'let mut h = 0;', 'for cmd in "RRLR".chars() {', 'h = if cmd == \'R\' { (h + 1) % 4 } else { (h + 3) % 4 };', 'println!("{cmd} -> {}", names[h]);', '}'],
    out: 'R -> East\nR -> South\nL -> East\nR -> South',
    how: 'The direction is a number 0–3, so turning right is `+1`, turning left is `+3`, and then taking the remainder by 4 makes it go around. The same trick works for clock hands (`% 12`), days of the week (`% 7`) and anything that cycles.',
  },
});
