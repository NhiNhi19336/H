/* ===== Zone 5: Type Workshop ===== */
G.add(5, {
  title: 'struct: bundling data', sub: 'struct and fields', tags: ['Spatial', 'Math'],
  learn: {
    intro: '`struct` bundles several named values into one new type. A point on a map has two coordinates, a box has a length, a width and a height: gather them into a struct so you can carry them around together.',
    points: ['`struct Point { x: i32, y: i32 }` defines the type. Create a value with `Point { x: 3, y: 4 }`.', 'Access a field with a dot: `p.x`. To change it you must declare `let mut p`.', '`#[derive(Debug)]` lets you print with `{:?}`; `#[derive(Clone, Copy, PartialEq)]` adds copying and comparing.', 'The update syntax `Point { x: 9, ..a }` takes the remaining fields from `a`.'],
    code: '#[derive(Debug, Clone, Copy, PartialEq)]\nstruct Point {\n    x: i32,\n    y: i32,\n}\n\nfn main() {\n    let a = Point { x: 3, y: 4 };\n    let b = Point { x: 9, ..a };\n    println!("{:?} {:?}", a, b);\n    println!("{}", a == b);\n    let distance_from_origin = ((a.x * a.x + a.y * a.y) as f64).sqrt();\n    println!("{distance_from_origin}");\n}',
    out: 'Point { x: 3, y: 4 } Point { x: 9, y: 4 }\nfalse\n5',
    note: 'The Pythagorean theorem is right there in the code: the distance from the origin to (3, 4) is exactly 5.',
  },
  ch: {
    type: 'order', brief: 'Arrange the code pieces into a program that computes the area of a rectangle using a `struct`. One extra piece has the wrong syntax.',
    hint: 'The `struct Rect { ... }` definition comes first, and the `main` function comes after it. Inside a `struct`, each field is written `name: type,`. When you create a value you must write the field names: `Rect { length: 5, width: 3 }`.',
    lines: ['struct Rect {', 'length: u32,', 'width: u32,', '}', 'fn main() {', 'let r = Rect { length: 5, width: 3 };', 'println!("area = {}", r.length * r.width);', '}'],
    decoys: ['let r = Rect(5, 3);'], out: 'area = 15', btn: 'Compile and run',
  },
  trick: {
    name: 'Print a struct on many lines', why: 'Inspect nested structures as easily as reading a table, without counting brackets.',
    pre: [], post: [],
    lines: ['#[derive(Debug)]', 'struct Point { x: i32, y: i32 }', 'fn main() {', 'let p = Point { x: 1, y: 2 };', 'println!("{:#?}", p);', '}'],
    out: 'Point {\n    x: 1,\n    y: 2,\n}',
    how: '`{:?}` prints on one line, while `{:#?}` prints “prettily” on several lines with indentation. Both rely on `#[derive(Debug)]` writing the printing function for you.',
  },
});

G.add(5, {
  title: 'impl: methods', sub: 'impl, self and associated functions', tags: ['Spatial', 'Math', 'Operators'],
  learn: {
    intro: '`impl` attaches **behavior** to a type. A function inside `impl` whose first parameter is `self` is called a method: `a.manhattan(&b)`. A function without `self` (like `Point::new`) is called an **associated function**, and it is often used as a constructor.',
    points: ['`&self` borrows to read, `&mut self` borrows to change, and `self` takes full ownership.', '`Self` is a short name for the type being implemented.', 'Associated functions are called with `::`, methods are called with `.`.', 'You can have several `impl` blocks for the same type.'],
    code: '#[derive(Debug, Clone, Copy)]\nstruct Point {\n    x: i32,\n    y: i32,\n}\n\nimpl Point {\n    fn new(x: i32, y: i32) -> Self {\n        Self { x, y }\n    }\n\n    fn move_by(&mut self, dx: i32, dy: i32) {\n        self.x += dx;\n        self.y += dy;\n    }\n\n    fn manhattan(&self, other: &Point) -> i32 {\n        (self.x - other.x).abs() + (self.y - other.y).abs()\n    }\n}\n\nfn main() {\n    let mut a = Point::new(1, 1);\n    let b = Point::new(4, 5);\n    println!("{}", a.manhattan(&b));\n    a.move_by(3, 4);\n    println!("{:?} {}", a, a.manhattan(&b));\n}',
    out: '7\nPoint { x: 4, y: 5 } 0',
    note: 'Our Bot is also just a struct with methods: `bot.forward()`, `bot.turn_left()`.',
  },
  ch: {
    type: 'bug', brief: 'A method wants to increase a counter, but it was only allowed to borrow for reading. Find the line the compiler rejects and choose the fix.', hint: 'How must a method borrow if it changes its own object’s data? Look at the signature of the function `increment`.',
    code: 'struct Counter {\n    n: u32,\n}\nimpl Counter {\n    fn increment(&self) {\n        self.n += 1;\n    }\n}\nfn main() {\n    let mut c = Counter { n: 0 };\n    c.increment();\n    println!("{}", c.n);\n}',
    bad: 5, fixAt: 4, ecode: 'E0594',
    err: 'error[E0594]: cannot assign to `self.n`, which is behind a `&` reference\n --> src/main.rs:6:9\n  |\n6 |         self.n += 1;\n  |         ^^^^^^^^^^^ `self` is a `&` reference, so it cannot be written to',
    fixes: ['fn increment(&mut self) {', 'fn increment(mut self) {', 'fn increment(self) {', 'fn increment(&self, mut n: u32) {'], fix: 0,
    why: '`&self` only allows reading. A method that wants to change its own object must declare `&mut self`, and the caller must hold a `mut` variable.',
  },
  trick: {
    name: 'Chaining methods (builder)', why: 'Set up properties one by one with a readable chain of calls.',
    pre: [], post: [],
    lines: ['struct Rect { length: u32, width: u32 }', 'impl Rect {', 'fn new() -> Self { Rect { length: 1, width: 1 } }', 'fn length(mut self, l: u32) -> Self { self.length = l; self }', 'fn width(mut self, w: u32) -> Self { self.width = w; self }', 'fn area(&self) -> u32 { self.length * self.width }', '}', 'fn main() {', 'println!("{}", Rect::new().length(6).width(7).area());', '}'],
    out: '42',
    how: 'Each method takes `self` by value, changes it and returns it, so you can chain `.length(6).width(7)`. This Builder pattern is very common in Rust libraries.',
  },
});

G.add(5, {
  title: 'enum and match', sub: 'enum, variants that carry data', tags: ['Logic', 'Spatial'],
  learn: {
    intro: '`enum` defines a type that can only be **one of a few variants**. In Rust each variant can also **carry its own data**. `match` checks that you have handled every variant.',
    points: ['`enum Direction { North, East, South, West }`, used as `Direction::East`.', 'A variant can carry data: `Shape::Circle(f64)` or `Shape::Rect { length: f64, width: f64 }`.', '`match` must be **exhaustive**: missing a variant is a compile error.', 'Add a new variant to the enum and the compiler points at every `match` that needs updating.'],
    code: '#[derive(Debug, Clone, Copy)]\nenum Direction {\n    North,\n    East,\n    South,\n    West,\n}\n\nimpl Direction {\n    fn turn_right(self) -> Direction {\n        match self {\n            Direction::North => Direction::East,\n            Direction::East => Direction::South,\n            Direction::South => Direction::West,\n            Direction::West => Direction::North,\n        }\n    }\n}\n\nfn main() {\n    let mut d = Direction::North;\n    for _ in 0..3 {\n        d = d.turn_right();\n        println!("{:?}", d);\n    }\n}',
    out: 'East\nSouth\nWest',
    note: 'The four directions turning in a circle are the `% 4` operation from lesson 3, but an enum is safer than the numbers 0 to 3: there can be no “direction number 7”.',
  },
  ch: {
    type: 'bug', brief: 'A traffic light has three colors, but the `match` handles only two. Find the line the compiler rejects and choose a complete fix.', hint: 'The compiler says exactly which variant is missing. A good fix is to add a whole new branch for that variant.',
    code: "enum Light {\n    Red,\n    Yellow,\n    Green,\n}\nfn action(l: Light) -> &'static str {\n    match l {\n        Light::Red => \"stop\",\n        Light::Green => \"go\",\n    }\n}\nfn main() {\n    println!(\"{}\", action(Light::Yellow));\n}",
    bad: 6, fixAt: 8, ecode: 'E0004',
    err: 'error[E0004]: non-exhaustive patterns: `Light::Yellow` not covered\n --> src/main.rs:7:11\n  |\n7 |     match l {\n  |           ^ pattern `Light::Yellow` not covered',
    fixes: ['Light::Green => "go", Light::Yellow => "slow down",', 'Light::Green => "go" Light::Yellow => "slow down",', 'Light::Green => "go", Light::Yellow,', 'Light::Green => "go", Light::Orange => "get ready",'], fix: 0,
    why: '`match` must cover every variant. With `Light::Yellow` missing, the compiler refuses, so you can never forget a case.',
  },
  trick: {
    name: 'One formula per shape', why: 'Use an enum that carries data to compute the area of many kinds of shapes with one function.',
    pre: [], post: [],
    lines: ['enum Shape { Square(f64), Triangle(f64, f64) }', 'fn area(s: &Shape) -> f64 {', 'match s {', 'Shape::Square(a) => a * a,', 'Shape::Triangle(base, height) => 0.5 * base * height,', '}', '}', 'fn main() {', 'println!("{}", area(&Shape::Square(3.0)) + area(&Shape::Triangle(4.0, 3.0)));', '}'],
    out: '15',
    how: 'Each variant carries different data, and `match` unpacks it right in the pattern. Want to add a circle? Add one variant, and the compiler will point to the places that need updating.',
  },
});

G.add(5, {
  title: 'Option and Result', sub: 'Option, Result and the ? operator', tags: ['Logic', 'Math'],
  learn: {
    intro: 'Rust has no `null`. A value that may be absent is wrapped in `Option<T>`: either `Some(value)` or `None`. An action that may fail is wrapped in `Result<T, E>`: either `Ok(value)` or `Err(error)`. You are **forced** to handle both cases.',
    points: ['`a.get(i)` returns `Option<&T>`: it is `None` if the index is out of range, and there is no panic.', '`"42".parse::<i32>()` returns a `Result`: `Ok(42)`, or `Err(..)` if the string is not a number.', 'Use `if let Some(x) = opt { ... }` or `match` to unwrap. `unwrap_or(0)` gives a default value.', 'The `?` operator inside a function that returns `Result`: on `Err` it leaves the function and passes the error up, and on `Ok` it takes the value.'],
    code: 'fn divide(a: i32, b: i32) -> Option<i32> {\n    if b == 0 { None } else { Some(a / b) }\n}\n\nfn add_strings(a: &str, b: &str) -> Result<i32, std::num::ParseIntError> {\n    let x: i32 = a.parse()?;\n    let y: i32 = b.parse()?;\n    Ok(x + y)\n}\n\nfn main() {\n    println!("{:?} {:?}", divide(10, 2), divide(1, 0));\n    println!("{:?}", add_strings("20", "22"));\n    println!("{}", add_strings("20", "abc").is_err());\n    let a = [1, 2, 3];\n    println!("{}", a.get(7).copied().unwrap_or(-1));\n}',
    out: 'Some(5) None\nOk(42)\ntrue\n-1',
    note: 'Imagine `Option` as a box that may be empty. You have to open the box before you use it, so you never meet a “null pointer” error.',
  },
  ch: {
    type: 'quiz', brief: 'Four questions about the two types “may be missing” and “may fail”. Three of them need you to guess what the program prints.', hint: '`get` does not panic: an out-of-range index gives `None`. `parse` gives `Ok` if it can read a number and `Err` if it cannot.',
    qs: [
      { q: 'What does this program print?', code: 'fn main() {\n    let v = vec![10, 20, 30];\n    println!("{:?} {:?}", v.get(1), v.get(5));\n}', run: true, opts: ['Some(20) None', '20 None', 'Some(20) Some(0)', 'Some(20) and then a panic'], ans: 0, why: '`get` returns an `Option`: cell 1 holds 20, so it is `Some(20)`, and cell 5 does not exist, so it is `None`.' },
      { q: 'What does this program print?', code: 'fn main() {\n    let a = "12".parse::<i32>();\n    let b = "1x".parse::<i32>();\n    println!("{} {}", a.is_ok(), b.is_ok());\n}', run: true, opts: ['true false', 'true true', 'false false', 'Compile error'], ans: 0, why: '"12" can be read as a number, so it is `Ok`. "1x" cannot, so it is `Err`.' },
      { q: 'What does this program print?', code: 'fn main() {\n    let x: Option<i32> = None;\n    println!("{}", x.unwrap_or(7) + Some(3).unwrap_or(0));\n}', run: true, opts: ['10', '7', '3', 'Compile error'], ans: 0, why: '`None.unwrap_or(7)` gives 7, and `Some(3).unwrap_or(0)` gives 3. The sum is 10.' },
      { q: 'In a function that returns `Result`, what does the line `let x = s.parse::<i32>()?;` do when `s` is not a number?', opts: ['It leaves the function at once and returns the `Err` to the caller', 'It sets `x = 0` and keeps running', 'It makes the program panic', 'It skips this line'], ans: 0, why: 'The `?` operator passes the error up: on `Err` the function ends and returns that very error.' },
    ],
  },
  trick: {
    name: 'let … else: a tidy early exit', why: 'Unwrap an `Option` or `Result` and leave at once if it fails, so the main part of your code does not get nested in many levels.',
    lines: ['let text = "42";', 'let Ok(number) = text.parse::<i32>() else {', 'println!("not a number");', 'return;', '};', 'println!("double = {}", number * 2);'],
    out: 'double = 84',
    how: '`let PATTERN = expression else { ... };` unwraps when the pattern matches, and otherwise runs the `else` block (which must leave with `return`, `break`, `continue` or a panic). The “happy path” of the code stays lined up on the left.',
  },
});
