/* ===== Zone 4: Ownership Tower ===== */
const ARR8 = ['5', '2', '8', '1', '9', '4', '7', '3'];
const DROPCODE = "struct Key(&'static str);\n\nimpl Drop for Key {\n    fn drop(&mut self) {\n        println!(\"returned {}\", self.0);\n    }\n}\n";
G.add(4, {
  title: 'Ownership and move', sub: 'every value has exactly one owner', tags: ['Spatial', 'Logic'],
  learn: {
    intro: 'This is the biggest idea in Rust. Every value has exactly **one owner**, and when the owner goes out of scope the value is cleaned up. Picture a value as a **single key**: hand it to someone else (a move) and you no longer have it.',
    points: ['Rule 1: every value has an owner, which is a variable.', 'Rule 2: there can only be one owner at a time.', 'Rule 3: when the owner goes out of its scope `{ }`, the value is freed.', 'Assigning `let b = a;` with a `String` is a **move**: `a` can no longer be used. Integers are **copied**, so they are fine.'],
    code: 'fn main() {\n    let a = String::from("key");\n    let b = a;\n    println!("{b}");\n    let x = 5;\n    let y = x;\n    println!("{x} {y}");\n    let c = b.clone();\n    println!("{b} {c}");\n}',
    out: 'key\n5 5\nkey key',
    note: 'Thanks to these three rules Rust knows exactly when to free memory, with no garbage collector running in the background.',
  },
  ch: {
    type: 'bug', brief: 'A key has changed owners, but the old owner is still trying to use it. Find the line the compiler rejects and choose the fix.', hint: 'The one and only key was handed to `b`. To let both have the data, one way is to make a separate copy.',
    code: 'fn main() {\n    let a = String::from("key");\n    let b = a;\n    println!("{}", a);\n    println!("{}", b);\n}',
    bad: 3, fixAt: 2, ecode: 'E0382',
    err: 'error[E0382]: borrow of moved value: `a`\n --> src/main.rs:4:20\n  |\n2 |     let a = String::from("key");\n  |         - move occurs because `a` has type `String`, which does not implement the `Copy` trait\n3 |     let b = a;\n  |             - value moved here\n4 |     println!("{}", a);\n  |                    ^ value borrowed here after move',
    fixes: ['let b = a.clone();', 'let b = *a;', 'let b = a.copy();', 'let b: String = &a;'], fix: 0,
    why: '`let b = a;` moves ownership to `b`, so `a` can no longer be used. `a.clone()` makes a separate copy: each variable holds its own key.',
  },
  trick: {
    name: 'Pass through a function and come back', why: 'Lend ownership to a function, get the result back, and keep using the same variable name.',
    pre: [], post: [],
    lines: ['fn add_suffix(mut s: String) -> String {', 's.push_str("!");', 's', '}', 'fn main() {', 'let word = String::from("Rust");', 'let word = add_suffix(word);', 'println!("{word}");', '}'],
    out: 'Rust!',
    how: 'Passing a `String` into a function hands the key to that function. When the function is done it hands the key back as its return value, and we shadow the old variable with the same name. The next lesson has a lighter way: borrowing.',
  },
});

G.add(4, {
  title: 'Borrowing: & and &mut', sub: 'references and the borrowing rules', tags: ['Spatial', 'Logic'],
  learn: {
    intro: 'You do not always need to hand over the key. You can **lend** a value with a reference `&`. Rust guards one golden rule: at any moment there are either **many** readers or **exactly one** writer, never both.',
    points: ['`&x` is an immutable reference (read only); you can have many of them at the same time.', '`&mut x` is a mutable reference (it can write): there is only **one** at a time, and it cannot exist together with an `&x`.', 'A reference may never outlive its owner.', 'A function should take `&T` when it only reads, `&mut T` when it needs to change something, and `T` when it needs to take over ownership.'],
    code: 'fn length(s: &String) -> usize {\n    s.len()\n}\n\nfn add_mark(s: &mut String) {\n    s.push(\'!\');\n}\n\nfn main() {\n    let mut text = String::from("hello there");\n    println!("{}", length(&text));\n    add_mark(&mut text);\n    println!("{text}");\n}',
    out: '11\nhello there!',
    note: 'The rule “many readers or one writer” shuts down a whole family of bugs: data races between different parts of a program.',
  },
  ch: {
    type: 'bug', brief: 'One part of the program is reading data while another part wants to write it. Find the line the compiler rejects and choose the fix.', hint: '`push` needs write access to `v`, but `first` is still borrowing `v` for reading on a later line. How can `first` stop depending on `v`?',
    code: 'fn main() {\n    let mut v = vec![1, 2, 3];\n    let first = &v[0];\n    v.push(4);\n    println!("{}", first);\n}',
    bad: 3, fixAt: 2, ecode: 'E0502',
    err: 'error[E0502]: cannot borrow `v` as mutable because it is also borrowed as immutable\n --> src/main.rs:4:5\n  |\n3 |     let first = &v[0];\n  |                  - immutable borrow occurs here\n4 |     v.push(4);\n  |     ^^^^^^^^^ mutable borrow occurs here\n5 |     println!("{}", first);\n  |                    ----- immutable borrow later used here',
    fixes: ['let first = v[0];', 'let first = &mut v[0];', 'let first = &v;', 'let first = v.first();'], fix: 0,
    why: '`first` is borrowing `v` for reading, and `push` may move the `Vec` to a new place in memory, leaving `first` pointing at empty space. If you copy the value out (`v[0]` for an integer), `first` no longer borrows `v`.',
  },
  trick: {
    name: 'Take it out of the borrow', why: 'Swap or pull data out through `&mut` without breaking the ownership rules.',
    lines: ['let mut a = vec![1, 2];', 'let mut b = vec![9];', 'std::mem::swap(&mut a, &mut b);', 'let old = std::mem::take(&mut a);', 'println!("{:?} {:?} {:?}", a, b, old);'],
    out: '[] [1, 2] [9]',
    how: '`swap` exchanges two values. `take` pulls the value out and leaves the default value behind (an empty Vec). Both only need `&mut`, not ownership, so they work even when the data sits behind a reference.',
  },
});

G.add(4, {
  title: 'Slices', sub: 'the window &a[x..y]', tags: ['Spatial', 'Math'],
  learn: {
    intro: 'A slice is a **window** looking at a stretch of consecutive items in an array or a string, without copying the data. It is just a starting point and a length.',
    points: ['`&a[1..4]` takes cells 1, 2, 3 (**not** cell 4). `&a[..2]` is the first two cells, `&a[2..]` is from cell 2 to the end.', '`&a[1..=3]` includes cell 3.', 'The slice type is `&[T]`, and for strings it is `&str`. A function that takes `&[T]` works for both arrays and `Vec`s.', 'Slicing out of range, or in the middle of a UTF-8 character, panics.'],
    code: 'fn sum(xs: &[i32]) -> i32 {\n    let mut s = 0;\n    for x in xs {\n        s += x;\n    }\n    s\n}\n\nfn main() {\n    let a = [4, 8, 15, 16, 23, 42];\n    println!("{}", sum(&a[1..4]));\n    println!("{:?}", &a[..2]);\n    println!("{:?}", &a[4..]);\n    let name = "Rustacean";\n    println!("{}", &name[..4]);\n}',
    out: '39\n[4, 8]\n[23, 42]\nRust',
    note: 'A range `a..b` is always “half open”: it takes a and leaves out b. That is why the slice length is exactly `b - a`, with no plus or minus 1.',
  },
  ch: {
    type: 'cells', brief: 'For each slice, tap the **first cell** and then the **last cell** of the stretch that the slice covers.', hint: '`a..b` starts at cell a and stops **before** cell b. `a..=b` includes cell b too.',
    rounds: [
      { kind: 'range', W: 8, vals: ARR8, q: 'The array `a` has 8 cells. Choose the slice `&a[1..4]`.', ans: [1, 3] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Choose the slice `&a[2..=5]`.', ans: [2, 5] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Choose the slice `&a[..3]`.', ans: [0, 2] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Choose the slice `&a[5..]` (the array has 8 cells).', ans: [5, 7] },
    ],
  },
  trick: {
    name: 'Peel off first, middle and last with a pattern', why: 'Split off the first and last element of a sequence with a single pattern, and gather the middle into one variable.',
    lines: ['let a = [10, 20, 30, 40];', 'if let [first, middle @ .., last] = a {', 'println!("{first} {:?} {last}", middle);', '}'],
    out: '10 [20, 30] 40',
    how: 'The pattern `[first, middle @ .., last]` peels off the first and last element, and `middle @ ..` gathers everything in between. It only matches a sequence with at least 2 elements, just as we want.',
  },
});

G.add(4, {
  title: 'Scope, Copy and Clone', sub: 'scope, Drop, Copy and Clone', tags: ['Logic', 'Spatial'],
  learn: {
    intro: 'A scope is the region between two braces `{ }` where a variable is alive. When it leaves that region, the variable is cleaned up automatically, and if its type has `Drop`, the `drop` function runs at exactly that moment. (The code below uses `struct` and `impl`, which zone 5 will explain. For now just watch the order of the printed lines.)',
    points: ['Variables are destroyed in **reverse** order of declaration, like a stack of plates: the plate put down last is taken off first.', '`Copy` types (numbers, `bool`, `char`, tuples made only of Copy types) are copied on assignment, so they are not moved.', 'Other types need `.clone()` to be copied explicitly. Cloning can be expensive, so Rust makes you say it out loud.', '`drop(x)` destroys a value early.'],
    code: DROPCODE + '\nfn main() {\n    let _a = Key("key A");\n    {\n        let _b = Key("key B");\n        println!("inside the block");\n    }\n    let _c = Key("key C");\n    println!("end of main");\n}',
    out: 'inside the block\nreturned key B\nend of main\nreturned key C\nreturned key A',
    note: 'Cleanup happens at a fixed, predictable place: that is why Rust can manage files, locks and network connections, not only memory.',
  },
  ch: {
    type: 'quiz', brief: 'Four questions about the lifetime of values. For the first two you need to guess what the program prints.', hint: 'The value declared later is destroyed first. `Copy` types are copied on assignment, while a `String` is moved.',
    qs: [
      { q: 'What does this program print?', code: DROPCODE + '\nfn main() {\n    let _a = Key("A");\n    let _b = Key("B");\n    println!("done");\n}', run: true, opts: ['done\nreturned B\nreturned A', 'done\nreturned A\nreturned B', 'returned A\nreturned B\ndone', 'done'], ans: 0, why: 'It prints `done` first, then destroys in reverse order: `_b` (declared later) is destroyed before `_a`.' },
      { q: 'What does this program print?', code: 'fn main() {\n    let a = 7;\n    let b = a;\n    let s = String::from("hi");\n    let t = s.clone();\n    println!("{a} {b} {s} {t}");\n}', run: true, opts: ['7 7 hi hi', 'It does not compile because `s` was moved', 'It does not compile because `a` was moved', '7 7 hi'], ans: 0, why: 'Integers are `Copy`, so `a` is still intact. `s.clone()` makes a copy, so `s` is not moved.' },
      { q: 'Which of these types is **not** `Copy`?', opts: ['i32', 'bool', 'String', 'char'], ans: 2, why: '`String` owns memory on the heap, so it cannot be copied silently. To copy it you must call `.clone()`.' },
      { q: 'Two variables are declared in the order `x` then `y`. When they go out of scope, which one is destroyed first?', opts: ['`y` is destroyed first, then `x`', '`x` is destroyed first, then `y`', 'Both are destroyed at the same time', 'It depends on the compiler'], ans: 0, why: 'Rust destroys in the reverse order of declaration, and this rule is fixed.' },
    ],
  },
  trick: {
    name: 'A block is an expression', why: 'Compute a result with temporary variables, and let Rust clean them up the moment you are done.',
    lines: ['let total = {', 'let temp = vec![3, 4, 5];', 'temp.iter().sum::<i32>()', '};', 'println!("{total}");'],
    out: '12',
    how: 'A block `{ }` is an expression: its last value (without a `;`) is the result of the whole block. Every temporary variable inside, like `temp`, is cleaned up the moment the block ends, so no rubbish is left behind.',
  },
});
