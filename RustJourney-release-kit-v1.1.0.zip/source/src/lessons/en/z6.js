/* ===== Zone 6: The Laboratory ===== */
G.add(6, {
  title: 'Generics: one function, many types', sub: 'generics <T> and trait bounds', tags: ['Logic', 'Math'],
  learn: {
    intro: 'Write a function that finds the largest `i32`, then copy it word for word for `f64`… what a waste of effort. **Generics** let you write it once for every type: `T` is a blank that gets filled with a real type at compile time. Rust generates separate code for each type, so it is exactly as fast as writing it by hand.',
    points: ['`fn largest<T: PartialOrd + Copy>(a: T, b: T) -> T`: the `<T: ...>` part declares a generic type together with its **bounds** (trait bounds).', 'A bound says what `T` must be able to do: compare (`PartialOrd`), be copied (`Copy`), be printed (`Debug`)…', 'Structs can be generic too: `struct Pair<T> { left: T, right: T }`.', 'Without a bound you cannot do anything with `T`, not even compare it.'],
    code: 'fn largest<T: PartialOrd + Copy>(a: T, b: T) -> T {\n    if a > b { a } else { b }\n}\n\n#[derive(Debug)]\nstruct Pair<T> {\n    left: T,\n    right: T,\n}\n\nimpl<T: Copy> Pair<T> {\n    fn swap_sides(&self) -> Pair<T> {\n        Pair { left: self.right, right: self.left }\n    }\n}\n\nfn main() {\n    println!("{} {} {}", largest(3, 9), largest(2.5, 1.5), largest(\'a\', \'z\'));\n    let p = Pair { left: "east", right: "west" };\n    println!("{:?}", p.swap_sides());\n}',
    out: '9 2.5 z\nPair { left: "west", right: "east" }',
    note: 'One function, three types: integers, floats and characters. The compiler checks every call to make sure that type can do whatever the bound asks for.',
  },
  ch: {
    type: 'bug', brief: 'This function finds the largest value of any type `T`. Find the line the compiler rejects and choose the fix.', hint: 'Rust does not know whether `T` supports the `>` sign. You have to say so with a trait bound right inside the `< >`.',
    code: 'fn largest<T>(a: T, b: T) -> T {\n    if a > b { a } else { b }\n}\nfn main() {\n    println!("{}", largest(3, 9));\n}',
    bad: 1, fixAt: 0, ecode: 'E0369',
    err: 'error[E0369]: binary operation `>` cannot be applied to type `T`\n --> src/main.rs:2:10\n  |\n2 |     if a > b { a } else { b }\n  |        - ^ - T\n  |        |\n  |        T',
    fixes: ['fn largest<T: PartialOrd>(a: T, b: T) -> T {', 'fn largest<T: Copy>(a: T, b: T) -> T {', 'fn largest<T: Display>(a: T, b: T) -> T {', 'fn largest(a: T, b: T) -> T {'], fix: 0,
    why: '`T` is any type, so Rust does not yet know whether it can be compared. The bound `T: PartialOrd` promises that every type passed in has the comparison `>`.',
  },
  trick: {
    name: 'Largest of any sequence', why: 'One function that finds the maximum for integers, floats or characters.',
    pre: [], post: [],
    lines: ['fn max_of<T: PartialOrd + Copy>(xs: &[T]) -> T {', 'let mut m = xs[0];', 'for &x in xs {', 'if x > m { m = x; }', '}', 'm', '}', 'fn main() {', 'println!("{} {}", max_of(&[4, 9, 2]), max_of(&[1.5, 0.5]));', '}'],
    out: '9 1.5',
    how: '`&[T]` accepts a slice of any comparable type `T`. `for &x in xs` unwraps each reference into a plain value thanks to the `Copy` bound. The same function runs for `i32` and for `f64`.',
  },
});

G.add(6, {
  title: 'Traits: contracts for behavior', sub: 'trait, impl Trait and polymorphism', tags: ['Logic', 'Spatial'],
  learn: {
    intro: 'A **trait** is a contract: “anyone who wants to join must be able to do these things”. When many different types sign the same contract, we can treat them all alike: that is polymorphism. Rust uses traits where other languages use inheritance.',
    points: ['`trait Shape { fn area(&self) -> f64; }` declares the contract.', '`impl Shape for Square { ... }` means the type `Square` fulfills the contract.', 'A trait can have default methods; each type either reuses them or overrides them.', '`&impl Shape` or `&dyn Shape` accepts any type that implements `Shape`. (`Box` below is a box on the heap, which zone 7 teaches.)'],
    code: 'trait Shape {\n    fn area(&self) -> f64;\n    fn describe(&self) -> String {\n        format!("a shape with area {}", self.area())\n    }\n}\n\nstruct Square(f64);\nstruct Rectangle(f64, f64);\n\nimpl Shape for Square {\n    fn area(&self) -> f64 {\n        self.0 * self.0\n    }\n}\n\nimpl Shape for Rectangle {\n    fn area(&self) -> f64 {\n        self.0 * self.1\n    }\n    fn describe(&self) -> String {\n        format!("rectangle {} x {}", self.0, self.1)\n    }\n}\n\nfn main() {\n    let shapes: Vec<Box<dyn Shape>> = vec![Box::new(Square(3.0)), Box::new(Rectangle(2.0, 5.0))];\n    for s in &shapes {\n        println!("{}", s.describe());\n    }\n}',
    out: 'a shape with area 9\nrectangle 2 x 5',
    note: '`describe` comes ready-made in the contract: `Rectangle` overrides it while `Square` uses the default. The two types are completely different, yet they stand side by side in one `Vec`.',
  },
  ch: {
    type: 'order', brief: 'Arrange the code pieces into a program: a trait `Speak`, a type `Cat` that implements it, then a call to the method. One extra piece is a decoy with the contract written backwards.',
    hint: 'Order: declare the `trait`, declare the `struct`, then `impl Trait for Type`, and finally `main`. The piece `impl Cat for Speak` is backwards: it has to be `impl Speak for Cat`.',
    lines: ['trait Speak {', 'fn sound(&self) -> String;', '}', 'struct Cat;', 'impl Speak for Cat {', 'fn sound(&self) -> String {', '"meow".to_string()', '}', '}', 'fn main() {', 'println!("{}", Cat.sound());', '}'],
    decoys: ['impl Cat for Speak {'], out: 'meow', btn: 'Compile and run',
  },
  trick: {
    name: 'Accept anything that can “speak”', why: 'Write one function that works for every type implementing the same trait.',
    pre: [], post: [],
    lines: ['trait Speak { fn sound(&self) -> String; }', 'struct Dog;', 'struct Duck;', 'impl Speak for Dog { fn sound(&self) -> String { "woof".to_string() } }', 'impl Speak for Duck { fn sound(&self) -> String { "quack".to_string() } }', 'fn twice(x: &impl Speak) -> String { format!("{0} {0}", x.sound()) }', 'fn main() {', 'println!("{} / {}", twice(&Dog), twice(&Duck));', '}'],
    out: 'woof woof / quack quack',
    how: '`&impl Speak` means “a reference to any type that implements `Speak`”. The compiler generates separate code for each type, so there is no extra cost at run time.',
  },
});

G.add(6, {
  title: 'Lifetimes: how long a reference lives', sub: "lifetime 'a and how references relate", tags: ['Spatial', 'Logic'],
  learn: {
    intro: 'A reference is a **string** tied to someone else’s data. The string must never outlive the data, or it would point into thin air. Rust measures the **lifetime** of every reference to stop that mistake at compile time.',
    points: ["Most of the time the compiler works out lifetimes on its own. You only write `'a` when it is not sure.", "`fn longer<'a>(x: &'a str, y: &'a str) -> &'a str`: the result lives no longer than **both** inputs.", "The label `'a` does not make anything live longer. It only **describes** how the references relate.", "`'static` is a lifetime that lasts the whole program, for example every string literal such as `\"hello\"`."],
    code: "fn longer<'a>(x: &'a str, y: &'a str) -> &'a str {\n    if x.len() >= y.len() { x } else { y }\n}\n\nfn main() {\n    let a = String::from(\"hello\");\n    let result;\n    {\n        let b = String::from(\"rust-lang\");\n        result = longer(&a, &b).to_string();\n    }\n    println!(\"{result}\");\n}",
    out: 'rust-lang',
    note: "Picture every reference as a string with an expiry date. `'a` records: “the result string expires at the same moment as the shorter-lived of the two input strings”. Above we call `.to_string()` inside the block so the result no longer borrows from `b`.",
  },
  ch: {
    type: 'bug', brief: 'This function takes two references and returns one. Find the line the compiler rejects and choose the fix.', hint: 'There are two references coming in and one going out, and Rust cannot tell which one the result borrows from. Name the lifetime with `<\'a>`.',
    code: 'fn longer(x: &str, y: &str) -> &str {\n    if x.len() >= y.len() { x } else { y }\n}\nfn main() {\n    println!("{}", longer("hello", "rust"));\n}',
    bad: 0, fixAt: 0, ecode: 'E0106',
    err: "error[E0106]: missing lifetime specifier\n --> src/main.rs:1:32\n  |\n1 | fn longer(x: &str, y: &str) -> &str {\n  |              ----     ----     ^ expected named lifetime parameter\n  |\n  = help: this function's return type contains a borrowed value, but the signature does not say whether it is borrowed from `x` or `y`",
    fixes: ["fn longer<'a>(x: &'a str, y: &'a str) -> &'a str {", "fn longer(x: &str, y: &str) -> &'static str {", 'fn longer(x: &str, y: &str) -> str {', "fn longer<'a>(x: &'a str, y: &str) -> &'a str {"], fix: 0,
    why: "The result may borrow from `x` or from `y`, so the compiler needs to know how long it lives. Give the same label `'a` to both inputs and to the result: the result does not outlive either of them.",
  },
  trick: {
    name: 'Slice out the first word without copying', why: 'Return a slice borrowed straight from the input, with no extra memory allocated.',
    pre: [], post: [],
    lines: ['fn first_word(s: &str) -> &str {', "match s.find(' ') {", 'Some(i) => &s[..i],', 'None => s,', '}', '}', 'fn main() {', 'println!("[{}] [{}]", first_word("hello brave world"), first_word("Rust"));', '}'],
    out: '[hello] [Rust]',
    how: "There is only one input reference, so Rust infers that the result borrows from `s` and there is no need to write `'a`. This is the **elision** rule that spares most functions from spelling out lifetimes.",
  },
});

G.add(6, {
  title: 'Closures: anonymous functions', sub: 'closure |x|, Fn, FnMut and move', tags: ['Logic', 'Math'],
  learn: {
    intro: 'A **closure** is a function without a name that can **capture** the variables around it. Write `|x| x + n` anywhere you need a small piece of behavior, and it remembers the value of `n` from the place where it was created.',
    points: ['Syntax: `|parameter| expression` or `|a, b| { several lines }`.', 'A closure guesses its parameter types from how it is used. You can store it in a variable: `let double = |x| x * 2;`.', 'It captures variables in three ways: by borrowing (`Fn`), by borrowing mutably (`FnMut`), or by taking them over completely (`FnOnce`, with `move`).', 'A function that accepts a closure declares it with a trait: `fn repeat<F: Fn(i32) -> i32>(f: F, x: i32) -> i32`.'],
    code: 'fn apply<F: Fn(i32) -> i32>(f: F, x: i32) -> i32 {\n    f(x)\n}\n\nfn main() {\n    let double = |x| x * 2;\n    let n = 10;\n    let add_n = |x| x + n;\n    println!("{} {}", apply(double, 7), apply(add_n, 7));\n\n    let mut count = 0;\n    let mut tick = || {\n        count += 1;\n        count\n    };\n    tick();\n    tick();\n    println!("{}", tick());\n}',
    out: '14 17\n3',
    note: 'Closures are the foundation of iterators in a later zone: `.map(|x| x * 2)`, `.filter(|x| x % 2 == 0)`.',
  },
  ch: {
    type: 'quiz', brief: 'Four questions about closures. The first two ask you to guess the output.', hint: 'A closure remembers the surrounding variables from the moment it is created. `move` transfers those variables completely into the closure.',
    qs: [
      { q: 'What does this program print?', code: 'fn main() {\n    let n = 5;\n    let add = |x| x + n;\n    println!("{}", add(3));\n}', run: true, opts: ['8', '3', '5', 'Compile error'], ans: 0, why: 'The closure captures the outside variable `n` (= 5) and adds it to the argument 3.' },
      { q: 'What does this program print?', code: 'fn main() {\n    let mut total = 0;\n    let mut add = |x| total += x;\n    add(4);\n    add(6);\n    println!("{}", total);\n}', run: true, opts: ['10', '0', '4', 'Compile error because `total` is borrowed'], ans: 0, why: 'The closure borrows `total` mutably (FnMut). After the last call the closure is no longer used, so `total` is handed back and prints 10.' },
      { q: 'What does the keyword `move` in front of a closure do?', opts: ['Transfers ownership of the captured variables into the closure', 'Makes the closure run faster', 'Lets the closure modify any variable', 'Turns the closure into an ordinary function'], ans: 0, why: '`move` puts the variables inside the closure, so the closure can live on its own, for example when it is returned from a function or run on another thread.' },
      { q: 'Which trait is for a closure that only **reads** its captured variables and can be called many times?', opts: ['Fn', 'FnMut', 'FnOnce', 'Copy'], ans: 0, why: '`Fn` only borrows to read. `FnMut` borrows to modify, and `FnOnce` takes full ownership, so it can be called only once.' },
    ],
  },
  trick: {
    name: 'A function that makes functions', why: 'Build custom functions from a parameter, for example “add n” for any n you like.',
    pre: [], post: [],
    lines: ['fn make_adder(n: i32) -> impl Fn(i32) -> i32 {', 'move |x| x + n', '}', 'fn main() {', 'let add5 = make_adder(5);', 'let add100 = make_adder(100);', 'println!("{} {}", add5(1), add100(1));', '}'],
    out: '6 101',
    how: '`move` carries the value of `n` into the closure so it stays alive after the function ends. `impl Fn(i32) -> i32` means “something callable that takes an `i32` and returns an `i32`”. Every call to `make_adder` produces its own separate function.',
  },
});
