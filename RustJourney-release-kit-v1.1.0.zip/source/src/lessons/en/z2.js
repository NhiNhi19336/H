/* ===== Zone 2: Crossroads of Flow ===== */
G.add(2, {
  title: 'Branching with if / else', sub: 'if, else and if as an expression', tags: ['Spatial', 'Logic'],
  learn: {
    intro: 'A program does not only go straight. `if` tells it when to turn. In Rust, `if` is also an **expression**: it returns a value.',
    points: ['`if condition { ... } else { ... }`. The condition must be a `bool`; Rust never turns a number into true/false for you.', 'No parentheses are needed around the condition, but the `{}` are always required.', 'Because it is an expression, you can write `let s = if x > 0 { "positive" } else { "not positive" };`.', 'For more branches use `else if`. Every branch must produce the same type.'],
    code: 'fn main() {\n    let temperature = 31;\n    let advice = if temperature > 35 {\n        "stay indoors"\n    } else if temperature > 25 {\n        "bring water"\n    } else {\n        "wear a jacket"\n    };\n    println!("{temperature} degrees: {advice}");\n}',
    out: '31 degrees: bring water',
    note: 'The Bot can branch too: `if bot.wall_ahead() { ... }` asks the sensor before deciding which way to go.',
  },
  ch: {
    type: 'robot', brief: 'The Bot stands at the start of a spiral path. The `while` loop is already there (the locked block). Write the loop body: if there is a wall ahead, turn right; otherwise go forward.',
    hint: 'Use the `if … else` block. Put `turn_right` in the `if` branch and `forward` in the `else` branch. Tap the dashed line under `} else {` to insert the block into the right branch.',
    grid: ['#######', '#S....#', '#####.#', '#..G#.#', '#.###.#', '#.....#', '#######'], dir: 'E',
    pre: '!while:!at_goal { }', cursor: 'main/0.body', palette: ['ifelse:wall_ahead', 'forward', 'right', 'left'], max: 5, par: 3,
    sol: '!while:!at_goal { if:wall_ahead { R } else { F } }',
  },
  trick: {
    name: 'if is an expression', why: 'Choose a value by condition right inside a `let`, with no helper variable.',
    lines: ['let score = 8;', 'let grade = if score >= 8 { "Great" } else { "Good" };', 'let stars = if score == 10 { 3 } else if score >= 8 { 2 } else { 1 };', 'println!("{grade} {stars}");'],
    out: 'Great 2',
    how: 'Every branch of an `if` is an expression and must have the same type, so a whole `if` can sit on the right of `=`. That is why Rust does not need the ternary `? :` operator that C has.',
  },
});

G.add(2, {
  title: 'Loops', sub: 'loop, while, for and the range 0..n', tags: ['Spatial', 'Math'],
  learn: {
    intro: 'To repeat something, do not copy and paste. Rust has three kinds of loops: `loop` (forever, until `break`), `while` (repeat while the condition is still true) and `for` (walk through a range of numbers or a collection).',
    points: ['`for i in 0..5` runs with i = 0, 1, 2, 3, 4. The range `0..5` does not include 5, but `0..=5` does.', '`while condition { ... }` checks the condition before every round.', '`loop { ... }` repeats forever; leave it with `break` (and `break value` hands back a value).', '`continue` skips the rest of the current round.'],
    code: 'fn main() {\n    let mut total = 0;\n    for i in 1..=5 {\n        total += i;\n    }\n    println!("1 + 2 + ... + 5 = {total}");\n    let mut n = 27;\n    let mut steps = 0;\n    while n != 1 {\n        n = if n % 2 == 0 { n / 2 } else { 3 * n + 1 };\n        steps += 1;\n    }\n    println!("27 reaches 1 after {steps} steps");\n}',
    out: '1 + 2 + ... + 5 = 15\n27 reaches 1 after 111 steps',
    note: 'Four identical commands like `bot.forward();` are a sign to switch to `for _ in 0..4`: fewer lines, fewer mistakes.',
  },
  ch: {
    type: 'robot', brief: 'This staircase has 4 identical steps. Copy-pasting 16 commands is tiring and easy to get wrong, so use a `for` loop to repeat one step.',
    hint: 'One step is: go 1 square, turn left, go 1 square, turn right. Put those 4 commands inside the `for` block, then press + to set the repeat count to 4.',
    grid: ['#######', '#####G#', '####..#', '###..##', '##..###', '#S.####', '#######'], dir: 'E', palette: ['forward', 'left', 'right', 'for:3'], max: 8, par: 5,
    sol: 'for:4 { F L F R }',
  },
  trick: {
    name: 'Break out of two loops at once', why: 'Find the first pair of numbers that fits the condition, then stop both nested `for` loops.',
    lines: ['let mut result = (0, 0);', "'outer: for i in 1..10 {", 'for j in 1..10 {', 'if i * j == 42 {', 'result = (i, j);', "break 'outer;", '}', '}', '}', 'println!("{result:?}");'],
    out: '(6, 7)',
    how: "A plain `break` only leaves the innermost loop. Put a label `'outer:` on the outer loop and write `break 'outer;` to jump straight out of both. The first pair under 10 whose product is 42 is 6 × 7.",
  },
});

const PLANE = []; for (let y = 2; y >= -2; y--) for (let x = -2; x <= 2; x++) PLANE.push(x + ',' + y);
const QUAD = f => PLANE.map((_, i) => i).filter(i => f(Math.sign(i % 5 - 2), Math.sign(2 - Math.floor(i / 5))));
G.add(2, {
  title: 'match: pattern matching', sub: 'match, ranges and tuples', tags: ['Logic', 'Spatial'],
  learn: {
    intro: '`match` is Rust’s multi-way switch: you hand it a value, it tries each pattern in turn and runs the first branch that matches. Rust makes you cover **every** case, so you cannot forget a branch.',
    points: ['A pattern can be a value (`1`), a range (`2..=5`), several values (`6 | 7`) or `_` (everything else).', 'You can match a tuple too: `match (x, y) { (0, 0) => ... }`, which suits coordinates very well.', 'A branch can have an extra condition: `n if n < 0 => ...` (called a match guard).', '`match` is an expression: the result of the branch that matched is the value of the whole `match`.'],
    code: 'fn quadrant(x: i32, y: i32) -> &\'static str {\n    match (x.signum(), y.signum()) {\n        (0, 0) => "origin",\n        (1, 1) => "quadrant I",\n        (-1, 1) => "quadrant II",\n        (-1, -1) => "quadrant III",\n        (1, -1) => "quadrant IV",\n        _ => "on an axis",\n    }\n}\n\nfn main() {\n    println!("{}", quadrant(3, 4));\n    println!("{}", quadrant(-2, 5));\n    println!("{}", quadrant(0, -7));\n}',
    out: 'quadrant I\nquadrant II\non an axis',
    note: 'Each branch of `match` is a region of the coordinate plane: spatial thinking turns straight into code.',
  },
  ch: {
    type: 'cells', brief: 'Each cell shows an `x,y` pair (the y axis points up, as in math class). Tap the cell for which `quadrant(x, y)` returns the result you are asked for.',
    hint: '`signum()` gives -1, 0 or 1 depending on the sign. The top row has the largest y, and the leftmost column has the smallest x.',
    rounds: [
      { W: 5, vals: PLANE, sm: true, q: 'Tap the cell that gives the result **"origin"**.', ans: 12, why: 'Only the pair `(0, 0)` matches the first branch.' },
      { W: 5, vals: PLANE, sm: true, q: 'Tap **any cell** that gives the result **"quadrant II"**, that is, where `(x.signum(), y.signum())` equals `(-1, 1)`.', ans: QUAD((a, b) => a === -1 && b === 1), why: 'Quadrant II means x is negative and y is positive: the top-left corner.' },
      { W: 5, vals: PLANE, sm: true, q: 'Tap **any cell** (other than the origin) that gives the result **"on an axis"**.', ans: QUAD((a, b) => (a === 0) !== (b === 0)), why: 'One of the two coordinates is 0, so the point lies on the x axis or the y axis. None of the branches above match, so it falls into `_`.' },
    ],
  },
  trick: {
    name: 'FizzBuzz with a tuple match', why: 'Combine two remainders into one pair and let `match` decide, instead of nesting ifs.',
    pre: ['fn main() {', 'for n in [3, 5, 15, 7] {'], post: ['}', '}'],
    lines: ['let s = match (n % 3, n % 5) {', '(0, 0) => "FizzBuzz".to_string(),', '(0, _) => "Fizz".to_string(),', '(_, 0) => "Buzz".to_string(),', '_ => n.to_string(),', '};', 'println!("{s}");'],
    out: 'Fizz\nBuzz\nFizzBuzz\n7',
    how: 'The pair `(n % 3, n % 5)` is a coordinate on a 3×5 grid. The pattern `(0, 0)` goes before the others because `match` stops at the first branch that fits: the order of the branches is their priority.',
  },
});

G.add(2, {
  title: 'Functions and return values', sub: 'fn, parameters and return types', tags: ['Spatial', 'Math'],
  learn: {
    intro: 'A function is a piece of code with a name. Name it once, call it as many times as you like. A function takes **parameters** as input and can give back a **value** as output.',
    points: ['`fn name(a: i32, b: i32) -> i32 { ... }`: the types of the parameters and of the return value are always written out.', 'The last expression of a function, **without a `;`**, is the return value. You only need `return` to leave early.', 'A function that returns nothing actually returns `()` (the unit type).', 'A function can call other functions, even itself (recursion).'],
    code: 'fn square(x: i32) -> i32 {\n    x * x\n}\n\nfn distance(x1: i32, y1: i32, x2: i32, y2: i32) -> i32 {\n    (x2 - x1).abs() + (y2 - y1).abs()\n}\n\nfn main() {\n    println!("{}", square(7));\n    println!("{}", distance(1, 1, 4, 5));\n}',
    out: '49\n7',
    note: '`distance` measures the number of steps on a grid (the Manhattan distance): exactly what the Bot needs to know when it heads for the goal flag.',
  },
  ch: {
    type: 'robot', brief: 'The same staircase section shows up several times. Give the “climb one step” piece a name with a function called `leo` (it means “climb” in Vietnamese), then call it many times. This block palette has no `for`.',
    hint: 'Tap the dashed line inside `fn leo` to insert: go 1 square, turn left, go 1 square, turn right. Then tap the dashed line in `main`, call `leo` twice, go straight 2 squares, and call `leo` twice more.',
    grid: ['#########', '#######G#', '######..#', '###....##', '##..#####', '#S.######', '#########'], dir: 'E', fns: ['leo'], cursor: 'fn_leo',
    palette: ['forward', 'left', 'right', 'call:leo'], max: 12, par: 10, sol: 'fn:leo { F L F R } call:leo call:leo F F call:leo call:leo',
  },
  trick: {
    name: 'Return several values', why: 'One function returns both the quotient and the remainder as a tuple.',
    pre: [], post: [],
    lines: ['fn quot_rem(a: i32, b: i32) -> (i32, i32) {', '(a / b, a % b)', '}', 'fn main() {', 'let (q, r) = quot_rem(17, 5);', 'println!("17 = 5 * {q} + {r}");', '}'],
    out: '17 = 5 * 3 + 2',
    how: 'A tuple bundles several values into one. The receiver can “unpack” it right away with `let (q, r) = ...`. The last expression `(a / b, a % b)` has no `;`, so it is the return value.',
  },
});
