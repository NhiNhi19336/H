/* ===== Zone 1: Starter Village ===== */
G.add(1, {
  title: 'Your first program', sub: 'fn main and println!', tags: ['Spatial', 'Sequence'],
  learn: {
    intro: 'Every Rust program starts in the `main` function. The computer runs one line after another from top to bottom, just like the Bot walking square by square on the board: the command that comes first runs first.',
    points: ['`fn main() { ... }` is the front door of your program.', '`println!` prints a line of text on the screen. The `!` tells you it is a **macro**, not an ordinary function.', 'Every statement ends with a `;`.', 'Use `{}` inside a string to insert a value.'],
    code: 'fn main() {\n    println!("Hello, Rust!");\n    println!("2 + 3 = {}", 2 + 3);\n}',
    out: 'Hello, Rust!\n2 + 3 = 5',
    note: 'Order is everything: swap the two `println!` lines and the text on the screen swaps too.',
  },
  ch: {
    type: 'robot', brief: 'Program the Bot to walk from the start square to the goal flag. Each block is one command, and the machine runs them from top to bottom, just like `main`.',
    hint: 'Go straight 2 squares, turn right, go 2 squares, turn right, then go the last 2 squares.',
    grid: ['#####', '#S..#', '###.#', '#G..#', '#####'], dir: 'E', palette: ['forward', 'left', 'right'], max: 10, par: 8, sol: 'F F R F F R F F',
  },
  trick: {
    name: 'Print neatly with variable names', why: 'Print information quickly without typing each variable name twice.',
    lines: ['let name = "Rust";', 'let year = 2015;', 'println!("{name} reached version 1.0 in {year}");', 'println!("{name:?} has {} characters", name.len());'],
    out: 'Rust reached version 1.0 in 2015\n"Rust" has 4 characters',
    how: 'Since Rust 1.58 you can write a variable name right inside `{}` instead of listing it after the string. Add `:?` to print in Debug form (with quotes), which is very handy when you are hunting for bugs.',
  },
});

G.add(1, {
  title: 'Variables and who may change them', sub: 'let and mut', tags: ['Logic', 'Labeled boxes'],
  learn: {
    intro: 'Think of a variable as a labeled box. By default Rust sticks a note on it: “do not open and swap the contents”. The variable is **immutable**. If you want to change what is inside, you have to say `mut` out loud.',
    points: ['`let x = 5;` creates an immutable variable. Assigning to it again is rejected by the compiler.', '`let mut x = 5;` allows changes: `x = 6;` or `x += 1;`.', 'Rust guesses the type: `5` is an `i32`, `2.5` is an `f64`, `true` is a `bool`. You can also be explicit: `let x: u8 = 5;`.', 'Declaring the same name again with `let` is called **shadowing**: it creates a brand-new box.'],
    code: 'fn main() {\n    let name = "Ana";\n    let mut score = 7;\n    score += 2;\n    let score = score * 10;\n    println!("{name}: {score}");\n}',
    out: 'Ana: 90',
    note: 'Immutable by default lets you read code and be sure: a box without `mut` is never changed behind your back.',
  },
  ch: {
    type: 'bug', brief: 'Play the compiler: find the line it rejects, then choose the right fix.', hint: 'The broken line is the one that assigns a new value to a variable. How was that variable declared above?',
    code: 'fn main() {\n    let score = 5;\n    println!("Before: {}", score);\n    score = score + 1;\n    println!("After: {}", score);\n}',
    bad: 3, fixAt: 1, ecode: 'E0384',
    err: 'error[E0384]: cannot assign twice to immutable variable `score`\n --> src/main.rs:4:5\n  |\n2 |     let score = 5;\n  |         ----- first assignment to `score`\n3 |     println!("Before: {}", score);\n4 |     score = score + 1;\n  |     ^^^^^^^^^^^^^^^^^ cannot assign twice to immutable variable',
    fixes: ['let mut score = 5;', 'let score: i32 = 5;', 'let score = mut 5;', 'const score = 5;'], fix: 0,
    why: 'Variables made with `let` are immutable by default. Add `mut` at the **declaration** to allow reassigning later.',
  },
  trick: {
    name: 'Swap without a temporary variable', why: 'Swap two variables in a single line.',
    lines: ['let mut a = 3;', 'let mut b = 8;', '(a, b) = (b, a);', 'println!("a = {a}, b = {b}");'],
    out: 'a = 8, b = 3',
    how: 'The right side `(b, a)` is fully evaluated first, and only then assigned into `(a, b)`. The same kind of trick gives you the Fibonacci sequence: `(a, b) = (b, a + b);`.',
  },
});

G.add(1, {
  title: 'Arithmetic and the remainder', sub: 'arithmetic operators and %', tags: ['Math', 'Operators', 'Ciphers'],
  learn: {
    intro: 'Rust has all the familiar arithmetic operators. One special thing: dividing two integers gives an integer, and `%` gives the **remainder**, the key to everything that goes around in circles, from clocks to ciphers.',
    points: ['`+ - * /` are add, subtract, multiply and divide. With integers, `7 / 2` is `3` (the fraction is dropped).', '`%` is the remainder: `7 % 3 = 1`. A number `x` is divisible by 3 when `x % 3 == 0`.', 'Different number types do not mix by themselves: convert with `as`, for example `(x as f64) / 2.0`.', 'Overflow (like `255u8 + 1`) is an error at run time in debug mode. To wrap around on purpose, use `wrapping_add`.'],
    code: 'fn main() {\n    let seconds = 3725;\n    let hours = seconds / 3600;\n    let minutes = (seconds % 3600) / 60;\n    let rest = seconds % 60;\n    println!("{seconds} s = {hours} h {minutes} min {rest} s");\n    println!("{}", 7.0 / 2.0);\n    println!("{}", 7 / 2);\n}',
    out: '3725 s = 1 h 2 min 5 s\n3.5\n3',
    note: 'The remainder turns a straight line into a circle: after the 9 on a number lock you are back at 0. We use exactly that to decode a message right now.',
  },
  ch: {
    type: 'cipher', brief: 'The treasure’s number lock has been encrypted: every digit had a secret number added to it, then was reduced to the remainder after dividing by 10. Adjust K so that `(d + K) % 10` gives back the original digits.',
    hint: 'On a circle of 10 numbers, how many more steps bring you back to the same spot? If the cipher added 3, then adding 7 completes the lap (3 + 7 = 10).',
    rounds: [
      { kind: 'digits', plain: '4096', shift: 3, q: 'Cipher 1: the lock code had 3 added to every digit. Find K to get the unlock code.' },
      { kind: 'digits', plain: '20481', shift: 8, q: 'Cipher 2: this time the encoder added a different number. Find K yourself.', clue: 'Keep trying until the four or five digits form a pattern you recognize: the number has a 0 in the second place.' },
    ],
  },
  trick: {
    name: 'Wrap-around index', why: 'Keep stepping around a circle of n cells without ever going out of bounds.',
    lines: ['let n = 5;', 'let mut i = 3;', 'for _ in 0..4 {', 'i = (i + 1) % n;', 'print!("{i} ");', '}', 'println!();'],
    out: '4 0 1 2',
    how: 'The remainder after dividing by `n` is always between 0 and n-1, so `i` wraps back to 0 after it touches n-1. To step backwards use `(i + n - 1) % n` so you never get a negative number.',
  },
});

G.add(1, {
  title: 'Logic: true or false', sub: 'bool, comparisons, && || !', tags: ['Logic', 'Operators'],
  learn: {
    intro: 'The `bool` type has only two values: `true` and `false`. Comparing two numbers gives a `bool`, and the logical operators let you combine several conditions into one big question.',
    points: ['Comparisons: `==` equal, `!=` not equal, `<` `<=` `>` `>=`.', '`&&` is AND (both must be true), `||` is OR (at least one is true), `!` is NOT.', '`&&` and `||` are evaluated **lazily**: if the left side already decides the answer, the right side does not run.', 'Precedence: `!` first, then `&&`, then `||`. Use parentheses to make it clear.'],
    code: 'fn main() {\n    let age = 17;\n    let has_ticket = true;\n    let can_enter = age >= 18 || (age >= 15 && has_ticket);\n    println!("{can_enter}");\n    println!("{}", !can_enter);\n    println!("{}", 5 == 5 && 3 != 3);\n}',
    out: 'true\nfalse\nfalse',
    note: 'This is exactly a logic gate in an electric circuit: AND puts two switches in a row, OR puts two switches side by side.',
  },
  ch: {
    type: 'logic', brief: 'Each row of a truth table is one combination of switches. Find **all** the combinations that make the lamp light up.',
    hint: 'Try everything on, everything off, then one switch at a time. The table below shows the result of every combination you have recorded.',
    rounds: [{ expr: 'a && b', vars: ['a', 'b'], want: true }, { expr: 'a || b', vars: ['a', 'b'], want: true }, { expr: '(a || b) && !c', vars: ['a', 'b', 'c'], want: true }],
  },
  trick: {
    name: 'Range check', why: 'Ask “is x inside this range?” with a single expression.',
    lines: ['let x = 42;', 'let in_range = (10..=50).contains(&x);', 'let is_even = x % 2 == 0;', 'println!("{in_range} {is_even}");'],
    out: 'true true',
    how: '`(a..=b).contains(&x)` replaces `x >= a && x <= b`: it is shorter, and you can never flip a comparison sign by mistake. A range `a..b` (without the `=`) leaves b out.',
  },
});
