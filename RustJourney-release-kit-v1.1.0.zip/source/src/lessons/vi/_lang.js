/* ===== Gói ngôn ngữ: Tiếng Việt (tên vùng, cấp bậc, giới thiệu) ===== */
G.defZones('vi', [
  ['Làng Khởi Động', 'Tập sự', 'Chương trình đầu tiên, biến, số và toán tử.'],
  ['Ngã Rẽ Dòng Chảy', 'Người dẫn đường', 'Rẽ nhánh, lặp, khớp mẫu và hàm.'],
  ['Kho Dữ Liệu', 'Thủ kho', 'Mảng, Vec, chuỗi và bảng băm.'],
  ['Tháp Sở Hữu', 'Người giữ chìa', 'Move, mượn, lát cắt và dọn dẹp tự động.'],
  ['Xưởng Kiểu Dữ Liệu', 'Kiến trúc sư', 'struct, enum, Option và Result.'],
  ['Phòng Thí Nghiệm', 'Nhà phát minh', 'Generics, trait, lifetime và closure.'],
  ['Dòng Chảy và Con Trỏ', 'Phù thủy', 'Iterator, con trỏ thông minh, toán tử tùy biến.'],
  ['Đỉnh Bậc Thầy', 'Bậc thầy Rust', 'Bit, đa luồng, macro và trùm cuối.'],
]);
