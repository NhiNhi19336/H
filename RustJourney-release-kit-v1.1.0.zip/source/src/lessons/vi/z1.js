/* ===== Vùng 1: Làng Khởi Động ===== */
G.add(1, {
  title: 'Chương trình đầu tiên', sub: 'fn main và println!', tags: ['Không gian', 'Trình tự'],
  learn: {
    intro: 'Mọi chương trình Rust bắt đầu từ hàm `main`. Máy tính chạy từng dòng từ trên xuống dưới, giống Bot đi từng ô trên bàn cờ: lệnh nào đứng trước thì chạy trước.',
    points: ['`fn main() { ... }` là cổng vào của chương trình.', '`println!` in một dòng chữ ra màn hình. Dấu `!` cho biết nó là **macro**, không phải hàm thường.', 'Mỗi câu lệnh kết thúc bằng dấu `;`.', 'Dùng `{}` trong chuỗi để chèn một giá trị vào.'],
    code: 'fn main() {\n    println!("Xin chào, Rust!");\n    println!("2 + 3 = {}", 2 + 3);\n}',
    out: 'Xin chào, Rust!\n2 + 3 = 5',
    note: 'Thứ tự là tất cả: đảo hai dòng `println!` thì chữ trên màn hình cũng đảo theo.',
  },
  ch: {
    type: 'robot', brief: 'Lập trình Bot đi từ ô xuất phát tới ô cờ đích. Mỗi khối là một câu lệnh, máy chạy từ trên xuống dưới, y như `main`.',
    hint: 'Đi thẳng 2 ô, rẽ phải, đi 2 ô, rẽ phải, rồi đi nốt 2 ô.',
    grid: ['#####', '#S..#', '###.#', '#G..#', '#####'], dir: 'E', palette: ['forward', 'left', 'right'], max: 10, par: 8, sol: 'F F R F F R F F',
  },
  trick: {
    name: 'In gọn bằng tên biến', why: 'In thông tin nhanh mà không phải viết tên biến hai lần.',
    lines: ['let ten = "Rust";', 'let nam = 2015;', 'println!("{ten} ra mắt bản 1.0 năm {nam}");', 'println!("{ten:?} có {} ký tự", ten.len());'],
    out: 'Rust ra mắt bản 1.0 năm 2015\n"Rust" có 4 ký tự',
    how: 'Từ Rust 1.58, bạn viết thẳng tên biến vào `{}` thay vì liệt kê phía sau. Thêm `:?` để in dạng Debug (có dấu nháy), rất tiện khi soi lỗi.',
  },
});

G.add(1, {
  title: 'Biến và quyền thay đổi', sub: 'let và mut', tags: ['Logic', 'Hộp có nhãn'],
  learn: {
    intro: 'Hãy nghĩ biến là một chiếc hộp có dán nhãn. Mặc định Rust dán thêm con tem “không được mở ra thay đồ”: biến **bất biến**. Muốn đổi nội dung, bạn phải ghi rõ `mut`.',
    points: ['`let x = 5;` tạo biến bất biến. Gán lại sẽ bị trình biên dịch từ chối.', '`let mut x = 5;` cho phép đổi giá trị: `x = 6;` hoặc `x += 1;`.', 'Rust tự đoán kiểu: `5` là `i32`, `2.5` là `f64`, `true` là `bool`. Có thể ghi rõ: `let x: u8 = 5;`.', 'Khai báo lại cùng tên bằng `let` gọi là **shadowing** (che bóng): tạo một chiếc hộp mới.'],
    code: 'fn main() {\n    let ten = "An";\n    let mut diem = 7;\n    diem += 2;\n    let diem = diem * 10;\n    println!("{ten}: {diem}");\n}',
    out: 'An: 90',
    note: 'Mặc định bất biến giúp bạn đọc code mà biết chắc: hộp nào không có `mut` thì không bao giờ bị đổi lén.',
  },
  ch: {
    type: 'bug', brief: 'Đóng vai trình biên dịch: tìm dòng bị từ chối, rồi chọn cách sửa đúng.', hint: 'Dòng bị lỗi là dòng đang gán lại giá trị cho một biến. Biến đó được khai báo thế nào ở trên?',
    code: 'fn main() {\n    let diem = 5;\n    println!("Trước: {}", diem);\n    diem = diem + 1;\n    println!("Sau: {}", diem);\n}',
    bad: 3, fixAt: 1, ecode: 'E0384',
    err: 'error[E0384]: cannot assign twice to immutable variable `diem`\n --> src/main.rs:4:5\n  |\n2 |     let diem = 5;\n  |         ---- first assignment to `diem`\n3 |     println!("Trước: {}", diem);\n4 |     diem = diem + 1;\n  |     ^^^^^^^^^^^^^^^ cannot assign twice to immutable variable',
    fixes: ['let mut diem = 5;', 'let diem: i32 = 5;', 'let diem = mut 5;', 'const diem = 5;'], fix: 0,
    why: 'Biến `let` mặc định bất biến. Thêm `mut` ở chỗ **khai báo** để cho phép gán lại về sau.',
  },
  trick: {
    name: 'Hoán đổi không cần biến tạm', why: 'Đổi chỗ hai biến chỉ bằng một dòng.',
    lines: ['let mut a = 3;', 'let mut b = 8;', '(a, b) = (b, a);', 'println!("a = {a}, b = {b}");'],
    out: 'a = 8, b = 3',
    how: 'Vế phải `(b, a)` được tính xong hoàn toàn trước, rồi mới gán sang `(a, b)`. Cùng kiểu mẹo này cho dãy Fibonacci: `(a, b) = (b, a + b);`.',
  },
});

G.add(1, {
  title: 'Số học và phép chia dư', sub: 'toán tử số học và %', tags: ['Toán', 'Toán tử', 'Mật mã'],
  learn: {
    intro: 'Rust có đủ các toán tử số học quen thuộc. Điều đặc biệt: chia hai số nguyên cho ra số nguyên, và `%` lấy **phần dư**, chìa khóa của mọi trò quay vòng, từ đồng hồ đến mật mã.',
    points: ['`+ - * /` là cộng, trừ, nhân, chia. Với số nguyên, `7 / 2` bằng `3` (bỏ phần thập phân).', '`%` là phần dư: `7 % 3 = 1`. Số `x` chia hết cho 3 khi `x % 3 == 0`.', 'Hai kiểu số khác nhau không tự trộn được: đổi bằng `as`, ví dụ `(x as f64) / 2.0`.', 'Tràn số (như `255u8 + 1`) báo lỗi khi chạy ở chế độ debug. Muốn quay vòng thì dùng `wrapping_add`.'],
    code: 'fn main() {\n    let giay = 3725;\n    let gio = giay / 3600;\n    let phut = (giay % 3600) / 60;\n    let con_lai = giay % 60;\n    println!("{giay} giây = {gio} giờ {phut} phút {con_lai} giây");\n    println!("{}", 7.0 / 2.0);\n    println!("{}", 7 / 2);\n}',
    out: '3725 giây = 1 giờ 2 phút 5 giây\n3.5\n3',
    note: 'Phép chia dư biến một đường thẳng thành một vòng tròn: sau số 9 của chiếc khóa số lại về 0. Ta dùng đúng điều đó để giải mã ngay bây giờ.',
  },
  ch: {
    type: 'cipher', brief: 'Chiếc khóa số của kho báu đã bị mã hóa: mỗi chữ số được cộng thêm một số bí mật rồi lấy dư cho 10. Hãy chỉnh K để `(d + K) % 10` trả lại các chữ số gốc.',
    hint: 'Trên vòng tròn 10 số, đi tiếp bao nhiêu bước để quay về đúng chỗ cũ? Nếu bản mã đã cộng thêm 3, thì cộng thêm 7 là đủ một vòng (3 + 7 = 10).',
    rounds: [
      { kind: 'digits', plain: '4096', shift: 3, q: 'Bản mã 1: khóa đã được cộng thêm 3. Tìm K để ra mã mở khóa.' },
      { kind: 'digits', plain: '20481', shift: 8, q: 'Bản mã 2: lần này người mã hóa cộng một số khác. Hãy tự tìm K.', clue: 'Chỉ cần thử đến khi bốn năm chữ số ra một dãy bạn đoán được ý nghĩa: số có 0 ở vị trí thứ hai.' },
    ],
  },
  trick: {
    name: 'Xoay vòng chỉ số', why: 'Đi tiếp trên một vòng tròn n ô mà không bao giờ vượt biên.',
    lines: ['let n = 5;', 'let mut i = 3;', 'for _ in 0..4 {', 'i = (i + 1) % n;', 'print!("{i} ");', '}', 'println!();'],
    out: '4 0 1 2',
    how: 'Chia dư cho `n` luôn trả về số trong khoảng 0 đến n-1, nên `i` tự quay về 0 sau khi chạm n-1. Muốn lùi một bước thì dùng `(i + n - 1) % n` để khỏi bị số âm.',
  },
});

G.add(1, {
  title: 'Logic: đúng hay sai', sub: 'bool, so sánh, && || !', tags: ['Logic', 'Toán tử'],
  learn: {
    intro: 'Kiểu `bool` chỉ có hai giá trị: `true` và `false`. So sánh hai số cho ra một `bool`, còn các toán tử logic cho phép ghép nhiều điều kiện thành một câu hỏi lớn.',
    points: ['So sánh: `==` bằng, `!=` khác, `<` `<=` `>` `>=`.', '`&&` là VÀ (cả hai cùng đúng), `||` là HOẶC (ít nhất một đúng), `!` là PHỦ ĐỊNH.', '`&&` và `||` đánh giá **lười**: nếu vế trái đã đủ quyết định thì vế phải không chạy.', 'Thứ tự ưu tiên: `!` trước, rồi `&&`, rồi `||`. Dùng ngoặc cho rõ ràng.'],
    code: 'fn main() {\n    let tuoi = 17;\n    let co_ve = true;\n    let duoc_vao = tuoi >= 18 || (tuoi >= 15 && co_ve);\n    println!("{duoc_vao}");\n    println!("{}", !duoc_vao);\n    println!("{}", 5 == 5 && 3 != 3);\n}',
    out: 'true\nfalse\nfalse',
    note: 'Đây chính là cổng logic trong mạch điện: VÀ nối tiếp hai công tắc, HOẶC nối song song hai công tắc.',
  },
  ch: {
    type: 'logic', brief: 'Mỗi dòng của bảng chân trị là một tổ hợp công tắc. Tìm **tất cả** tổ hợp làm bóng đèn sáng.',
    hint: 'Thử bật hết, tắt hết, rồi từng công tắc một. Bảng bên dưới hiện kết quả của mọi tổ hợp bạn đã ghi lại.',
    rounds: [{ expr: 'a && b', vars: ['a', 'b'], want: true }, { expr: 'a || b', vars: ['a', 'b'], want: true }, { expr: '(a || b) && !c', vars: ['a', 'b', 'c'], want: true }],
  },
  trick: {
    name: 'Kiểm tra khoảng giá trị', why: 'Hỏi “x có nằm trong khoảng này không?” chỉ bằng một biểu thức.',
    lines: ['let x = 42;', 'let trong_khoang = (10..=50).contains(&x);', 'let la_chan = x % 2 == 0;', 'println!("{trong_khoang} {la_chan}");'],
    out: 'true true',
    how: '`(a..=b).contains(&x)` thay cho `x >= a && x <= b`: gọn, và không bao giờ viết nhầm chiều dấu so sánh. Dải `a..b` (không có dấu `=`) sẽ loại b ra.',
  },
});
