/* ===== Vùng 3: Kho Dữ Liệu ===== */
const ARR7 = ['7', '3', '9', '1', '5', '8', '2'], LET12 = 'ABCDEFGHIJKL'.split('');
G.add(3, {
  title: 'Mảng và chỉ số', sub: 'mảng [T; N], chỉ số và len', tags: ['Không gian', 'Toán'],
  learn: {
    intro: 'Mảng là một dãy ô nằm sát nhau, mọi ô cùng kiểu và số ô cố định. Bạn tìm một ô bằng **chỉ số**, đếm từ 0, giống đánh số ghế trong một hàng mà ghế đầu tiên là số 0.',
    points: ['`let a = [10, 20, 30];` có kiểu `[i32; 3]`. `a[0]` là 10, `a[2]` là 30.', '`a.len()` cho số phần tử. Phần tử cuối là `a[a.len() - 1]`.', 'Chỉ số vượt biên làm chương trình **panic** (dừng an toàn), không bao giờ đọc bậy sang vùng nhớ khác. Muốn thử mà không panic, dùng `a.get(i)`.', '`for x in a` hoặc `for i in 0..a.len()` để đi qua từng ô.'],
    code: 'fn main() {\n    let a = [10, 20, 30, 40, 50];\n    println!("{} {}", a[0], a[a.len() - 1]);\n    let mut tong = 0;\n    for i in 0..a.len() {\n        tong += a[i];\n    }\n    println!("tổng = {tong}");\n    println!("{:?}", a.get(9));\n}',
    out: '10 50\ntổng = 150\nNone',
    note: 'Đếm từ 0 nghe lạ nhưng có lý: chỉ số chính là **khoảng cách** tính từ ô đầu tiên.',
  },
  ch: {
    type: 'cells', brief: 'Dãy số dưới đây là mảng `a`. Hãy chạm đúng ô mà biểu thức chỉ số trỏ tới.', hint: 'Chỉ số đếm từ 0. Mảng có 7 phần tử nên `a.len()` bằng 7 và ô cuối là `a[6]`.',
    rounds: [
      { W: 7, vals: ARR7, q: 'Chạm vào ô `a[2]`.', ans: 2, why: 'Đếm từ 0: ô 0, ô 1, ô 2.' },
      { W: 7, vals: ARR7, q: 'Chạm vào ô `a[a.len() - 1]`.', ans: 6, why: '`a.len()` là 7 nên chỉ số cuối là 6.' },
      { W: 7, vals: ARR7, q: 'Chạm vào ô `a[a.len() / 2]` (chia nguyên).', ans: 3, why: '7 / 2 = 3 (bỏ phần dư), đó là ô chính giữa.' },
      { W: 7, vals: ARR7, q: 'Cho `let i = 1;`. Chạm vào ô `a[i + 3]`.', ans: 4, why: '1 + 3 = 4.' },
    ],
  },
  trick: {
    name: 'Tìm lớn nhất và vị trí của nó', why: 'Giữ lại vị trí thay vì giá trị, để có cả hai thông tin cùng lúc.',
    lines: ['let a = [7, 3, 9, 1, 5];', 'let mut vi_tri = 0;', 'for i in 1..a.len() {', 'if a[i] > a[vi_tri] {', 'vi_tri = i;', '}', '}', 'println!("lớn nhất là {} ở vị trí {}", a[vi_tri], vi_tri);'],
    out: 'lớn nhất là 9 ở vị trí 2',
    how: 'Từ `vi_tri` ta lấy được giá trị `a[vi_tri]` lẫn chỗ nó đứng. Vòng lặp bắt đầu từ 1 vì phần tử 0 đã là ứng viên đầu tiên.',
  },
});

G.add(3, {
  title: 'Vec và lưới 2D', sub: 'Vec, push và công thức y * W + x', tags: ['Không gian', 'Toán'],
  learn: {
    intro: '`Vec<T>` là mảng biết **lớn lên** hoặc co lại lúc chạy. Một lưới 2D thường được cất phẳng trong một `Vec`: ô ở cột `x`, hàng `y` nằm ở chỉ số `y * W + x`, với `W` là số cột.',
    points: ['`let mut v = Vec::new();` hoặc `vec![1, 2, 3]`.', '`v.push(x)` thêm vào cuối, `v.pop()` lấy ra từ cuối (trả về `Option`).', 'Từ tọa độ ra chỉ số: `y * W + x`. Từ chỉ số ra tọa độ: `x = i % W`, `y = i / W`.', '`v.len()`, `v.is_empty()` và `for x in &v` là những thứ dùng hằng ngày.'],
    code: 'fn main() {\n    let w = 4;\n    let mut luoi = Vec::new();\n    for y in 0..3 {\n        for x in 0..w {\n            luoi.push(y * 10 + x);\n        }\n    }\n    println!("{:?}", luoi);\n    let (x, y) = (2, 1);\n    println!("ô ({x}, {y}) = {}", luoi[y * w + x]);\n    let i = 11;\n    println!("chỉ số {i} ở cột {}, hàng {}", i % w, i / w);\n}',
    out: '[0, 1, 2, 3, 10, 11, 12, 13, 20, 21, 22, 23]\nô (2, 1) = 12\nchỉ số 11 ở cột 3, hàng 2',
    note: 'Phép `%` và `/` ở đây là bộ đôi “cột và hàng”: chia W lấy thương là hàng, lấy dư là cột.',
  },
  ch: {
    type: 'cells', brief: 'Lưới 4 cột này được lưu phẳng trong một `Vec` tên `v`. Nhãn bên trên và bên trái chỉ cột và hàng. Dùng `%` và `/` để tìm đúng ô.',
    hint: 'Chia chỉ số cho 4: thương là hàng, số dư là cột. Ví dụ 9 = 2 × 4 + 1 nên hàng 2, cột 1.',
    rounds: [
      { W: 4, axes: true, vals: LET12, q: 'Chạm vào ô `v[5]`.', ans: 5, why: '5 = 1 × 4 + 1: hàng 1, cột 1.' },
      { W: 4, axes: true, vals: LET12, q: 'Chạm vào ô `v[9]`.', ans: 9, why: '9 = 2 × 4 + 1: hàng 2, cột 1.' },
      { W: 4, axes: true, vals: LET12, q: 'Chạm vào ô `v[11]`.', ans: 11, why: '11 = 2 × 4 + 3: hàng 2, cột 3.' },
      { W: 4, axes: true, vals: LET12, q: 'Chạm vào ô có `x = 2, y = 2`, tức `v[y * 4 + x]`.', ans: 10, why: '2 × 4 + 2 = 10.' },
    ],
  },
  trick: {
    name: 'Đổi qua lại chỉ số và tọa độ', why: 'Cặp hàm dùng được cho mọi trò chơi dạng lưới: cờ, ô chữ, dò mìn.',
    pre: [], post: [],
    lines: ['fn toa_do(i: usize, w: usize) -> (usize, usize) {', '(i % w, i / w)', '}', 'fn chi_so(x: usize, y: usize, w: usize) -> usize {', 'y * w + x', '}', 'fn main() {', 'let (x, y) = toa_do(11, 4);', 'println!("({x}, {y}) -> {}", chi_so(x, y, 4));', '}'],
    out: '(3, 2) -> 11',
    how: 'Hai hàm là nghịch đảo của nhau: `% w` và `/ w` tách chỉ số thành (cột, hàng), còn `y * w + x` ghép lại. Đi một vòng ra tọa độ rồi về lại chỉ số luôn cho kết quả ban đầu.',
  },
});

G.add(3, {
  title: 'Chuỗi và mật mã Caesar', sub: 'String, &str, char và byte', tags: ['Mật mã', 'Toán'],
  learn: {
    intro: 'Chữ trong máy tính thực chất là số. Mỗi ký tự ASCII có một mã `u8`: `b\'A\'` là 65, `b\'B\'` là 66… Rust có hai kiểu chuỗi: `&str` (chuỗi mượn, cố định) và `String` (chuỗi sở hữu, lớn lên được). Cả hai đều là UTF-8.',
    points: ['`String::from("xin chào")` hoặc `"xin chào".to_string()`; `s.push_str("!")` để nối thêm.', '`s.len()` đếm **byte**, còn `s.chars().count()` đếm **ký tự**. Chữ tiếng Việt có dấu chiếm nhiều byte.', '`b\'A\'` là mã byte của chữ A. `(b\'A\' + 2) as char` cho ra `\'C\'`.', 'Dịch chữ cái trên vòng tròn 26 chữ: `(c - b\'A\' + k) % 26 + b\'A\'`. Đó chính là mật mã Caesar.'],
    code: 'fn ma_hoa(s: &str, k: u8) -> String {\n    let mut kq = String::new();\n    for c in s.bytes() {\n        if c.is_ascii_uppercase() {\n            kq.push(((c - b\'A\' + k) % 26 + b\'A\') as char);\n        } else {\n            kq.push(c as char);\n        }\n    }\n    kq\n}\n\nfn main() {\n    let ban_ma = ma_hoa("HELLO RUST", 3);\n    println!("{ban_ma}");\n    println!("{}", ma_hoa(&ban_ma, 23));\n    let s = "chào";\n    println!("{} byte, {} ký tự", s.len(), s.chars().count());\n}',
    out: 'KHOOR UXVW\nHELLO RUST\n5 byte, 4 ký tự',
    note: 'Phép `% 26` làm chữ Z đi tiếp sẽ quay về A: chính là ý tưởng vòng tròn của bài 3. Dịch 3 rồi dịch 23 thì đủ 26, trở về chỗ cũ.',
  },
  ch: {
    type: 'cipher', brief: 'Giải mã hai bức thư Caesar. Mỗi chữ cái đã bị đẩy lên một số vị trí trong bảng chữ cái. Chỉnh K để `(c - b\'A\' + K) % 26 + b\'A\'` đưa chúng về chỗ cũ.',
    hint: 'Nếu thư bị đẩy lên 3 chữ, thì đẩy thêm 23 chữ (3 + 23 = 26, đúng một vòng) sẽ về chỗ cũ.',
    rounds: [
      { kind: 'caesar', plain: 'HELLO RUST', shift: 3, q: 'Bức thư 1.', clue: 'Từ đầu tiên có hai chữ giống hệt nhau đứng liền kề. Một từ tiếng Anh quen thuộc 5 chữ cái nào có “LL” ở giữa?' },
      { kind: 'caesar', plain: 'RUST AN TOAN', shift: 11, q: 'Bức thư 2, người gửi dùng một số khác.', clue: 'Mỗi lần K tăng thêm 1, mọi chữ đi thêm một ô trên vòng 26 chữ. Dừng khi đọc được tiếng Việt không dấu.' },
    ],
  },
  trick: {
    name: 'ROT13: một hàm, hai việc', why: 'Mã hóa và giải mã bằng cùng một hàm, nhờ 13 + 13 = 26.',
    pre: [], post: [],
    lines: ['fn rot13(s: &str) -> String {', 'let mut kq = String::new();', 'for c in s.bytes() {', "let m = if c.is_ascii_uppercase() { (c - b'A' + 13) % 26 + b'A' } else { c };", 'kq.push(m as char);', '}', 'kq', '}', 'fn main() {', 'let a = rot13("RUST");', 'println!("{a} {}", rot13(&a));', '}'],
    out: 'EHFG RUST',
    how: '13 là đúng một nửa vòng 26 chữ, nên áp dụng hai lần là đủ một vòng và trở về chữ gốc. Mật mã tự nghịch đảo như vậy rất gọn: không cần viết riêng hàm giải mã.',
  },
});

G.add(3, {
  title: 'Bảng băm HashMap', sub: 'HashMap, entry và bảng thay thế', tags: ['Mật mã', 'Logic'],
  learn: {
    intro: '`HashMap<K, V>` là một cuốn từ điển: tra bằng **khóa** là ra **giá trị**, nhanh gần như tức thì dù từ điển dày cỡ nào. Dùng nó để đếm, tra bảng thay thế hay nhóm dữ liệu.',
    points: ['Cần `use std::collections::HashMap;` ở đầu file.', '`m.insert(khoa, gia_tri)` thêm vào, `m.get(&khoa)` trả về `Option<&V>`.', '`*m.entry(khoa).or_insert(0) += 1;` là cách đếm quen thuộc: chưa có khóa thì tạo với 0, rồi cộng 1.', 'Thứ tự duyệt `HashMap` **không cố định**. Muốn in có thứ tự thì gom lại và sắp xếp trước.'],
    code: 'use std::collections::HashMap;\n\nfn main() {\n    let van_ban = "hello rust";\n    let mut dem: HashMap<char, u32> = HashMap::new();\n    for c in van_ban.chars() {\n        if c != \' \' {\n            *dem.entry(c).or_insert(0) += 1;\n        }\n    }\n    let mut cap: Vec<_> = dem.into_iter().collect();\n    cap.sort();\n    println!("{:?}", cap);\n}',
    out: "[('e', 1), ('h', 1), ('l', 2), ('o', 1), ('r', 1), ('s', 1), ('t', 1), ('u', 1)]",
    note: 'Một bảng thay thế mật mã cũng chỉ là `HashMap<char, char>`. Đếm tần suất chữ cái từng là vũ khí phá nhiều mật mã cổ điển.',
  },
  ch: {
    type: 'cipher', brief: 'Mỗi bức thư dùng một **bảng thay thế**: tra từng chữ cái trong một “từ điển” để ra chữ khác. Chọn đoạn code tạo ra đúng bảng để đọc được bản mã.',
    hint: 'Thử lần lượt từng đoạn code và nhìn dòng kết quả. Một bảng thay thế đảo ngược bảng chữ cái là A↔Z, B↔Y, C↔X…',
    rounds: [
      { kind: 'forms', plain: 'HASH MAP', use: 'atbash', forms: ['same', 'next', 'rot13', 'atbash'], q: 'Bức thư 1.', clue: 'Bản mã bắt đầu bằng S và Z. Trong bảng thay thế đảo ngược, chữ nào ứng với S?' },
      { kind: 'forms', plain: 'TRA CUU NHANH', use: 'rot13', forms: ['same', 'prev', 'rot13', 'atbash'], q: 'Bức thư 2, một bảng khác.' },
    ],
  },
  trick: {
    name: 'Nhóm theo khóa chỉ trong một dòng', why: 'Gom các từ cùng chữ cái đầu vào cùng một nhóm mà không cần kiểm tra “đã có khóa chưa”.',
    pre: ['use std::collections::HashMap;', 'fn main() {'], post: ['}'],
    lines: ['let tu = ["rust", "ruby", "go", "gleam", "gcc"];', 'let mut nhom: HashMap<char, Vec<&str>> = HashMap::new();', 'for t in tu {', 'nhom.entry(t.chars().next().unwrap()).or_default().push(t);', '}', "println!(\"{:?}\", nhom[&'g']);"],
    out: '["go", "gleam", "gcc"]',
    how: '`entry(khoa).or_default()` trả về `&mut Vec` (rỗng nếu khóa chưa có) nên `push` luôn chạy được. “Nếu chưa có thì tạo, rồi thêm vào” gói gọn trong một dòng.',
  },
});
