/* ===== Vùng 4: Tháp Sở Hữu ===== */
const ARR8 = ['5', '2', '8', '1', '9', '4', '7', '3'];
const DROPCODE = "struct Chia(&'static str);\n\nimpl Drop for Chia {\n    fn drop(&mut self) {\n        println!(\"trả {}\", self.0);\n    }\n}\n";
G.add(4, {
  title: 'Sở hữu và move', sub: 'mỗi giá trị chỉ có một chủ', tags: ['Không gian', 'Logic'],
  learn: {
    intro: 'Đây là ý tưởng lớn nhất của Rust. Mỗi giá trị có đúng **một chủ**, và khi chủ ra khỏi phạm vi thì giá trị được dọn dẹp. Hãy hình dung giá trị là một **chiếc chìa khóa duy nhất**: trao cho người khác (move) thì bạn không còn nó nữa.',
    points: ['Quy tắc 1: mỗi giá trị có một chủ sở hữu, là một biến.', 'Quy tắc 2: tại một thời điểm chỉ có một chủ.', 'Quy tắc 3: chủ ra khỏi phạm vi `{ }` thì giá trị bị giải phóng.', 'Gán `let b = a;` với `String` là **move**: `a` hết dùng được. Số nguyên thì được **copy** nên không sao.'],
    code: 'fn main() {\n    let a = String::from("chìa khóa");\n    let b = a;\n    println!("{b}");\n    let x = 5;\n    let y = x;\n    println!("{x} {y}");\n    let c = b.clone();\n    println!("{b} {c}");\n}',
    out: 'chìa khóa\n5 5\nchìa khóa chìa khóa',
    note: 'Nhờ ba quy tắc này Rust biết chính xác lúc nào giải phóng bộ nhớ, không cần bộ gom rác chạy ngầm.',
  },
  ch: {
    type: 'bug', brief: 'Một chiếc chìa khóa đã đổi chủ nhưng người cũ vẫn cố dùng. Tìm dòng bị từ chối và chọn cách sửa.', hint: 'Chìa khóa duy nhất đã được trao cho `b`. Muốn cả hai cùng có dữ liệu, một cách là tạo một bản sao riêng.',
    code: 'fn main() {\n    let a = String::from("chìa khóa");\n    let b = a;\n    println!("{}", a);\n    println!("{}", b);\n}',
    bad: 3, fixAt: 2, ecode: 'E0382',
    err: 'error[E0382]: borrow of moved value: `a`\n --> src/main.rs:4:20\n  |\n2 |     let a = String::from("chìa khóa");\n  |         - move occurs because `a` has type `String`, which does not implement the `Copy` trait\n3 |     let b = a;\n  |             - value moved here\n4 |     println!("{}", a);\n  |                    ^ value borrowed here after move',
    fixes: ['let b = a.clone();', 'let b = *a;', 'let b = a.copy();', 'let b: String = &a;'], fix: 0,
    why: '`let b = a;` chuyển quyền sở hữu sang `b` nên `a` hết dùng được. `a.clone()` tạo một bản sao riêng: mỗi biến giữ một chiếc chìa.',
  },
  trick: {
    name: 'Đi qua hàm rồi quay về', why: 'Cho hàm mượn quyền sở hữu, nhận lại kết quả và dùng lại cùng một tên biến.',
    pre: [], post: [],
    lines: ['fn them_hau_to(mut s: String) -> String {', 's.push_str("!");', 's', '}', 'fn main() {', 'let loi = String::from("Rust");', 'let loi = them_hau_to(loi);', 'println!("{loi}");', '}'],
    out: 'Rust!',
    how: 'Truyền `String` vào hàm là trao chìa khóa cho hàm. Hàm làm xong trả chìa về bằng giá trị trả về, và ta che bóng biến cũ bằng chính tên đó. Bài sau có cách nhẹ nhàng hơn: mượn.',
  },
});

G.add(4, {
  title: 'Mượn: & và &mut', sub: 'tham chiếu và quy tắc mượn', tags: ['Không gian', 'Logic'],
  learn: {
    intro: 'Không phải lúc nào cũng cần trao chìa khóa. Bạn có thể **cho mượn** một giá trị bằng tham chiếu `&`. Rust canh một quy tắc vàng: tại mọi thời điểm, hoặc có **nhiều** người đọc, hoặc có **đúng một** người ghi, không bao giờ cả hai.',
    points: ['`&x` là tham chiếu bất biến (chỉ đọc), có thể có nhiều cái cùng lúc.', '`&mut x` là tham chiếu khả biến (được ghi): chỉ có **một** tại một thời điểm và không chung với `&x`.', 'Tham chiếu không bao giờ được sống lâu hơn chủ của nó.', 'Hàm nên nhận `&T` khi chỉ cần đọc, `&mut T` khi cần sửa, và `T` khi cần lấy hẳn quyền sở hữu.'],
    code: 'fn do_dai(s: &String) -> usize {\n    s.len()\n}\n\nfn them_dau(s: &mut String) {\n    s.push(\'!\');\n}\n\nfn main() {\n    let mut loi = String::from("xin chào");\n    println!("{}", do_dai(&loi));\n    them_dau(&mut loi);\n    println!("{loi}");\n}',
    out: '9\nxin chào!',
    note: 'Quy tắc “nhiều người đọc hoặc một người ghi” chặn đứng cả một họ lỗi: tranh chấp dữ liệu giữa các phần của chương trình.',
  },
  ch: {
    type: 'bug', brief: 'Một người đang đọc dữ liệu trong khi người khác muốn ghi. Tìm dòng bị từ chối và chọn cách sửa.', hint: '`push` cần quyền ghi lên `v`, nhưng `dau` vẫn đang mượn `v` để đọc ở dòng sau. Làm sao để `dau` không còn phụ thuộc vào `v`?',
    code: 'fn main() {\n    let mut v = vec![1, 2, 3];\n    let dau = &v[0];\n    v.push(4);\n    println!("{}", dau);\n}',
    bad: 3, fixAt: 2, ecode: 'E0502',
    err: 'error[E0502]: cannot borrow `v` as mutable because it is also borrowed as immutable\n --> src/main.rs:4:5\n  |\n3 |     let dau = &v[0];\n  |                - immutable borrow occurs here\n4 |     v.push(4);\n  |     ^^^^^^^^^ mutable borrow occurs here\n5 |     println!("{}", dau);\n  |                    --- immutable borrow later used here',
    fixes: ['let dau = v[0];', 'let dau = &mut v[0];', 'let dau = &v;', 'let dau = v.first();'], fix: 0,
    why: '`dau` đang mượn `v` để đọc, còn `push` có thể làm `Vec` dời sang vùng nhớ mới khiến `dau` trỏ vào chỗ trống. Sao chép giá trị ra (`v[0]` với số nguyên) thì `dau` không còn mượn `v`.',
  },
  trick: {
    name: 'Lấy ra khỏi chỗ mượn', why: 'Hoán đổi hoặc rút dữ liệu ra qua `&mut` mà không vi phạm luật sở hữu.',
    lines: ['let mut a = vec![1, 2];', 'let mut b = vec![9];', 'std::mem::swap(&mut a, &mut b);', 'let cu = std::mem::take(&mut a);', 'println!("{:?} {:?} {:?}", a, b, cu);'],
    out: '[] [1, 2] [9]',
    how: '`swap` đổi chỗ hai giá trị. `take` lấy giá trị ra và để lại giá trị mặc định (Vec rỗng). Cả hai chỉ cần `&mut`, không cần sở hữu, nên dùng được cả khi dữ liệu nằm sau một tham chiếu.',
  },
});

G.add(4, {
  title: 'Lát cắt (slice)', sub: 'khung cửa sổ &a[x..y]', tags: ['Không gian', 'Toán'],
  learn: {
    intro: 'Lát cắt là một **khung cửa sổ** nhìn vào một đoạn liên tiếp của mảng hoặc chuỗi mà không sao chép dữ liệu. Nó chỉ gồm điểm bắt đầu và độ dài.',
    points: ['`&a[1..4]` lấy các ô 1, 2, 3 (**không** gồm ô 4). `&a[..2]` là hai ô đầu, `&a[2..]` là từ ô 2 đến hết.', '`&a[1..=3]` gồm cả ô 3.', 'Kiểu lát cắt là `&[T]`, với chuỗi là `&str`. Hàm nhận `&[T]` dùng được cho cả mảng lẫn `Vec`.', 'Cắt vượt biên, hoặc cắt giữa một ký tự UTF-8, sẽ panic.'],
    code: 'fn tong(xs: &[i32]) -> i32 {\n    let mut s = 0;\n    for x in xs {\n        s += x;\n    }\n    s\n}\n\nfn main() {\n    let a = [4, 8, 15, 16, 23, 42];\n    println!("{}", tong(&a[1..4]));\n    println!("{:?}", &a[..2]);\n    println!("{:?}", &a[4..]);\n    let ten = "Rustacean";\n    println!("{}", &ten[..4]);\n}',
    out: '39\n[4, 8]\n[23, 42]\nRust',
    note: 'Dải `a..b` luôn là “nửa mở”: lấy a, bỏ b. Nhờ vậy độ dài lát cắt đúng bằng `b - a`, không phải cộng trừ 1.',
  },
  ch: {
    type: 'cells', brief: 'Với mỗi lát cắt, chạm vào **ô đầu tiên** rồi **ô cuối cùng** của đoạn mà lát cắt bao phủ.', hint: '`a..b` lấy từ ô a và dừng **trước** ô b. Còn `a..=b` thì lấy luôn cả ô b.',
    rounds: [
      { kind: 'range', W: 8, vals: ARR8, q: 'Mảng `a` có 8 ô. Chọn lát cắt `&a[1..4]`.', ans: [1, 3] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Chọn lát cắt `&a[2..=5]`.', ans: [2, 5] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Chọn lát cắt `&a[..3]`.', ans: [0, 2] },
      { kind: 'range', W: 8, vals: ARR8, q: 'Chọn lát cắt `&a[5..]` (mảng có 8 ô).', ans: [5, 7] },
    ],
  },
  trick: {
    name: 'Bóc đầu, giữa, cuối bằng mẫu', why: 'Tách phần tử đầu và cuối của một dãy chỉ bằng một mẫu, phần giữa gom vào một biến.',
    lines: ['let a = [10, 20, 30, 40];', 'if let [dau, giua @ .., cuoi] = a {', 'println!("{dau} {:?} {cuoi}", giua);', '}'],
    out: '10 [20, 30] 40',
    how: 'Mẫu `[dau, giua @ .., cuoi]` bóc phần tử đầu và cuối, còn `giua @ ..` gom mọi thứ ở giữa. Nó chỉ khớp dãy có ít nhất 2 phần tử, đúng như ta mong.',
  },
});

G.add(4, {
  title: 'Phạm vi, Copy và Clone', sub: 'scope, Drop, Copy và Clone', tags: ['Logic', 'Không gian'],
  learn: {
    intro: 'Phạm vi (scope) là vùng giữa hai dấu `{ }` nơi một biến còn sống. Ra khỏi vùng đó, biến được dọn dẹp tự động, và nếu kiểu của nó có `Drop` thì hàm `drop` chạy đúng lúc. (Đoạn code dưới dùng `struct` và `impl`, vùng 5 sẽ giải thích. Bây giờ chỉ cần nhìn thứ tự in ra.)',
    points: ['Biến bị hủy theo thứ tự **ngược** với thứ tự khai báo, như chồng đĩa: đĩa đặt sau lấy ra trước.', 'Kiểu `Copy` (số, `bool`, `char`, tuple toàn Copy) tự sao chép khi gán nên không bị move.', 'Kiểu còn lại cần `.clone()` để sao chép rõ ràng. Clone có thể tốn kém nên Rust bắt bạn nói thẳng.', '`drop(x)` hủy sớm một giá trị.'],
    code: DROPCODE + '\nfn main() {\n    let _a = Chia("khóa A");\n    {\n        let _b = Chia("khóa B");\n        println!("trong khối");\n    }\n    let _c = Chia("khóa C");\n    println!("hết main");\n}',
    out: 'trong khối\ntrả khóa B\nhết main\ntrả khóa C\ntrả khóa A',
    note: 'Dọn dẹp xảy ra tại một chỗ cố định, dễ đoán trước: đó là lý do Rust quản lý được cả tệp, khóa và kết nối mạng, không chỉ bộ nhớ.',
  },
  ch: {
    type: 'quiz', brief: 'Bốn câu hỏi về vòng đời của giá trị. Hai câu đầu bạn cần đoán kết quả chạy chương trình.', hint: 'Giá trị khai báo sau bị hủy trước. `Copy` thì sao chép khi gán, còn `String` thì bị move.',
    qs: [
      { q: 'Chương trình này in ra gì?', code: DROPCODE + '\nfn main() {\n    let _a = Chia("A");\n    let _b = Chia("B");\n    println!("xong");\n}', run: true, opts: ['xong\ntrả B\ntrả A', 'xong\ntrả A\ntrả B', 'trả A\ntrả B\nxong', 'xong'], ans: 0, why: 'In `xong` trước, rồi hủy theo thứ tự ngược: `_b` (khai báo sau) bị hủy trước `_a`.' },
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let a = 7;\n    let b = a;\n    let s = String::from("hi");\n    let t = s.clone();\n    println!("{a} {b} {s} {t}");\n}', run: true, opts: ['7 7 hi hi', 'Không biên dịch được vì `s` đã bị move', 'Không biên dịch được vì `a` đã bị move', '7 7 hi'], ans: 0, why: 'Số nguyên là `Copy` nên `a` còn nguyên. `s.clone()` tạo bản sao, nên `s` không bị move.' },
      { q: 'Kiểu nào sau đây **không** phải `Copy`?', opts: ['i32', 'bool', 'String', 'char'], ans: 2, why: '`String` sở hữu vùng nhớ trên heap nên không thể sao chép ngầm. Muốn sao chép phải gọi `.clone()`.' },
      { q: 'Hai biến khai báo theo thứ tự `x` rồi `y`. Ra khỏi phạm vi, biến nào bị hủy trước?', opts: ['`y` bị hủy trước, rồi đến `x`', '`x` bị hủy trước, rồi đến `y`', 'Cả hai bị hủy cùng lúc', 'Tùy trình biên dịch'], ans: 0, why: 'Rust hủy theo thứ tự ngược với thứ tự khai báo, và quy tắc này cố định.' },
    ],
  },
  trick: {
    name: 'Khối là biểu thức', why: 'Tính một kết quả với các biến tạm, và để Rust dọn chúng ngay khi xong.',
    lines: ['let tong = {', 'let tam = vec![3, 4, 5];', 'tam.iter().sum::<i32>()', '};', 'println!("{tong}");'],
    out: '12',
    how: 'Khối `{ }` là một biểu thức: giá trị cuối cùng (không có `;`) là kết quả của cả khối. Mọi biến tạm bên trong, như `tam`, bị dọn ngay khi ra khỏi khối nên không để rác lại.',
  },
});
