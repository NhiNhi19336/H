/* ===== Vùng 7: Dòng Chảy và Con Trỏ ===== */
const GRID7 = []; for (let y = 3; y >= -3; y--) for (let x = -3; x <= 3; x++) GRID7.push(x + ',' + y);
const AT7 = (x, y) => (3 - y) * 7 + (x + 3);
G.add(7, {
  title: 'Iterator: dây chuyền dữ liệu', sub: 'iter, map, filter, sum, collect', tags: ['Mật mã', 'Toán tử'],
  learn: {
    intro: 'Iterator là một **dây chuyền sản xuất**: dữ liệu đi vào, qua từng trạm (`filter`, `map`…), rồi ra ở cuối (`sum`, `collect`). Các trạm đều **lười**: chưa ai “kéo” ở cuối thì chưa trạm nào chạy. Rust biên dịch dây chuyền này thành vòng lặp tối ưu, nhanh ngang vòng `for` viết tay.',
    points: ['`.iter()` mượn từng phần tử, `.into_iter()` lấy hẳn, `.iter_mut()` mượn để sửa.', 'Trạm trung gian (lười): `map`, `filter`, `enumerate`, `skip`, `take`, `zip`, `rev`.', 'Trạm kết thúc (kéo dữ liệu): `sum`, `count`, `max`, `min`, `fold`, `any`, `all`, `collect`.', '`collect()` cần biết gom vào kiểu gì: `Vec<_>`, `String`, `HashMap<_, _>`…'],
    code: 'fn main() {\n    let so = [1, 2, 3, 4, 5, 6];\n    let tong_chan_binh_phuong: i32 = so\n        .iter()\n        .filter(|x| *x % 2 == 0)\n        .map(|x| x * x)\n        .sum();\n    println!("{tong_chan_binh_phuong}");\n    let ten: Vec<String> = ["an", "binh"].iter().map(|s| s.to_uppercase()).collect();\n    println!("{:?}", ten);\n    for (i, x) in so.iter().enumerate().skip(4) {\n        println!("{i}: {x}");\n    }\n    let mat_ma: Vec<u8> = "RUST".bytes().map(|c| c ^ 42).collect();\n    println!("{:?}", mat_ma);\n}',
    out: '56\n["AN", "BINH"]\n4: 5\n5: 6\n[120, 127, 121, 126]',
    note: 'Dòng cuối là một mật mã XOR chỉ gồm một trạm `.map(|c| c ^ 42)`. Hãy dùng chính dây chuyền đó để giải mã ở thử thách.',
  },
  ch: {
    type: 'cipher', brief: 'Các bản mã dưới đây đã đi qua dây chuyền `.map(|c| c ^ KEY)`. Lật các bit của KEY cho đến khi bản mã hiện ra chữ có nghĩa.',
    hint: 'XOR hai lần với cùng một khóa thì về chỗ cũ: `a ^ k ^ k = a`. Biết một byte mã hóa và chữ gốc của nó thì tính được khóa: `KEY = byte_mã ^ chữ_gốc`.',
    rounds: [
      { kind: 'xor', plain: 'RUST', key: 42, q: 'Bản mã 1.', clue: 'Byte đầu tiên là 0x78 và chữ đầu tiên là R (mã 0x52). Vậy KEY = 0x78 ^ 0x52. Hãy lật bit trên bảng rồi xem chữ đầu đã thành R chưa.' },
      { kind: 'xor', plain: 'MAP FILTER', key: 19, q: 'Bản mã 2, khóa khác.', clue: 'Byte thứ 4 là chỗ dấu cách. Dấu cách có mã 0x20 nên byte mã hóa của nó là 0x20 ^ KEY. Nhìn ô thứ 4 trong bản mã, bạn tính ngược ra KEY.' },
    ],
  },
  trick: {
    name: 'Tích vô hướng bằng zip', why: 'Nhân từng cặp thành phần rồi cộng lại, chỉ bằng một dây chuyền ngắn.',
    lines: ['let a = [1, 2, 3];', 'let b = [4, 5, 6];', 'let tich: i32 = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum();', 'println!("{tich}");'],
    out: '32',
    how: '`zip` ghép từng cặp ở cùng vị trí, `map` nhân hai thành phần, `sum` cộng tất cả: đúng định nghĩa tích vô hướng của hai vectơ (1×4 + 2×5 + 3×6 = 32).',
  },
});

G.add(7, {
  title: 'Box, heap và đệ quy', sub: 'Box<T> và kiểu đệ quy', tags: ['Không gian', 'Toán'],
  learn: {
    intro: 'Mặc định giá trị nằm trên **stack**: nhanh, nhưng kích thước phải biết trước. `Box<T>` đưa giá trị lên **heap** và giữ một con trỏ nhỏ. Nhờ vậy ta tạo được kiểu **đệ quy** (một kiểu chứa chính nó), như cây hay danh sách liên kết.',
    points: ['`Box::new(5)` tạo hộp trên heap. `*hop` mở hộp lấy giá trị.', 'Khi `Box` ra khỏi phạm vi, vùng heap được giải phóng tự động.', 'Kiểu đệ quy trực tiếp như `enum Cay { La(i32), Nut(Cay, Cay) }` có kích thước vô hạn nên không biên dịch được. Dùng `Box<Cay>` thì kích thước chỉ là một con trỏ.', 'Hàm đệ quy gọi chính nó và luôn cần một **điều kiện dừng**.'],
    code: 'enum Cay {\n    La(i32),\n    Nut(Box<Cay>, Box<Cay>),\n}\n\nfn tong(c: &Cay) -> i32 {\n    match c {\n        Cay::La(v) => *v,\n        Cay::Nut(trai, phai) => tong(trai) + tong(phai),\n    }\n}\n\nfn do_sau(c: &Cay) -> u32 {\n    match c {\n        Cay::La(_) => 1,\n        Cay::Nut(trai, phai) => 1 + do_sau(trai).max(do_sau(phai)),\n    }\n}\n\nfn main() {\n    let cay = Cay::Nut(\n        Box::new(Cay::Nut(Box::new(Cay::La(1)), Box::new(Cay::La(2)))),\n        Box::new(Cay::La(3)),\n    );\n    println!("tổng = {}, độ sâu = {}", tong(&cay), do_sau(&cay));\n}',
    out: 'tổng = 6, độ sâu = 3',
    note: 'Cây là hình ảnh không gian của đệ quy: mỗi nút lại là một cây nhỏ hơn. Hàm `tong` có hình dạng giống hệt dữ liệu mà nó duyệt.',
  },
  ch: {
    type: 'robot', brief: 'Viết một hàm **đệ quy** `chay`: nếu Bot chưa tới đích thì làm một bước (gặp tường thì rẽ phải, không thì đi thẳng) rồi gọi lại chính `chay`. Điều kiện “chưa tới đích” chính là điều kiện dừng.',
    hint: 'Trong `fn chay`, dùng khối `if !at_goal`. Bên trong nó đặt khối `if … else` (nhánh if: rẽ phải, nhánh else: đi thẳng), rồi đặt `chay(bot);` ở **cuối** khối `if !at_goal`. Cuối cùng gọi `chay(&mut bot);` trong `main`.',
    grid: ['#########', '#S......#', '#######.#', '##G####.#', '##.####.#', '##......#', '#########'], dir: 'E', fns: ['chay'], cursor: 'fn_chay',
    palette: ['if:!at_goal', 'ifelse:wall_ahead', 'forward', 'right', 'call:chay'], max: 8, par: 6,
    sol: 'fn:chay { if:!at_goal { if:wall_ahead { R } else { F } call:chay } } call:chay',
  },
  trick: {
    name: 'Thuật toán Euclid', why: 'Tìm ước chung lớn nhất của hai số bằng một hàm đệ quy ngắn nhất có thể.',
    pre: [], post: [],
    lines: ['fn ucln(a: u32, b: u32) -> u32 {', 'if b == 0 { a } else { ucln(b, a % b) }', '}', 'fn main() {', 'println!("{}", ucln(48, 18));', '}'],
    out: '6',
    how: 'Điều kiện dừng là `b == 0`. Nếu chưa dừng thì thay cặp `(a, b)` bằng `(b, a % b)`: số dư luôn nhỏ hơn `b` nên chắc chắn đến lúc về 0. Với 48 và 18: (48,18) → (18,12) → (12,6) → (6,0) cho ra 6.',
  },
});

G.add(7, {
  title: 'Rc và RefCell', sub: 'nhiều chủ và sửa khi đang chia sẻ', tags: ['Không gian', 'Logic'],
  learn: {
    intro: 'Đôi khi một dữ liệu cần **nhiều chủ**, như nhiều nút cùng trỏ vào một nút chung. `Rc<T>` giữ một **bộ đếm số chủ**: chủ cuối cùng đi thì dữ liệu mới bị giải phóng. `RefCell<T>` cho phép **sửa** dữ liệu dù chỉ đang giữ tham chiếu bất biến: Rust kiểm tra quy tắc mượn lúc **chạy** thay vì lúc biên dịch.',
    points: ['`Rc::new(x)` để tạo. `Rc::clone(&a)` chỉ tăng bộ đếm chứ **không** sao chép dữ liệu. `Rc::strong_count(&a)` cho biết số chủ.', '`Rc<T>` chỉ cho đọc. Muốn sửa, gói thêm `RefCell`: `Rc<RefCell<T>>`.', '`cell.borrow()` mượn để đọc, `cell.borrow_mut()` mượn để ghi. Vi phạm quy tắc mượn sẽ **panic** lúc chạy.', '`Rc` chỉ dùng trong một luồng. Nhiều luồng thì dùng `Arc` (bài 30).'],
    code: 'use std::cell::RefCell;\nuse std::rc::Rc;\n\nfn main() {\n    let diem = Rc::new(RefCell::new(0));\n    let a = Rc::clone(&diem);\n    let b = Rc::clone(&diem);\n    *a.borrow_mut() += 10;\n    *b.borrow_mut() += 5;\n    println!("{} (chủ: {})", diem.borrow(), Rc::strong_count(&diem));\n    drop(a);\n    println!("chủ còn lại: {}", Rc::strong_count(&diem));\n}',
    out: '15 (chủ: 3)\nchủ còn lại: 2',
    note: 'Hãy hình dung một tờ giấy ghi chú dán trong phòng chung: ai cũng đọc được (`Rc`), và có một cây bút treo bên cạnh, mỗi lúc chỉ một người được cầm (`RefCell`).',
  },
  ch: {
    type: 'quiz', brief: 'Bốn câu về nhiều chủ và sửa khi chia sẻ. Hai câu đầu cần đoán kết quả chạy.', hint: '`Rc::clone` chỉ thêm một chủ: bộ đếm tăng 1, khi một chủ ra khỏi phạm vi thì bộ đếm giảm 1.',
    qs: [
      { q: 'Chương trình này in ra gì?', code: 'use std::rc::Rc;\nfn main() {\n    let a = Rc::new(String::from("dữ liệu"));\n    let b = Rc::clone(&a);\n    {\n        let _c = Rc::clone(&a);\n        println!("{}", Rc::strong_count(&a));\n    }\n    println!("{}", Rc::strong_count(&b));\n}', run: true, opts: ['3\n2', '2\n2', '3\n3', '2\n1'], ans: 0, why: 'Trong khối có 3 chủ (`a`, `b`, `_c`). Ra khỏi khối `_c` bị hủy nên còn 2.' },
      { q: 'Chương trình này in ra gì?', code: 'use std::cell::RefCell;\nfn main() {\n    let o = RefCell::new(vec![1, 2]);\n    o.borrow_mut().push(3);\n    println!("{:?} {}", o.borrow(), o.borrow().len());\n}', run: true, opts: ['[1, 2, 3] 3', '[1, 2] 2', 'Lỗi biên dịch vì `o` không phải `mut`', 'Panic lúc chạy'], ans: 0, why: '`RefCell` cho sửa qua `borrow_mut()` dù `o` không có `mut`. Hai lần `borrow()` cùng lúc để đọc thì hợp lệ.' },
      { q: '`Rc::clone(&a)` làm gì?', opts: ['Chỉ tăng bộ đếm số chủ, không sao chép dữ liệu', 'Sao chép toàn bộ dữ liệu sang vùng nhớ mới', 'Chuyển quyền sở hữu từ `a` sang bản mới', 'Tạo một tham chiếu có thể sửa'], ans: 0, why: 'Đó là lý do `Rc::clone` rất rẻ: chỉ cộng 1 vào bộ đếm.' },
      { q: 'Với `RefCell`, nếu gọi `borrow_mut()` khi đang có một `borrow()` chưa trả, chuyện gì xảy ra?', opts: ['Chương trình panic lúc chạy', 'Lỗi biên dịch', 'Rust tự xếp hàng chờ', 'Giá trị bị sao chép'], ans: 0, why: '`RefCell` dời việc kiểm tra quy tắc mượn từ lúc biên dịch sang lúc chạy, nên vi phạm thì panic.' },
    ],
  },
  trick: {
    name: 'Kho chung nhiều người cùng ghi', why: 'Hai chủ cùng thêm đồ vào một danh sách duy nhất.',
    pre: ['use std::cell::RefCell;', 'use std::rc::Rc;', 'fn main() {'], post: ['}'],
    lines: ['let kho = Rc::new(RefCell::new(Vec::new()));', 'let nguoi_a = Rc::clone(&kho);', 'let nguoi_b = Rc::clone(&kho);', 'nguoi_a.borrow_mut().push("táo");', 'nguoi_b.borrow_mut().push("lê");', 'println!("{:?}", kho.borrow());'],
    out: '["táo", "lê"]',
    how: 'Ba biến cùng trỏ vào một `Vec`. Ai cũng `push` được vì `RefCell` kiểm tra quy tắc mượn lúc chạy, và mỗi `borrow_mut()` chỉ giữ quyền ghi trong đúng một câu lệnh.',
  },
});

G.add(7, {
  title: 'Toán tử cho kiểu của bạn', sub: 'impl Add, Mul, Neg cho vectơ', tags: ['Toán', 'Toán tử', 'Không gian'],
  learn: {
    intro: 'Toán tử như `+`, `-`, `*` thật ra là **đường tắt** cho các trait trong `std::ops`: `a + b` chính là `a.add(b)` của trait `Add`. Thực hiện trait đó cho kiểu của bạn và `+` sẽ chạy với vectơ, ma trận, số phức… Mặt phẳng hai chiều rất hợp để thử.',
    points: ['`impl Add for Vec2 { type Output = Vec2; fn add(self, o: Vec2) -> Vec2 { ... } }`.', 'Các trait toán tử: `Add`, `Sub`, `Mul`, `Neg` (dấu trừ đơn), `AddAssign` (`+=`), `Index` (`[]`).', 'So sánh `==` và `<` đến từ `PartialEq` và `PartialOrd`, thường chỉ cần `#[derive(...)]`.', 'Hãy giữ nghĩa quen thuộc của toán tử: `+` mà làm việc lạ sẽ khiến code khó hiểu.'],
    code: 'use std::ops::{Add, Mul, Neg};\n\n#[derive(Debug, Clone, Copy, PartialEq)]\nstruct Vec2 {\n    x: i32,\n    y: i32,\n}\n\nimpl Add for Vec2 {\n    type Output = Vec2;\n    fn add(self, o: Vec2) -> Vec2 {\n        Vec2 { x: self.x + o.x, y: self.y + o.y }\n    }\n}\n\nimpl Mul<i32> for Vec2 {\n    type Output = Vec2;\n    fn mul(self, k: i32) -> Vec2 {\n        Vec2 { x: self.x * k, y: self.y * k }\n    }\n}\n\nimpl Neg for Vec2 {\n    type Output = Vec2;\n    fn neg(self) -> Vec2 {\n        Vec2 { x: -self.x, y: -self.y }\n    }\n}\n\nfn main() {\n    let a = Vec2 { x: 1, y: 2 };\n    let b = Vec2 { x: 3, y: -1 };\n    println!("{:?}", a + b);\n    println!("{:?}", a * 3);\n    println!("{:?}", -(a + b) * 2);\n}',
    out: 'Vec2 { x: 4, y: 1 }\nVec2 { x: 3, y: 6 }\nVec2 { x: -8, y: -2 }',
    note: 'Cộng hai vectơ là **đi tiếp** trên mặt phẳng: đến điểm a rồi đi thêm một đoạn b. Ta dùng đúng hình ảnh này ở thử thách.',
  },
  ch: {
    type: 'cells', brief: 'Mỗi ô ghi cặp `x,y` (trục y hướng lên). Hãy tính phép toán trên `Vec2` rồi chạm vào ô mà kết quả rơi vào.',
    hint: 'Cộng vectơ là cộng từng thành phần: `(x1 + x2, y1 + y2)`. Nhân với số `k` là nhân cả hai thành phần. Dấu trừ đổi dấu cả hai thành phần.',
    rounds: [
      { W: 7, vals: GRID7, sm: true, q: 'Cho `a = Vec2 { x: 1, y: 2 }`. Chạm vào ô `a + Vec2 { x: 2, y: -3 }`.', ans: AT7(3, -1), why: '(1 + 2, 2 + (-3)) = (3, -1).' },
      { W: 7, vals: GRID7, sm: true, q: 'Cho `a = Vec2 { x: 1, y: 1 }`. Chạm vào ô `a * 3`.', ans: AT7(3, 3), why: '(1 × 3, 1 × 3) = (3, 3).' },
      { W: 7, vals: GRID7, sm: true, q: 'Cho `a = Vec2 { x: 2, y: 1 }`. Chạm vào ô `-a + Vec2 { x: 1, y: 0 }`.', ans: AT7(-1, -1), why: '-a = (-2, -1), cộng (1, 0) được (-1, -1).' },
      { W: 7, vals: GRID7, sm: true, q: 'Cho `a = Vec2 { x: 1, y: 0 }` và `b = Vec2 { x: 0, y: 1 }`. Chạm vào ô `(a + b) * 2`.', ans: AT7(2, 2), why: 'a + b = (1, 1), nhân 2 được (2, 2).' },
    ],
  },
  trick: {
    name: 'Cộng dồn các bước đi bằng +=', why: 'Cập nhật vị trí tại chỗ bằng toán tử `+=` cho kiểu của bạn.',
    pre: [], post: [],
    lines: ['use std::ops::AddAssign;', '#[derive(Debug)]', 'struct V { x: i32, y: i32 }', 'impl AddAssign for V {', 'fn add_assign(&mut self, o: V) { self.x += o.x; self.y += o.y; }', '}', 'fn main() {', 'let mut p = V { x: 0, y: 0 };', 'p += V { x: 2, y: -1 };', 'p += V { x: 1, y: 5 };', 'println!("{:?}", p);', '}'],
    out: 'V { x: 3, y: 4 }',
    how: '`+=` đến từ trait `AddAssign`, nhận `&mut self` và sửa trực tiếp vế trái, khác với `Add` trả về giá trị mới. Mỗi bước là một vectơ dịch chuyển, cộng dồn lại ra vị trí cuối cùng.',
  },
});
