/* ===== Vùng 5: Xưởng Kiểu Dữ Liệu ===== */
G.add(5, {
  title: 'struct: ghép dữ liệu', sub: 'struct và các trường', tags: ['Không gian', 'Toán'],
  learn: {
    intro: '`struct` ghép nhiều giá trị có tên thành một kiểu mới. Một điểm trên bản đồ có hai tọa độ, một chiếc hộp có dài, rộng, cao: gom chúng vào một struct để mang đi cùng nhau.',
    points: ['`struct Diem { x: i32, y: i32 }` định nghĩa kiểu. Tạo giá trị: `Diem { x: 3, y: 4 }`.', 'Truy cập trường bằng dấu chấm: `d.x`. Muốn sửa phải khai báo `let mut d`.', '`#[derive(Debug)]` cho phép in bằng `{:?}`; `#[derive(Clone, Copy, PartialEq)]` thêm khả năng sao chép và so sánh.', 'Cú pháp cập nhật `Diem { x: 9, ..a }` lấy các trường còn lại từ `a`.'],
    code: '#[derive(Debug, Clone, Copy, PartialEq)]\nstruct Diem {\n    x: i32,\n    y: i32,\n}\n\nfn main() {\n    let a = Diem { x: 3, y: 4 };\n    let b = Diem { x: 9, ..a };\n    println!("{:?} {:?}", a, b);\n    println!("{}", a == b);\n    let khoang_cach_goc = ((a.x * a.x + a.y * a.y) as f64).sqrt();\n    println!("{khoang_cach_goc}");\n}',
    out: 'Diem { x: 3, y: 4 } Diem { x: 9, y: 4 }\nfalse\n5',
    note: 'Định lý Pitago nằm ngay trong code: khoảng cách từ gốc tọa độ đến (3, 4) là đúng 5.',
  },
  ch: {
    type: 'order', brief: 'Xếp các mảnh code thành chương trình tính diện tích một chiếc hộp chữ nhật bằng `struct`. Có một mảnh thừa viết sai cú pháp.',
    hint: 'Định nghĩa `struct Hop { ... }` đứng trước, hàm `main` đứng sau. Trong `struct`, mỗi trường là `ten: kieu,`. Khi tạo giá trị phải ghi tên trường: `Hop { dai: 5, rong: 3 }`.',
    lines: ['struct Hop {', 'dai: u32,', 'rong: u32,', '}', 'fn main() {', 'let h = Hop { dai: 5, rong: 3 };', 'println!("diện tích = {}", h.dai * h.rong);', '}'],
    decoys: ['let h = Hop(5, 3);'], out: 'diện tích = 15', btn: 'Biên dịch và chạy',
  },
  trick: {
    name: 'In struct thành nhiều dòng', why: 'Soi cấu trúc lồng nhau dễ như nhìn một bảng, không phải đếm ngoặc.',
    pre: [], post: [],
    lines: ['#[derive(Debug)]', 'struct Diem { x: i32, y: i32 }', 'fn main() {', 'let d = Diem { x: 1, y: 2 };', 'println!("{:#?}", d);', '}'],
    out: 'Diem {\n    x: 1,\n    y: 2,\n}',
    how: '`{:?}` in một dòng, còn `{:#?}` in “đẹp” nhiều dòng có thụt lề. Cả hai đều nhờ `#[derive(Debug)]` tự viết giúp bạn hàm in.',
  },
});

G.add(5, {
  title: 'impl: phương thức', sub: 'impl, self và hàm liên kết', tags: ['Không gian', 'Toán', 'Toán tử'],
  learn: {
    intro: '`impl` gắn **hành vi** vào một kiểu. Hàm trong `impl` có tham số đầu là `self` gọi là phương thức: `a.manhattan(&b)`. Hàm không có `self` (như `Diem::moi`) gọi là **hàm liên kết**, thường dùng làm bộ khởi tạo.',
    points: ['`&self` mượn để đọc, `&mut self` mượn để sửa, `self` lấy hẳn quyền sở hữu.', '`Self` là tên gọi tắt của chính kiểu đang `impl`.', 'Hàm liên kết gọi bằng `::`, phương thức gọi bằng `.`.', 'Có thể có nhiều khối `impl` cho cùng một kiểu.'],
    code: '#[derive(Debug, Clone, Copy)]\nstruct Diem {\n    x: i32,\n    y: i32,\n}\n\nimpl Diem {\n    fn moi(x: i32, y: i32) -> Self {\n        Self { x, y }\n    }\n\n    fn doi_cho(&mut self, dx: i32, dy: i32) {\n        self.x += dx;\n        self.y += dy;\n    }\n\n    fn manhattan(&self, khac: &Diem) -> i32 {\n        (self.x - khac.x).abs() + (self.y - khac.y).abs()\n    }\n}\n\nfn main() {\n    let mut a = Diem::moi(1, 1);\n    let b = Diem::moi(4, 5);\n    println!("{}", a.manhattan(&b));\n    a.doi_cho(3, 4);\n    println!("{:?} {}", a, a.manhattan(&b));\n}',
    out: '7\nDiem { x: 4, y: 5 } 0',
    note: 'Bot của chúng ta cũng chỉ là một struct có các phương thức: `bot.forward()`, `bot.turn_left()`.',
  },
  ch: {
    type: 'bug', brief: 'Một phương thức muốn tăng bộ đếm nhưng chỉ được cho mượn để đọc. Tìm dòng bị từ chối và chọn cách sửa.', hint: 'Phương thức sửa dữ liệu của chính đối tượng thì phải mượn theo kiểu nào? Hãy nhìn chữ ký hàm `tang`.',
    code: 'struct Dem {\n    n: u32,\n}\nimpl Dem {\n    fn tang(&self) {\n        self.n += 1;\n    }\n}\nfn main() {\n    let mut d = Dem { n: 0 };\n    d.tang();\n    println!("{}", d.n);\n}',
    bad: 5, fixAt: 4, ecode: 'E0594',
    err: 'error[E0594]: cannot assign to `self.n`, which is behind a `&` reference\n --> src/main.rs:6:9\n  |\n6 |         self.n += 1;\n  |         ^^^^^^^^^^^ `self` is a `&` reference, so it cannot be written to',
    fixes: ['fn tang(&mut self) {', 'fn tang(mut self) {', 'fn tang(self) {', 'fn tang(&self, mut n: u32) {'], fix: 0,
    why: '`&self` chỉ cho phép đọc. Phương thức muốn sửa đối tượng của chính nó phải khai báo `&mut self`, và người gọi phải giữ biến `mut`.',
  },
  trick: {
    name: 'Nối chuỗi phương thức (builder)', why: 'Thiết lập từng thuộc tính bằng một chuỗi lời gọi dễ đọc.',
    pre: [], post: [],
    lines: ['struct Hop { dai: u32, rong: u32 }', 'impl Hop {', 'fn moi() -> Self { Hop { dai: 1, rong: 1 } }', 'fn dai(mut self, d: u32) -> Self { self.dai = d; self }', 'fn rong(mut self, r: u32) -> Self { self.rong = r; self }', 'fn dien_tich(&self) -> u32 { self.dai * self.rong }', '}', 'fn main() {', 'println!("{}", Hop::moi().dai(6).rong(7).dien_tich());', '}'],
    out: '42',
    how: 'Mỗi phương thức nhận `self` theo giá trị, sửa rồi trả chính nó về, nên nối được `.dai(6).rong(7)`. Mẫu Builder này rất phổ biến trong thư viện Rust.',
  },
});

G.add(5, {
  title: 'enum và match', sub: 'enum, biến thể mang dữ liệu', tags: ['Logic', 'Không gian'],
  learn: {
    intro: '`enum` định nghĩa một kiểu chỉ có thể là **một trong vài biến thể**. Mỗi biến thể trong Rust còn có thể **mang dữ liệu** riêng. `match` kiểm tra bạn đã xử lý đủ mọi biến thể hay chưa.',
    points: ['`enum Huong { Bac, Dong, Nam, Tay }`, dùng bằng `Huong::Dong`.', 'Biến thể có thể mang dữ liệu: `Hinh::Tron(f64)` hoặc `Hinh::ChuNhat { dai: f64, rong: f64 }`.', '`match` bắt buộc **vét cạn**: thiếu một biến thể là lỗi biên dịch.', 'Thêm biến thể mới vào enum, trình biên dịch chỉ ngay mọi `match` cần cập nhật.'],
    code: '#[derive(Debug, Clone, Copy)]\nenum Huong {\n    Bac,\n    Dong,\n    Nam,\n    Tay,\n}\n\nimpl Huong {\n    fn re_phai(self) -> Huong {\n        match self {\n            Huong::Bac => Huong::Dong,\n            Huong::Dong => Huong::Nam,\n            Huong::Nam => Huong::Tay,\n            Huong::Tay => Huong::Bac,\n        }\n    }\n}\n\nfn main() {\n    let mut h = Huong::Bac;\n    for _ in 0..3 {\n        h = h.re_phai();\n        println!("{:?}", h);\n    }\n}',
    out: 'Dong\nNam\nTay',
    note: 'Bốn hướng quay vòng chính là phép `% 4` của bài 3, nhưng enum an toàn hơn con số 0 đến 3: không thể có “hướng số 7”.',
  },
  ch: {
    type: 'bug', brief: 'Đèn giao thông có ba màu nhưng `match` chỉ xử lý hai. Tìm dòng bị từ chối và chọn cách sửa trọn vẹn.', hint: 'Trình biên dịch nói rõ biến thể nào còn thiếu. Cách sửa tốt là thêm hẳn một nhánh cho biến thể đó.',
    code: "enum Den {\n    Do,\n    Vang,\n    Xanh,\n}\nfn hanh_dong(d: Den) -> &'static str {\n    match d {\n        Den::Do => \"dừng\",\n        Den::Xanh => \"đi\",\n    }\n}\nfn main() {\n    println!(\"{}\", hanh_dong(Den::Vang));\n}",
    bad: 6, fixAt: 8, ecode: 'E0004',
    err: 'error[E0004]: non-exhaustive patterns: `Den::Vang` not covered\n --> src/main.rs:7:11\n  |\n7 |     match d {\n  |           ^ pattern `Den::Vang` not covered',
    fixes: ['Den::Xanh => "đi", Den::Vang => "chậm lại",', 'Den::Xanh => "đi" Den::Vang => "chậm lại",', 'Den::Xanh => "đi", Den::Vang,', 'Den::Xanh => "đi", Den::Cam => "chuẩn bị",'], fix: 0,
    why: '`match` phải phủ mọi biến thể. Thiếu `Den::Vang` thì trình biên dịch từ chối, nên bạn không bao giờ quên một trường hợp.',
  },
  trick: {
    name: 'Mỗi hình một cách tính', why: 'Dùng enum mang dữ liệu để tính diện tích nhiều loại hình bằng một hàm.',
    pre: [], post: [],
    lines: ['enum Hinh { Vuong(f64), Tam(f64, f64) }', 'fn dien_tich(h: &Hinh) -> f64 {', 'match h {', 'Hinh::Vuong(a) => a * a,', 'Hinh::Tam(day, cao) => 0.5 * day * cao,', '}', '}', 'fn main() {', 'println!("{}", dien_tich(&Hinh::Vuong(3.0)) + dien_tich(&Hinh::Tam(4.0, 3.0)));', '}'],
    out: '15',
    how: 'Mỗi biến thể mang dữ liệu khác nhau và `match` bóc chúng ra ngay trong mẫu. Muốn thêm hình tròn? Thêm một biến thể, trình biên dịch sẽ chỉ chỗ cần cập nhật.',
  },
});

G.add(5, {
  title: 'Option và Result', sub: 'Option, Result và toán tử ?', tags: ['Logic', 'Toán'],
  learn: {
    intro: 'Rust không có `null`. Giá trị có thể vắng mặt được gói trong `Option<T>`: hoặc `Some(giá_trị)` hoặc `None`. Việc có thể thất bại được gói trong `Result<T, E>`: hoặc `Ok(giá_trị)` hoặc `Err(lỗi)`. Bạn **buộc** phải xử lý cả hai trường hợp.',
    points: ['`a.get(i)` trả `Option<&T>`: là `None` nếu chỉ số vượt biên, không panic.', '`"42".parse::<i32>()` trả `Result`: `Ok(42)`, hoặc `Err(..)` nếu chuỗi không phải số.', '`if let Some(x) = opt { ... }` hay `match` để mở gói. `unwrap_or(0)` cho giá trị mặc định.', 'Toán tử `?` trong hàm trả `Result`: gặp `Err` thì thoát hàm và chuyển lỗi lên trên, gặp `Ok` thì lấy giá trị.'],
    code: 'fn chia(a: i32, b: i32) -> Option<i32> {\n    if b == 0 { None } else { Some(a / b) }\n}\n\nfn cong_chuoi(a: &str, b: &str) -> Result<i32, std::num::ParseIntError> {\n    let x: i32 = a.parse()?;\n    let y: i32 = b.parse()?;\n    Ok(x + y)\n}\n\nfn main() {\n    println!("{:?} {:?}", chia(10, 2), chia(1, 0));\n    println!("{:?}", cong_chuoi("20", "22"));\n    println!("{}", cong_chuoi("20", "abc").is_err());\n    let a = [1, 2, 3];\n    println!("{}", a.get(7).copied().unwrap_or(-1));\n}',
    out: 'Some(5) None\nOk(42)\ntrue\n-1',
    note: 'Hãy tưởng tượng `Option` là một chiếc hộp có thể rỗng. Bạn phải mở hộp trước khi dùng, nên không bao giờ gặp lỗi “null pointer”.',
  },
  ch: {
    type: 'quiz', brief: 'Bốn câu về hai kiểu “có thể vắng” và “có thể hỏng”. Ba câu cần đoán kết quả chạy.', hint: '`get` không panic: chỉ số vượt biên thì trả `None`. `parse` trả `Ok` nếu đọc được số và `Err` nếu không.',
    qs: [
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let v = vec![10, 20, 30];\n    println!("{:?} {:?}", v.get(1), v.get(5));\n}', run: true, opts: ['Some(20) None', '20 None', 'Some(20) Some(0)', 'Some(20) rồi panic'], ans: 0, why: '`get` trả `Option`: ô 1 có giá trị 20 nên là `Some(20)`, ô 5 không tồn tại nên là `None`.' },
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let a = "12".parse::<i32>();\n    let b = "1x".parse::<i32>();\n    println!("{} {}", a.is_ok(), b.is_ok());\n}', run: true, opts: ['true false', 'true true', 'false false', 'Lỗi biên dịch'], ans: 0, why: '"12" đọc được thành số nên `Ok`. "1x" thì không nên là `Err`.' },
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let x: Option<i32> = None;\n    println!("{}", x.unwrap_or(7) + Some(3).unwrap_or(0));\n}', run: true, opts: ['10', '7', '3', 'Lỗi biên dịch'], ans: 0, why: '`None.unwrap_or(7)` cho 7, `Some(3).unwrap_or(0)` cho 3. Tổng là 10.' },
      { q: 'Trong hàm trả về `Result`, dòng `let x = s.parse::<i32>()?;` làm gì khi `s` không phải số?', opts: ['Thoát khỏi hàm ngay và trả `Err` cho người gọi', 'Gán `x = 0` rồi chạy tiếp', 'Làm chương trình panic', 'Bỏ qua dòng này'], ans: 0, why: 'Toán tử `?` chuyển lỗi lên trên: gặp `Err` thì hàm kết thúc và trả chính lỗi đó.' },
    ],
  },
  trick: {
    name: 'let … else: thoát sớm gọn gàng', why: 'Mở gói `Option` hoặc `Result` và thoát ngay nếu thất bại, để phần chính của code không bị lồng nhiều tầng.',
    lines: ['let chuoi = "42";', 'let Ok(so) = chuoi.parse::<i32>() else {', 'println!("không phải số");', 'return;', '};', 'println!("gấp đôi = {}", so * 2);'],
    out: 'gấp đôi = 84',
    how: '`let MẪU = biểu_thức else { ... };` mở gói khi khớp mẫu, còn không thì chạy khối `else` (bắt buộc phải thoát bằng `return`, `break`, `continue` hoặc panic). Đường “vui” của code nằm thẳng hàng bên trái.',
  },
});
