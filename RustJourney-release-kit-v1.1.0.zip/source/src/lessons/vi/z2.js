/* ===== Vùng 2: Ngã Rẽ Dòng Chảy ===== */
G.add(2, {
  title: 'Rẽ nhánh if / else', sub: 'if, else và if là biểu thức', tags: ['Không gian', 'Logic'],
  learn: {
    intro: 'Chương trình không chỉ đi thẳng. `if` cho nó biết khi nào phải rẽ. Trong Rust, `if` còn là một **biểu thức**: nó trả về giá trị.',
    points: ['`if điều_kiện { ... } else { ... }`. Điều kiện phải là `bool`, Rust không tự đổi số thành đúng/sai.', 'Không cần ngoặc quanh điều kiện, nhưng luôn phải có `{}`.', 'Vì là biểu thức, bạn viết được `let s = if x > 0 { "dương" } else { "không dương" };`.', 'Nhiều nhánh thì dùng `else if`. Mọi nhánh phải cho ra cùng một kiểu.'],
    code: 'fn main() {\n    let nhiet_do = 31;\n    let loi_khuyen = if nhiet_do > 35 {\n        "ở trong nhà"\n    } else if nhiet_do > 25 {\n        "mang theo nước"\n    } else {\n        "mặc thêm áo"\n    };\n    println!("{nhiet_do} độ: {loi_khuyen}");\n}',
    out: '31 độ: mang theo nước',
    note: 'Bot cũng rẽ nhánh được: `if bot.wall_ahead() { ... }` hỏi cảm biến trước khi quyết định hướng đi.',
  },
  ch: {
    type: 'robot', brief: 'Bot đứng ở đầu một đường xoắn ốc. Vòng lặp `while` đã có sẵn (khối bị khóa). Hãy viết phần thân vòng lặp: nếu phía trước là tường thì rẽ phải, nếu không thì đi thẳng.',
    hint: 'Dùng khối `if … else`. Nhánh `if` đặt `turn_right`, nhánh `else` đặt `forward`. Chạm vào dòng gạch đứt nằm dưới `} else {` để chèn khối vào đúng nhánh.',
    grid: ['#######', '#S....#', '#####.#', '#..G#.#', '#.###.#', '#.....#', '#######'], dir: 'E',
    pre: '!while:!at_goal { }', cursor: 'main/0.body', palette: ['ifelse:wall_ahead', 'forward', 'right', 'left'], max: 5, par: 3,
    sol: '!while:!at_goal { if:wall_ahead { R } else { F } }',
  },
  trick: {
    name: 'if là biểu thức', why: 'Chọn giá trị theo điều kiện ngay trong một câu `let`, không cần biến phụ.',
    lines: ['let diem = 8;', 'let xep_loai = if diem >= 8 { "Giỏi" } else { "Khá" };', 'let so_sao = if diem == 10 { 3 } else if diem >= 8 { 2 } else { 1 };', 'println!("{xep_loai} {so_sao}");'],
    out: 'Giỏi 2',
    how: 'Mỗi nhánh của `if` là một biểu thức và phải cùng kiểu, nên cả `if` có thể đứng bên phải dấu `=`. Rust vì vậy không cần toán tử ba ngôi `? :` như C.',
  },
});

G.add(2, {
  title: 'Vòng lặp', sub: 'loop, while, for và dải 0..n', tags: ['Không gian', 'Toán'],
  learn: {
    intro: 'Muốn lặp lại một việc, đừng chép dán. Rust có ba loại vòng lặp: `loop` (mãi mãi, đến khi `break`), `while` (lặp khi điều kiện còn đúng) và `for` (đi qua một dải số hay một bộ sưu tập).',
    points: ['`for i in 0..5` chạy với i = 0, 1, 2, 3, 4. Dải `0..5` không gồm 5, còn `0..=5` thì có.', '`while điều_kiện { ... }` kiểm tra điều kiện trước mỗi vòng.', '`loop { ... }` lặp vô hạn, thoát bằng `break` (và `break giá_trị` trả về một giá trị).', '`continue` bỏ qua phần còn lại của vòng hiện tại.'],
    code: 'fn main() {\n    let mut tong = 0;\n    for i in 1..=5 {\n        tong += i;\n    }\n    println!("1 + 2 + ... + 5 = {tong}");\n    let mut n = 27;\n    let mut buoc = 0;\n    while n != 1 {\n        n = if n % 2 == 0 { n / 2 } else { 3 * n + 1 };\n        buoc += 1;\n    }\n    println!("27 về 1 sau {buoc} bước");\n}',
    out: '1 + 2 + ... + 5 = 15\n27 về 1 sau 111 bước',
    note: 'Bốn lệnh giống hệt nhau như `bot.forward();` là dấu hiệu nên đổi sang `for _ in 0..4`: ít dòng hơn, ít lỗi hơn.',
  },
  ch: {
    type: 'robot', brief: 'Cầu thang này có 4 bậc giống hệt nhau. Chép dán 16 lệnh thì mệt và dễ sai, hãy dùng vòng lặp `for` để lặp lại một bậc.',
    hint: 'Một bậc gồm: đi 1 ô, rẽ trái, đi 1 ô, rẽ phải. Đặt 4 lệnh đó vào trong khối `for`, rồi bấm + để chỉnh số lần lặp thành 4.',
    grid: ['#######', '#####G#', '####..#', '###..##', '##..###', '#S.####', '#######'], dir: 'E', palette: ['forward', 'left', 'right', 'for:3'], max: 8, par: 5,
    sol: 'for:4 { F L F R }',
  },
  trick: {
    name: 'Thoát hai vòng lặp cùng lúc', why: 'Tìm cặp số đầu tiên thỏa điều kiện rồi dừng cả hai vòng for lồng nhau.',
    lines: ['let mut ket_qua = (0, 0);', "'ngoai: for i in 1..10 {", 'for j in 1..10 {', 'if i * j == 42 {', 'ket_qua = (i, j);', "break 'ngoai;", '}', '}', '}', 'println!("{ket_qua:?}");'],
    out: '(6, 7)',
    how: "`break` thường chỉ thoát vòng trong cùng. Gắn nhãn `'ngoai:` cho vòng ngoài rồi viết `break 'ngoai;` để thoát thẳng ra ngoài. Cặp đầu tiên có tích 42 với hai số dưới 10 là 6 × 7.",
  },
});

const PLANE = []; for (let y = 2; y >= -2; y--) for (let x = -2; x <= 2; x++) PLANE.push(x + ',' + y);
const QUAD = f => PLANE.map((_, i) => i).filter(i => f(Math.sign(i % 5 - 2), Math.sign(2 - Math.floor(i / 5))));
G.add(2, {
  title: 'match: khớp mẫu', sub: 'match, dải giá trị và tuple', tags: ['Logic', 'Không gian'],
  learn: {
    intro: '`match` là công tắc đa nhánh của Rust: đưa một giá trị vào, nó thử lần lượt từng mẫu và chạy nhánh đầu tiên khớp. Rust bắt bạn phủ **mọi** trường hợp, nên không thể quên một nhánh.',
    points: ['Mẫu có thể là một giá trị (`1`), một dải (`2..=5`), nhiều giá trị (`6 | 7`) hoặc `_` (mọi thứ còn lại).', 'Khớp được cả một bộ (tuple): `match (x, y) { (0, 0) => ... }`, rất hợp với tọa độ.', 'Nhánh có thể thêm điều kiện: `n if n < 0 => ...` (gọi là match guard).', '`match` là biểu thức: kết quả của nhánh được khớp chính là giá trị của cả `match`.'],
    code: 'fn goc_phan_tu(x: i32, y: i32) -> &\'static str {\n    match (x.signum(), y.signum()) {\n        (0, 0) => "gốc tọa độ",\n        (1, 1) => "phần tư I",\n        (-1, 1) => "phần tư II",\n        (-1, -1) => "phần tư III",\n        (1, -1) => "phần tư IV",\n        _ => "nằm trên một trục",\n    }\n}\n\nfn main() {\n    println!("{}", goc_phan_tu(3, 4));\n    println!("{}", goc_phan_tu(-2, 5));\n    println!("{}", goc_phan_tu(0, -7));\n}',
    out: 'phần tư I\nphần tư II\nnằm trên một trục',
    note: 'Mỗi nhánh của `match` là một vùng trên mặt phẳng tọa độ: tư duy không gian chuyển thẳng thành code.',
  },
  ch: {
    type: 'cells', brief: 'Mỗi ô ghi cặp `x,y` (trục y hướng lên như trong toán). Chạm vào ô mà `goc_phan_tu(x, y)` trả về đúng kết quả được hỏi.',
    hint: '`signum()` cho -1, 0 hoặc 1 tùy dấu. Hàng trên cùng có y lớn nhất, cột ngoài cùng bên trái có x nhỏ nhất.',
    rounds: [
      { W: 5, vals: PLANE, sm: true, q: 'Chạm vào ô cho kết quả **"gốc tọa độ"**.', ans: 12, why: 'Chỉ cặp `(0, 0)` khớp nhánh đầu tiên.' },
      { W: 5, vals: PLANE, sm: true, q: 'Chạm vào **một ô bất kỳ** cho kết quả **"phần tư II"**, tức là `(x.signum(), y.signum())` bằng `(-1, 1)`.', ans: QUAD((a, b) => a === -1 && b === 1), why: 'Phần tư II là x âm và y dương: góc trên bên trái.' },
      { W: 5, vals: PLANE, sm: true, q: 'Chạm vào **một ô bất kỳ** (khác gốc) cho kết quả **"nằm trên một trục"**.', ans: QUAD((a, b) => (a === 0) !== (b === 0)), why: 'Một trong hai tọa độ bằng 0, tức là nằm trên trục x hoặc trục y. Các nhánh trên không khớp nên rơi vào `_`.' },
    ],
  },
  trick: {
    name: 'FizzBuzz bằng match tuple', why: 'Gộp hai phép chia dư thành một cặp rồi để `match` quyết định, thay cho chuỗi if lồng nhau.',
    pre: ['fn main() {', 'for n in [3, 5, 15, 7] {'], post: ['}', '}'],
    lines: ['let s = match (n % 3, n % 5) {', '(0, 0) => "FizzBuzz".to_string(),', '(0, _) => "Fizz".to_string(),', '(_, 0) => "Buzz".to_string(),', '_ => n.to_string(),', '};', 'println!("{s}");'],
    out: 'Fizz\nBuzz\nFizzBuzz\n7',
    how: 'Cặp `(n % 3, n % 5)` là tọa độ trên một lưới 3×5. Mẫu `(0, 0)` đặt trước các mẫu còn lại vì `match` dừng ở nhánh khớp đầu tiên: thứ tự nhánh chính là độ ưu tiên.',
  },
});

G.add(2, {
  title: 'Hàm và giá trị trả về', sub: 'fn, tham số và kiểu trả về', tags: ['Không gian', 'Toán'],
  learn: {
    intro: 'Hàm là một đoạn code có tên. Đặt tên một lần, gọi bao nhiêu lần cũng được. Hàm nhận **tham số** ở đầu vào và có thể trả về một **giá trị** ở đầu ra.',
    points: ['`fn ten(a: i32, b: i32) -> i32 { ... }`: kiểu của tham số và kiểu trả về luôn được ghi rõ.', 'Biểu thức cuối cùng của hàm, **không có dấu `;`**, chính là giá trị trả về. `return` chỉ cần khi muốn thoát sớm.', 'Hàm không trả về gì thật ra trả về `()` (kiểu đơn vị).', 'Hàm có thể gọi hàm khác, kể cả gọi chính nó (đệ quy).'],
    code: 'fn binh_phuong(x: i32) -> i32 {\n    x * x\n}\n\nfn khoang_cach(x1: i32, y1: i32, x2: i32, y2: i32) -> i32 {\n    (x2 - x1).abs() + (y2 - y1).abs()\n}\n\nfn main() {\n    println!("{}", binh_phuong(7));\n    println!("{}", khoang_cach(1, 1, 4, 5));\n}',
    out: '49\n7',
    note: '`khoang_cach` đo số bước đi trên lưới (khoảng cách Manhattan): đúng thứ Bot cần biết khi muốn đến cờ đích.',
  },
  ch: {
    type: 'robot', brief: 'Hai đoạn cầu thang giống nhau xuất hiện nhiều lần. Hãy đặt tên cho đoạn “bước lên một bậc” bằng hàm `leo`, rồi gọi nó nhiều lần. Bảng khối này không có `for`.',
    hint: 'Chạm dòng gạch đứt trong `fn leo` để chèn: đi 1 ô, rẽ trái, đi 1 ô, rẽ phải. Sau đó chạm dòng gạch đứt trong `main`, gọi `leo` hai lần, đi thẳng 2 ô, rồi gọi `leo` thêm hai lần.',
    grid: ['#########', '#######G#', '######..#', '###....##', '##..#####', '#S.######', '#########'], dir: 'E', fns: ['leo'], cursor: 'fn_leo',
    palette: ['forward', 'left', 'right', 'call:leo'], max: 12, par: 10, sol: 'fn:leo { F L F R } call:leo call:leo F F call:leo call:leo',
  },
  trick: {
    name: 'Trả về nhiều giá trị', why: 'Một hàm trả về cả thương lẫn dư bằng một bộ tuple.',
    pre: [], post: [],
    lines: ['fn thuong_du(a: i32, b: i32) -> (i32, i32) {', '(a / b, a % b)', '}', 'fn main() {', 'let (q, r) = thuong_du(17, 5);', 'println!("17 = 5 * {q} + {r}");', '}'],
    out: '17 = 5 * 3 + 2',
    how: 'Tuple gộp nhiều giá trị thành một. Bên nhận có thể “mở gói” ngay bằng `let (q, r) = ...`. Biểu thức cuối `(a / b, a % b)` không có dấu `;` nên nó là giá trị trả về.',
  },
});
