/* ===== Vùng 8: Đỉnh Bậc Thầy (bài 29–32) ===== */

/* ---- Bài 29: Thao tác bit ---- */
G.add(8, {
  title: 'Thao tác bit', sub: 'Toán tử & | ^ ! << >> trên từng công tắc', tags: ['Toán tử', 'Toán'],
  learn: {
    intro: 'Mọi số trong máy đều là một hàng công tắc bật tắt, gọi là **bit**. Rust cho bạn chạm thẳng vào từng công tắc bằng các toán tử bit. Chúng nhanh, gọn và là nền của mật mã, đồ họa, cờ trạng thái và giao thức mạng.',
    points: [
      '`&` (AND) chỉ giữ bit nào **cả hai** cùng bật, nên dùng làm **mặt nạ** để lọc hoặc xóa bit. `|` (OR) bật bit nếu **một trong hai** bật.',
      '`^` (XOR) bật khi hai bit **khác nhau**. XOR hai lần cùng một giá trị thì về chỗ cũ, đó là lý do nó có mặt trong mật mã. `!x` đảo mọi bit của `x`.',
      '`x << n` dịch sang trái n bit, tương đương nhân với 2ⁿ. `x >> n` dịch sang phải, tương đương chia nguyên cho 2ⁿ.',
      'Viết số nhị phân bằng `0b0001_0110` (gạch dưới chỉ để dễ đọc), in bằng `{:08b}`. Khác với C, trong Rust `&` được tính trước `==`.',
    ],
    code: 'fn main() {\n    let x: u8 = 0b0001_0110; // 22\n    println!("{}", x << 1);\n    println!("{}", x >> 2);\n    println!("{:08b}", x & 0b0000_1111);\n    println!("{:08b}", x | 0b1000_0000);\n    println!("{:08b}", x ^ 0b0000_1111);\n    println!("{:08b}", !x);\n    println!("{}", x.count_ones());\n}',
    out: '44\n5\n00000110\n10010110\n00011001\n11101001\n3',
    note: 'Dịch từ số bit của kiểu trở lên (ví dụ `x << 8` với `u8`) là lỗi: Rust báo lỗi lúc biên dịch hoặc panic lúc chạy. Với số có dấu, `>>` giữ nguyên bit dấu.',
  },
  ch: {
    type: 'bits', brief: 'Một thanh ghi 8 bit đang chờ bạn. Vòng đầu bật đúng các công tắc. Các vòng sau chọn toán tử để biến đổi số, càng ít lượt càng tốt.',
    hint: 'Vòng 1: các công tắc có giá trị 128, 64, 32, 16, 8, 4, 2, 1; cộng chúng lại. Sau đó: `|` bật bit, `&` với mặt nạ xóa bit, `^` lật bit, `<<` nhân đôi.',
    rounds: [
      { mode: 'set', target: 77, q: 'Bật các bit để thanh ghi bằng **77**.' },
      { mode: 'ops', start: 4, target: 3, palette: [{ op: '|', v: 2 }, { op: '|', v: 1 }, { op: '&', v: 251 }, { op: '^', v: 4 }, { op: '<<', v: 1 }], max: 4, q: 'Tệp đang có quyền **đọc** (bit 2). Hãy đổi thành chỉ có quyền **ghi** (bit 1) và **chạy** (bit 0).' },
      { mode: 'ops', start: 5, target: 40, palette: [{ op: '<<', v: 1 }, { op: '<<', v: 2 }, { op: '>>', v: 1 }, { op: '|', v: 1 }], max: 3, q: 'Nhân **5** với **8** chỉ bằng phép dịch bit.' },
      { mode: 'ops', start: 22, target: 30, palette: [{ op: '&', v: 240 }, { op: '|', v: 1 }, { op: '^', v: 15 }, { op: '>>', v: 1 }], max: 4, q: 'Biến **22** thành **30**.' },
    ],
  },
  trick: {
    name: 'Lũy thừa của 2 trong một phép AND', why: 'Kiểm tra một số có phải lũy thừa của 2 mà không cần vòng lặp hay logarit.',
    pre: [], post: [],
    lines: ['fn la_luy_thua_2(n: u32) -> bool {', 'n != 0 && n & (n - 1) == 0', '}', 'fn main() {', 'for n in [1, 6, 8, 12, 64] {', 'println!("{n}: {}", la_luy_thua_2(n));', '}', '}'],
    out: '1: true\n6: false\n8: true\n12: false\n64: true',
    how: 'Lũy thừa của 2 chỉ có **một** bit bật. Trừ 1 làm bit đó tắt và mọi bit thấp hơn bật hết, nên `n & (n - 1)` xóa bit bật thấp nhất. Kết quả bằng 0 khi `n` chỉ có đúng một bit. Vì `&` được tính trước `==` nên không cần thêm ngoặc.',
  },
});

/* ---- Bài 30: Luồng song song ---- */
G.add(8, {
  title: 'Luồng song song', sub: 'thread, mpsc, Arc và Mutex', tags: ['Logic', 'Trình tự'],
  learn: {
    intro: 'Máy hiện đại có nhiều nhân, và **luồng (thread)** cho phép nhiều đoạn code chạy cùng lúc. Nỗi đau kinh điển là **data race**: hai luồng cùng sửa một dữ liệu mà không ai canh. Rust biến lỗi này thành **lỗi biên dịch**, nên người ta gọi đó là “song song không sợ”.',
    points: [
      '`thread::spawn(move || { ... })` tạo luồng mới và trả về `JoinHandle`. Gọi `.join()` để chờ luồng xong và nhận kết quả của nó.',
      'Luồng có thể sống lâu hơn hàm đã tạo ra nó, nên closure phải **sở hữu** dữ liệu nó dùng. Từ khóa `move` chuyển quyền sở hữu vào closure.',
      'Kênh `mpsc::channel()` cho luồng gửi tin về một nơi: `tx.send(v)` ở đầu gửi, `rx` ở đầu nhận. `tx.clone()` cho phép nhiều luồng cùng gửi.',
      'Dữ liệu dùng chung cần `Arc<Mutex<T>>`: `Arc` đếm tham chiếu an toàn giữa các luồng (bản dành cho luồng của `Rc` ở bài 27), còn `Mutex` là ổ khóa, mỗi lúc chỉ một luồng được `lock()` để sửa. `Rc` bị cấm đi qua luồng.',
    ],
    code: 'use std::sync::{mpsc, Arc, Mutex};\nuse std::thread;\n\nfn main() {\n    // 1) Luồng trả kết quả qua join\n    let tong = thread::spawn(|| (1..=100).sum::<u32>());\n    println!("tổng = {}", tong.join().unwrap());\n\n    // 2) Kênh: ba luồng gửi về một nơi\n    let (tx, rx) = mpsc::channel();\n    for id in 1..=3 {\n        let tx = tx.clone();\n        thread::spawn(move || tx.send(id * 10).unwrap());\n    }\n    drop(tx);\n    let mut nhan: Vec<i32> = rx.iter().collect();\n    nhan.sort();\n    println!("nhận {:?}", nhan);\n\n    // 3) Arc<Mutex>: bộ đếm chung\n    let dem = Arc::new(Mutex::new(0));\n    let mut tay = Vec::new();\n    for _ in 0..4 {\n        let dem = Arc::clone(&dem);\n        tay.push(thread::spawn(move || {\n            for _ in 0..1000 {\n                *dem.lock().unwrap() += 1;\n            }\n        }));\n    }\n    for t in tay {\n        t.join().unwrap();\n    }\n    println!("đếm = {}", *dem.lock().unwrap());\n}',
    out: 'tổng = 5050\nnhận [10, 20, 30]\nđếm = 4000',
    note: 'Hai cặp song sinh: `Rc` ↔ `Arc` và `RefCell` ↔ `Mutex`. Bản dùng cho nhiều luồng chậm hơn một chút vì phải đồng bộ, nên Rust bắt bạn chọn có chủ đích. Trình biên dịch phân biệt chúng bằng hai trait đánh dấu `Send` và `Sync`.',
  },
  ch: {
    type: 'bug', brief: 'Một luồng mới được tạo ra nhưng nó chỉ đang mượn dữ liệu của hàm `main`, trong khi luồng có thể chạy lâu hơn hàm. Tìm dòng bị từ chối và chọn cách sửa.',
    hint: 'Luồng mới không được giữ tham chiếu tới biến của `main`, vì không ai bảo đảm `main` còn sống. Hãy để closure **sở hữu** luôn `so`.',
    code: 'use std::thread;\n\nfn main() {\n    let so = vec![1, 2, 3];\n    let t = thread::spawn(|| println!("{:?}", so));\n    t.join().unwrap();\n}',
    bad: 4, ecode: 'E0373',
    err: 'error[E0373]: closure may outlive the current function, but it borrows `so`, which is owned by the current function\n --> src/main.rs:5:27\n  |\n5 |     let t = thread::spawn(|| println!("{:?}", so));\n  |                           ^^                  -- `so` is borrowed here\n  |                           |\n  |                           may outlive borrowed value `so`\n  |\nnote: function requires argument type to outlive `\'static`\n --> src/main.rs:5:13\n  |\n5 |     let t = thread::spawn(|| println!("{:?}", so));\n  |             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^',
    fixes: ['let t = thread::spawn(move || println!("{:?}", so));', 'let t = thread::spawn(|| println!("{:?}", so.clone()));', 'let t = thread::spawn(|| println!("{:?}", &so));', 'let t = thread::spawn(&|| println!("{:?}", so));'], fix: 0,
    why: '`thread::spawn` đòi closure sống đủ lâu (`\'static`), nhưng `|| println!(.., so)` chỉ **mượn** `so` từ `main`. `move` chuyển quyền sở hữu `so` vào closure để luồng tự giữ dữ liệu của mình. Chép `so.clone()` bên trong closure không giúp: closure vẫn phải mượn `so` để gọi `clone`.',
  },
  trick: {
    name: 'Chia đôi việc bằng thread::scope', why: 'Cho hai luồng mượn dữ liệu cục bộ mà không cần `move`, `Arc` hay `clone`.',
    lines: ['let so = [1, 2, 3, 4, 5, 6];', 'let (trai, phai) = so.split_at(3);', 'let (a, b) = std::thread::scope(|s| {', 'let ha = s.spawn(|| trai.iter().sum::<i32>());', 'let hb = s.spawn(|| phai.iter().sum::<i32>());', '(ha.join().unwrap(), hb.join().unwrap())', '});', 'println!("{a} {b} {}", a + b);'],
    out: '6 15 21',
    how: '`thread::scope` bảo đảm mọi luồng bên trong **kết thúc trước khi** nó trả về, nên các luồng được phép mượn biến cục bộ (`trai`, `phai`) một cách an toàn. Đây là cách sửa khác cho lỗi E0373 khi dữ liệu không cần sống lâu hơn hàm.',
  },
});

/* ---- Bài 31: Macro ---- */
G.add(8, {
  title: 'Macro: code viết code', sub: 'macro_rules! và dấu chấm than', tags: ['Logic', 'Trình tự'],
  learn: {
    intro: 'Hàm nhận **giá trị**. Macro nhận **mã nguồn** và trả về mã nguồn mới ngay lúc biên dịch. Bạn đã dùng macro từ bài đầu tiên: `println!`, `vec!`, `assert_eq!` đều là macro, vì thế chúng có dấu `!`.',
    points: [
      '`macro_rules! ten { (mẫu) => { mã sinh ra }; }` khai báo một macro. Mỗi nhánh gồm **mẫu** bên trái và **khuôn mã** bên phải, giống `match` nhưng cho cú pháp.',
      '`$x:expr` bắt một biểu thức, `$t:ty` bắt một kiểu, `$i:ident` bắt một tên. Biểu thức được giữ nguyên khối nên không dính bẫy thứ tự phép tính của macro trong C.',
      '`$( ... ),*` lặp mẫu cho từng phần tử cách nhau dấu phẩy. Một nhánh cho trường hợp ngắn nhất cộng với lời gọi đệ quy sẽ xử lý được danh sách dài bất kỳ.',
      'Macro chỉ thấy cú pháp, không thấy kiểu hay giá trị, và lỗi trong macro khó đọc hơn lỗi hàm. Hãy dùng macro khi hàm không làm được.',
    ],
    code: 'macro_rules! toi_da {\n    ($a:expr) => { $a };\n    ($a:expr, $($con:expr),+) => {{\n        let phan_con = toi_da!($($con),+);\n        if $a > phan_con { $a } else { phan_con }\n    }};\n}\n\nfn main() {\n    println!("{}", toi_da!(7));\n    println!("{}", toi_da!(3, 9, 4));\n    println!("{}", toi_da!(1 + 1, 2 * 5, 8));\n}',
    out: '7\n9\n10',
    note: 'Biểu thức `$a` được chép vào hai chỗ nên sẽ chạy hai lần. Với biểu thức có tác dụng phụ, hãy gán vào biến trước. Ngoài `macro_rules!`, Rust còn macro thủ tục như `#[derive(Debug)]`, viết bằng chính code Rust để biến đổi cú pháp.',
  },
  ch: {
    type: 'quiz', brief: 'Bốn câu hỏi về macro. Ba câu đầu bạn cần đoán kết quả khi biên dịch và chạy chương trình.', hint: 'Hãy khai triển macro bằng tay: thay `$x` bằng đối số, rồi tính. Nhớ rằng `$x:expr` được giữ nguyên khối.',
    qs: [
      { q: 'Chương trình này in ra gì?', code: 'macro_rules! gap_doi {\n    ($x:expr) => { $x * 2 };\n}\n\nfn main() {\n    println!("{}", gap_doi!(3 + 4));\n}', run: true, opts: ['14', '11', '10', 'Không biên dịch được'], ans: 0, why: '`$x:expr` là một biểu thức nguyên khối nên `3 + 4` được tính trước rồi mới nhân đôi. Macro của C chỉ thay chữ và cho `3 + 4 * 2 = 11`; macro Rust không mắc bẫy này.' },
      { q: 'Chương trình này in ra gì?', code: 'macro_rules! tong {\n    () => { 0 };\n    ($d:expr $(, $con:expr)*) => { $d + tong!($($con),*) };\n}\n\nfn main() {\n    println!("{}", tong!(1, 2, 3, 4));\n}', run: true, opts: ['10', '4', '1234', 'Không biên dịch được'], ans: 0, why: '`tong!(1, 2, 3, 4)` khai triển thành `1 + tong!(2, 3, 4)`, rồi `1 + (2 + (3 + (4 + 0)))`. Nhánh `()` rỗng là điều kiện dừng của đệ quy.' },
      { q: 'Chương trình này in ra gì?', code: 'macro_rules! tao_ham {\n    ($ten:ident, $v:expr) => {\n        fn $ten() -> i32 { $v }\n    };\n}\n\ntao_ham!(nam, 5);\ntao_ham!(sau, 6);\n\nfn main() {\n    println!("{}", nam() * sau());\n}', run: true, opts: ['30', '56', '11', 'Không biên dịch được'], ans: 0, why: 'Macro sinh ra hai hàm: `fn nam() -> i32 { 5 }` và `fn sau() -> i32 { 6 }`. Sau đó `nam() * sau()` là `5 * 6 = 30`. Macro có thể tạo cả khai báo, thứ mà hàm không làm được.' },
      { q: 'Điểm nào là khác biệt thật sự giữa macro và hàm?', opts: ['Macro mở rộng thành code lúc biên dịch, nên nhận được số đối số tùy ý và cả mẫu cú pháp', 'Macro luôn chạy nhanh hơn hàm', 'Macro không bao giờ gây lỗi biên dịch', 'Macro chỉ dùng được trong thư viện chuẩn'], ans: 0, why: 'Hàm có số tham số và kiểu cố định. Macro làm việc trên cú pháp trước khi biên dịch, nên `println!` mới nhận được số đối số tùy ý. Tốc độ chạy không phải lý do dùng macro.' },
    ],
  },
  trick: {
    name: 'Macro soi: in cả biểu thức lẫn giá trị', why: 'In ra chính đoạn code bạn viết cùng kết quả của nó, rất hợp để kiểm tra phép toán.',
    pre: [], post: [],
    lines: ['macro_rules! soi {', '($e:expr) => {', 'println!("{} = {}", stringify!($e), $e)', '};', '}', 'fn main() {', 'soi!(2 + 3 * 4);', 'soi!(10 % 4);', '}'],
    out: '2 + 3 * 4 = 14\n10 % 4 = 2',
    how: '`stringify!($e)` biến chính các ký tự của biểu thức thành chuỗi, còn `$e` được tính ra giá trị. Hàm thường không làm được điều này vì khi hàm chạy, văn bản của biểu thức đã mất. Thư viện chuẩn có sẵn macro `dbg!` làm việc tương tự.',
  },
});

/* ---- Bài 32: Trùm cuối ---- */
G.add(8, {
  title: 'Trùm cuối: Mê cung', sub: 'ghép mọi thứ đã học', tags: ['Không gian', 'Toán', 'Logic'],
  learn: {
    intro: 'Bạn đã đi từ dòng `println!` đầu tiên tới đây. Hãy nhìn lại: Bot suốt hành trình thật ra là một `struct` có vị trí, hướng và bản đồ. Hướng là một số từ 0 đến 3, và rẽ chỉ là cộng trừ **theo modulo 4**. Chương trình dưới đây là ruột của Bot, chạy theo **luật tay phải**.',
    points: [
      'Hướng là số `h` trong `0..4` (Bắc, Đông, Nam, Tây). **Rẽ phải** là `(h + 1) % 4`, **rẽ trái** là `(h + 3) % 4`, vì cộng 3 giống trừ 1 khi tính theo modulo 4.',
      'Hai mảng hằng `DX`, `DY` là **vectơ chỉ hướng**: đi một ô theo hướng `h` nghĩa là cộng `(DX[h], DY[h])` vào tọa độ. Toán học và không gian gặp nhau ở đây.',
      '**Luật tay phải**: mỗi vòng, nếu bên phải trống thì rẽ phải; trong khi phía trước vướng tường thì rẽ trái; rồi tiến một bước. Bot không cần bản đồ hay trí nhớ, chỉ cần cảm biến quanh mình.',
      'Luật này luôn tìm được lối ra của mê cung không có vòng, nhưng không chọn đường ngắn nhất: Bot chui cả vào ngõ cụt. Muốn đường ngắn nhất, cần thuật toán biết cả bản đồ như BFS.',
    ],
    code: 'const DX: [i32; 4] = [0, 1, 0, -1]; // Bắc, Đông, Nam, Tây\nconst DY: [i32; 4] = [-1, 0, 1, 0];\n\nstruct Bot {\n    x: i32,\n    y: i32,\n    h: usize, // hướng: 0 Bắc, 1 Đông, 2 Nam, 3 Tây\n    luoi: Vec<Vec<char>>,\n}\n\nimpl Bot {\n    fn o_tai(&self, h: usize) -> char {\n        let h = h % 4;\n        self.luoi[(self.y + DY[h]) as usize][(self.x + DX[h]) as usize]\n    }\n    fn tien(&mut self) {\n        self.x += DX[self.h];\n        self.y += DY[self.h];\n    }\n}\n\nfn main() {\n    let ban_do = ["#######", "#S..#G#", "#.#.#.#", "#.#...#", "#######"];\n    let luoi: Vec<Vec<char>> = ban_do.iter().map(|d| d.chars().collect()).collect();\n    let mut bot = Bot { x: 1, y: 1, h: 1, luoi };\n    let mut so_buoc = 0;\n    while bot.luoi[bot.y as usize][bot.x as usize] != \'G\' {\n        if bot.o_tai(bot.h + 1) != \'#\' {\n            bot.h = (bot.h + 1) % 4; // rẽ phải\n        }\n        while bot.o_tai(bot.h) == \'#\' {\n            bot.h = (bot.h + 3) % 4; // rẽ trái\n        }\n        bot.tien();\n        so_buoc += 1;\n    }\n    println!("Tới đích ({}, {}) sau {so_buoc} bước", bot.x, bot.y);\n}',
    out: 'Tới đích (5, 1) sau 12 bước',
    note: 'Đường ngắn nhất trong mê cung nhỏ này chỉ dài 8 bước, còn Bot tay phải mất 12 vì chui vào ngõ cụt. Bạn vừa dùng `struct`, `impl`, mảng hằng, vòng lặp lồng, số học modulo và `&self` trong một chương trình: mọi mảnh ghép đều đã học ở các vùng trước.',
  },
  ch: {
    type: 'robot', brief: 'Mê cung này quá lớn để viết từng bước, lại có 3 đồng xu nằm trong các ngõ cụt. Hãy dạy Bot **luật tay phải**. Mỗi vòng lặp: nhặt xu nếu đang đứng trên xu; nếu bên phải trống thì rẽ phải; trong khi phía trước vướng tường thì rẽ trái; rồi tiến một ô. Lặp tới khi Bot tới đích. Tối đa 9 khối.',
    hint: 'Khung chương trình là `while !at_goal { ... }`. Bên trong, theo thứ tự: `if on_coin { grab }`, `if !wall_right { right }`, `while wall_ahead { left }`, và cuối cùng `forward`.',
    grid: ['###########', '#S..#.....#', '###.#####.#', '#*#.......#', '#.#######.#', '#......*#.#', '#.#.#.###.#', '#.#.#*#...#', '#.#.###.###', '#G#.......#', '###########'], dir: 'E',
    palette: ['forward', 'left', 'right', 'grab', 'while:!at_goal', 'while:wall_ahead', 'if:on_coin', 'if:!wall_right', 'if:wall_ahead'], max: 9, par: 8,
    sol: 'while:!at_goal { if:on_coin { G } if:!wall_right { R } while:wall_ahead { L } F }',
  },
  trick: {
    name: 'Quay hướng bằng phép chia dư', why: 'Đổi hướng trên la bàn mà không cần một chuỗi `if` cho từng hướng.',
    lines: ['let ten = ["Bắc", "Đông", "Nam", "Tây"];', 'let mut h = 0;', 'for lenh in "RRLR".chars() {', 'h = if lenh == \'R\' { (h + 1) % 4 } else { (h + 3) % 4 };', 'println!("{lenh} -> {}", ten[h]);', '}'],
    out: 'R -> Đông\nR -> Nam\nL -> Đông\nR -> Nam',
    how: 'Hướng là số 0–3 nên rẽ phải là `+1`, rẽ trái là `+3`, rồi lấy dư cho 4 để quay vòng. Cùng mẹo này dùng cho kim đồng hồ (`% 12`), thứ trong tuần (`% 7`) và mọi thứ quay vòng.',
  },
});
