/* ===== Vùng 6: Phòng Thí Nghiệm ===== */
G.add(6, {
  title: 'Generics: kiểu tổng quát', sub: 'generics <T> và trait bound', tags: ['Logic', 'Toán'],
  learn: {
    intro: 'Viết hàm tìm số lớn nhất cho `i32`, rồi lại chép y hệt cho `f64`… thật phí công. **Generics** cho phép viết một lần cho mọi kiểu: `T` là chỗ trống được điền kiểu thật lúc biên dịch. Rust tạo mã riêng cho từng kiểu, nên nhanh y như viết tay.',
    points: ['`fn lon_nhat<T: PartialOrd + Copy>(a: T, b: T) -> T`: phần `<T: ...>` khai báo kiểu tổng quát kèm **ràng buộc** (trait bound).', 'Ràng buộc nói rõ `T` phải làm được gì: so sánh (`PartialOrd`), sao chép (`Copy`), in ra (`Debug`)…', 'Struct cũng có generics: `struct Cap<T> { trai: T, phai: T }`.', 'Không có ràng buộc thì bạn không làm được gì với `T`, kể cả so sánh.'],
    code: 'fn lon_nhat<T: PartialOrd + Copy>(a: T, b: T) -> T {\n    if a > b { a } else { b }\n}\n\n#[derive(Debug)]\nstruct Cap<T> {\n    trai: T,\n    phai: T,\n}\n\nimpl<T: Copy> Cap<T> {\n    fn doi_cho(&self) -> Cap<T> {\n        Cap { trai: self.phai, phai: self.trai }\n    }\n}\n\nfn main() {\n    println!("{} {} {}", lon_nhat(3, 9), lon_nhat(2.5, 1.5), lon_nhat(\'a\', \'z\'));\n    let c = Cap { trai: "đông", phai: "tây" };\n    println!("{:?}", c.doi_cho());\n}',
    out: '9 2.5 z\nCap { trai: "tây", phai: "đông" }',
    note: 'Một hàm, ba kiểu: số nguyên, số thực, ký tự. Trình biên dịch kiểm tra từng lời gọi xem kiểu đó có đủ khả năng mà ràng buộc yêu cầu hay không.',
  },
  ch: {
    type: 'bug', brief: 'Hàm tìm số lớn nhất dùng kiểu `T` bất kỳ. Tìm dòng bị từ chối và chọn cách sửa.', hint: 'Rust không biết `T` có hỗ trợ dấu `>` hay không. Bạn phải nói rõ điều đó bằng một ràng buộc trait ngay trong dấu `< >`.',
    code: 'fn lon_nhat<T>(a: T, b: T) -> T {\n    if a > b { a } else { b }\n}\nfn main() {\n    println!("{}", lon_nhat(3, 9));\n}',
    bad: 1, fixAt: 0, ecode: 'E0369',
    err: 'error[E0369]: binary operation `>` cannot be applied to type `T`\n --> src/main.rs:2:10\n  |\n2 |     if a > b { a } else { b }\n  |        - ^ - T\n  |        |\n  |        T',
    fixes: ['fn lon_nhat<T: PartialOrd>(a: T, b: T) -> T {', 'fn lon_nhat<T: Copy>(a: T, b: T) -> T {', 'fn lon_nhat<T: Display>(a: T, b: T) -> T {', 'fn lon_nhat(a: T, b: T) -> T {'], fix: 0,
    why: '`T` là kiểu bất kỳ nên Rust chưa biết nó so sánh được hay không. Ràng buộc `T: PartialOrd` hứa rằng mọi kiểu được truyền vào đều có phép so sánh `>`.',
  },
  trick: {
    name: 'Lớn nhất của mọi dãy', why: 'Một hàm tìm giá trị lớn nhất dùng cho số nguyên, số thực hay ký tự.',
    pre: [], post: [],
    lines: ['fn lon_nhat<T: PartialOrd + Copy>(xs: &[T]) -> T {', 'let mut m = xs[0];', 'for &x in xs {', 'if x > m { m = x; }', '}', 'm', '}', 'fn main() {', 'println!("{} {}", lon_nhat(&[4, 9, 2]), lon_nhat(&[1.5, 0.5]));', '}'],
    out: '9 1.5',
    how: '`&[T]` nhận mọi lát cắt của kiểu `T` so sánh được. `for &x in xs` bóc tham chiếu ra thành giá trị nhờ ràng buộc `Copy`. Cùng một hàm chạy cho `i32` lẫn `f64`.',
  },
});

G.add(6, {
  title: 'Trait: hợp đồng hành vi', sub: 'trait, impl Trait và đa hình', tags: ['Logic', 'Không gian'],
  learn: {
    intro: '**Trait** là một bản hợp đồng: “ai muốn gia nhập thì phải làm được những việc này”. Nhiều kiểu khác nhau cùng ký hợp đồng thì ta đối xử với chúng như nhau: đó là đa hình. Rust dùng trait ở chỗ các ngôn ngữ khác dùng kế thừa.',
    points: ['`trait Hinh { fn dien_tich(&self) -> f64; }` khai báo hợp đồng.', '`impl Hinh for Vuong { ... }` nghĩa là kiểu `Vuong` thực hiện hợp đồng.', 'Trait có thể có phương thức mặc định; mỗi kiểu dùng lại hoặc ghi đè.', '`&impl Hinh` hay `&dyn Hinh` nhận mọi kiểu thực hiện `Hinh`. (`Box` ở dưới là một chiếc hộp trên heap, vùng 7 sẽ học.)'],
    code: 'trait Hinh {\n    fn dien_tich(&self) -> f64;\n    fn mo_ta(&self) -> String {\n        format!("hình có diện tích {}", self.dien_tich())\n    }\n}\n\nstruct Vuong(f64);\nstruct ChuNhat(f64, f64);\n\nimpl Hinh for Vuong {\n    fn dien_tich(&self) -> f64 {\n        self.0 * self.0\n    }\n}\n\nimpl Hinh for ChuNhat {\n    fn dien_tich(&self) -> f64 {\n        self.0 * self.1\n    }\n    fn mo_ta(&self) -> String {\n        format!("chữ nhật {} x {}", self.0, self.1)\n    }\n}\n\nfn main() {\n    let ds: Vec<Box<dyn Hinh>> = vec![Box::new(Vuong(3.0)), Box::new(ChuNhat(2.0, 5.0))];\n    for h in &ds {\n        println!("{}", h.mo_ta());\n    }\n}',
    out: 'hình có diện tích 9\nchữ nhật 2 x 5',
    note: '`mo_ta` có sẵn trong hợp đồng: `ChuNhat` ghi đè còn `Vuong` dùng bản mặc định. Hai kiểu khác hẳn nhau nhưng cùng đứng chung trong một `Vec`.',
  },
  ch: {
    type: 'order', brief: 'Xếp các mảnh code thành chương trình: một trait `Keu`, kiểu `Meo` thực hiện nó, rồi gọi phương thức. Có một mảnh thừa bị viết ngược hợp đồng.',
    hint: 'Thứ tự: khai báo `trait`, khai báo `struct`, rồi `impl Trait for Kieu`, cuối cùng là `main`. Mảnh `impl Meo for Keu` bị viết ngược: phải là `impl Keu for Meo`.',
    lines: ['trait Keu {', 'fn tieng(&self) -> String;', '}', 'struct Meo;', 'impl Keu for Meo {', 'fn tieng(&self) -> String {', '"meo".to_string()', '}', '}', 'fn main() {', 'println!("{}", Meo.tieng());', '}'],
    decoys: ['impl Meo for Keu {'], out: 'meo', btn: 'Biên dịch và chạy',
  },
  trick: {
    name: 'Nhận mọi thứ biết “kêu”', why: 'Viết một hàm dùng được cho mọi kiểu thực hiện cùng một trait.',
    pre: [], post: [],
    lines: ['trait Keu { fn tieng(&self) -> String; }', 'struct Cho;', 'struct Ga;', 'impl Keu for Cho { fn tieng(&self) -> String { "gâu".to_string() } }', 'impl Keu for Ga { fn tieng(&self) -> String { "ò ó o".to_string() } }', 'fn vang(x: &impl Keu) -> String { format!("{0} {0}", x.tieng()) }', 'fn main() {', 'println!("{} / {}", vang(&Cho), vang(&Ga));', '}'],
    out: 'gâu gâu / ò ó o ò ó o',
    how: '`&impl Keu` nghĩa là “tham chiếu tới bất kỳ kiểu nào thực hiện `Keu`”. Trình biên dịch tạo mã riêng cho từng kiểu nên không tốn thêm chi phí lúc chạy.',
  },
});

G.add(6, {
  title: 'Lifetime: tuổi thọ tham chiếu', sub: "lifetime 'a và quan hệ giữa các tham chiếu", tags: ['Không gian', 'Logic'],
  learn: {
    intro: 'Tham chiếu là một **sợi dây** nối tới dữ liệu của người khác. Sợi dây không được sống lâu hơn dữ liệu, nếu không nó sẽ trỏ vào khoảng không. Rust đo **tuổi thọ** (lifetime) của từng tham chiếu để chặn lỗi đó ngay lúc biên dịch.',
    points: ["Phần lớn thời gian trình biên dịch tự suy ra tuổi thọ. Bạn chỉ ghi `'a` khi nó không chắc chắn.", "`fn dai_hon<'a>(x: &'a str, y: &'a str) -> &'a str`: kết quả sống không lâu hơn **cả hai** đầu vào.", "Nhãn `'a` không kéo dài tuổi thọ của ai cả. Nó chỉ **mô tả** mối quan hệ giữa các tham chiếu.", "`'static` là tuổi thọ suốt chương trình, ví dụ mọi chuỗi viết sẵn như `\"xin chào\"`."],
    code: "fn dai_hon<'a>(x: &'a str, y: &'a str) -> &'a str {\n    if x.len() >= y.len() { x } else { y }\n}\n\nfn main() {\n    let a = String::from(\"hello\");\n    let ket_qua;\n    {\n        let b = String::from(\"rust-lang\");\n        ket_qua = dai_hon(&a, &b).to_string();\n    }\n    println!(\"{ket_qua}\");\n}",
    out: 'rust-lang',
    note: "Hãy hình dung mỗi tham chiếu là một sợi dây có hạn sử dụng. `'a` ghi chú: “sợi dây kết quả hết hạn cùng lúc với sợi ngắn nhất trong hai sợi đầu vào”. Ở trên ta `.to_string()` ngay trong khối để kết quả không còn mượn từ `b`.",
  },
  ch: {
    type: 'bug', brief: 'Hàm nhận hai tham chiếu và trả về một tham chiếu. Tìm dòng bị từ chối và chọn cách sửa.', hint: 'Có hai tham chiếu vào và một tham chiếu ra, Rust không biết kết quả mượn từ cái nào. Hãy đặt tên cho tuổi thọ bằng `<\'a>`.',
    code: 'fn dai_hon(x: &str, y: &str) -> &str {\n    if x.len() >= y.len() { x } else { y }\n}\nfn main() {\n    println!("{}", dai_hon("hello", "rust"));\n}',
    bad: 0, fixAt: 0, ecode: 'E0106',
    err: "error[E0106]: missing lifetime specifier\n --> src/main.rs:1:33\n  |\n1 | fn dai_hon(x: &str, y: &str) -> &str {\n  |               ----     ----     ^ expected named lifetime parameter\n  |\n  = help: this function's return type contains a borrowed value, but the signature does not say whether it is borrowed from `x` or `y`",
    fixes: ["fn dai_hon<'a>(x: &'a str, y: &'a str) -> &'a str {", "fn dai_hon(x: &str, y: &str) -> &'static str {", 'fn dai_hon(x: &str, y: &str) -> str {', "fn dai_hon<'a>(x: &'a str, y: &str) -> &'a str {"], fix: 0,
    why: "Kết quả có thể mượn từ `x` hoặc `y`, nên trình biên dịch cần biết nó sống bao lâu. Gắn cùng nhãn `'a` cho cả hai đầu vào và cho kết quả: kết quả không sống lâu hơn cả hai.",
  },
  trick: {
    name: 'Cắt từ đầu tiên không sao chép', why: 'Trả về một lát cắt mượn thẳng từ đầu vào, không cấp phát thêm bộ nhớ.',
    pre: [], post: [],
    lines: ['fn tu_dau(s: &str) -> &str {', "match s.find(' ') {", 'Some(i) => &s[..i],', 'None => s,', '}', '}', 'fn main() {', 'println!("[{}] [{}]", tu_dau("xin chào bạn"), tu_dau("Rust"));', '}'],
    out: '[xin] [Rust]',
    how: "Chỉ có một tham chiếu đầu vào nên Rust tự suy ra kết quả mượn từ `s`, không cần ghi `'a`. Đây là quy tắc **lược bớt** (elision) giúp phần lớn hàm khỏi phải ghi tuổi thọ.",
  },
});

G.add(6, {
  title: 'Closure: hàm vô danh', sub: 'closure |x|, Fn, FnMut và move', tags: ['Logic', 'Toán'],
  learn: {
    intro: '**Closure** là hàm không tên có thể **bắt** các biến xung quanh. Viết `|x| x + n` ở bất cứ đâu cần một hành vi nhỏ, và nó nhớ giá trị `n` ở nơi nó được tạo.',
    points: ['Cú pháp: `|tham_so| biểu_thức` hoặc `|a, b| { nhiều dòng }`.', 'Closure tự đoán kiểu tham số từ cách dùng. Có thể gán vào biến: `let nhan_doi = |x| x * 2;`.', 'Bắt biến theo ba cách: mượn (`Fn`), mượn có thể sửa (`FnMut`), hoặc lấy hẳn (`FnOnce`, dùng `move`).', 'Hàm nhận closure khai báo bằng trait: `fn lap<F: Fn(i32) -> i32>(f: F, x: i32) -> i32`.'],
    code: 'fn ap_dung<F: Fn(i32) -> i32>(f: F, x: i32) -> i32 {\n    f(x)\n}\n\nfn main() {\n    let nhan_doi = |x| x * 2;\n    let n = 10;\n    let cong_n = |x| x + n;\n    println!("{} {}", ap_dung(nhan_doi, 7), ap_dung(cong_n, 7));\n\n    let mut dem = 0;\n    let mut tang = || {\n        dem += 1;\n        dem\n    };\n    tang();\n    tang();\n    println!("{}", tang());\n}',
    out: '14 17\n3',
    note: 'Closure là nền của iterator ở vùng sau: `.map(|x| x * 2)`, `.filter(|x| x % 2 == 0)`.',
  },
  ch: {
    type: 'quiz', brief: 'Bốn câu về closure. Hai câu đầu cần đoán kết quả chạy.', hint: 'Closure ghi nhớ các biến xung quanh ở lúc nó được tạo. `move` chuyển hẳn các biến đó vào bên trong closure.',
    qs: [
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let n = 5;\n    let cong = |x| x + n;\n    println!("{}", cong(3));\n}', run: true, opts: ['8', '3', '5', 'Lỗi biên dịch'], ans: 0, why: 'Closure bắt biến `n` ở ngoài (= 5) và cộng với đối số 3.' },
      { q: 'Chương trình này in ra gì?', code: 'fn main() {\n    let mut tong = 0;\n    let mut them = |x| tong += x;\n    them(4);\n    them(6);\n    println!("{}", tong);\n}', run: true, opts: ['10', '0', '4', 'Lỗi biên dịch vì `tong` đang bị mượn'], ans: 0, why: 'Closure mượn `tong` để sửa (FnMut). Sau lần gọi cuối, closure không còn được dùng nên `tong` được trả lại và in ra 10.' },
      { q: 'Từ khóa `move` đặt trước closure có tác dụng gì?', opts: ['Chuyển quyền sở hữu các biến bắt được vào bên trong closure', 'Làm closure chạy nhanh hơn', 'Cho phép closure sửa mọi biến', 'Biến closure thành một hàm thường'], ans: 0, why: '`move` đưa các biến vào trong closure, để closure sống độc lập, ví dụ khi trả về từ hàm hay chạy ở luồng khác.' },
      { q: 'Trait nào dành cho closure chỉ **đọc** các biến bắt được và có thể gọi nhiều lần?', opts: ['Fn', 'FnMut', 'FnOnce', 'Copy'], ans: 0, why: '`Fn` chỉ mượn để đọc. `FnMut` mượn để sửa, còn `FnOnce` lấy hẳn quyền sở hữu nên chỉ gọi được một lần.' },
    ],
  },
  trick: {
    name: 'Hàm sản xuất ra hàm', why: 'Tạo ra các hàm tùy biến từ một tham số, ví dụ “cộng thêm n” với n tùy ý.',
    pre: [], post: [],
    lines: ['fn tao_bo_cong(n: i32) -> impl Fn(i32) -> i32 {', 'move |x| x + n', '}', 'fn main() {', 'let cong5 = tao_bo_cong(5);', 'let cong100 = tao_bo_cong(100);', 'println!("{} {}", cong5(1), cong100(1));', '}'],
    out: '6 101',
    how: '`move` mang giá trị `n` vào closure để nó vẫn sống sau khi hàm kết thúc. `impl Fn(i32) -> i32` nghĩa là “một thứ gọi được, nhận `i32` và trả `i32`”. Mỗi lần gọi `tao_bo_cong` cho ra một hàm riêng.',
  },
});
