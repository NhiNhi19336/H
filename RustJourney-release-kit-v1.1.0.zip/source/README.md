# Source

```
node tools/build.js          # dist/index.html (bản xem thử / artifact)
node tools/test.js --full   # biên dịch mọi đoạn Rust bằng rustc thật và giải mọi thử thách
node tools/make-assets.js   # tạo lại biểu tượng, splash, ảnh cửa hàng (cần Playwright)
node tools/release.js       # tạo lại gói phát hành
```

Thêm ngôn ngữ mới: xem `tools/TRANSLATING.md`.
