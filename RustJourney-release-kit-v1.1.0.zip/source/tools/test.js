/* Kiểm thử: cấu trúc bài, lời giải mọi thử thách, và biên dịch THẬT mọi đoạn Rust trong game bằng rustc */
const fs = require('fs'), path = require('path'), vm = require('vm'), cp = require('child_process'), os = require('os');
const root = path.join(__dirname, '..'), FULL = process.argv.includes('--full'), NORUST = process.argv.includes('--no-rust');
const arg = k => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : null; };
const LANG = arg('--lang'), ONLY = arg('--only') ? arg('--only').split(',') : null, COUNT = +(arg('--count') || 32);
const noop = () => { };
const el = () => ({ style: {}, classList: { add: noop, remove: noop, toggle: noop }, setAttribute: noop, appendChild: noop, addEventListener: noop, remove: noop, innerHTML: '', dataset: {} });
const ctx = vm.createContext({ console, setTimeout, clearTimeout, document: { addEventListener: noop, createElement: el, body: el(), documentElement: el(), querySelector: () => null, querySelectorAll: () => [] }, window: { scrollTo: noop, addEventListener: noop }, localStorage: { getItem: () => null, setItem: noop }, matchMedia: () => ({ matches: true }), innerWidth: 400, innerHeight: 800, requestAnimationFrame: noop, navigator: {} });
vm.runInContext(require('./bundle').bundle().js + '\nG.finalize();', ctx);
const G = vm.runInContext('G', ctx), trickCode = vm.runInContext('trickCode', ctx);
const errs = [], bad = (L, m) => errs.push(`[${L.lang}] bài ${L.n} (${L.title}): ${m}`);
const jobs = [];
const norm = s => String(s).replace(/\r/g, '').split('\n').map(l => l.trimEnd()).join('\n').trimEnd();

/* ---- biên dịch Rust ---- */
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rg-')); let jid = 0;
const rust = src => new Promise(res => {
  const id = 'j' + jid++, f = path.join(tmp, id + '.rs'), bin = path.join(tmp, id); fs.writeFileSync(f, src);
  cp.execFile('rustc', ['--edition', '2021', '-A', 'warnings', '-o', bin, f], { timeout: 90000 }, (e, so, se) => {
    if (e) return res({ ok: false, stderr: se || String(e) });
    cp.execFile(bin, [], { timeout: 10000 }, (e2, out, se2) => res({ ok: !e2, stdout: out, stderr: se2 }));
  });
});
const expectRun = (L, what, src, out) => jobs.push(() => rust(src).then(r => { if (!r.ok) bad(L, `${what}: không biên dịch/chạy được\n${(r.stderr || '').split('\n').slice(0, 8).join('\n')}`); else if (norm(r.stdout) !== norm(out)) bad(L, `${what}: kết quả sai.\n  khai báo: ${JSON.stringify(norm(out))}\n  thực tế : ${JSON.stringify(norm(r.stdout))}`); }));
const expectFail = (L, what, src, code) => jobs.push(() => rust(src).then(r => { if (r.ok) bad(L, `${what}: lẽ ra phải lỗi nhưng lại biên dịch được`); else if (code && !(r.stderr || '').includes(`error[${code}]`)) bad(L, `${what}: lỗi không phải ${code}\n${(r.stderr || '').split('\n').slice(0, 4).join('\n')}`); }));
const expectOk = (L, what, src) => jobs.push(() => rust(src).then(r => { if (!r.ok) bad(L, `${what}: lẽ ra biên dịch được\n${(r.stderr || '').split('\n').slice(0, 8).join('\n')}`); }));

/* ---- kiểm tra từng bài ---- */
const palId = b => b.k === 'for' ? 'for' : b.k === 'while' ? 'while:' + b.c : b.k === 'if' ? (b.els ? 'ifelse:' : 'if:') + b.c : b.k === 'call' ? 'call:' + b.f : b.k;
const walk = (l, f) => l.forEach(b => { f(b); walk(b.body || [], f); walk(b.then || [], f); walk(b.els || [], f); });
const LANGS = Object.keys(G.packs).filter(k => !LANG || k === LANG); let CHECKED = 0;
LANGS.forEach(lang => { G.setLang(lang); G.all.filter(L => !ONLY || ONLY.includes('z' + L.z)).forEach(L => { CHECKED++;
  for (const k of ['title', 'sub']) if (!L[k]) bad(L, 'thiếu ' + k);
  if (!L.tags || !L.tags.length) bad(L, 'thiếu tags');
  const l = L.learn || {}, c = L.ch || {}, t = L.trick || {};
  if (!l.intro || !l.code || l.out == null || !l.points || l.points.length < 3) bad(L, 'learn thiếu trường');
  if (!c.type || !c.brief || !c.hint) bad(L, 'ch thiếu trường');
  if (!t.name || !t.why || !t.lines || t.lines.length < 3 || t.out == null || !t.how) bad(L, 'trick thiếu trường');
  if (!G.engines[c.type]) { bad(L, 'engine không tồn tại: ' + c.type); return; }
  if (l.code) expectRun(L, 'learn.code', l.code, l.out);
  if (t.lines) expectRun(L, 'trick', trickCode(L), t.out);
  const uniq = (a) => new Set(a).size === a.length;
  if (c.type === 'robot') {
    const sol = G.robot.parseProg(c.sol || ''), pre = c.pre ? G.robot.parseProg(c.pre) : { main: [], fns: {} };
    const r = G.robot.run(c, G.robot.parseProg(c.sol));
    if (!r.ok) bad(L, `robot: lời giải không thắng (${r.why})`);
    if (c.max && r.blocks > c.max) bad(L, `robot: lời giải dùng ${r.blocks} khối > max ${c.max}`);
    const empty = G.robot.run(c, { main: JSON.parse(JSON.stringify(pre.main)), fns: pre.fns });
    if (empty.ok) bad(L, 'robot: chương trình rỗng đã thắng');
    const pal = c.palette || [], need = new Set(); walk(sol.main, b => need.add(palId(b))); Object.keys(sol.fns).forEach(f => walk(sol.fns[f], b => need.add(palId(b))));
    need.forEach(id => { if (!pal.some(p => p === id || (id === 'for' && p.startsWith('for')))) { const locked = []; walk(pre.main, b => locked.push(palId(b))); if (!locked.includes(id)) bad(L, `robot: lời giải cần khối "${id}" nhưng palette không có`); } });
    if (c.max) { const worse = G.robot.run(c, G.robot.parseProg(c.sol)); if (!(worse.blocks <= c.max)) bad(L, 'robot: vượt max'); }
    if (c.nosol) { }
  } else if (c.type === 'quiz') {
    c.qs.forEach((q, i) => {
      if (q.ans == null || q.ans >= q.opts.length) bad(L, `quiz câu ${i + 1}: ans sai`);
      if (q.opts.length < 3 || !uniq(q.opts)) bad(L, `quiz câu ${i + 1}: cần ≥3 đáp án khác nhau`);
      if (!q.why) bad(L, `quiz câu ${i + 1}: thiếu why`);
      if (q.run) expectRun(L, `quiz câu ${i + 1}`, q.code, q.opts[q.ans].replace(/`/g, ''));
    });
  } else if (c.type === 'order') {
    if (c.lines.length < 3) bad(L, 'order: ít dòng'); if (c.out != null) expectRun(L, 'order', G.fmt([].concat(c.pre || [], c.lines, c.post || [])).join('\n'), c.out);
  } else if (c.type === 'bug') {
    const lines = c.code.replace(/\n$/, '').split('\n'), at = c.fixAt == null ? c.bad : c.fixAt;
    if (c.bad >= lines.length || at >= lines.length) bad(L, 'bug: chỉ số dòng sai');
    expectFail(L, 'bug gốc', c.code, c.ecode);
    c.fixes.forEach((f, i) => { const src = lines.map((x, j) => (j === at ? f : x)).join('\n'); if (i === c.fix) expectOk(L, 'bug sửa đúng', src); else expectFail(L, `bug sửa sai #${i}`, src); });
    if (c.fixes.length < 3) bad(L, 'bug: cần ≥3 cách sửa');
  } else if (c.type === 'logic') {
    c.rounds.forEach((R, i) => { const rows = G.engines.logic.rows(R); const n = rows.filter(r => r.r === R.want).length; if (!n || n === rows.length) bad(L, `logic vòng ${i + 1}: số hàng đúng không hợp lệ (${n}/${rows.length})`); });
  } else if (c.type === 'cells') {
    c.rounds.forEach((R, i) => { const n = R.vals.length; const a = [].concat(R.ans); if (a.some(x => x < 0 || x >= n)) bad(L, `cells vòng ${i + 1}: ans ngoài lưới`); if (R.kind === 'range' && !(R.ans[0] <= R.ans[1])) bad(L, `cells ${i + 1}: range sai`); });
  } else if (c.type === 'bits') {
    c.rounds.forEach((R, i) => { if (R.mode === 'ops') { const s = G.engines.bits.solve(R); if (!s) bad(L, `bits vòng ${i + 1}: không giải được trong ${R.max} lượt`); else if (s.length < 2) bad(L, `bits vòng ${i + 1}: quá dễ`); } else if (R.target < 0 || R.target > 255) bad(L, 'bits: target sai'); });
  } else if (c.type === 'cipher') {
    c.rounds.forEach((R, i) => {
      const P = G.cipher.prep(R); if (G.cipher.dec(R, P.cipher, P.key) !== R.plain) bad(L, `cipher ${i + 1}: khóa đúng không giải ra bản rõ`);
      const k0 = R.kind === 'forms' ? R.forms[0] : 0; if (G.cipher.dec(R, P.cipher, k0) === R.plain) bad(L, `cipher ${i + 1}: núm khởi đầu đã đúng sẵn`);
      if (R.kind === 'forms' && !R.forms.includes(R.use)) bad(L, `cipher ${i + 1}: forms thiếu ${R.use}`);
    });
  }
}); });
/* ---- so khớp cấu trúc giữa các gói ngôn ngữ (cùng một trò chơi, chỉ khác chữ) ---- */
function parity() {
  const A = G.packs.vi, B = G.packs.en; if (!A || !B || LANG) return;
  const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  if (!ONLY && A.all.length !== B.all.length) errs.push(`[parity] số bài khác nhau: vi ${A.all.length}, en ${B.all.length}`);
  A.zones.forEach((z, i) => { if (!ONLY && B.zones[i] && B.zones[i].lessons.length !== z.lessons.length) errs.push(`[parity] vùng ${z.id}: vi ${z.lessons.length} bài, en ${B.zones[i].lessons.length} bài`); });
  A.all.forEach(a => {
    const b = B.all[a.n - 1]; if (!b || (ONLY && !ONLY.includes('z' + a.z))) return;
    const bd = m => errs.push(`[parity] bài ${a.n} (${a.title}): ${m}`), x = a.ch, y = b.ch;
    if (x.type !== y.type) return bd(`kiểu thử thách vi=${x.type} en=${y.type}`);
    if (x.type === 'robot') ['grid', 'dir', 'pre', 'sol', 'max', 'par', 'palette', 'fns', 'cursor', 'need', 'nosol'].forEach(k => { if (!eq(x[k], y[k])) bd(`robot.${k} khác nhau`); });
    else if (x.type === 'quiz') { if (x.qs.length !== y.qs.length) bd('số câu quiz khác nhau'); else x.qs.forEach((q, i) => { const r = y.qs[i]; if (q.ans !== r.ans || q.opts.length !== r.opts.length || !!q.run !== !!r.run) bd(`quiz câu ${i + 1}: ans/số đáp án/run khác nhau`); }); }
    else if (x.type === 'bug') { ['bad', 'fixAt', 'fix', 'ecode'].forEach(k => { if (x[k] !== y[k]) bd(`bug.${k} khác nhau`); }); if (x.fixes.length !== y.fixes.length) bd('số cách sửa khác nhau'); if (x.code.split('\n').length !== y.code.split('\n').length) bd('số dòng code khác nhau'); }
    else if (x.type === 'order') { if (x.lines.length !== y.lines.length || (x.decoys || []).length !== (y.decoys || []).length) bd('số mảnh ghép/mảnh thừa khác nhau'); }
    else if (x.type === 'cells') { if (x.rounds.length !== y.rounds.length) bd('số vòng cells khác nhau'); else x.rounds.forEach((r, i) => { const q = y.rounds[i]; if (!eq(r.ans, q.ans) || r.vals.length !== q.vals.length || r.kind !== q.kind) bd(`cells vòng ${i + 1}: ans/vals/kind khác nhau`); }); }
    else if (x.type === 'bits') { if (x.rounds.length !== y.rounds.length) bd('số vòng bits khác nhau'); else x.rounds.forEach((r, i) => { const q = y.rounds[i]; ['mode', 'start', 'target', 'max', 'palette'].forEach(k => { if (!eq(r[k], q[k])) bd(`bits vòng ${i + 1}: ${k} khác nhau`); }); }); }
    else if (x.type === 'logic' || x.type === 'cipher') { if (x.rounds.length !== y.rounds.length) bd('số vòng khác nhau'); else if (x.type === 'cipher') x.rounds.forEach((r, i) => { if (r.kind !== y.rounds[i].kind) bd(`cipher vòng ${i + 1}: kind khác nhau`); }); }
  });
}
parity();
if (FULL) {
  Object.keys(G.packs).filter(k => !LANG || k === LANG).forEach(k => {
    const p = G.packs[k]; if (p.all.length !== COUNT) errs.push(`[${k}] cần đúng ${COUNT} bài, hiện có ${p.all.length}`);
    p.zones.forEach(z => { if (!z.lessons.length) errs.push(`[${k}] vùng ${z.id} trống`); });
    const types = new Set(p.all.map(L => L.ch.type)); console.log(`[${k}] ${p.all.length} bài, ${p.zones.map(z => z.lessons.length).join('/')} bài mỗi vùng; engine đã dùng: ${[...types].join(', ')}`);
  });
}

/* ---- chạy hàng đợi biên dịch (4 luồng) ---- */
(async () => {
  if (!NORUST) { let i = 0; const worker = async () => { while (i < jobs.length) { const j = jobs[i++]; await j(); } }; await Promise.all([1, 2, 3, 4].map(worker)); }
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`${CHECKED} bài (${LANGS.join('+')}), ${NORUST ? 0 : jobs.length} lần biên dịch Rust, ${errs.length} lỗi`);
  errs.forEach(e => console.log(' ✗ ' + e)); process.exit(errs.length ? 1 : 0);
})();
