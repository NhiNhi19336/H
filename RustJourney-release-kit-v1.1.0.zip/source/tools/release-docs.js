/* Tài liệu trong gói phát hành: README, mô tả cửa hàng, chính sách riêng tư */
const path = require('path'), fs = require('fs');
const brand = (() => { try { return new Function(fs.readFileSync(path.join(__dirname, '..', 'src', 'brand.js'), 'utf8') + '; return BRAND;')(); } catch (e) { return { owner: 'Chillvibes', year: 2026, code: 'MIT', content: 'CC BY 4.0' }; } })();
const MIT = b => `MIT License

Copyright (c) ${b.year} ${b.owner}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Scope: the source code of the game (src/, tools/). The lesson text is under
CONTENT-LICENSE.md. The name "Hành Trình Rust / Rust Journey", the icon, the intro and
the store graphics are NOT covered by this license (all rights reserved).
`;
exports.write = (kit, V, write, hasEN) => {
  write(path.join(kit, 'LICENSE'), MIT(brand));
  write(path.join(kit, 'CONTENT-LICENSE.md'), `# Content license / Giấy phép nội dung

Lesson text, quiz questions, hints, trick descriptions, Rust code samples written for the lessons, and the translations
(Vietnamese and English) are © ${brand.year} ${brand.owner}, licensed under **Creative Commons Attribution 4.0 International (${brand.content})**.

- Full text: <https://creativecommons.org/licenses/by/4.0/legalcode>
- Summary: you may share and adapt the material, even commercially, **as long as you give credit, link to the license and say if you changed it.**
- Suggested credit: "Hành Trình Rust · Rust Journey by ${brand.owner}, CC BY 4.0".

Không bao gồm: tên "Hành Trình Rust / Rust Journey", biểu tượng, intro (hình và giọng) và ảnh cửa hàng, những thứ này được bảo lưu mọi quyền.
Câu danh ngôn là trích dẫn ngắn có ghi tác giả; tục ngữ thuộc về cộng đồng.
`);
  write(path.join(kit, 'NOTICE.md'), `# NOTICE

**Hành Trình Rust · Rust Journey** v${V}, © ${brand.year} ${brand.owner}.

- Source code: ${brand.code} (\`LICENSE\`). Lesson content: ${brand.content} (\`CONTENT-LICENSE.md\`).
- Name, icon, intro animation and voice, store graphics: all rights reserved by ${brand.owner}.
- The intro pack (animation script and voice track) was supplied by the project owner and is shipped unchanged except that the text can be switched by language.
- "Rust" and the Rust logo are trademarks of the Rust Foundation. This is an unofficial learning project, not affiliated with or endorsed by the Rust Foundation. The icon is an original hexagon, not the Rust logo.
- No third-party libraries, fonts or images are bundled in the release build (system fonts are used, no network calls). Links to doc.rust-lang.org and play.rust-lang.org open only when the user taps them.
- Every Rust sample in the lessons was compiled with rustc ${'1.97'} (edition 2021) while the game was built.
`);
  write(path.join(kit, 'README.md'), `# Hành Trình Rust — bộ phát hành v${V}

Game tự học Rust từ cơ bản đến bậc thầy: 32 bài, mỗi bài có phần học, thử thách (không gian, toán, logic, mật mã) và xưởng ráp đoạn code mẹo.
Ngôn ngữ trong game: ${hasEN ? 'Tiếng Việt và English (nút chọn ngôn ngữ ở màn hình chính và trong Cài đặt)' : 'Tiếng Việt (bản English đang được thêm)'}.

> Lưu ý thật thà: gói này đã được kiểm thử phần game (mọi đoạn Rust đều biên dịch thật bằng rustc, mọi thử thách đều giải được),
> nhưng **chưa được build ra .apk/.aab** vì môi trường tạo gói không có Android SDK và không có mạng. Các bước bên dưới theo tài liệu của PWABuilder và Capacitor.

## Trong gói có gì

| Thư mục | Dùng để |
|---|---|
| \`web/\` | Ứng dụng web hoàn chỉnh (PWA, chạy offline, không gọi mạng). Gốc có \`index.html\`: tải lên hosting HTTPS hoặc nén lại để đưa vào công cụ chuyển đổi |
| \`android-capacitor/\` | Cấu hình Capacitor sẵn: \`www/\` (bản web), \`assets/\` (icon và splash), \`res-extra/\` (tên app tiếng Việt) |
| \`store/\` | Mô tả cửa hàng (VI${hasEN ? '/EN' : ''}), chính sách riêng tư mẫu, icon 512, ảnh feature graphic, ảnh chụp màn hình |
| \`source/\` | Mã nguồn đầy đủ + công cụ kiểm thử và đóng gói |

## Cách A: PWABuilder (dễ nhất, không cần cài gì)

1. Đưa thư mục \`web/\` lên một hosting tĩnh có HTTPS (miễn phí: Netlify Drop kéo thả, Cloudflare Pages, GitHub Pages, Vercel).
2. Vào <https://www.pwabuilder.com>, dán địa chỉ trang, bấm Start. Manifest và service worker phải báo đạt.
3. Chọn **Package for stores → Android**. Đặt Package ID (ví dụ \`vn.hanhtrinhrust.app\`), version \`${V}\` (version code 1), chọn tạo khóa ký mới.
4. Tải về: file **.aab** (đưa lên Google Play), file **.apk** (cài thử trực tiếp) và **signing.keystore** cùng file thông tin khóa. **Sao lưu keystore và mật khẩu**, mất là không cập nhật app được.
5. Để app chạy toàn màn hình không có thanh địa chỉ, đặt file \`assetlinks.json\` mà PWABuilder đưa vào đường dẫn \`/.well-known/assetlinks.json\` trên hosting rồi build lại nếu cần.

## Cách B: Capacitor + Android Studio (không cần hosting)

Cần: Node.js LTS, Android Studio bản mới nhất (kèm JDK), có mạng khi chạy \`npm\`.

\`\`\`
cd android-capacitor
npm install
npx cap add android
npm run assets          # sinh icon thích ứng và splash từ thư mục assets/
npx cap sync android
npx cap open android    # mở Android Studio
\`\`\`

Trong Android Studio: **Build → Generate Signed App Bundle / APK**. Chọn *Android App Bundle* (.aab) để lên Google Play, hoặc *APK* để cài trực tiếp. Tạo keystore mới ở bước này và sao lưu cẩn thận.
Muốn tên app hiện tiếng Việt trên máy tiếng Việt: chép \`res-extra/values-vi\` vào \`android/app/src/main/res/\` sau khi chạy \`npx cap add android\`.
Tăng \`versionCode\` và \`versionName\` trong \`android/app/build.gradle\` cho mỗi lần phát hành mới.

## Lên Google Play

- Cần tài khoản nhà phát triển Google Play (có phí đăng ký một lần). Tài khoản cá nhân mới thường phải chạy thử nghiệm kín với một số người thử trong vài tuần trước khi phát hành chính thức: hãy kiểm tra yêu cầu hiện hành trong Play Console.
- Dùng nội dung trong \`store/\`: mô tả, icon 512, feature graphic, ảnh chụp màn hình.
- **Chính sách riêng tư**: Play yêu cầu một đường dẫn. Đăng nội dung \`store/privacy-policy.md\` lên một trang web (điền email liên hệ).
- Mục An toàn dữ liệu: game không thu thập và không chia sẻ dữ liệu. Phân loại nội dung: phù hợp mọi lứa tuổi, không quảng cáo, không mua trong ứng dụng.
- Nhắm API mới nhất mà Play yêu cầu tại thời điểm phát hành: bản mới nhất của PWABuilder và Capacitor đã tự cập nhật.

## Cập nhật nội dung sau này

\`\`\`
node tools/build.js && node tools/test.js --full   # kiểm tra mọi bài bằng rustc thật
node tools/release.js                              # tạo lại gói trong release/
\`\`\`

Tiến độ người chơi lưu trong máy (localStorage) và có "mã lưu" để chuyển máy. Đổi số phiên bản trong \`src/app.js\` (\`VERSION\`).

## Giấy phép và bản quyền (mặc định mình đặt, đổi được)

Đây không phải tư vấn pháp lý, chỉ là lựa chọn hợp lý để bạn **vẫn là chủ** của game:

- **Mã nguồn**: MIT (file \`LICENSE\`). Ai cũng được dùng và sửa, miễn giữ dòng bản quyền của bạn.
- **Nội dung bài học, câu hỏi, mẹo**: ${brand.content} (file \`CONTENT-LICENSE.md\`). Ai cũng được chia sẻ, dịch, sửa, kể cả thương mại, nhưng **phải ghi tên bạn**.
- **Tên game, biểu tượng, intro, ảnh cửa hàng**: bảo lưu mọi quyền, để người khác không đăng lại app dưới tên của họ với đúng biểu tượng của bạn.
- Không có thư viện, phông chữ hay hình ảnh của bên thứ ba trong bản phát hành.

**Vì sao không dùng CC0?** CC0 là "tặng cho công chúng": ai cũng có thể tải app lên cửa hàng dưới tên họ, không cần ghi tên bạn, và bạn không rút lại được. Chỉ nên dùng nếu bạn thật sự muốn cho đi hoàn toàn. Muốn vậy thì thay nội dung \`CONTENT-LICENSE.md\` và chuỗi \`content\` trong \`src/brand.js\`.

Đổi tên chủ sở hữu: sửa \`src/brand.js\` (\`owner\`, \`year\`) rồi chạy \`node tools/release.js\`. Không có Node thì tìm chữ "${brand.owner}" trong \`web/index.html\`, \`LICENSE\`, \`CONTENT-LICENSE.md\`, \`NOTICE.md\` và thay tay.

## Intro, câu danh ngôn, bố cục

- **Intro 3,8 giây** (gói intro bạn đưa) phát mỗi lần mở game, chạm hoặc Esc để bỏ qua; tắt/bật và xem lại trong Cài đặt. Giọng đọc là tiếng Việt nên bản English chạy hình, không tiếng. Trình duyệt thường chặn tự phát tiếng ở lần mở đầu (intro vẫn chạy hình). Nếu app Android bị câm, kiểm tra WebView có cho phát media không cần chạm (\`mediaPlaybackRequiresUserGesture = false\`).
- **Câu danh ngôn mỗi ngày** và **chuỗi ngày học** hiện sau intro, mỗi ngày một lần (36 câu, sửa trong \`src/quotes.js\`).
- **Bố cục co giãn**: từ màn hình ngoài của điện thoại gập (~280px) tới iPad, gập mở và máy tính. Mê cung hai cột trên màn hình rộng; trên điện thoại, bảng mê cung và nút Chạy được ghim để bấm Chạy là thấy Bot chạy ngay (tắt được trong Cài đặt).
- Màu nền của app (\`background_color\`, splash) là xanh đậm của intro để màn hình chờ nối liền với intro.

## Lưu ý pháp lý

Đây là dự án học tập không chính thức, không liên kết với Rust Foundation. "Rust" là nhãn hiệu của Rust Foundation. Biểu tượng của game là hình ốc lục giác riêng, không dùng logo Rust.
Link ngoài duy nhất trong game là các liên kết học tiếp và nút chạy thử trên play.rust-lang.org; chúng chỉ mở khi người chơi bấm.

---

# English summary

**Rust Journey** v${V}: a self-study game that teaches Rust from first steps to mastery (32 lessons, mazes, math, logic and ciphers, a "trick workshop" after each lesson). ${hasEN ? 'It ships in Vietnamese and English.' : 'English is being added.'}
It has **not** been built into an .apk/.aab inside the sandbox that produced this kit (no Android SDK, no network); the steps follow the PWABuilder and Capacitor docs.

- **Fastest:** host \`web/\` on any HTTPS static host, open pwabuilder.com, Package for stores → Android, download the signed .aab/.apk and back up the keystore.
- **Without hosting:** \`cd android-capacitor && npm install && npx cap add android && npm run assets && npx cap sync android && npx cap open android\`, then Build → Generate Signed App Bundle / APK in Android Studio.
- The app makes no network requests by itself, stores progress only on the device, and works offline. See \`store/\` for listing text, a privacy-policy template and graphics.
- Unofficial project, not affiliated with the Rust Foundation; the icon does not use the Rust logo.
`);
  write(path.join(kit, 'store', 'privacy-policy.md'), `# Chính sách riêng tư / Privacy policy: Hành Trình Rust · Rust Journey

**Tiếng Việt.** Ứng dụng không thu thập, không gửi và không chia sẻ dữ liệu cá nhân. Không có tài khoản, quảng cáo hay công cụ theo dõi. Tiến độ học và cài đặt chỉ lưu trên thiết bị của bạn (bộ nhớ cục bộ của ứng dụng) và bị xóa khi bạn xóa dữ liệu ứng dụng hoặc gỡ cài đặt. Khi bạn bấm vào liên kết ngoài (ví dụ nút "Chạy thử trên Playground"), trình duyệt của bạn mở trang đó và trang đó có chính sách riêng. Liên hệ: [điền email của bạn].

**English.** The app does not collect, transmit or share personal data. There are no accounts, ads or trackers. Progress and settings are stored only on your device (the app's local storage) and are removed when you clear the app's data or uninstall it. If you tap an external link (for example "Run in the Playground"), your browser opens that site, which has its own policy. Contact: [your email].

Cập nhật / Last updated: [ngày / date]
`);
  write(path.join(kit, 'store', 'listing.vi.md'), `# Mô tả cửa hàng (Tiếng Việt)

**Tên (≤30 ký tự):** Hành Trình Rust

**Mô tả ngắn (≤80 ký tự):** Tự học Rust qua mê cung, toán và logic: 32 bài từ cơ bản đến bậc thầy.

**Mô tả đầy đủ:**

Muốn học Rust nhưng thấy khô và khó? Hành Trình Rust biến việc học thành một chuyến phiêu lưu từ dễ đến khó, để bạn tự học ở bất cứ đâu, kể cả khi không có mạng.

32 bài trong 8 vùng, đi từ "Chào Rust!" tới đa luồng, macro và trùm cuối mê cung. Mỗi bài có 3 chặng:
• Học: giải thích ngắn gọn, đoạn code mẫu và kết quả chạy.
• Thử thách: lập trình Bot đi mê cung, bắt lỗi trình biên dịch, giải mã, bật tắt bit, ghép code... dùng tư duy không gian, toán học và logic.
• Xưởng mẹo: tự tay ráp một đoạn code mẹo và cất vào Sổ mẹo để dùng lại.

Điểm nổi bật:
• Lộ trình từ dễ nhất tới khó nhất: biến, vòng lặp, hàm, sở hữu, mượn, struct, trait, lifetime, closure, iterator, Rc/RefCell, thread, macro.
• Mọi đoạn code Rust trong game đều đã được biên dịch và chạy thử bằng trình biên dịch thật.
• Có gợi ý, xem lời giải, chấm sao và điểm kinh nghiệm.
• Chạy offline, không quảng cáo, không thu thập dữ liệu, chuyển tiến độ sang máy khác bằng mã lưu.
• Chế độ sáng, tối và tự động.
• Song ngữ Việt - Anh: đổi ngôn ngữ bất cứ lúc nào trong game.
• Mỗi ngày mở app có một câu danh ngôn và chuỗi ngày học liên tiếp để giữ nhịp.
• Giao diện co giãn cho điện thoại, điện thoại gập, máy tính bảng và màn hình lớn.

Dự án học tập không chính thức, không liên kết với Rust Foundation.

**Danh mục:** Giáo dục (Education). **Gắn thẻ gợi ý:** học lập trình, Rust, giáo dục, câu đố.
`);
  if (hasEN) write(path.join(kit, 'store', 'listing.en.md'), `# Store listing (English)

**Title (≤30 chars):** Rust Journey: Learn Rust

**Short description (≤80 chars):** Learn Rust with mazes, math and logic puzzles. 32 lessons, zero to master.

**Full description:**

Want to learn Rust without the dry textbook? Rust Journey turns it into an adventure that goes from the easiest ideas to the hardest, so you can teach yourself anywhere, even offline.

32 lessons in 8 zones, from "Hello, Rust!" to threads, macros and a final maze boss. Every lesson has three steps:
• Learn: a short explanation, sample code and its real output.
• Challenge: program a Bot through a maze, hunt compiler errors, crack ciphers, flip bits, assemble code... using spatial thinking, math and logic.
• Trick Workshop: build a handy code trick yourself and keep it in your Trick Book.

Highlights:
• A path from the easiest to the hardest topics: variables, loops, functions, ownership, borrowing, structs, traits, lifetimes, closures, iterators, Rc/RefCell, threads, macros.
• Every Rust snippet in the game was compiled and run with the real compiler.
• Hints, solutions, star ratings and XP.
• Works offline, no ads, no data collection, and a save code to move your progress between devices.
• Light, dark and automatic themes.
• Bilingual (English and Vietnamese): switch language any time in the game.
• A quote of the day and a learning streak when you open the app, to keep you going.
• A layout that adapts to phones, foldables, tablets and big screens.

An unofficial learning project, not affiliated with the Rust Foundation.

**Category:** Education. **Suggested tags:** learn to code, Rust, programming, puzzles.
`);
};
