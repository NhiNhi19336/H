/* Gộp mã nguồn thành dist/game.js (để kiểm thử) và dist/index.html (để đăng) */
const fs = require('fs'), path = require('path'), { bundle, R, root } = require('./bundle');
const { files, js } = bundle(), full = js + 'init();\n';
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist', 'game.js'), js);
const html = R('shell.html').replace('/*CSS*/', () => R('style.css')).replace('/*JS*/', () => full.replace(/<\/script>/g, '<\\/script>'));
fs.writeFileSync(path.join(root, 'dist', 'index.html'), html);
console.log('build ok:', files.length, 'files,', (html.length / 1024).toFixed(1), 'KB');
