/* Gộp mã nguồn: dùng chung cho build.js (đăng) và test.js (kiểm thử trong bộ nhớ, không đụng dist/) */
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), src = p => path.join(root, 'src', p), R = p => fs.readFileSync(src(p), 'utf8');
function lessonFiles() {
  const out = [];
  fs.readdirSync(src('lessons')).sort().forEach(lang => {
    if (!fs.statSync(src('lessons/' + lang)).isDirectory()) return;
    fs.readdirSync(src('lessons/' + lang)).filter(f => f.endsWith('.js')).sort().forEach(f => out.push(`lessons/${lang}/${f}`));
  });
  return out;
}
/* mỗi file zN.js được bọc trong một khối { } để const cấp cao của vi/en không đụng tên nhau */
/* giọng của intro được nhúng thẳng vào mã (base64) để chạy offline và không cần tệp rời */
const GEN = { 'intro-audio.gen': () => { const f = path.join(root, 'assets', 'intro', 'rust-intro-audio.m4a'); return fs.existsSync(f) ? `const INTRO_AUDIO = 'data:audio/mp4;base64,${fs.readFileSync(f).toString('base64')}';` : 'const INTRO_AUDIO = null;'; } };
const wrap = f => (GEN[f] ? GEN[f]() : /\/z\d+\.js$/.test(f) ? '{\n' + R(f) + '\n}' : R(f));
function bundle() {
  const files = ['core.js', 'brand.js', 'quotes.js', 'intro-audio.gen', 'intro.js', 'engines/robot.js', 'engines/quiz.js', 'engines/logic.js', 'engines/bits.js', ...lessonFiles(), 'app.js'];
  return { files, js: files.map(wrap).join('\n') + '\n' };
}
module.exports = { bundle, R, root };
