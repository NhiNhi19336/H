/* Tạo biểu tượng, ảnh splash và đồ họa cửa hàng bằng Chromium (Playwright). Chạy: node tools/make-assets.js */
const { chromium } = require('playwright'), fs = require('fs'), path = require('path');
const A = path.join(__dirname, '..', 'assets'), INK = '#2a211b', CREAM = '#fff4e2';
const hex = (cx, cy, R) => [0, 1, 2, 3, 4, 5].map(i => { const a = Math.PI / 3 * i; return `${(cx + R * Math.cos(a)).toFixed(1)},${(cy + R * Math.sin(a)).toFixed(1)}`; }).join(' ');
const defs = '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e0591a"/><stop offset="1" stop-color="#a5330a"/></linearGradient></defs>';
/* dấu hiệu: con ốc lục giác (nut) có mũi tên “đi tới” ở giữa */
const mark = (o = {}) => `<g${o.dx ? ` transform="translate(${o.dx} ${o.dy})"` : ''}>
  <polygon points="${hex(264, 266, 170)}" fill="rgba(42,18,6,.38)"/>
  <polygon points="${hex(256, 256, 170)}" fill="${CREAM}" stroke="${INK}" stroke-width="12" stroke-linejoin="round"/>
  <circle cx="256" cy="256" r="92" fill="${INK}"/>
  <path d="M236 206l60 50-60 50" fill="none" stroke="${CREAM}" stroke-width="28" stroke-linecap="round" stroke-linejoin="round"/></g>`;
const svg = (body, size) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="${size}" height="${size}">${defs}${body}</svg>`;
const full = svg(`<rect width="512" height="512" fill="url(#g)"/>${mark()}`, 512);
const rounded = svg(`<rect width="512" height="512" rx="112" fill="url(#g)"/>${mark()}`, 512);
const fg = svg(mark(), 512), bgOnly = svg('<rect width="512" height="512" fill="url(#g)"/>', 512);
const splash = dark => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="#1B271F"/></svg>`; /* chỉ một màu nền khớp intro (#1B271F): intro tự vẽ logo ngay sau đó */

async function shot(page, html, file, w, h, opaque) {
  await page.setViewportSize({ width: w, height: h });
  await page.setContent(`<style>html,body{margin:0;background:transparent}svg,div.f{display:block}</style>${html}`);
  await page.screenshot({ path: file, omitBackground: !opaque, clip: { x: 0, y: 0, width: w, height: h } });
}
const feature = (lang) => {
  const t = lang === 'vi' ? ['Hành Trình Rust', 'Tự học Rust từ cơ bản đến bậc thầy', 'Mê cung, toán, logic và 32 bài có thử thách'] : ['Rust Journey', 'Learn Rust from first steps to mastery', 'Mazes, math, logic puzzles and 32 hands-on lessons'];
  return `<div class="f" style="width:1024px;height:500px;position:relative;overflow:hidden;font-family:'DejaVu Sans',system-ui,sans-serif;background:#f6efe4"><div style="position:absolute;inset:0;background:linear-gradient(135deg,#e0591a,#a5330a);clip-path:polygon(640px 0,1024px 0,1024px 500px,500px 500px)"></div>
    <div style="position:absolute;left:46px;top:84px;width:470px"><div style="font-weight:800;font-size:56px;line-height:1.05;color:${INK};letter-spacing:-1px">${t[0]}</div>
    <div style="margin-top:18px;font-size:25px;line-height:1.3;color:#6b5e50">${t[1]}</div><div style="margin-top:16px;font-size:20px;color:#a5330a;font-weight:700">${t[2]}</div></div>
    <div style="position:absolute;right:-10px;top:30px;width:440px;height:440px">${svg(mark(), 440)}</div></div>`;
};
(async () => {
  const b = await chromium.launch(), p = await b.newPage({ deviceScaleFactor: 1 });
  const I = f => path.join(A, 'icons', f), C = f => path.join(A, 'capacitor', f), S = f => path.join(A, 'store', f);
  const at = (s, n) => s.replace('width="512" height="512"', `width="${n}" height="${n}"`);
  await shot(p, at(rounded, 192), I('icon-192.png'), 192, 192); await shot(p, at(rounded, 512), I('icon-512.png'), 512, 512);
  await shot(p, at(full, 512), I('maskable-512.png'), 512, 512, true); await shot(p, at(full, 180), I('apple-touch-icon.png'), 180, 180, true);
  await shot(p, at(rounded, 32), I('favicon-32.png'), 32, 32); fs.writeFileSync(I('favicon.svg'), rounded);
  await shot(p, at(full, 1024), C('icon-only.png'), 1024, 1024, true); await shot(p, at(fg, 1024), C('icon-foreground.png'), 1024, 1024);
  await shot(p, at(bgOnly, 1024), C('icon-background.png'), 1024, 1024, true);
  await shot(p, `<div style="width:2732px;height:2732px">${splash(false).replace('<svg ', '<svg width="2732" height="2732" ')}</div>`, C('splash.png'), 2732, 2732, true);
  await shot(p, `<div style="width:2732px;height:2732px">${splash(true).replace('<svg ', '<svg width="2732" height="2732" ')}</div>`, C('splash-dark.png'), 2732, 2732, true);
  await shot(p, at(full, 512), S('icon-512.png'), 512, 512, true);
  for (const l of ['vi', 'en']) await shot(p, feature(l), S(`feature-graphic-${l}.png`), 1024, 500, true);
  await b.close(); console.log('assets ok');
})().catch(e => { console.error(e); process.exit(1); });
