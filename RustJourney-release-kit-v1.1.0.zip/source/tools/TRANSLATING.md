# Translating the lessons (guide for translators and for adding a new language)

The game ("Hành Trình Rust" / "Rust Journey") keeps one **language pack** per language:

```
src/lessons/vi/_lang.js   zone names, ranks, blurbs      (G.defZones('vi', [...]))
src/lessons/vi/z1.js …    lessons of zone 1…8            (G.add(zone, {...}))
src/lessons/en/…          the same files in English
```

Vietnamese (`vi`) is the source. A translation is a file `src/lessons/<lang>/zN.js` that has **the same
`G.add(N, {...})` calls in the same order**, with all human-readable text translated. Lesson numbers are
shared between languages (progress is saved by lesson number), so never add, remove or reorder lessons in one pack only.

## What to translate

Everything a learner reads: `title`, `sub`, `tags`, `learn.intro/points/note`, `ch.brief/hint/why/btn`, every quiz
`q`/`opts`/`why`, bug `why`/`err`, cells/logic/bits/cipher labels and questions, `trick.name/why/how`.

Keep the `**bold**` and `` `code` `` markdown conventions. Use plain, friendly English at a B1–B2 reading level
(many readers are not native speakers): short sentences, no slang, explain jargon the first time. US spelling.
Keep the metaphors (keys for ownership, the Bot, gems, the workshop) and the playful but calm tone.

Tag vocabulary (use exactly these):
`Không gian`→`Spatial`, `Toán`→`Math`, `Logic`→`Logic`, `Mật mã`→`Ciphers`, `Toán tử`→`Operators`,
`Trình tự`→`Sequence`, `Hộp có nhãn`→`Labeled boxes`.

Glossary: Bot, gem, goal flag, challenge, trick, Trick Workshop (Xưởng mẹo), Trick Book (Sổ mẹo),
ownership, borrow, move, slice, lifetime, trait, closure, iterator, smart pointer, stack, heap.
Zone names are in `src/lessons/en/_lang.js`; reuse them when a lesson mentions a zone.
References such as "lesson 30" must keep pointing to the same lesson number.

## Rust code is translated too

English readers should see natural English code. In `learn.code`, quiz `code`, bug `code`/`fixes`, order `lines`/`decoys`
and `trick.lines`: translate **identifiers** (variables, functions, structs, enums, fields, labels), **string literals**
and **comments** (`diem`→`score`, `Xin chào`→`Hello`). Keep Rust keywords and standard-library names.
Use neutral names (Sam, Ana) instead of Vietnamese names.

Hard rules, because the engines and tests depend on them:

1. **Same line structure.** Same number of lines in the same order for every code block, so that `bad`, `fixAt`, `fix`,
   order `lines`/`decoys`, quiz `ans` and trick `lines` keep their meaning. Do not change indentation conventions.
2. **Non-text engine data stays byte-identical**: robot `grid/dir/pre/sol/palette/max/par/fns/cursor/need`;
   quiz `ans`, `run`, option order; bug `bad/fixAt/fix/ecode`; cells `ans/kind/axes/sm` and `vals` length;
   bits rounds; cipher `kind/shift/key` (only the plaintext changes: pick English words of the same length class).
3. **Outputs must be re-derived**, not guessed. If translating changes what a program prints (string lengths with and
   without diacritics, sorting order, `{:?}` of strings…), update `learn.out`, `trick.out`, `order.out` and quiz options to the
   real output, and make sure the explanation text is still true.
4. **Compiler errors are real.** For a bug lesson, compile the English code with `rustc --edition 2021` and copy the real
   diagnostic into `err`, trimmed and formatted like the Vietnamese one (same `src/main.rs` path style).
5. Every wrong `fixes` option must still fail to compile and the right one must compile (the test checks this).
6. Do not rename the exported structure (`G.add(N, {...})`) and do not touch any other file.

## Verify

```
node tools/test.js --lang en --only z3        # compiles every snippet with real rustc, solves every puzzle
node tools/test.js --only z3                  # both languages + structural parity check against vi
node tools/test.js --full                     # whole game (needs all zones)
```

`--only z3` can list several zones (`--only z3,z4`). Never run `node tools/build.js` while other people are editing
(it rewrites `dist/`); the tests build in memory and are safe to run in parallel.

## Adding another language

1. Create `src/lessons/<code>/_lang.js` with `G.defZones('<code>', [...8 zones...])` and `zN.js` files translated from `vi`.
2. Add `['<code>', 'Native name', 'XX']` to `G.LANGS` in `src/core.js` and extend `T(vi, en)` call sites
   (UI strings live in `src/app.js` and `src/engines/*.js` as `T('vi text', 'en text')`).
3. Run `node tools/test.js --full`.
