/* Đóng gói phát hành: node tools/release.js
   Tạo release/RustJourney-web-vX.zip (gốc là index.html) và release/RustJourney-release-kit-vX.zip (đủ bộ để ra .apk/.aab). */
const fs = require('fs'), path = require('path'), cp = require('child_process'), { bundle, R, root } = require('./bundle');
const VERSION = (R('app.js').match(/const VERSION = '([^']+)'/) || [0, '1.0.0'])[1];
const out = path.join(root, 'release'), A = path.join(root, 'assets');
const rm = p => fs.rmSync(p, { recursive: true, force: true }), mk = p => fs.mkdirSync(p, { recursive: true });
const copy = (a, b) => fs.cpSync(a, b, { recursive: true });
const write = (p, s) => { mk(path.dirname(p)); fs.writeFileSync(p, s); };
rm(out); mk(out);

/* ---------- 1. ứng dụng web (PWA) ---------- */
const THEME = '#bf3f0a', BG = '#1B271F';
const head = `<meta name="theme-color" content="${THEME}">
<meta name="description" content="Học Rust từ cơ bản đến bậc thầy bằng mê cung, toán và logic. Learn Rust from zero to master with mazes, math and logic.">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icons/favicon.svg" type="image/svg+xml">
<link rel="icon" href="icons/favicon-32.png" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Rust Journey">`;
const swReg = `<script>if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () { }); });</script>`;
let html = R('shell.html')
  .replace(/<!--FONTS-->[\s\S]*?<!--\/FONTS-->\n?/, '') /* bản phát hành không gọi mạng: dùng phông hệ thống */
  .replace('width=device-width, initial-scale=1"', 'width=device-width, initial-scale=1, viewport-fit=cover"')
  .replace('<!--PWA-->', head).replace('<!--SW-->', swReg)
  .replace('/*CSS*/', () => R('style.css')).replace('/*JS*/', () => (bundle().js + 'init();\n').replace(/<\/script>/g, '<\\/script>'));
const web = path.join(out, 'web');
write(path.join(web, 'index.html'), html);
write(path.join(web, 'manifest.webmanifest'), JSON.stringify({
  id: './', name: 'Hành Trình Rust · Rust Journey', short_name: 'Rust Journey',
  description: 'Tự học Rust từ cơ bản đến bậc thầy với mê cung, toán và logic. Learn Rust from zero to master.',
  lang: 'vi', dir: 'ltr', start_url: './index.html', scope: './', display: 'standalone', orientation: 'any',
  background_color: BG, theme_color: THEME, categories: ['education', 'games'],
  icons: [
    { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
  ],
}, null, 2) + '\n');
write(path.join(web, 'sw.js'), `/* Chạy offline: lưu sẵn vỏ ứng dụng, ưu tiên bản đã lưu. Đổi tên V khi phát hành bản mới. */
const V = 'rust-journey-v${VERSION}';
const CORE = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-512.png', 'icons/favicon.svg', 'icons/favicon-32.png', 'icons/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request; if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
  e.respondWith(caches.match(r, { ignoreSearch: true }).then(hit => hit || fetch(r).then(res => { const k = res.clone(); caches.open(V).then(c => c.put(r, k)); return res; }).catch(() => caches.match('index.html'))));
});
`);
copy(path.join(A, 'icons'), path.join(web, 'icons'));
write(path.join(web, 'robots.txt'), 'User-agent: *\nAllow: /\n');

/* ---------- 2. bộ phát hành ---------- */
const kit = path.join(out, 'rust-journey-kit');
copy(web, path.join(kit, 'web'));
const cap = path.join(kit, 'android-capacitor');
copy(web, path.join(cap, 'www')); copy(path.join(A, 'capacitor'), path.join(cap, 'assets'));
write(path.join(cap, 'package.json'), JSON.stringify({
  name: 'rust-journey', version: VERSION, private: true,
  scripts: { 'android:add': 'cap add android', 'android:sync': 'cap sync android', 'android:open': 'cap open android', 'assets': 'capacitor-assets generate --android' },
  dependencies: { '@capacitor/android': 'latest', '@capacitor/cli': 'latest', '@capacitor/core': 'latest' }, devDependencies: { '@capacitor/assets': 'latest' },
}, null, 2) + '\n');
write(path.join(cap, 'capacitor.config.json'), JSON.stringify({ appId: 'vn.hanhtrinhrust.app', appName: 'Rust Journey', webDir: 'www', server: { androidScheme: 'https' }, backgroundColor: BG }, null, 2) + '\n');
write(path.join(cap, 'res-extra', 'values-vi', 'strings.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">Hành Trình Rust</string>\n    <string name="title_activity_main">Hành Trình Rust</string>\n</resources>\n');

const hasEN = fs.existsSync(path.join(root, 'src', 'lessons', 'en', 'z1.js'));
require('./release-docs').write(kit, VERSION, write, hasEN);
const st = path.join(kit, 'store'); mk(st);
['icon-512.png', 'feature-graphic-vi.png', 'feature-graphic-en.png'].forEach(f => copy(path.join(A, 'store', f), path.join(st, f)));
if (fs.existsSync(path.join(A, 'store', 'screenshots'))) copy(path.join(A, 'store', 'screenshots'), path.join(st, 'screenshots'));
const src = path.join(kit, 'source');
['src', 'tools', 'assets'].forEach(d => copy(path.join(root, d), path.join(src, d), { filter: p => !/screenshots/.test(p) }));
write(path.join(src, 'README.md'), '# Source\n\n```\nnode tools/build.js          # dist/index.html (bản xem thử / artifact)\nnode tools/test.js --full   # biên dịch mọi đoạn Rust bằng rustc thật và giải mọi thử thách\nnode tools/make-assets.js   # tạo lại biểu tượng, splash, ảnh cửa hàng (cần Playwright)\nnode tools/release.js       # tạo lại gói phát hành\n```\n\nThêm ngôn ngữ mới: xem `tools/TRANSLATING.md`.\n');

/* ---------- 3. nén ---------- */
const zip = (dir, name) => { const f = path.join(out, name); cp.execFileSync('zip', ['-r', '-q', '-X', f, '.'], { cwd: dir }); return f; };
const z1 = zip(web, `RustJourney-web-v${VERSION}.zip`), z2 = zip(kit, `RustJourney-release-kit-v${VERSION}.zip`);
[z1, z2].forEach(z => console.log(path.basename(z), (fs.statSync(z).size / 1024).toFixed(0) + ' KB'));
console.log('index.html', (html.length / 1024).toFixed(1), 'KB');
