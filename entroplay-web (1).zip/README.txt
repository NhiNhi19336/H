ENTROPLAY – gói web + khung Android (Capacitor)

CẤU TRÚC
  www/                 app web (chạy offline, không cần mạng)
  resources/           icon gốc (icon-only, foreground, background) cho Android
  icon-playstore-512.png  icon 512x512 để upload lên Google Play
  capacitor.config.json, package.json

THỬ TRÊN MÁY:  python3 -m http.server -d www 8080  → mở http://localhost:8080

XUẤT FILE .AAB (cách 1 – gói file vào app, offline hoàn toàn)
  1. Cài Node 20+, JDK 17+, Android Studio.
  2. npm install
  3. npm run android        (thêm nền tảng Android, tạo icon, đồng bộ www)
  4. npm run open           (mở Android Studio)
  5. Build > Generate Signed App Bundle / APK > Android App Bundle > tạo keystore
     (GIỮ KỸ file keystore và mật khẩu, mất là không cập nhật app được) > release.
  6. Upload file .aab lên Google Play Console. Mỗi lần cập nhật phải tăng versionCode
     trong android/app/build.gradle.

CÁCH 2 (không cần Android Studio): đưa thư mục www lên hosting HTTPS
  (GitHub Pages, Netlify...) rồi vào pwabuilder.com > Android > tải gói AAB.

LƯU Ý KHI LÊN PLAY
  - appId mặc định: com.entroplay.app (đổi trong capacitor.config.json nếu đã bị trùng).
  - Play yêu cầu trang chính sách quyền riêng tư. App không thu thập dữ liệu; tiến độ
    lưu trên máy (localStorage).
  - Cần thêm ảnh chụp màn hình và ảnh bìa 1024x500 khi tạo trang cửa hàng.

BẢN 1.1 – CÓ GÌ MỚI
  - Bộ giải đề dán: nhận bối cảnh (hãm phanh, quãng đường, chậm dần/nhanh dần đều... → cơ học chất điểm lớp 10 trước;
    khối lượng riêng, áp suất, đòn bẩy → THCS; công thức hiện đại chỉ khi đề nhắc lượng tử/tương đối/hạt nhân).
    Kết quả luôn đủ 7 bước: Đề cho, Cần tìm, Công thức, Thay số, Kết quả (3 c.s.n.), Kiểm tra (kiểm tra chéo), Mẹo.
  - 11 sandbox mới trong tab Lab (va chạm, con lắc, lò xo, lực đẩy, thấu kính, điện trường, giao thoa, khí, phóng xạ,
    thắp bóng đèn, mô hình 3D/AR). Âm thanh có nút tắt/bật và nhớ lựa chọn.
  - Thư viện mở rộng: 367 công thức và 147 khái niệm từ lớp 6 đến đại học (song ngữ).
  - Tab Mẹo (54 mẹo song ngữ), Level, chuỗi ngày, sao lưu mã gồm cả kho công thức.
  - Font Be Vietnam Pro đóng gói sẵn trong www/fonts: không còn gọi Google Fonts, chạy offline thật.

ANDROID: dùng camera cho chế độ AR cần thêm dòng sau vào android/app/src/main/AndroidManifest.xml (sau khi chạy npm run android):
  <uses-permission android:name="android.permission.CAMERA" />
  Cảm biến xoay/nghiêng không cần quyền. Nếu không thêm quyền camera, các phần khác vẫn chạy bình thường.
