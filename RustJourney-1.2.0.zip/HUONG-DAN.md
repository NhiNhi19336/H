# Hành Trình Rust 1.2.0 – hướng dẫn cập nhật bản thử nghiệm

Trong gói này:

| Thư mục / file | Dùng để làm gì |
|---|---|
| `www/` | Toàn bộ app (đã sửa). Thay cho thư mục `www` trong dự án. |
| `android-res/` | Icon app + màn hình chờ. Chép đè vào `android/app/src/main/res/`. |
| `capacitor.config.json` | Thêm màu nền tối cho lúc mở app (đỡ chớp trắng). |
| `store/play-store-icon-512.png` | Icon cho trang CH Play (tải lên Play Console). |
| `GHI-CHU-PHAT-HANH.txt` | Ghi chú phát hành để dán vào Play Console. |

## Các bước (làm trên máy có dự án)

**0. Sao lưu** cả thư mục dự án trước khi làm.

**1. Thay app web**
Xóa thư mục `www` cũ trong dự án, chép thư mục `www` trong gói này vào đúng chỗ đó.

**2. Cập nhật cấu hình Capacitor**
Chép đè `capacitor.config.json` (chỉ thêm dòng `"backgroundColor"`, các dòng khác giữ nguyên như cũ).

**3. Cài plugin cho nút Back** (bắt buộc, không có thì nút Back vẫn thoát app)
```
npm install @capacitor/app
npx cap sync android
```
Nếu báo lỗi lệch phiên bản: mở `package.json`, coi `@capacitor/core` đang là bản mấy (ví dụ `^7.x`), rồi cài cùng bản đó: `npm install @capacitor/app@7`, sau đó chạy lại `npx cap sync android`.

**4. Thay icon và màn hình chờ**
Chép **toàn bộ** các thư mục bên trong `android-res/` vào `android/app/src/main/res/`, chọn **ghi đè** khi được hỏi.
(Gồm `mipmap-*` cho icon, `mipmap-anydpi-v26` cho icon thích ứng + icon một màu Android 13, `drawable*` cho màn hình chờ, `values/ic_launcher_background.xml`.)

Tùy chọn cho Android 12 trở lên (màn hình chờ nền tối cho đồng bộ): mở `android/app/src/main/res/values/styles.xml`, trong khối `<style name="AppTheme.NoActionBarLaunch" ...>` thêm một dòng:
```xml
<item name="windowSplashScreenBackground">#1B271F</item>
```

**5. Tăng số phiên bản**
Mở `android/app/build.gradle`, trong `defaultConfig` sửa:
```
versionCode 8
versionName "1.2.0"
```

**6. Build file .aab**
Android Studio → Build → Generate Signed App Bundle / APK → Android App Bundle → chọn **đúng file khóa (keystore) cũ** đã dùng cho bản 7 → release.

**7. Tải lên Play Console**
- Testing → **Closed testing** → đúng track đang chạy → Create new release → tải file `.aab` mới → dán ghi chú phát hành → Save → Review → Start rollout.
- Icon trên trang CH Play: Grow users → Store presence → Main store listing → App icon → tải `store/play-store-icon-512.png`.

Người thử mở CH Play cập nhật app là thấy bản mới. Đợt test 14 ngày vẫn đếm tiếp, không bị reset.

## Kiểm tra nhanh sau khi cài bản mới
- Icon ngoài màn hình là lục giác cam, không còn chữ X xanh.
- Mở app lần đầu: màn hình chờ nền xanh rêu → intro mới, có giọng "Hành Trình Rust" (cả khi chọn tiếng Anh). Mở lại trong cùng ngày thì vào thẳng, không phát intro; qua ngày mới mới phát lại.
- Vào một bài, bấm nút Back của điện thoại → quay về bản đồ. Bấm Back lần nữa ở bản đồ → thoát app.
- Bấm nút, chạy robot, trả lời đúng/sai → có tiếng rõ ràng; có nhạc nền nhẹ (tắt được trong Cài đặt → Nhạc nền).
