/**
 * VertexNode 3D - AI proxy (Cloudflare Worker)
 *
 * App gửi:   POST { "messages": [ {role:"user"|"assistant", content:"..."} ] }
 * Worker trả: { "choices":[ { "message": { "role":"assistant", "content":"..." } } ], "provider":"groq" }
 *        lỗi: { "error": { "message": "..." } }
 *
 * Chọn nhà cung cấp bằng biến PROVIDER (có thể liệt kê nhiều, ngăn cách bằng dấu phẩy;
 * lỗi hoặc hết quota ở cái đầu thì tự thử cái sau):
 *   workers-ai  -> Cloudflare Workers AI   (không cần API key, chỉ cần binding "AI")
 *   groq        -> Groq (Llama 3 / Qwen)   (secret GROQ_API_KEY)
 *   gemini      -> Google Gemini API       (secret GEMINI_API_KEY)
 *
 * Ví dụ: PROVIDER = "groq,gemini,workers-ai"
 *
 * Tuỳ chọn đổi model bằng biến (không bắt buộc):
 *   WORKERS_AI_MODEL, GROQ_MODEL, GEMINI_MODEL
 */

const DEFAULT_MODELS = {
  "workers-ai": "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
  groq: "llama-3.3-70b-versatile", // nhanh hơn: "llama-3.1-8b-instant"; Qwen: "qwen3-32b"
  gemini: "gemini-flash-lite-latest",
};

const LIMITS = {
  maxMessages: 24,
  maxCharsPerMessage: 6000,
  maxCharsTotal: 20000,
  maxOutputTokens: 1200,
  temperature: 0.3,
  timeoutMs: 25000,
  perIpPerMinute: 20, // giới hạn "best effort" trong bộ nhớ của Worker
};

const SYSTEM_PROMPT = [
  "You are a friendly, accurate tutor for maths and geometry (especially 3D geometry) inside the VertexNode 3D learning app.",
  "Reply in the same language as the student's last message (Vietnamese or English).",
  "Solve step by step, double-check the arithmetic, and say clearly if you are unsure. Keep answers short and clear.",
  "Only discuss maths and geometry; politely decline anything else.",
  "Output plain text only: you may use **bold** for key results, but no markdown headings, tables, code fences or LaTeX. Write formulas in plain text like a², √3, V = a³.",
  "If the student asks you to return a single JSON object, return ONLY that JSON, with no other words and no code fences.",
].join("\n");

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400",
};

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...CORS },
  });

const fail = (message, status = 400) => json({ error: { message } }, status);

/* ---------- giới hạn tốc độ (best effort, theo IP) ---------- */
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) for (const k of hits.keys()) { hits.delete(k); if (hits.size < 2500) break; }
  return arr.length > LIMITS.perIpPerMinute;
}

/* ---------- kiểm tra dữ liệu app gửi lên ---------- */
function cleanMessages(body) {
  const list = body && Array.isArray(body.messages) ? body.messages : null;
  if (!list || !list.length) return { error: "messages is required" };
  if (list.length > LIMITS.maxMessages) return { error: "Too many messages" };
  let total = 0;
  const out = [];
  for (const m of list) {
    if (!m || typeof m.content !== "string") return { error: "Invalid message" };
    // app chỉ được gửi user/assistant; system prompt do Worker giữ
    const role = m.role === "assistant" ? "assistant" : "user";
    const content = m.content.slice(0, LIMITS.maxCharsPerMessage);
    total += content.length;
    out.push({ role, content });
  }
  if (total > LIMITS.maxCharsTotal) return { error: "Message too long" };
  if (out[out.length - 1].role !== "user") return { error: "Last message must be from user" };
  return { messages: out };
}

const stripThink = (t) => String(t).replace(/<think>[\s\S]*?<\/think>/gi, "").trim();

async function fetchJson(url, init) {
  const ctl = new AbortController();
  const tm = setTimeout(() => ctl.abort(), LIMITS.timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ctl.signal });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = (data.error && (data.error.message || data.error)) || `HTTP ${res.status}`;
      throw new Error(String(msg).slice(0, 200));
    }
    return data;
  } finally {
    clearTimeout(tm);
  }
}

/* ---------- 1) Cloudflare Workers AI ---------- */
async function runWorkersAI(env, messages) {
  if (!env.AI) throw new Error("Chưa gắn binding AI (Workers AI)");
  const model = env.WORKERS_AI_MODEL || DEFAULT_MODELS["workers-ai"];
  const r = await env.AI.run(model, {
    messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
    max_tokens: LIMITS.maxOutputTokens,
    temperature: LIMITS.temperature,
  });
  const text =
    (r && typeof r.response === "string" && r.response) ||
    (r && r.choices && r.choices[0] && r.choices[0].message && r.choices[0].message.content) ||
    (r && r.result && r.result.response) ||
    "";
  return text;
}

/* ---------- 2) Groq (Llama 3 / Qwen) ---------- */
async function runGroq(env, messages) {
  if (!env.GROQ_API_KEY) throw new Error("Thiếu GROQ_API_KEY");
  const d = await fetchJson("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.GROQ_API_KEY },
    body: JSON.stringify({
      model: env.GROQ_MODEL || DEFAULT_MODELS.groq,
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
      max_tokens: LIMITS.maxOutputTokens,
      temperature: LIMITS.temperature,
    }),
  });
  return (d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || "";
}

/* ---------- 3) Google Gemini API ---------- */
async function runGemini(env, messages) {
  if (!env.GEMINI_API_KEY) throw new Error("Thiếu GEMINI_API_KEY");
  const model = env.GEMINI_MODEL || DEFAULT_MODELS.gemini;
  // Gemini dùng role "model" và muốn các lượt xen kẽ -> gộp các lượt liền nhau cùng role
  const contents = [];
  for (const m of messages) {
    const role = m.role === "assistant" ? "model" : "user";
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += "\n\n" + m.content;
    else contents.push({ role, parts: [{ text: m.content }] });
  }
  const d = await fetchJson(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { temperature: LIMITS.temperature, maxOutputTokens: LIMITS.maxOutputTokens * 2 },
      }),
    }
  );
  const parts = d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts;
  return parts ? parts.map((p) => p.text || "").join("") : "";
}

const RUNNERS = { "workers-ai": runWorkersAI, groq: runGroq, gemini: runGemini };

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    const chain = String(env.PROVIDER || "workers-ai")
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter((s) => RUNNERS[s]);

    if (request.method === "GET") {
      // kiểm tra nhanh worker còn sống (không lộ key)
      return json({ ok: true, providers: chain });
    }
    if (request.method !== "POST") return fail("Method not allowed", 405);

    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    if (rateLimited(ip)) return fail("Bạn hỏi nhanh quá, đợi một chút rồi thử lại nhé.", 429);

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return fail("Invalid JSON");
    }
    const v = cleanMessages(body);
    if (v.error) return fail(v.error);
    if (!chain.length) return fail("PROVIDER chưa được cấu hình đúng", 500);

    const errors = [];
    for (const name of chain) {
      try {
        const text = stripThink(await RUNNERS[name](env, v.messages));
        if (text) {
          return json({ choices: [{ message: { role: "assistant", content: text } }], provider: name });
        }
        errors.push(name + ": empty");
      } catch (e) {
        errors.push(name + ": " + String((e && e.message) || e).slice(0, 120));
      }
    }
    return fail("AI chưa trả lời được (" + errors.join(" | ") + ")", 502);
  },
};
