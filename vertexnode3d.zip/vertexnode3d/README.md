# VertexNode 3D – gói để đưa lên app (AAB)

```
www/       Web app (index.html, manifest.json, sw.js, icons) – chạy offline như PWA
worker/    Worker AI cho khung chat (Workers AI / Groq / Gemini)
assets/    Icon + splash gốc 1024px để sinh icon Android
capacitor.config.json, package.json   Cấu hình đóng gói Android bằng Capacitor
```

---

## 1. Gắn AI cho khung chat (làm 1 lần)

App **không chứa API key**. App gọi Worker, Worker gọi AI. `WORKER_URL` trong `www/index.html` đang trỏ tới
`https://dark-breeze-9e59.bentobeto19.workers.dev` – chỉ cần dán code mới vào đúng Worker đó là xong, không phải sửa app.

**Dán code:** Cloudflare Dashboard → Workers & Pages → worker `dark-breeze-9e59` → Edit code → xoá code cũ, dán toàn bộ `worker/worker.js` → Deploy.

Chọn **1** trong 3 (biến `PROVIDER`, vào Settings → Variables and Secrets):

| Muốn dùng | PROVIDER | Cần làm thêm |
|---|---|---|
| **Cloudflare Workers AI** (dễ nhất, không cần key) | `workers-ai` | Settings → Bindings → Add → **Workers AI**, đặt tên biến là `AI` |
| **Groq** (Llama 3 / Qwen, rất nhanh) | `groq` | Lấy key ở console.groq.com/keys → thêm **Secret** `GROQ_API_KEY`. Đổi model: biến `GROQ_MODEL` = `qwen3-32b` hoặc `llama-3.1-8b-instant` |
| **Google Gemini** (free tier) | `gemini` | Lấy key ở aistudio.google.com/apikey → thêm **Secret** `GEMINI_API_KEY`. Đổi model: biến `GEMINI_MODEL` |

**Ghép nhiều cái cho chắc:** `PROVIDER` = `groq,gemini,workers-ai` → cái đầu lỗi / hết quota thì tự chuyển sang cái sau.

**Kiểm tra:** mở URL Worker bằng trình duyệt, thấy `{"ok":true,"providers":[...]}` là sống.

Dùng dòng lệnh thay cho dashboard (tuỳ chọn): `cd worker` rồi `npx wrangler deploy`, và `npx wrangler secret put GROQ_API_KEY`.

Ghi chú:
- Free tier có giới hạn số lượt/ngày; Worker có chặn spam cơ bản (20 lượt/phút/IP).
- Gemini bản free: Google có thể dùng nội dung gửi lên để cải thiện sản phẩm. App đã nhắc "đừng nhập thông tin cá nhân", và chế độ 5–10 tuổi **không** có nút AI.
- Tên model free có thể đổi theo thời gian; nếu một model bị gỡ, chỉ cần đổi biến `*_MODEL`.

## 2. Chạy thử trên máy

```
cd vertexnode3d
npx serve www
```
Mở địa chỉ hiện ra (trên điện thoại cùng Wi-Fi cũng được).

## 3. Ra file AAB (Windows 10)

Cài trước: **Node.js LTS** và **Android Studio** (đã kèm JDK).

*(Tuỳ chọn)* đổi `appId` trong `capacitor.config.json` thành tên gói của bạn (vd `com.tenban.vertexnode3d`) **trước** bước `cap add`. Tên này gắn cố định với app trên Google Play.

Mở CMD trong thư mục `vertexnode3d`:

```
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/assets
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
npx cap open android
```

Trong Android Studio (lần đầu đợi Gradle sync xong; nếu nó đề nghị cập nhật thì cứ cập nhật):

1. **Build → Generate Signed App Bundle / APK → Android App Bundle → Next**
2. **Create new…** để tạo keystore (lưu file + mật khẩu thật kỹ, mất là không cập nhật app được)
3. Chọn **release → Finish**
4. File ra ở `android\app\release\app-release.aab` → upload lên Google Play Console

Cập nhật app sau này: sửa file trong `www/` → `npx cap sync android` → tăng `versionCode` trong `android\app\build.gradle` → build lại.

### Cách khác: PWABuilder (không cần Android Studio)
Đưa thư mục `www` lên hosting HTTPS (vd Cloudflare Pages: `npx wrangler pages deploy www --project-name vertexnode3d`), rồi vào pwabuilder.com, dán URL → Package for stores → Android → tải AAB.
